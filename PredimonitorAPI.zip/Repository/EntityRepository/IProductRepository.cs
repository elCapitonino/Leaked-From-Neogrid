using Repository.Entity.Databricks;
using Repository.EntityRepository.Bases;

namespace Repository.EntityRepository;

public interface IProductRepository : IGenericDatabricksRepository<ProductEntity>
{
}
