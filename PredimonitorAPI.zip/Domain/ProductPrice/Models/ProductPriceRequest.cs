namespace Domain.ProductPrice.Models;

public class ProductPriceRequest
{
}