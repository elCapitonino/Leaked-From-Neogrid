﻿using Domain.BackgroundTasks;
using Domain.IndexGenerator.DataSourceDomains;
using Domain.IndexGenerator.DataSourceDomains.Interfaces;
using Domain.IndexGenerator.Models;
using Domain.Models;
using Domain.Status;
using DomainTests.Extensions;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.DependencyInjection;
using MongoDB.Driver;
using Moq;
using Moq.Protected;
using Repository.DbContexts;
using Repository.Entity;
using Repository.UnitOfWork;
using Services.SearchAPI;
using System.Net;
using System.Text;

namespace DomainTests.IndexGenerator.DataSourceDomains
{
    [TestClass()]
    public class IndexGeneratorPredifyDomainTests
    {
        private ServiceProvider _serviceProvider;
        private Mock<HttpMessageHandler> _handler;

        [TestInitialize]
        public void Initialize()
        {
            var services = new ServiceCollection();
            var mongo = new Mock<MongoClient>().Object;

            services.AddTransient<IMongoClient>(provider => mongo);
            services.SetAutoMapper();

            services.AddDbContext<ApplicationDbContext>(options => options.UseSqlite("Filename=:memory:").ConfigureWarnings(opt => opt.Ignore(RelationalEventId.AmbientTransactionWarning)));

            services.AddDbContext<HorusDbContext>(options => options.UseMongoDB(mongo, "Horus").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            services.AddDbContext<InfoPriceSaoJoaoDbContext>(options => options.UseMongoDB(mongo, "InfroPriceSaoJoao").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            services.AddDbContext<NormalizerDbContext>(options => options.UseMongoDB(mongo, "Normalizer").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            services.AddDbContext<LinxDbContext>(options => options.UseMongoDB(mongo, "Linx").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            services.AddDbContext<NeogridDbContext>(options => options.UseMongoDB(mongo, "Neogrid").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            services.AddDbContext<NielsenDbContext>(options => options.UseMongoDB(mongo, "Nielsen").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            services.AddDbContext<SmarketCompetitorDbContext>(options => options.UseMongoDB(mongo, "SmarketCompetitor").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            services.AddDbContext<OfflineDbContext>(options => options.UseMongoDB(mongo, "Offline").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            services.AddDbContext<ScantechSupermaxiDbContext>(options => options.UseMongoDB(mongo, "Scantech").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);

            services.AddTransient(provider => new DatabricsDbContext("", ""));


            services.Configure<AppsettingsOptions>(AppsettingsOptions =>
            {
                AppsettingsOptions.IndexConfiguration.PeriodyInMonthToIndexing = 6;
            });

            services.AddScoped<IIndexGeneratorPredifyDomain, IndexGeneratorPredifyDomain>();
            services.AddSingleton<IBackgroundTaskQueue, BackgroundTaskQueue>();
            services.AddHostedService<QueuedService>();

            services.AddScoped<IStatusDomain, StatusDomain>();
            services.AddMemoryCache();


           

            _handler = new Mock<HttpMessageHandler>();
           


            services.AddHttpClient<ISearchAPIService, SearchAPIService>((service, client) => { client.BaseAddress = new Uri("http://yourapi.com"); })
                .ConfigurePrimaryHttpMessageHandler(() => _handler.Object);


            services.AddScoped<IUnitOfWork, UnitOfWork>();
            services.AddLogging();
            _serviceProvider = services.BuildServiceProvider();

            var context = _serviceProvider.GetRequiredService<ApplicationDbContext>();
            context.Database.OpenConnection();
            context.Database.EnsureCreated();
        }

        [TestMethod()]
        public async Task GenerateIndexAsyncTest()
        {
            var mockv4SearchResponseContent = File.ReadAllText("IndexGenerator/Assets/SearchAPIResponse.json");
            var mockv4SearchResponse = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                Content = new StringContent(mockv4SearchResponseContent, Encoding.UTF8, "application/json")
            };
            _handler.Protected()
               .Setup<Task<HttpResponseMessage>>(
                   "SendAsync",
                   ItExpr.Is<HttpRequestMessage>(req => req.RequestUri.AbsolutePath.EndsWith("v4/search")),
                   ItExpr.IsAny<CancellationToken>())
               .ReturnsAsync(mockv4SearchResponse);

            var domain = _serviceProvider.GetRequiredService<IIndexGeneratorPredifyDomain>();

            var uow = _serviceProvider.GetRequiredService<IUnitOfWork>();
            uow.CompanyMonitoringCrawler.Create(new CompanyMonitoringCrawlerEntity()
            {
                CompanyId = 3026,
                IsDeleted = false,
                MonitoringCrawler = new MonitoringCrawlerEntity()
                {
                    IsDeleted = false,
                    Description = "Teste",
                    CompanyMonitorings = new List<CompanyMonitoringCrawlerEntity>()
                    {
                        new CompanyMonitoringCrawlerEntity()
                        {
                            IsDeleted = false,
                        }
                    },
                    Source = Repository.Enums.CrawlerSourceType.Predify,
                },
            });

            uow.MonitoringItem.Create(new MonitoringItemEntity()
            {
                Id = 269393,
                Description = "Água de coco",
            });

            uow.Company.Create(new CompanyEntity()
            {
                Id = 3026,
                Company = "Teste"
            });

            uow.MonitoringCrawler.AddRange(new[]{new MonitoringCrawlerEntity()
                {
                    Id = 163,
                    Description = "Teste",
                    Source = Repository.Enums.CrawlerSourceType.Predify
                },
                new MonitoringCrawlerEntity()
                {
                    Id = 148,
                    Description = "Teste",
                }
            });

            var count = uow.MonitoringItemResults.GetAll().Count();

            await domain.GenerateIndexAsync( companyId: 3026,crawlerId: new[] { 1, 2, 3 },monitoringItems: new[] { new MonitoringItemTags() {
                Eans = new[] { "7894900011517" },
                MonitoringItemId = 1,
                Tags = new[] { "teste" },
                RequiredWords = "teste",
                RestrictedWords = "teste"
            } }, startDate: DateTime.Today.AddDays(-7),endDate: DateTime.Today, taskId: null, listIdsDelete: new List<long>());

            Assert.AreEqual(5, uow.MonitoringItemResults.GetAll().Count(), "Deve ter 5 registros na tabela de resultados de monitoramento");

        }
    }
}