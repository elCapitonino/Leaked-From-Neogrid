﻿using Domain.IndexGenerator.Models;

namespace Domain.IndexGenerator.DataSourceDomains.Interfaces
{
    public interface IIndexGeneratorPredifyDomain
    {
        Task GenerateIndexAsync(long companyId, IEnumerable<int> crawlerId, IEnumerable<MonitoringItemTags> monitoringItems, DateTime startDate, DateTime endDate, Guid? taskId, List<long> listIdsDelete);
        Task GenerateIndexForCrawlersAsync(long companyId, IEnumerable<MonitoringItemTags> monitoringItems, Guid? crawlerTaskId);
    }
}
