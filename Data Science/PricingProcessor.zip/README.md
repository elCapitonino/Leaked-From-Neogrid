# PricingProcessor

API para processar dados das tabelas `Enterprise_Sales_History` e `Enterprise_Prices_Projection` armazenadas no SQL Server, gerar métricas contábeis agregadas por mês ou agregadas pelo período entre uma precificação e outra relacionadas aos _grupos de precificação_ e salvá-las no PostgreSQL. Esse processo gera os dados necessários para exibir gráficos de impacto na tela Home (projeções) bem como para gerar os relatórios de impacto bruto e consolidado.

## Como rodar

Após criar um ambiente virtual e ativá-lo, instale as dependências:

```bash
python -m pip install -r requirements.txt
```

Cria um arquivo `.env.local` na raiz do repositório preenchendo _todas_ as variáveis de ambiente especificadas no arquivo `.env`.

Para rodar em modo debug:

```bash
export DEBUG=1
export PYTHONPATH=.
fastapi dev app/main.py
```

**Importante**: ao rodar em modo debug, um cache local dos metadados dos bancos de dados será salvo. **Se houver mudanças no _schema_ dos bancos de dados é necessário excluir esses arquivos**. Basta excluir o diretório `./cache`. Isso é feito porque o processo de reflexão de metadados é demorado e atrapalha o desenvolvimento, no qual reiniciamos a API muitas vezes.

Rodar com Docker:

```bash
docker compose up
```

Para forçar um _rebuild_ da imagem, se necessário:

```bash
docker compose up --build --force-recreate --no-deps
```

Para rodar com Docker em modo _debug_, basta apontar para o arquivo YAML de desenvolvimento:

```bash
docker compose -f docker-compose-dev.yml up
```

## Funcionamento

### Diagrama

![diagrama](/docs/diagram_pricing_processor.png)

### Endpoints

#### `/health` (GET)

Retorna apenas "OK". Usado para testar saúde da aplicação.

#### `/calculate_projection_metrics/{id_company}/date_range` (POST)

Calcula métricas de projeção para todas as projeções entre as datas fornecidas. Isso inclui tanto dados para o relatório bruto quando para gráficos e relatório consolidado (dados mensais). Recebe uma faixa de datas como parâmetros. Exemplo de requisição (local):

```bash
curl -X 'POST' \
  'http://localhost:8081/calculate_projection_metrics/3026/date_range?initial_date=2024-01-01&final_date=2024-01-22' \
  -H 'accept: application/json' \
  -d ''
```

Retorna um JSON com o seguinte formato:

```json
{
  "id_company": 3026,
  "date_task_id": "d84b873b-64bc-47cc-a277-903d784455b6",
  "pg_task_ids": [
    "8f81d36c-cd61-480f-b280-63811a4ff737",
    "3f625cc3-04b3-4660-a273-3fd1a5322e08",
    "7fb34523-35ff-4cf1-a6c2-fa63a6b1163f",
    "95306432-fa75-4c79-95dc-d0643285ed00",
    "5bc0327c-5cd4-4f1d-9777-aee1476229cb",
    "8f51213e-0515-44b3-accf-8b076c2e6fb1",
    "d4763f86-f1a3-425e-ba7e-4980888f6058",
    "5297765d-0f5b-4ab2-a279-84b6b9c44687",
    "793c388a-32cb-4795-9993-8058f233ea4b",
    "c8a9fc21-0922-4d74-9a00-d70958fb4b3a",
    "f50d6e38-6165-4de7-8e38-9acbc65f2bcb"
  ]
}
```

Há dois tipos de IDs únicos (UUID v4) de tarefas na resposta:

- _date\_task\_id_: ID da tarefa de processamento dos dados mensais para relatório consolidado e gráficos.
- _pg\_task\_ids_: lista de IDs das tarefas de processamentos dos dados de cada precificação afetada pelo período, para o relatório bruto.

Note que o _endpoint_ recebe datas como parâmetros, mas inicia tarefas de importação baseada em datas (para consolidado e gráficos) e importações de grupos de precificação (para relatório bruto). Ou seja, as faixas de data fornecidas ao _endpoint_ são parâmetros para se buscar (1) quais meses foram afetados e (2) quais precificações estão relacionadas ao período.

As tarefas de importação ocorrem de forma assíncrone em uma _BackgroundTask_.

#### `/calculate_projection_metrics/{id_company}/price_group` (POST)

Calcula métricas de projeção para a precificação especificada e para a anterior. Como mencionado acima, esse _endpoint_ também inicia tarefas de importação baseadas em datas (para consolidado e gráficos) bem como importações de grupos de precificação (para relatório bruto). Ou seja, ambos os _endpoints_ calculam dados brutos e mensais, o que muda são os parâmetros de entrada: uma faixa de datas no _endpoint_ anterior, um ID de grupo de precificação nesse. Além disso, apenas neste _endpoint_ registram-se todos os preços sugeridos para que seja possível, posteriormente, encontrar precificações anteriores e posteriores **por projeção**.

Recebe o ID do grupo de precificação como parâmetro. Exemplo de requisição (local):

```bash
curl -X 'POST' \
  'http://localhost:8081/calculate_projection_metrics/3026/price_group?id_price_group=19585' \
  -H 'accept: application/json' \
  -d ''
```

Retorna um JSON com o seguinte formato:

```json
{
  "id_company": 3026,
  "date_task_id": "08e17ad6-7939-455f-b3f6-205f36d54bd3",
  "pg_task_ids": [
    "bf99e126-cfa4-4be9-a833-c5532979196d",
    "9e401610-f12a-4d94-94b7-fb0b55a08757"
  ]
}
```

Note que é o mesmo formato de retorno do _endpoint_ anterior.

#### `/get_price_group_task_status` (GET)

Retorna o _status_ de uma importação _de grupo de precificação_ a partir de seu ID único. Ou seja, funciona **apenas para os IDs retornados em `pg_task_ids`**. O ID único deve ser fornecido como um parâmetro e não no _body_. Exemplo de requisição (local):

```bash
curl -X 'GET' \
  'http://localhost:8081/get_price_group_task_status?import_id=bf99e126-cfa4-4be9-a833-c5532979196d' \
  -H 'accept: application/json'
```

Retorna um JSON com o seguinte formato:

```json
{
  "id_company": 3026,
  "status": "success",
  "price_group_id": 19585,
  "last_change": "2024-07-04T18:27:18.007671+00:00"
}
```

Hoje os seguintes valores de _status_ são possíveis: running, success, failed, interrupted.

Uma tarefa bem sucedida passa pela seguinte sequência: running > success.

Em ambos os casos, é possível que uma falha aconteça a qualquer momento, alterando o _status_ para failed. O estado interrupted acontece quando o processo ou a _thread_ responsáveis pelo cálculo são interrompidos pelo próprio servidor ASGI (uvicorn) ou pelo sistema operacional antes de atingir o final (success). **Importante**: o sistema operacional pode interromper o processo de forma abrupta ou até mesmo pausar o processo sem interrompê-lo por tempo indeterminado; nesses casos, o _status_ **não será atualizado para interrupted**. Ou seja, é possível ter tarefas permanentemente em _running_.

Além disso, a conexão com o banco de dados (PostgreSQL) pode falhar a qualquer momento, então o _status_ no banco deve ser considerado apenas um _indicativo_ do estado real da importação. Ainda assim, marcações de success, failed, empty ou interrupted indicam que com certeza a importação foi finalizada.

A sincronização entre o estado das importações e o banco de dados é feita por meio de [_context managers_](https://docs.python.org/3/library/contextlib.html#contextlib.contextmanager). Dessa forma, com exceção da marcação empty, o código da aplicação é separado do gerenciamento de estado, o qual ocorre utilizando a sintaxe `with ...:` do Python.

Significado dos valores retornados:

- _id\_company_: ID da empresa da tarefa
- _status_: _status_ da importação
- _price\_group\_id_: ID do grupo de precificação ao qual a tarefa se refere
- _last\_change_: data-hora (UTC) da última mudança de _status_ da tarefa

#### `/get_date_range_task_status` (GET)

Retorna o _status_ de uma importação _de faixa de data_ a partir de seu ID único. Ou seja, funciona **apenas para os IDs retornados em `date_task_id`**. O ID único deve ser fornecido como um parâmetro e não no _body_. Exemplo de requisição (local):

```bash
curl -X 'GET' \
  'http://localhost:8081/get_date_range_task_status?import_id=08e17ad6-7939-455f-b3f6-205f36d54bd3' \
  -H 'accept: application/json'
```

Retorna um JSON com o seguinte formato:

```json
{
  "id_company": 3026,
  "status": "success",
  "start_date_request": "2024-01-01T00:00:00+00:00",
  "end_date_request": "2024-01-31T00:00:00+00:00",
  "last_change": "2024-07-04T18:25:13.869603+00:00"
}
```

A lógica do _status_ é a mesma do _endpoint_ anterior, conforme explicada acima.

Significado dos valores retornados:

- _id\_company_: ID da empresa da tarefa
- _status_: _status_ da importação
- _start\_date\_request_: data inicial do período incluído na tarefa (inclusivo)
- _end\_date\_request_: data final do período incluído na tarefa (inclusivo)
- _last\_change_: data-hora (UTC) da última mudança de _status_ da tarefa

### Granularidade

A granularidade é armazenada no PostgreSQL em duas tabelas: `GranularityGroup` e `GranularityLevel`. A primeira armazena os grupos de granularidade por tipo e ID de empresa. Já a segunda armazena quais colunas são usadas em cada grupo de granularidade e em que ordem, por meio de uma hierarquia com a coluna `ParentId`. A aplicação usa uma consulta recursiva para buscar as colunas de um grupo de granularidade na ordem correta.

A primeira coluna da granularidade também é chamada de `MajorGranularity` e é usada em alguns agrupamentos, conforme descrito abaixo.

### Tarefa de importação por datas

Todos os grupos de precificação aprovados entre as datas fornecidas são considerados. Além disso, buscamos a última precificação antes do início do período considerado, com um limite de 3 meses. Essa busca é feita por granularidade, isto é, pegamos a precificação mais recente para cada valor de granularidade até 3 meses antes do período analisado, se houver.

A última precificação por granularidade é usada para preencher o início do mês com uma projeção, com um limite de 3 meses para a idade máxima da precificação. Eliminamos as projeções cujos preços são repetições de preços que já foram sugeridos para aquela granularidade no período ou na última precificação anterior. Em seguida, medimos a adoção com os seguintes critérios para cada granularidade:

- Se o preço praticado de _pelo menos um dia_ apresentar menos de 1% da sugestão de preço _mais recente_, houve adoção.
- Se o preço praticado de _pelo menos um dia_ for igual (centavos) a algum preço sugerido no período ou na última precificação anterior ao período, houve adoção.

Nesse processo de buscar adoções também geramos um DataFrame ordenado em que temos as mudanças de projeção vigente para cada granularidade. Digamos que a precificação mais recente chama-se 2. Há uma linha indicando que a projeção da precificação 2 (abreviada aqui como projeção 2) é a vigente, pois é a mais recente. Após alguns dias, há uma adoção do preço da precificação 1. Adiciona-se uma nova linha indicando a mudança para a projeção 1, a qual passa a ser vigente até que outra adoção aconteça ou até que uma nova precificação seja aprovada.

Esse é o formato de dados comum usado a partir desse ponto, gerado pela função _calculate\_adoption_ do módulo _projections_. Consideramos todas as projeções para fins de contagem de sugestões de preço, inclusive as reprovadas pelas regras. Mas gerados projeções contábeis (demanda, receita e lucro) e, portanto, avaliação de impacto **apenas para sugestões de preço aprovadas pelas regras ou preços manuais aprovados**.

As projeções de demanda, receita e lucro são calculadas seguindo a lógica descrita de projeção vigente, para cada dia do mês, e são somadas ao final. Note que mesmo assim pode haver um hiato sem projeção para uma granularidade no início do mês. Nesse caso, usamos um fator de correção para que as projeções sejam estendidas até o número de dias do mês (exemplo: há projeção para 15 dos 30 dias, multiplicamos as projeções por 2).

#### Agrupamento e geração de dados de impacto

Após gerar as projeções mensais na mesma granularidade da projeção (grupo de precificação), combinamos dados da tabela `MonthlyProjectionData` (projeções geradas na etapa anterior) e da tabela `MonthlySaleHistoryData` (dados agregados por mês do histórico de vendas gerados pela API _MonthlySaleHistoryProcessor_) por meio do ano-mês e do `ProductId`.

Esses dados são agrupados pela primeira coluna da granularidade (`MajorGranularity`) e pela coluna `ConsolidateGroupBy`, a qual é salva como configuração na tabela `ImpactReportConfiguration`. Após agrupá-los, são inseridos na tabela `MonthlyImpactData`, a qual é usada para alimentar gráficos e a geração do relatório consolidado mensal.

### Tarefa de importação de dados brutos

Há duas partes relevantes dentro dessa tarefa: manter a tabela `ProductLaterPeriod` atualizada e gerar os dados brutos para o relatório bruto de impacto.

#### Gerenciamento da tabela `ProductLaterPeriod`

Essa tabela registra todas as sugestões de preço (aprovadas ou não) de grupos de precificação aprovados (publicados). A finalidade é manter um registro conveniente de qual a próxima sugestão de preço por valor de granularidade, bem como uma coluna para filtrar as últimas sugestões.

Quando uma precificação é publicada, primeiro buscamos as precificações anteriores para _cada sugestão de preço_ por meio da coluna `Found` da tabela `ProductLaterPeriod`. Depois, inserimos os valores de granularidade (`ProductId`) da precificação nova na tabela `ProductLaterPeriod` sem apontar para nenhuma precificação seguinte, pois nesse momento trata-se da última precificação aprovada.

Em seguida, geramos os dados brutos para essa precificação. Para cada grupo de precificação anterior encontrado no passo anterior, atualizamos a tabela `ProductLaterPeriod` para registrar a nova sugestão de preço como a sugestão seguinte à do grupo de precificação em questão. Por fim, geramos novamente os dados brutos para cada um desses grupos.

A integridade dos dados desse processo **depende da ordem de processamento das precificações**. Assim, com essa arquitetura **não é possível ter concorrência para uma mesma empresa**. Por isso adotamos semáforos por ID de empresa na API, mas **isso funciona apenas enquanto houver uma única instância da API com um único _worker_**. Caso seja necessário escalar horizontalmente, será necessário mudar a arquitetura do sistema para evitar problemas de concorrência.

#### Importação dos dados brutos

Também consideramos apenas grupos de precificação publicados. Os dados brutos são gerados para um grupo de precificação, um período anterior à precificação e um período posterior à precificação. O número de dias desses períodos é o mínimo entre 3 valores: número de dias do início do histórico de vendas até a precificação, número de dias do dia da precificação até o final do histórico de vendas, número de dias entre a precificação e a próxima precificação. O objetivo é considerar o número de dias entre a precificação e a próxima, mas os outros valores são limitações de disponibilidade de dados.

A próxima precificação é determinada _para cada sugestão de preço_, conforme descrito no item anterior. Ou seja, é possível ter períodos (em dias) diferentes para cada sugestão de preço dentro dos dados brutos de uma mesma precificação.

A partir desses períodos, buscamos no histórico de vendas as métricas contábeis para os períodos anterior e posterior. A adoção é medida seguindo a mesma lógica descrita acima, mas aqui incluímos apenas as projeções diárias de uma precificação. A precificação que será base para a projeção exibida é a da adoção mais recente ou, na ausência de adoção, a da precificação mais recente.

### Logs

Os logs são direcionados para _stdout/stderr_ e também são salvos no diretório _logs_ e rotacionados periodicamente.

## Deploy

Há uma esteira de CI/CD configurada. Basta levar as mudanças para a _branch_ principal.
