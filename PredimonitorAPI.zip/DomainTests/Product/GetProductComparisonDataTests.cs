﻿using Domain.CompanyMonitoringCrawler;
using Domain.MonitoringResult;
using Domain.Product;
using Domain.Product.Models;
using Domain.Status;
using DomainTests.Extensions;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using MongoDB.Driver;
using Moq;
using Repository.DbContexts;
using Repository.UnitOfWork;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainTests.Product
{
    [TestClass()]
    public class GetProductComparisonDataTests
    {
        private IServiceCollection _services;
        private ServiceProvider _serviceProvider;

        [TestInitialize]
        public void Initialize()
        {
            _services = new ServiceCollection();
            var mongo = new Mock<MongoClient>().Object;

            _services.AddTransient<IMongoClient>(provider => mongo);
            _services.SetAutoMapper();

            _services.AddDbContext<ApplicationDbContext>(options => options.UseSqlite("Filename=:memory:").ConfigureWarnings(opt => opt.Ignore(RelationalEventId.AmbientTransactionWarning)));

            _services.AddDbContext<HorusDbContext>(options => options.UseMongoDB(mongo, "Horus").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            _services.AddDbContext<InfoPriceSaoJoaoDbContext>(options => options.UseMongoDB(mongo, "InfroPriceSaoJoao").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            _services.AddDbContext<NormalizerDbContext>(options => options.UseMongoDB(mongo, "Normalizer").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            _services.AddDbContext<LinxDbContext>(options => options.UseMongoDB(mongo, "Linx").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            _services.AddDbContext<NeogridDbContext>(options => options.UseMongoDB(mongo, "Neogrid").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            _services.AddDbContext<NielsenDbContext>(options => options.UseMongoDB(mongo, "Nielsen").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            _services.AddDbContext<SmarketCompetitorDbContext>(options => options.UseMongoDB(mongo, "SmarketCompetitor").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            _services.AddDbContext<OfflineDbContext>(options => options.UseMongoDB(mongo, "Offline").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            _services.AddDbContext<ScantechSupermaxiDbContext>(options => options.UseMongoDB(mongo, "Scantech").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);

            _services.AddTransient(provider => new DatabricsDbContext("Driver=Simba Spark ODBC Driver;Host=adb-1165720697464401.1.azuredatabricks.net;Port=443;HTTPPath=/sql/1.0/warehouses/bb3e5168ee7e6ca6;SSL=1;ThriftTransport=2;AuthMech=3;UID=token;PWD=dapib21631ae7a26d105f43b29d37237aa34;Timeout=30", "predimonitor_test"));

            _services.AddScoped<IMonitoringResultDomain, MonitoringResultDomain>();
            _services.AddScoped<ICompanyMonitoringCrawlerDomain, CompanyMonitoringCrawlerDomain>();
            _services.AddScoped<IStatusDomain, StatusDomain>();
            _services.AddScoped<IProductDomain, ProductDomain>();
            _services.AddMemoryCache();

            _services.AddScoped<IUnitOfWork, UnitOfWork>();
            _services.AddLogging();

            _serviceProvider = _services.BuildServiceProvider();

            var context = _serviceProvider.GetRequiredService<ApplicationDbContext>();
            context.Database.OpenConnection();
            context.Database.EnsureCreated();
        }

        [TestMethod()]
        public void CalculateProductComparisonShouldCalcuteCorrectData()
        {
            var uow = _serviceProvider.GetService<IUnitOfWork>()!;
            var companyMonitoringCrawlerDomain = _serviceProvider.GetService<ICompanyMonitoringCrawlerDomain>()!;
            var logger = new Mock<ILogger<ProductDomain>>().Object;

            var domain = new ProductDomain(logger, uow, companyMonitoringCrawlerDomain);


            //resultados dos calculos gerados em pré prod
            //Max       Q3      Mediana     Q1      Min     Médio    Frequente
            //27,27     27,27   22,11       21,90   21,90   24,01    27,27

            var prices = new List<ProductComparisonPricesResponse>();

            for (int i = 0; i < 16; i++)
            {
                prices.Add(new() { Name = "Produto Teste", Price = 27.27m });
            }

            for (int i = 0; i < 11; i++)
            {
                prices.Add(new() { Name = "Produto Teste", Price = 21.90m });
            }

            for (int i = 0; i < 4; i++)
            {
                prices.Add(new() { Name = "Produto Teste", Price = 22.13m });
            }

            for (int i = 0; i < 11; i++)
            {
                prices.Add(new() { Name = "Produto Teste", Price = 22.11m });
            }

            prices.Add(new() { Name = "Produto Teste", Price = 23.49m });

            var result = domain.CalculateProductComparison(prices);

            var product = result.FirstOrDefault();

            Assert.AreEqual(prices?.Max(x => x.Price) ?? 0, product.Max, "Falha ao calcular preço máximo do produto");
            Assert.AreEqual(27.27m, product.Q3, "Falha ao calcular quartil superior do produto");
            Assert.AreEqual(22.11m, product.Median, "Falha ao calcular mediana do produto");
            Assert.AreEqual(21.90m, product.Q1, "Falha ao calcular quartil inferior do produto");
            Assert.AreEqual(prices?.Min(x => x.Price) ?? 0, product.Min, "Falha ao calcular preço mínimo do produto");
            Assert.AreEqual(prices?.Average(x => x.Price) ?? 0, product.Avg, "Falha ao calcular preço médio do produto");
            Assert.AreEqual(27.27m, product.MostFrequently, "Falha ao calcular preço mais frequente");

        }

        [TestMethod()]
        public void CalculateProductComparisonShouldIdentifyOutliers()
        {
            var uow = _serviceProvider.GetService<IUnitOfWork>()!;
            var companyMonitoringCrawlerDomain = _serviceProvider.GetService<ICompanyMonitoringCrawlerDomain>()!;
            var logger = new Mock<ILogger<ProductDomain>>().Object;

            var domain = new ProductDomain(logger, uow, companyMonitoringCrawlerDomain);

            var prices = new List<ProductComparisonPricesResponse>
            {
                new() { Name = "Produto Teste", Price = 27.27m },
                new() { Name = "Produto Teste", Price = 21.90m },
                new() { Name = "Produto Teste", Price = 22.13m },
                new() { Name = "Produto Teste", Price = 22.11m },
                new() { Name = "Produto Teste", Price = 23.49m },
                new() { Name = "Produto Teste", Price = 236.37m },
                new() { Name = "Produto Teste", Price = 3.15m }
            };

            var result = domain.CalculateProductComparison(prices);

            var product = result.FirstOrDefault();

            Assert.AreEqual(2, product?.Outliers?.Count() ?? 0, "Falha ao identificar outliers");
        }
    }
}
