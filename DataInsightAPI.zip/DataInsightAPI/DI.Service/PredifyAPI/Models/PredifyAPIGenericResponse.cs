﻿namespace DI.Service.PredifyAPI.Models
{
    public class PredifyAPIGenericResponse<TModel>
    {
        public TModel[] result { get; set; }
        public bool success { get; set; }
        public string messages { get; set; }
    }

}
