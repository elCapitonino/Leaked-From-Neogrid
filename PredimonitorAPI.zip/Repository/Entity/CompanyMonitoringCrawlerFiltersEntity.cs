﻿namespace Repository.Entity
{
    public class CompanyMonitoringCrawlerFiltersEntity : BaseEntity
    {
        public long CompanyMonitoringCrawlerId { get; set; }
        public CompanyMonitoringCrawlerEntity CompanyMonitoringCrawler { get; set; }

        public string Operator { get; set; }

        public string Field { get; set; }

        public bool IsDeleted { get; set; }

        public ICollection<CompanyMonitoringCrawlerFiltersValuesEntity>? CompanyMonitoringCrawlerFiltersValues { get; set; }
    }
}
