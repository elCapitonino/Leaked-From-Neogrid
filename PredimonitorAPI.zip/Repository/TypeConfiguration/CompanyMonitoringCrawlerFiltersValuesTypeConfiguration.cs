﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Repository.Attributes;
using Repository.DbContexts;
using Repository.Entity;

namespace Repository.TypeConfiguration
{
    [DbContextTypeConfiguration(typeof(ApplicationDbContext))]
    public class CompanyMonitoringCrawlerFiltersValuesTypeConfiguration : TypeConfigurationBase<CompanyMonitoringCrawlerFiltersValuesEntity>, IEntityTypeConfiguration<CompanyMonitoringCrawlerFiltersValuesEntity>
    {
        public override void Configure(EntityTypeBuilder<CompanyMonitoringCrawlerFiltersValuesEntity> builder)
        {
            builder.ToTable("Company_MonitoringCrawlerFiltersValues");
            builder.Property(x => x.Id).HasColumnName("IdCompany_MonitoringCrawlerFiltersValues");
            builder.Property(x => x.CompanyMonitoringCrawlerFiltersId).HasColumnName("IdCompany_MonitoringCrawlerFilters");
            builder.Property(x => x.Values).HasMaxLength(256);
            builder.HasOne(x => x.CompanyMonitoringCrawlerFilters);
            builder.HasOne(w => w.CompanyMonitoringCrawlerFilters).WithMany(b => b.CompanyMonitoringCrawlerFiltersValues).HasForeignKey(w => w.CompanyMonitoringCrawlerFiltersId);
        }
    }
}
