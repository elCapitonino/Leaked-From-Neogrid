﻿using DI.Domain.ImpactReportConfiguration;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;

namespace DI.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class ImpactReportConfigurationController : ControllerBase
    {
        private readonly ILogger<ImpactReportConfigurationController> _logger;
        private readonly IImpactReportConfigurationDomain _domain;

        public ImpactReportConfigurationController(ILogger<ImpactReportConfigurationController> logger, IImpactReportConfigurationDomain domain)
        {
            _logger = logger;
            _domain = domain;
        }


        [HttpGet("GetAllImpactConfigs")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [SwaggerOperation(Summary = "See configuration of companies that have records in the ImpactReportConfiguration table", Description = "Returns company configuration data")]
        public async Task<IActionResult> GetAllImpactConfigs()
        {
            try
            {
                var response = _domain.GetImpactReportConfig();

                return Ok(response);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving impact report configurations.");
                return BadRequest(ex.Message);
            }
        }
    }
}
