namespace Repository.Entity.Databricks
{
    public class ProductPriceEntity
    {
        public string? Id { get; set; }
        public string? ProductSellerId { get; set; }
        public string? ProductId { get; set; }
        public DateTime CollectedDate { get; set; }
        public DateTime ImportDate { get; set; }
        public decimal Price { get; set; }
        public string? ProductLink { get; set; }
        public decimal InstallmentQuantity { get; set; }
        public decimal InstallmentPrice { get; set; }
        public string? PriceOrigin { get; set; }
    }
}