from enum import Enum, auto


class ExternalSearchStatus(Enum):
    SUCESS = auto()
    HTTP_ERROR = auto()
    NO_ADDRESS_ERROR = auto()
