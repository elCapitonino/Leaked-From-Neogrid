﻿using DI.Repository.Contexts;
using DI.Repository.Interfaces;

namespace DI.Repository.Repositories.Base
{
    public abstract class PostgreGenericNoModifyRepository<TEntity> : PostgreGenericRepository<TEntity>
        where TEntity : class, IEntity
    {
        protected PostgreGenericNoModifyRepository(PostgreContext dbContext) : base(dbContext)
        {
        }

        public override void Delete(Guid id)
        {
            throw new NotImplementedException("Devido ao intuito da entitade não é para fazer alteração no banco apenas consulta");
        }

        public override void Delete(TEntity entity, bool autosave = true)
        {
            throw new NotImplementedException("Devido ao intuito da entitade não é para fazer alteração no banco apenas consulta");
        }

        public override IQueryable<TEntity> GetAll()
        {
            throw new NotImplementedException("Devido ao volume de dados e ao intuito da entitade não é viavel um GetAll");
        }

        public override void AddRange(IEnumerable<TEntity> entities, bool autosave = false)
        {
            throw new NotImplementedException("Devido ao intuito da entitade não é para fazer alteração no banco apenas consulta");
        }

        public override TEntity Create(TEntity entity, bool autosave = true)
        {
            throw new NotImplementedException("Devido ao intuito da entitade não é para fazer alteração no banco apenas consulta");
        }

        public override void Update(TEntity entity, bool autosave = true)
        {
            throw new NotImplementedException("Devido ao intuito da entitade não é para fazer alteração no banco apenas consulta");
        }
    }
}
