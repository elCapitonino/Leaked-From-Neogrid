using Domain.CompanyMonitoringCrawler;
using Domain.Filter;
using Domain.IndexGenerator;
using Domain.IndexGenerator.DataSourceDomains;
using Domain.IndexGenerator.DataSourceDomains.Interfaces;
using Domain.MonitoringResult;
using Domain.Product;
using Domain.ProductPrice;
using Domain.ProductSeller;
using Domain.Status;

namespace PredimonitorAPI.Extensions
{
    public static class DomainExtensions
    {
        public static void AddDomain(this IServiceCollection services)
        {
            services.AddScoped<IIndexGeneratorDomain, IndexGeneratorDomain>();

            services.AddScoped<IIndexGeneratorHorusDomain, IndexGeneratorHorusDomain>();
            services.AddScoped<IIndexGeneratorInfoPriceDomain, IndexGeneratorInfoPriceDomain>();
            services.AddScoped<IIndexGeneratorIndiretaDomain, IndexGeneratorIndiretaDomain>();
            services.AddScoped<IIndexGeneratorSmarketDomain, IndexGeneratorSmarketDomain>();
            services.AddScoped<IIndexGeneratorNielsenPeraltaDomain, IndexGeneratorNielsenPeraltaDomain>();
            services.AddScoped<IIndexGeneratorNielsenVemDomain, IndexGeneratorNielsenVemDomain>();
            services.AddScoped<IIndexGeneratorPredifyDomain, IndexGeneratorPredifyDomain>();
            services.AddScoped<IIndexGeneratorInfoPricePeraltaDomain, IndexGeneratorInfoPricePeraltaDomain>();
            services.AddScoped<IIndexGeneratorOfflineSupermarketTorreDomain, IndexGeneratorOfflineSupermarketTorreDomain>();
            services.AddScoped<IIndexGeneratorInfoPriceTorreDomain, IndexGeneratorInfoPriceTorreDomain>();
            services.AddScoped<IIndexGeneratorScantechSupermaxiDomain, IndexGeneratorScantechSupermaxiDomain>();

            services.AddScoped<IStatusDomain, StatusDomain>();
            services.AddScoped<IMonitoringResultDomain, MonitoringResultDomain>();
            services.AddScoped<IProductDomain, ProductDomain>();
            services.AddScoped<ICompanyMonitoringCrawlerDomain, CompanyMonitoringCrawlerDomain>();
            services.AddScoped<IFilterDomain, FilterDomain>();
            services.AddScoped<IProductSellerDomain, ProductSellerDomain>();
            services.AddScoped<IProductPriceDomain, ProductPriceDomain>();
        }
    }
}