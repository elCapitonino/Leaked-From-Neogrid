﻿using MongoDB.Bson.Serialization.Attributes;

namespace Repository.Entity.Abv
{
    public class CompetitorEntity
    {
        [BsonElement("SEQCONCORRENTE")]
        public long? SeqConcorrente { get; set; }

        [BsonElement("CONCORRENTE")]
        public string? Concorrente { get; set; }

        [BsonElement("LOGRADOURO")]
        public string? Logradouro { get; set; }

        [BsonElement("NUMERO")]
        public string? Numero { get; set; }

        [BsonElement("COMPLEMENTO")]
        public string? Complemento { get; set; }

        [BsonElement("BAIRRO")]
        public string? Bairro { get; set; }

        [BsonElement("CIDADE")]
        public string? Cidade { get; set; }

        [BsonElement("ESTADO")]
        public string? Estado { get; set; }

        [BsonElement("PAIS")]
        public string? Pais { get; set; }

        [BsonElement("CEP")]
        public string? Cep { get; set; }

        [BsonElement("RAZAO_SOCIAL")]
        public string? RazaoSocial { get; set; }

        [BsonElement("CNPJ")]
        public string? Cnpj { get; set; }

        [BsonElement("IE")]
        public string? Ie { get; set; }
    }

}
