﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Entity
{
    public class MonitoringProductMarketResultItemEntity : BaseEntity
    {
        public long MonitoringProductMarketResultId { get; set; }
        public virtual MonitoringProductMarketResultEntity MonitoringProductMarketResult { get; set; }

        [MaxLength(800)]
        public string ProductName { get; set; }

        [MaxLength(350)]
        public string ProductLink { get; set; }

        [MaxLength(64)]
        public string CrawlerName { get; set; }

        public int CrawlerId { get; set; }

        [MaxLength(256)]
        public string? SellerName { get; set; }

        [MaxLength(256)]
        public string? SellerLink { get; set; }

        [MaxLength(128)]
        public string? Brand { get; set; }

        public decimal? Price { get; set; }

        public DateTime RefDate { get; set; }

        public int? QuantityInstallments { get; set; }
        public decimal? DeflatedValue { get; set; }

        [MaxLength(256)]
        public string? LocalState { get; set; }

        [MaxLength(256)]
        public string? LocalCity { get; set; }

        [MaxLength(32)]
        public string? ZipCode { get; set; }

        public bool IsManual { get; set; }

        public long? MonitoringItemProductManualResultId { get; set; }

        public bool OnRequest { get; set; } = false;
        public bool IsDeleted { get; set; }
    }
}
