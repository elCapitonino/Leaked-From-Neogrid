﻿using System.Security.Claims;

namespace PredifyClientAPI.Models
{
    public class CurrentUser : ICurrentUser
    {
        private ClaimsIdentity? _identity;

        public CurrentUser(IHttpContextAccessor httpContextAccessor)
        {
            _identity = httpContextAccessor?.HttpContext?.User?.Identity as ClaimsIdentity;
        }
        public string? Name => _identity?.Name;
        public bool IsAuthenticated => _identity?.IsAuthenticated ?? false;
        public Guid UserId => Guid.TryParse(_identity?.FindFirst(ClaimTypes.NameIdentifier)?.Value, out Guid userId) ? userId : throw new Exception($"Usuário autenticado: {IsAuthenticated}");
        public string AccessToken => _identity?.FindFirst("access_token")?.Value ?? throw new Exception($"Usuário autenticado: {IsAuthenticated}");

        public ClaimsIdentity? Identity => _identity;
    }
}
