from pydantic import BaseModel
from typing import List, Any
from enum import Enum


class Messages(BaseModel):
    type: str
    code: int
    message: str


class Result(BaseModel):
    result: Any
    success: bool
    messages: List[Messages]


class TypeErrors(Enum):
    info = 0
    warning = 1
    error = 2
