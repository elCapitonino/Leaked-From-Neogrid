﻿using Microsoft.AspNetCore.Mvc;
using PH.Domain.Interfaces.Services;

namespace PH.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GraficoController : ControllerBase
    {
        private readonly ILogger<GraficoController> _logger;
        private readonly IGraficoServices _service;

        public GraficoController(ILogger<GraficoController> logger,
                                IGraficoServices service)
        {
            _logger = logger;
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> Get(string? loja, string? curva, string? categoria)
        {
            _logger.LogInformation("Controller: Buscando todos os Graficos");

            try
            {
                if (String.IsNullOrEmpty(loja) || loja.ToUpper() == "NULL")
                    loja = null;

                var recipes = await _service.Get(loja, curva, categoria);
                return Ok(recipes);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Controller: Erro ao buscar todos os Graficos. {ex.Message}");
                return StatusCode(500, "Erro ao buscar todos os Graficos");
            }
        }


        [HttpGet]
        [Route("GetGraficoReceita")]
        public async Task<IActionResult> GetGraficoReceita(long? idCompany, string? loja)
        {
            _logger.LogInformation("Controller: Buscando Graficos de receita");

            try
            {
                if (idCompany == null || idCompany == 0)
                    throw new Exception("Id da Compania ou Id do grupo não podem ser nulo ou 0");

                var recipes = await _service.GetGraficoReceita(idCompany.Value, loja);
                return Ok(recipes);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Controller: Erro ao buscar Graficos de receita. {ex.Message}");
                return StatusCode(500, "Erro ao buscar Graficos de receita");
            }
        }
    }
}
