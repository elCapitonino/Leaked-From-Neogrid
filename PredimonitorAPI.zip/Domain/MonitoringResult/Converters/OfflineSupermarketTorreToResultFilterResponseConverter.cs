﻿using AutoMapper;
using Domain.MonitoringResult.Models;
using Repository.Entity;
using Repository.Enums;

namespace Domain.MonitoringResult.Converters
{
    public class OfflineSupermarketTorreToResultFilterResponseConverter : ITypeConverter<OfflineSupermarketTorreEntity, ResultFilterResponse>
    {
        public ResultFilterResponse Convert(OfflineSupermarketTorreEntity source, ResultFilterResponse destination, ResolutionContext context)
        {
            var dest = new ResultFilterResponse()
            {
                ProductName = source.ProductName,
                ProductLink = source.Hash,
                ProductBrand = null,
                SellerName = source.SellerName,
                Marketplace = (string)context.Items["CrawlerName"],
                Price = source.UnitPrice,
                PaymentType = "-",
                Price_unit_type = PriceUnitType.UNITARIO,
                CrawlerDate = source.Date,
                Disregarded = false,
                IdCrawler = (int)context.Items["CrawlerId"],
                Format_market = source.Segment,
                City = source.City,
                On_request = false,
                State = source.State,
                Coordinates = source.Coordinates == null ? null : new PrediMonitorProduct_CoordinatesModel()
                {
                    Longitude = (decimal)source.Coordinates.Coordinates[0],
                    Latitude = (decimal)source.Coordinates.Coordinates[1],
                },
            };

            return dest;
        }
    }
}
