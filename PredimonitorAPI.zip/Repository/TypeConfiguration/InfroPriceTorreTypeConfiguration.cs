﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using MongoDB.EntityFrameworkCore.Extensions;
using Repository.Attributes;
using Repository.DbContexts;
using Repository.Entity;

namespace Repository.TypeConfiguration
{
    [DbContextTypeConfiguration(typeof(InfoPriceSaoJoaoDbContext))]
    public class InfroPriceTorreTypeConfiguration : TypeConfigurationBase<InfoPriceTorreEntity>, IEntityTypeConfiguration<InfoPriceTorreEntity>
    {
        public override void Configure(EntityTypeBuilder<InfoPriceTorreEntity> builder)
        {
            builder.ToTable("Torre").ToCollection("Torre");
        }
    }
}
