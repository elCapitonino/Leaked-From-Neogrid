import os
from dotenv import load_dotenv
from http import server
from pymongo import MongoClient

# conectar mongo
load_dotenv()

controle = 0

Server = {
    "host": os.getenv("SERVER_MONGO_HOST"),
    "port": os.getenv("SERVER_MONGO_PORT"),
    "user": os.getenv("SERVER_MONGO_USER"),
    "password": os.getenv("SERVER_MONGO_PASSWORD"),
}

url_normalizer_predmonitor = f'{os.getenv("NORMALIZER_API_HOST")}/search_pred_monitor/'

url_normalizer = f'{os.getenv("NORMALIZER_API_HOST")}/'