from search_general_type import *
from config import *
from fastapi.encoders import jsonable_encoder
from search_products import *
import requests
from time import sleep, time
from datetime import datetime
from fastapi import HTTPException
from search_products import Search_products
from predimonitor_type import *
from search_horus import Search_horus
from search_smarket import Search_smarket
from search_neogrid import Search_neogrid
from search_nielsen import Search_nielsen
from models.getAllDataModelRequest import getAllDataModelRequest
from bson import json_util
import json

from logger import logger

class Search_general:
    def __init__(self):
        self.Restriction_list = RestrictionList()

    async def search_general(self, products: Search_Products):

        list_restrict = self.Restriction_list.get_restriction(
            products.id_company)
        products.products[0].language = products.language
        result_final = []
        result_horus = []
        result_smarket = []
        result_neogrid = []
        result_nielsen = []
        search_name = ""
        search_ean = ""
        search_mandatory_tag_model = ""
        # print(products.idcrawlers_offline)
        if (products.products[0].name != None and len(products.products[0].name.split()[0]) > 1):
            search_name = products.products[0].name.split()[0]
        if (products.products[0].ean != None and len(products.products[0].ean) > 1):
            search_ean = products.products[0].ean
        if (products.products[0].mandatoryTagModel != None and products.products[0].mandatoryTagModel != ""):
            search_mandatory_tag_model = products.products[0].mandatoryTagModel
        # try:
        inicio_busca = time()
        # print("  inicio 04", inicio_busca)
        # for i in products.products:
        #     if i.language == None or i.language == '' or 'language' not in i.language:
        #         i.language = products.language

        # ######################################
        if (products.data_source == search_source_type.Horus_search and products.products[0].ean != None and products.idcrawlers_offline != None):
            search_horus = Search_horus()
            result_horus = await search_horus.search_get_V1(
                products.idcrawlers_offline, products.data_source, products.products, products.start_date, products.end_date)
            # print(result_horus)
        # ######################################
        if (products.data_source == search_source_type.Horus_search and products.products[0].ean != None and products.idcrawlers_offline != None):
            search_neogrid = Search_neogrid()
            result_neogrid = await search_neogrid.search_get_V1(
                products.idcrawlers_offline,products.data_source, products.products, products.start_date, products.end_date)

        # ######################################
        if (products.data_source == search_source_type.Smarket_search and products.products[0].code != None and products.idcrawlers_offline != None):
            print('Searching Smarket Code:', products.products[0].code)
            search_smarket = Search_smarket()
            result_smarket = await search_smarket.search_get_V1(
                products.idcrawlers_offline, products.data_source, products.products, products.start_date, products.end_date)
            
            print('Searching Smarket Result:', len(result_smarket))

        # ######################################
        if (products.data_source == search_source_type.Nielsen and products.products[0].ean != None and products.idcrawlers_offline != None):
            search_nielsen = Search_nielsen()
            print(f"chegou no Nielsen {search_source_type.Nielsen}")
            result_nielsen = await search_nielsen.search_get_V1(products, products.start_date, products.end_date)

    
        inicio_requisicao = time()
        resp = requests.post(url=url_normalizer,
                                json=jsonable_encoder(products.products))

        fim_requisicao = time()
        data_resp = resp.json()
        result = result_horus + result_smarket + result_neogrid + result_nielsen

        if (data_resp['products_list'][0] == []):
            result_final.append(
                {'id': products.products[0].id, 'name': search_name+"_"+search_ean, 'results': result})
            return result_final

        # ######################################
        # if (products.data_source == search_source_type.Horus_search and products.products[0].ean != None and products.idcrawlers_offline != None):
        #     print('Searching Neogrid EAN:', products.products[0].ean)
            
        #     search_neogrid = Search_neogrid()
        #     result_neogrid = await search_neogrid.search_get_V1(
        #         products.idcrawlers_offline, products.data_source, products.products, products.start_date, products.end_date)
            
        #     print('Searching Neogrid Result:', len(result_neogrid))

        # ######################################

        inicio_coleta_mongo = time()
        if (products.data_source == search_source_type.predify or products.data_source == search_source_type.Horus_search or products.data_source == search_source_type.Smarket_search or products.data_source == search_source_type.Neogrid_search):
            search_products_general = Search_products()
            result += await search_products_general.get_products(
                data_resp, products.start_date, products.end_date, products.idcrawlers, products.language, products.id_company, list_restrict,
                products.products[0].name, search_mandatory_tag_model)

        result_final.append(
            {'id': products.products[0].id, 'name': search_name+"_"+search_ean, 'results': result})

        fim_coleta_mongo = time()
        # print(result)
        #########################################
        try:
            db_mongo = AsyncMongoConnect()
            await db_mongo.log_search(products.products[0].name, round((fim_coleta_mongo - inicio_busca), 3), round(
                (fim_coleta_mongo - inicio_coleta_mongo), 3), round((fim_requisicao - inicio_requisicao), 3), "search_general")
        except Exception as e:
            print(str(e))

        #########################################
        return result_final
        # except Exception as ex:
        #     print('Error01:', ex)
        #     return HTTPException(status_code=500, detail=ex)

    async def search_get_all(self, params: getAllDataModelRequest):
        sear_products = Search_products()
        result = await sear_products.get_all_products(params.ids_crawler, params.start_date, params.end_date)

        return json.loads(json_util.dumps(result))
    
    async def search_get_all_netshoes(self, params: getAllDataModelRequest):
        sear_products = Search_products()
        result = await sear_products.get_all_products_netshoes(params.ids_crawler, params.start_date, params.end_date)

        return json.loads(json_util.dumps(result))
