﻿using Microsoft.EntityFrameworkCore;
using MongoDB.Driver;
using Repository.DbContexts.Bases;

namespace Repository.DbContexts
{
    public class NeogridDbContext : MongoDbContextBase
    {
        public NeogridDbContext(DbContextOptions<NeogridDbContext> options, IMongoClient mongoClient) : base(options, mongoClient)
        {
        }

        public override string DbContextName => nameof(NeogridDbContext);
    }
}
