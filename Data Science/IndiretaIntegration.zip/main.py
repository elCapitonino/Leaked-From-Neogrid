from pymongo import MongoClient
import pandas as pd
from pymongo import MongoClient
import numpy as np
import uuid
import os
from dotenv import load_dotenv
import geoApiService
from hashlib import sha256
import requests
import json
load_dotenv(dotenv_path='.env.local', override=True)

CSV_PATH = os.getenv("CSV_PATH")
MONGO_URI = os.getenv("MONGO_CONECTION_STRING")
MONGO_DB = os.getenv("MONGO_DATABASE")
MONGO_COLLECTION = os.getenv("MONGO_COLLECTION")
PREDIFY_TOKEN_ADDRESS = os.getenv("PREDIFY_TOKEN_ADDRESS")
PREDIFY_USERNAME = os.getenv("PREDIFY_USERNAME")
PREDIFY_PASSWORD = os.getenv("PREDIFY_PASSWORD")
PREDIFY_CLIENT_ID = os.getenv("PREDIFY_CLIENT_ID")
REINDEX_API_URL = os.getenv("REINDEX_API_URL")
REINDEX_SOURCE = os.getenv("REINDEX_SOURCE")

def distinct_dicts(dict_list, props):
    """
    Return a list of dictionaries with distinct combinations of properties.
    Args:
        dict_list (list): A list of dictionaries.
        props (list): A list of properties to consider for distinctness.
    Returns:
        list: A list of dictionaries with distinct combinations of properties.
    Example:
        >>> dict_list = [{'name': 'John', 'age': 25}, {'name': 'Jane', 'age': 30}, {'name': 'John', 'age': 25}]
        >>> props = ['name', 'age']
        >>> distinct_dicts(dict_list, props)
        [{'name': 'John', 'age': 25}, {'name': 'Jane', 'age': 30}]
    """
    seen = set()
    result = []
    
    for d in dict_list:
        key = tuple(d[prop] for prop in props)
        if key not in seen:
            seen.add(key)
            result.append(d)
    
    return result

def hash_rows(df: pd.DataFrame, hash_cols: list[str]) -> pd.Series:
    """
    Hashes the values in the specified columns of a DataFrame row-wise using SHA256 algorithm.

    Args:
        df (pd.DataFrame): The DataFrame containing the data to be hashed.
        hash_cols (list[str]): The list of column names to be hashed.

    Returns:
        pd.Series: A Series containing the hashed values for each row.

    Raises:
        None

    Examples:
        >>> df = pd.DataFrame({'col1': ['abc', 'def'], 'col2': ['123', '456']})
        >>> hash_cols = ['col1', 'col2']
        >>> hash_rows(df, hash_cols)
        0    900150983cd24fb0d6963f7d28e17f72
        1    698d51a19d8a121ce581499d7b701668
        dtype: object
    """
    return (
        df[hash_cols]
        .agg("|".join, axis=1)
        .apply(lambda x: sha256(x.encode("utf-8")).hexdigest())
    )

def csv_to_mongo(csv_file_path, mongo_uri, db_name, collection_name):
    """
    Reads a CSV file, validates headers, performs data transformations, geocodes addresses, and inserts the data into a MongoDB collection.
    Parameters:
    - csv_file_path (str): The file path of the CSV file to be read.
    - mongo_uri (str): The URI of the MongoDB server.
    - db_name (str): The name of the MongoDB database.
    - collection_name (str): The name of the MongoDB collection.
    Returns:
    - Min and Max date of the data inserted
    Raises:
    - None
    """
    expected_headers = ['ANO MES MOVIMENTO'
                        , 'CNPJ DISTRIBUIDOR'
                        , 'NOME DISTRIBUIDOR'
                        , 'ULTIMA VENDA'
                        , 'SETOR'
                        , 'DESCRICAOO PRODUTO'
                        , 'EAN PRODUTO'
                        , 'VALOR VENDA'
                        , 'PRECO MEDIO'
                        , 'QTD VENDA'
                        , 'CEP'
                        , 'ENDERECO'
                        , 'BAIRRO'
                        , 'CIDADE'
                        , 'UF'
                        , 'CUSTO ITEM']

    dtypes = {
        'ANO MES MOVIMENTO': int,
        'CNPJ DISTRIBUIDOR': str,
        'NOME DISTRIBUIDOR': str,
        'SETOR': str,
        'DESCRICAOO PRODUTO': str,
        'EAN PRODUTO': str,
        'VALOR VENDA': float,
        'PRECO MEDIO': float,
        'QTD VENDA': float,
        'CEP': str,
        'ENDERECO': str,
        'BAIRRO': str,
        'CIDADE': str,
        'UF': str,
        'CUSTO ITEM': str
    }

    date_columns = ['ULTIMA VENDA']

    print('lendo csv')
    df = pd.read_csv(csv_file_path, sep=';', dtype=dtypes, parse_dates=date_columns)
    
    print('registros:', len(df))

    print('validando headers')
    actual_headers = list(df.columns)
    if actual_headers != expected_headers:
        print(f'Headers incorretos. Esperados: {expected_headers}, Encontrados: {actual_headers}')
        return
    
    siglas = {
        'Acre': 'AC', 'Alagoas': 'AL', 'Amapá': 'AP', 'Amazonas': 'AM', 'Bahia': 'BA', 
        'Ceará': 'CE', 'Distrito Federal': 'DF', 'Espírito Santo': 'ES', 'Goiás': 'GO', 
        'Maranhão': 'MA', 'Mato Grosso': 'MT', 'Mato Grosso do Sul': 'MS', 'Minas Gerais': 'MG', 
        'Pará': 'PA', 'Paraíba': 'PB', 'Paraná': 'PR', 'Pernambuco': 'PE', 'Piauí': 'PI', 
        'Rio de Janeiro': 'RJ', 'Rio Grande do Norte': 'RN', 'Rio Grande do Sul': 'RS', 
        'Rondônia': 'RO', 'Roraima': 'RR', 'Santa Catarina': 'SC', 'São Paulo': 'SP', 
        'Sergipe': 'SE', 'Tocantins': 'TO'
    }

    print('mapeando siglas UFs')
    df['UF2'] = df['UF'].map(siglas)
    
    print('eliminando espaço livre')
    df = df.applymap(lambda x: x.strip() if isinstance(x, str) else x)

    print('eliminando 0 a esquerda dos eans para padronização das outras bases e consultas')
    df['EAN PRODUTO'] = df['EAN PRODUTO'].apply(lambda x: str(x).lstrip('0'))

    print('trantando Nan')
    df = df.replace({np.nan: None})

    print('Gerando id import')
    id_import = str(uuid.uuid4())
    df['id_import'] = id_import

    print('Gerando hash')
    df["HASH"] = hash_rows(df, ["EAN PRODUTO", "NOME DISTRIBUIDOR"])

    print('criando dicionário')
    data = df.to_dict(orient='records')
        
    print('Analisando endereços')
    geoService = geoApiService.geoApiService()

    props_to_check = ['UF', 'CIDADE', 'ENDERECO', 'CEP']

    distinct_adress = distinct_dicts(data, props_to_check)
    print('Endereços distintos encontrados:', len(distinct_adress))

    print('Pesquisando endereços')
    address_founded = {}
    for da in distinct_adress:
        address_info = {
            "base": "indireta",
            "id_consulta": f"{da['UF']}, {da['CIDADE']}, {da['ENDERECO']}, {da['CEP']}",
            "address": da['ENDERECO'] if da['ENDERECO'] is not None else "",
            "neighborhood": "",
            "city": da['CIDADE'] if da['ENDERECO'] is not None else "",
            "state": da['UF'] if da['UF'] is not None else "",
            "country": ""
        }
        address = geoService.get_address(address_info)
        address_founded[f"{da['UF']}, {da['CIDADE']}, {da['ENDERECO']}, {da['CEP']}"] = address

    print('coordenadas encontradas:', len(address_founded))

    for d in data:
        id_address = f"{d['UF']}, {d['CIDADE']}, {d['ENDERECO']}, {d['CEP']}"
        if id_address in address_founded:
            d['coordinates'] = address_founded[id_address]['coordinates']

    print('coordenadas inseridas:', len(address_founded))

    print('conectando mongo')
    client = MongoClient(mongo_uri)
    db = client[db_name]
    collection = db[collection_name]

    print('inserindo no mongo')
    collection.insert_many(data)
    
    print('dados inseridos:', len(data))
    
    print(f'Dados inseridos na coleção {collection_name} do banco de dados {db_name} com sucesso!')

    client.close()

    return min(df['ULTIMA VENDA']), max(df['ULTIMA VENDA'])

def get_predify_access_token():
    """
    Retrieve the Predify access key (access token) via login
    Args:
        None
    Returns:
        str: The access key if successful, or None if there is an error.
    """
    url = PREDIFY_TOKEN_ADDRESS
    payload = {
        "grant_type": "password",
        "username": PREDIFY_USERNAME,
        "password": PREDIFY_PASSWORD,
        "client_id": PREDIFY_CLIENT_ID
    }
    headers = {
        "Content-Type": "application/x-www-form-urlencoded"
    }
    response = requests.post(url, data=payload, headers=headers)
    
    if response.status_code == 200:
        response_json = response.json()
        return response_json.get("access_token")
    else:
        print(f"Failed to get access key. Status code: {response.status_code}, Response: {response.text}")
        exit(1)

def re_index_mongo_collection(min_date, max_date):
    """
    Reindexa a coleção do MongoDB via API
    Args:
        min_date (str): A data mínima para reindexar.
        max_date (str): A data máxima para reindexar.
    Returns:
        None
    """
    print(f"Reindexing MongoDB collection from {min_date} to {max_date}")

    access_key = get_predify_access_token()
    print(f"Access key: {access_key}")
    data = {
        "source": REINDEX_SOURCE,
        "startDate": min_date,
        "endDate": max_date
        }
    headers = {
        "Authorization": f"Bearer {access_key}",
        "Content-Type": "application/json"
    }
    print(json.dumps(data, indent=2))
    response = requests.post(
        url=REINDEX_API_URL,
        json=data,
        headers=headers,
        timeout=None
    )
    if response.status_code == 200:
        print("Reindexing successful")
    else:
        print(f"Failed to reindex. Status code: {response.status_code}, Response: {response.text}")
        exit(1)


print("File path:", CSV_PATH)

min_date, max_date = csv_to_mongo(CSV_PATH, MONGO_URI, MONGO_DB, MONGO_COLLECTION)
re_index_mongo_collection(min_date, max_date)
