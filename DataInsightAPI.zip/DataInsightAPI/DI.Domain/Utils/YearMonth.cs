﻿namespace DI.Domain.Utils
{
    public struct YearMonth
    {
        public int Year { get; }
        public int Month { get; }

        public readonly int Value => (Year * 100) + Month;

        public YearMonth(int yearMonth)
        {
            if (yearMonth < 100 || yearMonth > 999999)
                throw new ArgumentException("YearMonth must be in the format YYYYMM.", nameof(yearMonth));

            Year = yearMonth / 100;
            Month = yearMonth % 100;

            if (Month < 1 || Month > 12)
                throw new ArgumentOutOfRangeException(nameof(Month), "Month must be between 1 and 12.");
        }

        public YearMonth(DateTime dateTime)
        {
            Year = dateTime.Year;
            Month = dateTime.Month;
        }

        public YearMonth(int year, int month)
        {
            if (year < 0)
                throw new ArgumentOutOfRangeException(nameof(year), "Year must be a non-negative integer.");

            if (month < 1 || month > 12)
                throw new ArgumentOutOfRangeException(nameof(month), "Month must be between 1 and 12.");

            Year = year;
            Month = month;
        }

        public YearMonth(string yearMonth)
        {
            if (yearMonth == null)
                throw new ArgumentNullException(nameof(yearMonth));

            if (yearMonth.Length != 6 || !int.TryParse(yearMonth.Substring(0, 4), out int year) || !int.TryParse(yearMonth.Substring(4, 2), out int month))
                throw new ArgumentException("YearMonth must be in the format YYYYMM.", nameof(yearMonth));

            if (year < 0)
                throw new ArgumentOutOfRangeException(nameof(year), "Year must be a non-negative integer.");

            if (month < 1 || month > 12)
                throw new ArgumentOutOfRangeException(nameof(month), "Month must be between 1 and 12.");

            Year = year;
            Month = month;
        }

        public YearMonth AddYears(int yearsToAdd)
        {
            return new YearMonth(Year + yearsToAdd, Month);
        }

        public YearMonth AddMonths(int monthsToAdd)
        {
            int totalMonths = Year * 12 + (Month - 1) + monthsToAdd;
            int newYear = totalMonths / 12;
            int newMonth = totalMonths % 12 + 1;

            return new YearMonth(newYear, newMonth);
        }

        public DateTime GetDateTime()
        {
            return new DateTime(Year, Month, 01);
        }

        public override string ToString()
        {
            return $"{Year:D4}{Month:D2}";
        }

        public override bool Equals(object obj)
        {
            if (obj is YearMonth other)
            {
                return Year == other.Year && Month == other.Month;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(Year, Month);
        }

        public static bool operator ==(YearMonth left, YearMonth right)
        {
            return left.Equals(right);
        }

        public static bool operator !=(YearMonth left, YearMonth right)
        {
            return !(left == right);
        }

        public static bool operator >(YearMonth left, YearMonth right)
        {
            return left.Year > right.Year || (left.Year == right.Year && left.Month > right.Month);
        }

        public static bool operator <(YearMonth left, YearMonth right)
        {
            return left.Year < right.Year || (left.Year == right.Year && left.Month < right.Month);
        }

        public static bool operator >=(YearMonth left, YearMonth right)
        {
            return left.Year > right.Year || (left.Year == right.Year && left.Month >= right.Month);
        }

        public static bool operator <=(YearMonth left, YearMonth right)
        {
            return left.Year < right.Year || (left.Year == right.Year && left.Month <= right.Month);
        }

        public static YearMonth operator ++(YearMonth yearMonth)
        {
            return yearMonth.AddMonths(1);
        }
        public static YearMonth operator --(YearMonth yearMonth)
        {
            return yearMonth.AddMonths(-1);
        }

    }
}
