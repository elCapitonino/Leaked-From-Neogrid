﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PH.Domain.Domain
{
    public class ProdutosTabelados
    {
        public ProdutosTabelados() 
        { 
            CreationDate = DateTime.Now;
        }

        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; private set; }
        public string Description { get; set; }
        public string? Brand { get; set; }
        public double Price { get; set; }
        public string? State { get; set; }
        public string EAN { get; set; }
        public long IdCompany { get; set; }
        public DateTime? CreationDate { get; private set; }
    }
}
