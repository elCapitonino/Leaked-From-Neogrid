﻿using Repository.Enums;

namespace Domain.IndexGenerator.Models
{
    public class IndexGeneratorForOfflineRequest
    {
        public CrawlerSourceType Source { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }
}
