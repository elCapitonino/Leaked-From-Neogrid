﻿using MongoDB.Bson.Serialization.Attributes;

namespace Repository.Entity.Abv
{
    public class ProductDescriptionEntity
    {
        [BsonElement("SEQPRODUTO")]
        public long? SeqProduto { get; set; }

        [BsonElement("SEQSIMILARIDADE")]
        public string? SeqSimilaridade { get; set; }

        [BsonElement("SEQFORNECEDOR")]
        public long? SeqFornecedor { get; set; }

        [BsonElement("DESCRICAO")]
        public string? Descricao { get; set; }

        [BsonElement("TIPO_EMBALAGEM")]
        public string? TipoEmbalagem { get; set; }

        [BsonElement("QUANTIDADE_EMBALAGEM")]
        public string? QuantidadeEmbalagem { get; set; }

        [BsonElement("QUANTIDADE_PROPORCIONAL")]
        public string? QuantidadeProporcional { get; set; }

        [BsonElement("UNIDADE_EMBALAGEM")]
        public string? UnidadeEmbalagem { get; set; }

        [BsonElement("UNIDADE_PROPORCIONAL")]
        public string? UnidadeProporcional { get; set; }

        [BsonElement("MARCA")]
        public string? Marca { get; set; }
    }

}
