﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Repository.Attributes;
using Repository.DbContexts;
using Repository.Entity;

namespace Repository.TypeConfiguration
{
    [DbContextTypeConfiguration(typeof(ApplicationDbContext))]
    public class CompanyMonitoringCrawlerTypeConfiguration : TypeConfigurationBase<CompanyMonitoringCrawlerEntity>, IEntityTypeConfiguration<CompanyMonitoringCrawlerEntity>
    {
        public override void Configure(EntityTypeBuilder<CompanyMonitoringCrawlerEntity> builder)
        {
            builder.ToTable("Company_MonitoringCrawler");
            builder.Property(x => x.Id).HasColumnName("IdCompany_MonitoringCrawler");
            builder.Property(x => x.CompanyId).HasColumnName("IdCompany");
            builder.Property(x => x.MonitoringCrawlerId).HasColumnName("IdMonitoringCrawler");
            builder.HasOne(x => x.MonitoringCrawler);
            builder.HasOne(w => w.MonitoringCrawler).WithMany(b => b.CompanyMonitorings).HasForeignKey(w => w.MonitoringCrawlerId);
        }
    }
}
