﻿using Microsoft.AspNetCore.Http;
using PH.Domain.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PH.Domain.Interfaces.Services
{
    public interface IProdutosTabeladosServices
    {
        Task ImportTabelados(IFormFile file);
        Task<List<ProdutosTabeladosDTO>> GetProdutosTabelados(long idCompany, string state, string affiliate);
    }
}
