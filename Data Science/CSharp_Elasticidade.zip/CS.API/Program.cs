using CS.Data.Imp;
using CS.Domain.Interfaces.Repositories;
using CS.Domain.Interfaces.Services;
using CS.Service.Imp;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddScoped<IEnterpriseSalesHistoryRepository, EnterpriseSalesHistoryRepository>();
builder.Services.AddScoped<IEnterpriseSalesHistoryService, EnterpriseSalesHistoryService>();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
