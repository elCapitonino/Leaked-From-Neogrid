﻿namespace Repository.Entity
{
    public sealed class DinPreRule_Cond_ValueEntity : BaseEntity
    {
        public long ConditionValueId { get; set; }
        public long IdRuleCondition { get; set; }
        public DinPreRule_ConditionEntity? RuleCondition { get; set; }
        public string StringValue { get; set; }
        public decimal DecimalValue { get; set; }
        public bool BooleanValue { get; set; }
        public bool IsDeletado { get; set; }
    }
}
