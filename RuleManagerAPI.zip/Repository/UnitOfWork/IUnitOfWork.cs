﻿using Repository.EntityRepository;
using System.Transactions;

namespace Repository.UnitOfWork
{
    public interface IUnitOfWork : IDisposable
    {
        IRuleGroupRepository RuleGroupRepository { get; }
        IRuleRepository RuleRepository { get; }
        IDefaultFilterRepository DefaultFilterRepository { get; }
        IProductMarketResultSellerRepository ProductMarketResultSellerRepository { get; }
        TransactionScope CreateTransactionScope();
        TransactionScope CreateTransactionScope(TransactionScopeAsyncFlowOption asyncFlowOption);       
    }
}
