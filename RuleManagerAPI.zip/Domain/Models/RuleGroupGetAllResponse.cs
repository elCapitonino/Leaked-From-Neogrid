﻿namespace Domain.Models
{
    public sealed class RuleGroupGetAllResponse
    {
        public long Id { get; set; }

        public string Name { get; set; } = string.Empty;
    }
}
