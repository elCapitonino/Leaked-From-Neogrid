﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Domain.MonitoringResult;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Repository.Entity;
using Repository.Entity.ProductPrices;
using Repository.Enums;
using MongoDB.Driver.GeoJsonObjectModel;

namespace Domain.MonitoringResult.Tests
{
    [TestClass()]
    public class ProductPricesMappingsTests
    {
        [TestMethod]
        public async Task MappingsProductPricesToResultResponse_Should_Transform_BasicData_Correctly()
        {
            // Arrange
            var pricingMappings = new ProductPricesMappings();
            var datas = new List<ProductPricesEntity>
            {
                new ProductPricesEntity
                {
                    IdCrawler = 1,
                    ProductName = "Test Product",
                    ProductLink = "http://example.com",
                    Sellers = new List<ProductPricesSeller>
                    {
                        new ProductPricesSeller
                        {
                            SellerName = "Test Seller",
                            Prices = new List<ProductPricesSellerPrice>
                            {
                                new ProductPricesSellerPrice
                                {
                                    Price = 100,
                                    PricePaymentType = "Cash"
                                }
                            }
                        }
                    }
                }
            };
            var companyCrawlers = new List<CompanyMonitoringCrawlerEntity>
            {
                new CompanyMonitoringCrawlerEntity
                {
                    MonitoringCrawlerId = 1,
                    MonitoringCrawler = new MonitoringCrawlerEntity
                    {
                        Description = "Test Marketplace"
                    }
                }
            };

            // Act
            var result = await pricingMappings.MappingsProductPricesToResultResponse(datas, companyCrawlers);

            // Assert
            Assert.AreEqual(1, result.Count, "The number of results should match the number of price entries.");
            Assert.AreEqual("Test Product", result[0].ProductName, "The ProductName should match the input data.");
            Assert.AreEqual("Test Seller", result[0].SellerName, "The SellerName should match the input seller.");
            Assert.AreEqual(100, result[0].Price, "The Price should be correctly assigned from the price entry.");
            Assert.AreEqual("Test Marketplace", result[0].Marketplace, "The Marketplace should match the associated MonitoringCrawler description.");
        }

        [TestMethod]
        public async Task MappingsProductPricesToResultResponse_Should_Handle_Installments_Correctly()
        {
            // Arrange
            var pricingMappings = new ProductPricesMappings();
            var datas = new List<ProductPricesEntity>
            {
                new ProductPricesEntity
                {
                    IdCrawler = 1,
                    ProductName = "Test Product",
                    Sellers = new List<ProductPricesSeller>
                    {
                        new ProductPricesSeller
                        {
                            Prices = new List<ProductPricesSellerPrice>
                            {
                                new ProductPricesSellerPrice
                                {
                                    Price = 100,
                                    Installments = new List<ProductPricesSellerPriceInstallment>
                                    {
                                        new ProductPricesSellerPriceInstallment
                                        {
                                            Quantity = 10,
                                            TotalPrice = 110,
                                            Price = 11
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            };
            var companyCrawlers = new List<CompanyMonitoringCrawlerEntity>
            {
                new CompanyMonitoringCrawlerEntity
                {
                    MonitoringCrawlerId = 1,
                    MonitoringCrawler = new MonitoringCrawlerEntity
                    {
                        Description = "Test Marketplace"
                    }
                }
            };

            // Act
            var result = await pricingMappings.MappingsProductPricesToResultResponse(datas, companyCrawlers);

            // Assert
            Assert.AreEqual(1, result.Count, "The result count should match the number of price entries.");
            Assert.AreEqual(10, result[0].QuantityInstallment, "Installment quantity should be correctly assigned.");
            Assert.AreEqual(110, result[0].Total_priceInstallment, "Total installment price should be correctly assigned.");
            Assert.AreEqual(11, result[0].PriceInstallment, "Installment price should be correctly assigned.");
        }
        [TestMethod]
        public async Task MappingsProductPricesToResultResponse_Should_Handle_Null_Installments_Correctly()
        {
            // Arrange
            var pricingMappings = new ProductPricesMappings();
            var datas = new List<ProductPricesEntity>
            {
                new ProductPricesEntity
                {
                    IdCrawler = 1,
                    ProductName = "Test Product",
                    Sellers = new List<ProductPricesSeller>
                    {
                        new ProductPricesSeller
                        {
                            Prices = new List<ProductPricesSellerPrice>
                            {
                                new ProductPricesSellerPrice
                                {
                                    Price = 100,
                                    Installments = null
                                }
                            }
                        }
                    }
                }
            };
                    var companyCrawlers = new List<CompanyMonitoringCrawlerEntity>
            {
                new CompanyMonitoringCrawlerEntity
                {
                    MonitoringCrawlerId = 1,
                    MonitoringCrawler = new MonitoringCrawlerEntity
                    {
                        Description = "Test Marketplace"
                    }
                }
            };

            // Act
            var result = await pricingMappings.MappingsProductPricesToResultResponse(datas, companyCrawlers);

            // Assert
            Assert.AreEqual(1, result.Count, "The result count should match the number of price entries.");
            Assert.IsNull(result[0].QuantityInstallment, "Installment quantity should be null when no installments are provided.");
            Assert.IsNull(result[0].Total_priceInstallment, "Total installment price should be null when no installments are provided.");
            Assert.IsNull(result[0].PriceInstallment, "Installment price should be null when no installments are provided.");
        }
        [TestMethod]
        public async Task MappingsProductPricesToResultResponse_Should_Adjust_Price_For_Caixa_Correctly()
        {
            // Arrange
            var pricingMappings = new ProductPricesMappings();
            var datas = new List<ProductPricesEntity>
            {
                new ProductPricesEntity
                {
                    IdCrawler = 1,
                    ProductName = "Test Product",
                    Sellers = new List<ProductPricesSeller>
                    {
                        new ProductPricesSeller
                        {
                            Prices = new List<ProductPricesSellerPrice>
                            {
                                new ProductPricesSellerPrice
                                {
                                    PriceUnitType = PriceUnitType.CAIXA,
                                    Price = 100,
                                    PriceUnitQuantity = 10
                                }
                            }
                        }
                    }
                }
            };
                    var companyCrawlers = new List<CompanyMonitoringCrawlerEntity>
            {
                new CompanyMonitoringCrawlerEntity
                {
                    MonitoringCrawlerId = 1,
                    MonitoringCrawler = new MonitoringCrawlerEntity
                    {
                        Description = "Test Marketplace"
                    }
                }
            };

            // Act
            var result = await pricingMappings.MappingsProductPricesToResultResponse(datas, companyCrawlers);

            // Assert
            Assert.AreEqual(1, result.Count, "The result count should match the number of price entries.");
            Assert.AreEqual(10, result[0].Price, "The price should be correctly adjusted when the unit type is 'CAIXA'.");
        }
        [TestMethod]
        public async Task MappingsProductPricesToResultResponse_Should_Handle_Zero_Price_With_OnRequest_Correctly()
        {
            // Arrange
            var pricingMappings = new ProductPricesMappings();
            var datas = new List<ProductPricesEntity>
            {
                new ProductPricesEntity
                {
                    IdCrawler = 1,
                    ProductName = "Test Product",
                    Sellers = new List<ProductPricesSeller>
                    {
                        new ProductPricesSeller
                        {
                            Prices = new List<ProductPricesSellerPrice>
                            {
                                new ProductPricesSellerPrice
                                {
                                    Price = 0,
                                    OnRequest = true
                                }
                            }
                        }
                    }
                }
            };
                    var companyCrawlers = new List<CompanyMonitoringCrawlerEntity>
            {
                new CompanyMonitoringCrawlerEntity
                {
                    MonitoringCrawlerId = 1,
                    MonitoringCrawler = new MonitoringCrawlerEntity
                    {
                        Description = "Test Marketplace"
                    }
                }
            };

            // Act
            var result = await pricingMappings.MappingsProductPricesToResultResponse(datas, companyCrawlers);

            // Assert
            Assert.AreEqual(1, result.Count, "The result count should include items with zero price when 'OnRequest' is true.");
        }
        [TestMethod]
        public async Task MappingsProductPricesToResultResponse_Should_Use_Defaults_For_Null_PricePaymentType_And_PriceUnitType()
        {
            // Arrange
            var pricingMappings = new ProductPricesMappings();
            var datas = new List<ProductPricesEntity>
            {
                new ProductPricesEntity
                {
                    IdCrawler = 1,
                    ProductName = "Test Product",
                    Sellers = new List<ProductPricesSeller>
                    {
                        new ProductPricesSeller
                        {
                            Prices = new List<ProductPricesSellerPrice>
                            {
                                new ProductPricesSellerPrice
                                {
                                    Price = 100,
                                    PricePaymentType = null,
                                    PriceUnitType = null
                                }
                            }
                        }
                    }
                }
            };
                    var companyCrawlers = new List<CompanyMonitoringCrawlerEntity>
            {
                new CompanyMonitoringCrawlerEntity
                {
                    MonitoringCrawlerId = 1,
                    MonitoringCrawler = new MonitoringCrawlerEntity
                    {
                        Description = "Test Marketplace"
                    }
                }
            };

            // Act
            var result = await pricingMappings.MappingsProductPricesToResultResponse(datas, companyCrawlers);

            // Assert
            Assert.AreEqual(1, result.Count, "The result count should match the number of price entries.");
            Assert.AreEqual("-", result[0].PaymentType, "The default payment type should be used when PricePaymentType is null.");
            Assert.AreEqual(PriceUnitType.UNITARIO, result[0].Price_unit_type, "The default unit type should be 'UNITARIO' when PriceUnitType is null.");
        }
        [TestMethod]
        public async Task MappingsProductPricesToResultResponse_Should_Call_GenerateCoordinates_Async()
        {
            // Arrange
            var pricingMappings = new ProductPricesMappings();
            var datas = new List<ProductPricesEntity>
            {
                new ProductPricesEntity
                {
                    IdCrawler = 1,
                    ProductName = "Test Product",
                    ProductLocal = new ProductPricesProductLocal { City = "Test City" },
                    Sellers = new List<ProductPricesSeller>
                    {
                        new ProductPricesSeller
                        {
                            Coordinates = new GeoJson2DGeographicCoordinatesWrapper(new GeoJson2DGeographicCoordinates(10, 20)),
                            Prices = new List<ProductPricesSellerPrice>
                            {
                                new ProductPricesSellerPrice
                                {
                                    Price = 100,
                                    PricePaymentType = null,
                                    PriceUnitType = null
                                }
                            }

                        }
                    }
                }
            };
            var companyCrawlers = new List<CompanyMonitoringCrawlerEntity>
            {
                new CompanyMonitoringCrawlerEntity
                {
                    MonitoringCrawlerId = 1,
                    MonitoringCrawler = new MonitoringCrawlerEntity
                    {
                        Description = "Test Marketplace"
                    }
                }
            };

            // Act
            var result = await pricingMappings.MappingsProductPricesToResultResponse(datas, companyCrawlers);

            // Assert
            Assert.IsNotNull(result[0].Coordinates, "Coordinates should be generated asynchronously.");
            Assert.AreEqual(10, result[0].Coordinates.Latitude, "The generated latitude should match the input data.");
            Assert.AreEqual(20, result[0].Coordinates.Longitude, "The generated longitude should match the input data.");
        }
        [TestMethod]
        public async Task MappingsProductPricesToResultResponse_Should_Handle_Missing_CompanyMonitoringCrawlerEntity()
        {
            // Arrange
            var pricingMappings = new ProductPricesMappings();
            var datas = new List<ProductPricesEntity>
            {
                new ProductPricesEntity
                {
                    IdCrawler = 1,
                    ProductName = "Test Product",
                    Sellers = new List<ProductPricesSeller>
                    {
                        new ProductPricesSeller
                        {
                            SellerName = "Test Seller",
                            Prices = new List<ProductPricesSellerPrice>
                            {
                                new ProductPricesSellerPrice
                                {
                                    Price = 100
                                }
                            }
                        }
                    }
                }
            };
            var companyCrawlers = new List<CompanyMonitoringCrawlerEntity>(); // Empty list

            // Act
            var result = await pricingMappings.MappingsProductPricesToResultResponse(datas, companyCrawlers);

            // Assert
            Assert.AreEqual("N/A", result[0].Marketplace, "The Marketplace should default to 'N/A' if no matching CompanyMonitoringCrawlerEntity is found.");
        }
        [TestMethod]
        public async Task MappingsProductPricesToResultResponse_Should_Handle_Null_Or_Empty_Sellers_And_Prices()
        {
            // Arrange
            var pricingMappings = new ProductPricesMappings();
            var datas = new List<ProductPricesEntity>
            {
                new ProductPricesEntity
                {
                    IdCrawler = 1,
                    ProductName = "Test Product",
                    Sellers = null // Null Sellers
                },
                new ProductPricesEntity
                {
                    IdCrawler = 2,
                    ProductName = "Test Product 2",
                    Sellers = new List<ProductPricesSeller>
                    {
                        new ProductPricesSeller
                        {
                            Prices = null // Null Prices
                        }
                    }
                }
            };
                    var companyCrawlers = new List<CompanyMonitoringCrawlerEntity>
            {
                new CompanyMonitoringCrawlerEntity
                {
                    MonitoringCrawlerId = 1,
                    MonitoringCrawler = new MonitoringCrawlerEntity
                    {
                        Description = "Test Marketplace"
                    }
                }
            };

            // Act
            var result = await pricingMappings.MappingsProductPricesToResultResponse(datas, companyCrawlers);

            // Assert
            Assert.AreEqual(0, result.Count, "No results should be returned when Sellers or Prices are null.");
        }
        [TestMethod]
        public async Task MappingsProductPricesToResultResponse_Should_Handle_Multiple_Items_In_Datas()
        {
            // Arrange
            var pricingMappings = new ProductPricesMappings();
            var datas = new List<ProductPricesEntity>
            {
                new ProductPricesEntity
                {
                    IdCrawler = 1,
                    ProductName = "Test Product",
                    Sellers = new List<ProductPricesSeller>
                    {
                        new ProductPricesSeller
                        {
                            SellerName = "Seller 1",
                            Prices = new List<ProductPricesSellerPrice>
                            {
                                new ProductPricesSellerPrice
                                {
                                    Price = 100
                                }
                            }
                        }
                    }
                },
                new ProductPricesEntity
                {
                    IdCrawler = 2,
                    ProductName = "Test Product 2",
                    Sellers = new List<ProductPricesSeller>
                    {
                        new ProductPricesSeller
                        {
                            SellerName = "Seller 2",
                            Prices = new List<ProductPricesSellerPrice>
                            {
                                new ProductPricesSellerPrice
                                {
                                    Price = 200
                                }
                            }
                        }
                    }
                }
            };
                    var companyCrawlers = new List<CompanyMonitoringCrawlerEntity>
            {
                new CompanyMonitoringCrawlerEntity
                {
                    MonitoringCrawlerId = 1,
                    MonitoringCrawler = new MonitoringCrawlerEntity
                    {
                        Description = "Test Marketplace"
                    }
                },
                new CompanyMonitoringCrawlerEntity
                {
                    MonitoringCrawlerId = 2,
                    MonitoringCrawler = new MonitoringCrawlerEntity
                    {
                        Description = "Test Marketplace 2"
                    }
                }
            };

            // Act
            var result = await pricingMappings.MappingsProductPricesToResultResponse(datas, companyCrawlers);

            // Assert
            Assert.AreEqual(2, result.Count, "The result should contain entries for each item in the datas list.");
            Assert.AreEqual("Test Product", result[0].ProductName, "The first result's ProductName should match the first input product.");
            Assert.AreEqual("Test Product 2", result[1].ProductName, "The second result's ProductName should match the second input product.");
        }

        [TestMethod]
        public async Task MappingsProductPricesToResultResponse_Should_Adjust_Price_When_PriceUnitType_Is_CAIXA_And_PriceUnit_Is_Zero()
        {
            // Arrange
            var pricingMappings = new ProductPricesMappings();
            var datas = new List<ProductPricesEntity>
            {
                new ProductPricesEntity
                {
                    IdCrawler = 1,
                    ProductName = "Boxed Product",
                    Sellers = new List<ProductPricesSeller>
                    {
                        new ProductPricesSeller
                        {
                            SellerName = "Box Seller",
                            Prices = new List<ProductPricesSellerPrice>
                            {
                                new ProductPricesSellerPrice
                                {
                                    PriceUnitType = PriceUnitType.CAIXA,
                                    Price = 100, // Initial price
                                    PriceUnit = 0, // Price unit is zero
                                    PriceUnitQuantity = 10, // Price unit quantity for calculation
                                    Installments = new List<ProductPricesSellerPriceInstallment>
                                    {
                                        new ProductPricesSellerPriceInstallment
                                        {
                                            Quantity = 5,
                                            TotalPrice = 55,
                                            Price = 11
                                        }
                                    },
                                    OnRequest = false
                                }
                            }
                        }
                    }
                }
            };
            var companyCrawlers = new List<CompanyMonitoringCrawlerEntity>
            {
                new CompanyMonitoringCrawlerEntity
                {
                    MonitoringCrawlerId = 1,
                    MonitoringCrawler = new MonitoringCrawlerEntity
                    {
                        Description = "Box Marketplace"
                    }
                }
            };

            // Act
            var result = await pricingMappings.MappingsProductPricesToResultResponse(datas, companyCrawlers);

            // Assert
            Assert.AreEqual(1, result.Count, "The result count should include the entry after price adjustment.");
            Assert.AreEqual(10, result[0].Price, "The price should be correctly adjusted to 100 when PriceUnitType is 'CAIXA' and PriceUnit is zero.");
        }
        [TestMethod]
        public async Task MappingsProductPricesToResultResponse_Should_Add_Result_When_Price_Is_Zero_And_OnRequest_Is_True()
        {
            // Arrange
            var pricingMappings = new ProductPricesMappings();
            var datas = new List<ProductPricesEntity>
            {
                new ProductPricesEntity
                {
                    IdCrawler = 1,
                    ProductName = "On Request Product",
                    Sellers = new List<ProductPricesSeller>
                    {
                        new ProductPricesSeller
                        {
                            SellerName = "Request Seller",
                            Prices = new List<ProductPricesSellerPrice>
                            {
                                new ProductPricesSellerPrice
                                {
                                    PriceUnitType = PriceUnitType.CAIXA,
                                    Price = 0, // Price is zero
                                    PriceUnit = 0,
                                    PriceUnitQuantity = 10,
                                    Installments = new List<ProductPricesSellerPriceInstallment>
                                    {
                                        new ProductPricesSellerPriceInstallment
                                        {
                                            Quantity = 10,
                                            TotalPrice = 110,
                                            Price = 11
                                        }
                                    },
                                    OnRequest = true // OnRequest is true
                                }
                            }
                        }
                    }
                }
            };
            var companyCrawlers = new List<CompanyMonitoringCrawlerEntity>
            {
                new CompanyMonitoringCrawlerEntity
                {
                    MonitoringCrawlerId = 1,
                    MonitoringCrawler = new MonitoringCrawlerEntity
                    {
                        Description = "Request Marketplace"
                    }
                }
            };

            // Act
            var result = await pricingMappings.MappingsProductPricesToResultResponse(datas, companyCrawlers);

            // Assert
            Assert.AreEqual(1, result.Count, "The result count should include the entry when price is zero and OnRequest is true.");
            Assert.AreEqual(0, result[0].Price, "The price should be zero as specified.");
            Assert.IsTrue(result[0].On_request, "OnRequest should be true for the resulting entry.");
        }

        [TestMethod]
        public async Task MappingsProductPricesToResultResponse_Should_Skip_When_PriceUnitQuantity_Is_Null_Or_Zero()
        {
            // Arrange
            var pricingMappings = new ProductPricesMappings();
            var datas = new List<ProductPricesEntity>
            {
                new ProductPricesEntity
                {
                    IdCrawler = 1,
                    ProductName = "Quantity Test Product",
                    Sellers = new List<ProductPricesSeller>
                    {
                        new ProductPricesSeller
                        {
                            SellerName = "Quantity Seller",
                            Prices = new List<ProductPricesSellerPrice>
                            {
                                new ProductPricesSellerPrice
                                {
                                    PriceUnitType = PriceUnitType.CAIXA,
                                    Price = 100,
                                    PriceUnit = null, // PriceUnit is null
                                    PriceUnitQuantity = null, // PriceUnitQuantity is null
                                    Installments = new List<ProductPricesSellerPriceInstallment>
                                    {
                                        new ProductPricesSellerPriceInstallment
                                        {
                                            Quantity = 10,
                                            TotalPrice = 110,
                                            Price = 11
                                        }
                                    },
                                    OnRequest = false
                                }
                            }
                        }
                    }
                },
                new ProductPricesEntity
                {
                    IdCrawler = 2,
                    ProductName = "Zero Quantity Product",
                    Sellers = new List<ProductPricesSeller>
                    {
                        new ProductPricesSeller
                        {
                            SellerName = "Zero Seller",
                            Prices = new List<ProductPricesSellerPrice>
                            {
                                new ProductPricesSellerPrice
                                {
                                    PriceUnitType = PriceUnitType.CAIXA,
                                    Price = 100,
                                    PriceUnit = null, // PriceUnit is null
                                    PriceUnitQuantity = 0, // PriceUnitQuantity is 0
                                    Installments = new List<ProductPricesSellerPriceInstallment>
                                    {
                                        new ProductPricesSellerPriceInstallment
                                        {
                                            Quantity = 10,
                                            TotalPrice = 110,
                                            Price = 11
                                        }
                                    },
                                    OnRequest = false
                                }
                            }
                        }
                    }
                }
            };
            var companyCrawlers = new List<CompanyMonitoringCrawlerEntity>
            {
                new CompanyMonitoringCrawlerEntity
                {
                    MonitoringCrawlerId = 1,
                    MonitoringCrawler = new MonitoringCrawlerEntity
                    {
                        Description = "Marketplace"
                    }
                }
            };

            // Act
            var result = await pricingMappings.MappingsProductPricesToResultResponse(datas, companyCrawlers);

            // Assert
            Assert.AreEqual(0, result.Count, "The result should not include any entries when PriceUnitQuantity is null or zero.");
        }
        [TestMethod]
        public async Task MappingsProductPricesToResultResponse_Should_Calculate_Price_When_PriceUnit_Is_Null_Or_LessThanOrEqualToZero()
        {
            // Arrange
            var pricingMappings = new ProductPricesMappings();
            var datas = new List<ProductPricesEntity>
            {
                new ProductPricesEntity
                {
                    IdCrawler = 1,
                    ProductName = "Unit Test Product",
                    Sellers = new List<ProductPricesSeller>
                    {
                        new ProductPricesSeller
                        {
                            SellerName = "Unit Seller",
                            Prices = new List<ProductPricesSellerPrice>
                            {
                                new ProductPricesSellerPrice
                                {
                                    PriceUnitType = PriceUnitType.CAIXA,
                                    Price = 100,
                                    PriceUnit = null, // PriceUnit is null
                                    PriceUnitQuantity = 10, // PriceUnitQuantity is greater than 0
                                    Installments = new List<ProductPricesSellerPriceInstallment>
                                    {
                                        new ProductPricesSellerPriceInstallment
                                        {
                                            Quantity = 10,
                                            TotalPrice = 110,
                                            Price = 11
                                        }
                                    },
                                    OnRequest = false
                                }
                            }
                        }
                    }
                },
                new ProductPricesEntity
                {
                    IdCrawler = 2,
                    ProductName = "Zero Unit Product",
                    Sellers = new List<ProductPricesSeller>
                    {
                        new ProductPricesSeller
                        {
                            SellerName = "Zero Unit Seller",
                            Prices = new List<ProductPricesSellerPrice>
                            {
                                new ProductPricesSellerPrice
                                {
                                    PriceUnitType = PriceUnitType.CAIXA,
                                    Price = 100,
                                    PriceUnit = 0, // PriceUnit is 0
                                    PriceUnitQuantity = 5, // PriceUnitQuantity is greater than 0
                                    Installments = new List<ProductPricesSellerPriceInstallment>
                                    {
                                        new ProductPricesSellerPriceInstallment
                                        {
                                            Quantity = 5,
                                            TotalPrice = 55,
                                            Price = 11
                                        }
                                    },
                                    OnRequest = false
                                }
                            }
                        }
                    }
                }
            };
            var companyCrawlers = new List<CompanyMonitoringCrawlerEntity>
            {
                new CompanyMonitoringCrawlerEntity
                {
                    MonitoringCrawlerId = 1,
                    MonitoringCrawler = new MonitoringCrawlerEntity
                    {
                        Description = "Marketplace"
                    }
                }
            };

            // Act
            var result = await pricingMappings.MappingsProductPricesToResultResponse(datas, companyCrawlers);

            // Assert
            Assert.AreEqual(2, result.Count, "The result should include entries when PriceUnit is null or zero and PriceUnitQuantity is greater than zero.");
            Assert.AreEqual(10, result.Find(x=>x.ProductName== "Unit Test Product")?.Price, "The price should be calculated correctly when PriceUnit is null.");
            Assert.AreEqual(20, result.Find(x => x.ProductName == "Zero Unit Product")?.Price, "The price should be calculated correctly when PriceUnit is zero.");
        }

        [TestMethod]
        public async Task MappingsProductPricesToResultResponse_Should_Set_Price_To_PriceUnit_When_Valid_And_PriceUnitType_Is_CAIXA()
        {
            // Arrange
            var pricingMappings = new ProductPricesMappings();
            var datas = new List<ProductPricesEntity>
            {
                new ProductPricesEntity
                {
                    IdCrawler = 1,
                    ProductName = "Valid Unit Product",
                    Sellers = new List<ProductPricesSeller>
                    {
                        new ProductPricesSeller
                        {
                            SellerName = "Valid Unit Seller",
                            Prices = new List<ProductPricesSellerPrice>
                            {
                                new ProductPricesSellerPrice
                                {
                                    PriceUnitType = PriceUnitType.CAIXA,
                                    Price = 100, // Initial price
                                    PriceUnit = 25, // PriceUnit is valid and greater than 0
                                    Installments = new List<ProductPricesSellerPriceInstallment>
                                    {
                                        new ProductPricesSellerPriceInstallment
                                        {
                                            Quantity = 5,
                                            TotalPrice = 125,
                                            Price = 25
                                        }
                                    },
                                    OnRequest = false
                                }
                            }
                        }
                    }
                }
            };
            var companyCrawlers = new List<CompanyMonitoringCrawlerEntity>
            {
                new CompanyMonitoringCrawlerEntity
                {
                    MonitoringCrawlerId = 1,
                    MonitoringCrawler = new MonitoringCrawlerEntity
                    {
                        Description = "Marketplace"
                    }
                }
            };

            // Act
            var result = await pricingMappings.MappingsProductPricesToResultResponse(datas, companyCrawlers);

            // Assert
            Assert.AreEqual(1, result.Count, "The result count should include the entry when PriceUnit is valid.");
            Assert.AreEqual(25, result[0].Price, "The price should be set to the value of PriceUnit when it is valid and PriceUnitType is 'CAIXA'.");
        }

        [TestMethod]
        public async Task MappingsProductPricesToResultResponse_Should_Skip_When_PriceUnitQuantity_Is_Null_Or_Zero_And_No_Installments()
        {
            // Arrange
            var pricingMappings = new ProductPricesMappings();
            var datas = new List<ProductPricesEntity>
            {
                new ProductPricesEntity
                {
                    IdCrawler = 1,
                    ProductName = "Quantity Test Product",
                    Sellers = new List<ProductPricesSeller>
                    {
                        new ProductPricesSeller
                        {
                            SellerName = "Quantity Seller",
                            Prices = new List<ProductPricesSellerPrice>
                            {
                                new ProductPricesSellerPrice
                                {
                                    PriceUnitType = PriceUnitType.CAIXA,
                                    Price = 100,
                                    PriceUnit = null, // PriceUnit is null
                                    PriceUnitQuantity = null, // PriceUnitQuantity is null
                                    Installments = null, // No installments
                                    OnRequest = false
                                }
                            }
                        }
                    }
                },
                new ProductPricesEntity
                {
                    IdCrawler = 2,
                    ProductName = "Zero Quantity Product",
                    Sellers = new List<ProductPricesSeller>
                    {
                        new ProductPricesSeller
                        {
                            SellerName = "Zero Seller",
                            Prices = new List<ProductPricesSellerPrice>
                            {
                                new ProductPricesSellerPrice
                                {
                                    PriceUnitType = PriceUnitType.CAIXA,
                                    Price = 100,
                                    PriceUnit = null, // PriceUnit is null
                                    PriceUnitQuantity = 0, // PriceUnitQuantity is 0
                                    Installments = null, // No installments
                                    OnRequest = false
                                }
                            }
                        }
                    }
                }
            };
            var companyCrawlers = new List<CompanyMonitoringCrawlerEntity>
            {
                new CompanyMonitoringCrawlerEntity
                {
                    MonitoringCrawlerId = 1,
                    MonitoringCrawler = new MonitoringCrawlerEntity
                    {
                        Description = "Marketplace"
                    }
                }
            };

            // Act
            var result = await pricingMappings.MappingsProductPricesToResultResponse(datas, companyCrawlers);

            // Assert
            Assert.AreEqual(0, result.Count, "The result should not include any entries when PriceUnitQuantity is null or zero and there are no installments.");
        }

        [TestMethod]
        public async Task MappingsProductPricesToResultResponse_Should_Set_Price_To_PriceUnit_When_Valid_And_No_Installments()
        {
            // Arrange
            var pricingMappings = new ProductPricesMappings();
            var datas = new List<ProductPricesEntity>
            {
                new ProductPricesEntity
                {
                    IdCrawler = 1,
                    ProductName = "Valid Unit No Installments Product",
                    Sellers = new List<ProductPricesSeller>
                    {
                        new ProductPricesSeller
                        {
                            SellerName = "Valid Unit Seller",
                            Prices = new List<ProductPricesSellerPrice>
                            {
                                new ProductPricesSellerPrice
                                {
                                    PriceUnitType = PriceUnitType.CAIXA,
                                    Price = 100, // Initial price
                                    PriceUnit = 25, // PriceUnit is valid and greater than 0
                                    PriceUnitQuantity = 10, // PriceUnitQuantity is greater than 0
                                    Installments = null, // No installments
                                    OnRequest = false
                                }
                            }
                        }
                    }
                }
            };
            var companyCrawlers = new List<CompanyMonitoringCrawlerEntity>
            {
                new CompanyMonitoringCrawlerEntity
                {
                    MonitoringCrawlerId = 1,
                    MonitoringCrawler = new MonitoringCrawlerEntity
                    {
                        Description = "Marketplace"
                    }
                }
            };

            // Act
            var result = await pricingMappings.MappingsProductPricesToResultResponse(datas, companyCrawlers);

            // Assert
            Assert.AreEqual(1, result.Count, "The result count should include the entry when PriceUnit is valid and there are no installments.");
            Assert.AreEqual(25, result[0].Price, "The price should be set to the value of PriceUnit when it is valid and there are no installments.");
        }

        [TestMethod]
        public async Task GenerateCoordinates_Should_Use_ProductLocal_Coordinates_When_Seller_Coordinates_Is_Null()
        {
            // Arrange
            var pricingMappings = new ProductPricesMappings();
       

            var datas = new List<ProductPricesEntity>
            {
                new ProductPricesEntity
                {
                    IdCrawler = 1,
                    ProductName = "Test Product",
                    ProductLocal = new ProductPricesProductLocal { City = "Test City",Coordinates = new GeoJson2DGeographicCoordinatesWrapper(new GeoJson2DGeographicCoordinates(10, 20)), },
                    Sellers = new List<ProductPricesSeller>
                    {
                        new ProductPricesSeller
                        {
                            
                            Prices = new List<ProductPricesSellerPrice>
                            {
                                new ProductPricesSellerPrice
                                {
                                    Price = 100,
                                    PricePaymentType = null,
                                    PriceUnitType = null
                                }
                            }

                        }
                    }
                }
            };
            var companyCrawlers = new List<CompanyMonitoringCrawlerEntity>
            {
                new CompanyMonitoringCrawlerEntity
                {
                    MonitoringCrawlerId = 1,
                    MonitoringCrawler = new MonitoringCrawlerEntity
                    {
                        Description = "Test Marketplace"
                    }
                }
            };

            // Act
            var result = await pricingMappings.MappingsProductPricesToResultResponse(datas, companyCrawlers);

            // Assert
            Assert.IsNotNull(result[0].Coordinates, "The result should not be null when productLocal coordinates are provided.");
            Assert.AreEqual(10, result[0].Coordinates.Latitude, "The Longitude should be correctly set from productLocal coordinates.");
            Assert.AreEqual(20, result[0].Coordinates.Longitude, "The Latitude should be correctly set from productLocal coordinates.");
        }


    }
}

