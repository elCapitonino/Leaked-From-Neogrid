# Nível de atividade

Relatórios em Excel para o nível de atividade. 

## Limitações

- **Todos os _scripts_ devem ser chamados com os mesmos parâmetros utilizados no momento do último cálculo do nível de atividade da empresa.**
- **Se houver dados novos posteriores ao último cálculo do nível de atividade, os dados diários não corresponderão ao mesmo período dos dados agregados**. As informações de data não ficam salvas na planilha de nível de atividade.

Ambas as limitações ocorrem por conta da planilha de informações diárias.

## Gerar o relatório

```bash
PYTHONPATH=. python activity_level/main.py --env preproducao --id-company 1234 --prod-id ProdVar --granularity Var1 Var2
```

## Gerar o relatório para as filiais especiais da VEM

1. Selecionar os produtos:

```bash
PYTHONPATH=. python activity_level/vem_get_top_products.py
```

2. Gerar o relatório

```bash
PYTHONPATH=. python activity_level/vem_special_stores.py --env preproducao --allowed-json ./activity_level/chosen_products.json
```
