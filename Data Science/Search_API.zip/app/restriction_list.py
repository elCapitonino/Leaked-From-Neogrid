from async_mongo import AsyncMongoConnect


class RestrictionList():

    __instance = None

    def __new__(cls, *args, **kwargs):
        if not RestrictionList.__instance:
            RestrictionList.__instance = super(
                RestrictionList, cls).__new__(cls, *args, **kwargs)
        return RestrictionList.__instance

    def __init__(self):
        pass

    async def load_restriction(self):
        db_mongo = AsyncMongoConnect()
        restriction = await db_mongo.load_list_restrictions()
        self.list_restriction = {}
        for r in restriction:
            self.list_restriction[r['id_company']] = r['list_restriction']
        # print("load_restriction")

    def get_restriction(self, id_company):
        if id_company in self.list_restriction:
            return self.list_restriction[id_company]
        return []

    async def update_restriction(self, id_company, list_restriction, update_list):

        if (update_list == False):
            db_mongo = AsyncMongoConnect()
            dict = {}
            lista_sucesso = []
            lista_ja_cadastrado = []
            for termo_restricao in list_restriction:
                result = await db_mongo.get_list_restrictions(
                    id_company, termo_restricao)

                resultMongo = list(result)
                if(len(list(resultMongo)) == 0):
                    await db_mongo.update_list_restrictions(
                        id_company, termo_restricao)
                    lista_sucesso.append(termo_restricao)

                if(len(list(resultMongo)) >= 1):
                    lista_ja_cadastrado.append(termo_restricao)

            dict['sucesso'] = lista_sucesso
            dict['ja_cadastrado'] = lista_ja_cadastrado

            return dict

        if (update_list == True):
            self.load_restriction()
            return "Lista de restrição atualizados com sucesso"
            #print("update_list == True")
