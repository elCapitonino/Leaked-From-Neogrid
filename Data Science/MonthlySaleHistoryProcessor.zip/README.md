# MonthlySaleHistoryProcessor

API para processar dados da tabela `Enterprise_Sales_History` armazenada no SQL Server, gerar métricas contábeis agregadas por mês e salvá-las no PostgreSQL. Esse processo gera os dados necessários para exibir gráficos de impacto na tela Home.

## Como rodar

Após criar um ambiente virtual e ativá-lo, instale as dependências:

```bash
python -m pip install -r requirements.txt
```

Cria um arquivo `.env.local` na raiz do repositório preenchendo _todas_ as variáveis de ambiente especificadas no arquivo `.env`.

Para rodar em modo debug:

```bash
export DEBUG=1
export PYTHONPATH=.
fastapi dev app/main.py
```

**Importante**: ao rodar em modo debug, um cache local dos metadados dos bancos de dados será salvo. **Se houver mudanças no _schema_ dos bancos de dados é necessário excluir esses arquivos**. Basta excluir o diretório `./cache`. Isso é feito porque o processo de reflexão de metadados é demorado e atrapalha o desenvolvimento, no qual reiniciamos a API muitas vezes.

Rodar com Docker:

```bash
docker compose up
```

Para forçar um _rebuild_ da imagem, se necessário:

```bash
docker compose up --build --force-recreate --no-deps
```

Para rodar com Docker em modo _debug_, basta apontar para o arquivo YAML de desenvolvimento:

```bash
docker compose -f docker-compose-dev.yml up
```
