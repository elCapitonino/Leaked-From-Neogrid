﻿namespace Services.AzureDevops.Models
{
    public sealed class AzureDevopsOptions
    {
        public required string Host { get; set; }
        public required string Organization { get; set; }
        public required string PAT { get; set; }
    }
}
