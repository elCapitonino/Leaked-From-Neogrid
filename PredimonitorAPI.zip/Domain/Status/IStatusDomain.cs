﻿using Domain.Status.Models;
using Repository.Enums;

namespace Domain.Status
{
    public interface IStatusDomain
    {
        MonitoringItemResultsStatusResponse GetByCompanyId(long companyId);
        IEnumerable<MonitoringItemResultsStatusResponse> GetTaskRunnings();
        MonitoringItemResultsStatusResponse AddOrUpdate(MonitoringItemResultsStatusRequest request);
        void AddToCache(Guid? taskId);
        void UpdateCache(StatusCacheModel model);
        Dictionary<CrawlerSourceType, StatusCacheModel> GetTaskStatus(Guid taskId);
        void RemoveCache(Guid taskId);
    }
}
