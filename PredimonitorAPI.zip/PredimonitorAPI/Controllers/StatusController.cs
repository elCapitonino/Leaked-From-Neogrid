using Domain.Exceptions;
using Domain.Status;
using Domain.Status.Models;
using Microsoft.AspNetCore.Mvc;

namespace PredimonitorAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StatusController : ControllerBase
    {
        private readonly ILogger<StatusController> _logger;
        private readonly IStatusDomain _domain;

        public StatusController(ILogger<StatusController> logger, IStatusDomain domain)
        {
            _logger = logger;
            _domain = domain;
        }

        [HttpGet]
        [Route("GetByCompanyId/{companyId}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(MonitoringItemResultsStatusResponse))]
        [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status401Unauthorized, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
        public IActionResult GetByCompanyId(long companyId)
        {
            try
            {
                var response =  _domain.GetByCompanyId(companyId);

                return Ok(response);
            }
            catch (NotFoundException ex)
            {
                _logger.LogError(ex.Message, ex);
                return NotFound(ex.Message);
            }
            catch (UnauthorizedAccessException ex)
            {
                _logger.LogError(ex.Message, ex);
                return Unauthorized(ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(MonitoringItemResultsStatusResponse))]
        [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status401Unauthorized, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
        public IActionResult AddOrUpdateStatus([FromBody] MonitoringItemResultsStatusRequest request)
        {
            try
            {
                var response = _domain.AddOrUpdate(request);

                return Ok(response);
            }
            catch (NotFoundException ex)
            {
                _logger.LogError(ex.Message, ex);
                return NotFound(ex.Message);
            }
            catch (UnauthorizedAccessException ex)
            {
                _logger.LogError(ex.Message, ex);
                return Unauthorized(ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex);
                return BadRequest(ex.Message);
            }
        }
    }
}
