"""
Script para gerar relatório com informações sobre índice de competitividade
para precificações específicas da VEM.

Mantido para registro, não para ser utilizado diretamente em outro contexto.
"""

import os
from datetime import datetime

import pandas as pd
from dotenv import load_dotenv
from pymongo import MongoClient
from pymongo.collection import Collection
from xlsxwriter.utility import xl_col_to_name

from geral import config


def search_ean_city_nielsen(
    coll: Collection,
    affiliate: str,
    ean: str,
    city: str,
    format_market: str,
    min_date: datetime,
    max_date: datetime,
):
    query = {
        "EAN": ean,
        "DATE": {"$gte": min_date, "$lte": max_date},
        "FORMAT_MARKET": format_market,
        "CITY": city.lower(),
    }
    cur = coll.find(query)

    out = list(cur)
    for doc in out:
        doc["Affiliate"] = affiliate

    return out


def search_ean_state_nielsen(
    coll: Collection,
    affiliate: str,
    ean: str,
    state: str,
    format_market: str,
    min_date: datetime,
    max_date: datetime,
):
    query = {
        "EAN": ean,
        "DATE": {"$gte": min_date, "$lte": max_date},
        "FORMAT_MARKET": format_market,
        "STATE_UF": state.upper(),
    }
    cur = coll.find(query)

    out = list(cur)
    for doc in out:
        doc["Affiliate"] = affiliate

    return out


def boxplot_outlier(df: pd.DataFrame) -> pd.DataFrame:
    q1 = df["WEEKLY_PRICE"].quantile(0.25)
    q3 = df["WEEKLY_PRICE"].quantile(0.75)
    iqr = q3 - q1

    lb = q1 - 1.5 * iqr
    ub = q3 - 1.5 * iqr

    out = df[["_id"]].copy()
    out["outlier"] = (df["WEEKLY_PRICE"] < lb) | (df["WEEKLY_PRICE"] > ub)
    return out.reset_index(drop=True)


def add_nielsen(
    coll: Collection,
    df_products: pd.DataFrame,
    format_market: str,
    min_date: datetime,
    max_date: datetime,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    results_city = []
    results_state = []
    for i, row in df_products.iterrows():
        if (i + 1) % 10 == 0:
            print(f"-> fetched {i+1}/{df_products.shape[0]} products from mongo")

        city_matches = search_ean_city_nielsen(
            coll,
            row["Affiliate"],
            row["ean"],
            row["city"],
            format_market,
            min_date,
            max_date,
        )
        state_matches = search_ean_state_nielsen(
            coll,
            row["Affiliate"],
            row["ean"],
            row["uf"],
            format_market,
            min_date,
            max_date,
        )

        results_city.extend(city_matches)
        results_state.extend(state_matches)

    df_city = pd.DataFrame(results_city).rename(columns={"EAN": "ean"})
    df_state = pd.DataFrame(results_state).rename(columns={"EAN": "ean"})

    variables = {
        "Affiliate": "",
        "ean": "",
        "_id": "",
        "WEEKLY_PRICE": float(),
    }

    # NOTE garante que merge funcione mesmo com DataFrame vazio
    if df_city.empty:
        df_city = pd.DataFrame(variables, index=[])

    if df_state.empty:
        df_state = pd.DataFrame(variables, index=[])

    df_city = pd.merge(
        df_products,
        df_city[["Affiliate", "ean", "_id", "WEEKLY_PRICE"]],
        on=["ean", "Affiliate"],
        how="left",
    )
    df_state = pd.merge(
        df_products,
        df_state[["Affiliate", "ean", "_id", "WEEKLY_PRICE"]],
        on=["ean", "Affiliate"],
        how="left",
    )

    return df_city, df_state


def calculate_ic(df_nielsen: pd.DataFrame) -> pd.DataFrame:
    group = df_nielsen.groupby(["Affiliate", "Description"])
    is_outlier = group.apply(boxplot_outlier).reset_index()

    df_outlier = pd.merge(
        df_nielsen, is_outlier, on=["_id", "Affiliate", "Description"], how="left"
    )

    df_clean = df_outlier[~df_outlier["outlier"]]

    df_clean.head()

    df_final = (
        df_nielsen.groupby(["Affiliate", "Description"])
        .agg(
            {
                "Issuance": "max",
                "Category": "first",
                "Subcategory": "first",
                "SalePrice": "first",
                "ean": "first",
                "WEEKLY_PRICE": lambda x: x.mode().mean(),
            }
        )
        .reset_index()
        .rename(columns={"WEEKLY_PRICE": "NielsenPrice"})
    )

    df_final["IC"] = df_final["SalePrice"] / df_final["NielsenPrice"]
    return df_final


def coalesce_state(df_city: pd.DataFrame, df_state: pd.DataFrame) -> pd.DataFrame:
    df_ic_city = calculate_ic(df_city)
    df_ic_state = calculate_ic(df_state)

    join_cols = ["Affiliate", "Description"]
    df_ic = pd.merge(
        df_ic_state[[*join_cols, "IC", "NielsenPrice"]].rename(
            columns={"IC": "IC_state", "NielsenPrice": "NielsenPrice_state"}
        ),
        df_ic_city,
        how="left",
        on=join_cols,
    )

    df_ic["IC"] = df_ic["IC"].combine_first(df_ic["IC_state"])
    df_ic["NielsenPrice"] = df_ic["NielsenPrice"].combine_first(
        df_ic["NielsenPrice_state"]
    )

    return df_ic


def write_excel(
    fname: str, df_sheets: list[tuple[pd.DataFrame, str]], col_mapping: dict[str, str]
) -> None:
    with pd.ExcelWriter(fname, engine="xlsxwriter") as writer:
        for df, sheet_name in df_sheets:
            df = df.rename(columns=col_mapping)
            df.to_excel(writer, sheet_name=sheet_name, index=False)

            # Get the xlsxwriter workbook and worksheet objects.
            workbook = writer.book
            worksheet = writer.sheets[sheet_name]

            float_cols = [
                i
                for i, type in enumerate(df.dtypes)
                if type == "float" and "%" not in df.columns[i]
            ]
            format1 = workbook.add_format({"num_format": "0.00"})
            for col in float_cols:
                worksheet.set_column(
                    f"{xl_col_to_name(col)}:{xl_col_to_name(col)}", None, format1
                )

            pct_cols = [
                i
                for i, type in enumerate(df.dtypes)
                if type == "float" and "%" in df.columns[i]
            ]

            format2 = workbook.add_format({"num_format": "0.00%"})
            for col in pct_cols:
                worksheet.set_column(
                    f"{xl_col_to_name(col)}:{xl_col_to_name(col)}", None, format2
                )
            worksheet.autofit()


def group_subcategory(df_ic: pd.DataFrame) -> pd.DataFrame:
    return (
        df_ic.groupby(["Affiliate", "Category", "Subcategory"])["IC"]
        .mean()
        .reset_index()
    )


def main():
    load_dotenv()
    client = MongoClient(os.getenv("MONGO_URI"))
    coll = client["nielsen"]["base_vem"]
    conn = config.getDadosAWSSession("producao")

    min_date = datetime(2023, 12, 1)
    max_date = datetime(2024, 1, 2)
    df_products = pd.read_sql_query(
        """
        SELECT
            Product, Affiliate, ProductName AS Description, SalePrice, Issuance,
            Category3 AS Category, Category4 AS Subcategory,
            PackageDescription AS ean, AffiliateCity AS city, AffiliateState AS uf
        FROM Enterprise_Prices_Projection 
        WHERE IsDeletado = 0
        AND IdEnterprisePriceGroups IN (19860,19859,19858,19857,19856)
        """,
        conn,
    )

    df_products.head()

    df_desc = pd.read_csv("./aff_desc.csv", sep=";").rename(
        columns={"Product": "Description"}
    )
    df_desc["Affiliate"] = df_desc["Affiliate"].astype(str)
    print(f"{df_desc.shape = }")
    print(f"{df_products.shape = }")
    df_products = pd.merge(
        df_products, df_desc, on=["Affiliate", "Description"], how="inner"
    )
    print(f"{df_products.shape = }")
    df_products["Issuance"] = df_products["Issuance"].dt.strftime("%d/%m/%Y")

    df_sheets = []
    for format_market in [
        "GAS STATION",
        "CASH AND CARRY",
        "SUPERETTE",
        "SMALL SUPERMARKET",
    ]:
        print(f">> generating with market type {format_market}")
        df_city, df_state = add_nielsen(
            coll, df_products, format_market, min_date, max_date
        )
        df_ic = coalesce_state(df_city, df_state)

        df_ic = df_ic.drop(columns=["IC_state", "NielsenPrice_state"])

        df_sheets.append((df_ic, format_market))

        # NOTE nome da planilha deve ter no máximo 31 caracteres (xlsxwriter)
        df_sheets.append((group_subcategory(df_ic), f"subcat - {format_market}"[:31]))

    col_mapping = {
        "Issuance": "Data da Última Venda",
        "SalePrice": "Preço de Venda",
        "Affiliate": "Filial",
        "Description": "Descrição",
        "ean": "EAN",
        "NielsenPrice": "Média da(s) Moda(s) do Preço dos Competidores",
        "IC": "IC (%)",
        "Category": "Categoria",
        "Subcategory": "Subcategoria",
    }

    write_excel("vem_ic.xlsx", df_sheets, col_mapping)


if __name__ == "__main__":
    main()
