﻿namespace DI.Domain.Models.ImpactReport
{
    public class ImpactRawRequestModel
    {
        public required long CompanyId { get; set; }
        public required List<long> PriceGroupIds { get; set; }

        public string GenerateCacheKey()
        {
            return $"RawReport_{CompanyId}_{string.Join(",", PriceGroupIds.OrderBy(x => x))}";
        }
    }
}
