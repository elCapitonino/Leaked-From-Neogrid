﻿using Repository.Entity;

namespace Repository.EntityRepository
{
    public sealed class ProductMarketResultSellerRepository : GenericRepository<ProductMarketResultSellerEntity>, IProductMarketResultSellerRepository
    {
        public new static string DbContextName => nameof(ApplicationDbContext);
        public ProductMarketResultSellerRepository(ApplicationDbContext dbContext) : base(dbContext)
        {
        }
    }
}
