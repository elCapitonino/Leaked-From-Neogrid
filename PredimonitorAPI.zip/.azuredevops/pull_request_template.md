# Descrição

<!--- Inclua uma descrição sumária das mudanças no PR. Por exemplo, qual problema ele resolve, ou quais funcionalidades ele adiciona. -->

## Tipo de Mudança

<!--- Marque com um 'x' todas as opções aplicáveis: -->

- [ ] Bug fix (correção de bug)
- [ ] Nova funcionalidade (mudança sem quebra de compatibilidade que adiciona funcionalidades)
- [ ] Mudança disruptiva (fix ou funcionalidade que causa mudança de comportamento em funcionalidades existentes)
- [ ] Documentação (somente mudanças na documentação)
- [ ] Outros (especificar)

## Checklist

<!--- Marque com um 'x' todas as opções aplicáveis: -->

- [ ] O código segue o guia de estilo do projeto.
- [ ] Realizei uma revisão do meu próprio código.
- [ ] Documentei meu código conforme necessário.
- [ ] Adicionei testes que cobrem minhas mudanças.
- [ ] Todos os testes novos e existentes passam.
- [ ] Minha mudança requer uma atualização de documentação.
- [ ] Atualizei a documentação conforme necessário.

## Revisão

<!--- Marque com um 'x' todas as opções aplicáveis: -->

### Avaliei o código com base nos princípios do Clean Code:
  - [ ] Nomes de variáveis, funções e classes são claros e descritivos.
  - [ ] Funções são pequenas e realizam apenas uma tarefa.
  - [ ] Não há duplicação de código.
  - [ ] Código é modular e reutilizável.
  - [ ] Comentários são usados apenas quando necessário e são claros e úteis.
  - [ ] Não há código morto ou não utilizado.
  - [ ] Tratamento de erros é realizado de forma adequada.
  - [ ] Código segue os princípios SOLID.
  - [ ] Não há senhas ou credenciais no código
  - [ ] Não há nenhum código chumbado (Hardcoded)

## Outras Informações

<!--- Se necessário, adicione outras informações relevantes para o PR. -->

## Referências

<!--- Se aplicável, adicione links para issues, PRs, ou outras referências relevantes. -->
