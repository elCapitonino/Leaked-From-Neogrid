﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Repository.Entity;

namespace Repository.TypeConfiguration
{
    public sealed class DinPreRuleTypeConfiguration : TypeConfigurationBase<DinPreRuleEntity>, IEntityTypeConfiguration<DinPreRuleEntity>
    {
        public override void Configure(EntityTypeBuilder<DinPreRuleEntity> builder)
        {
            ConfigureTableName(builder, "DinPreRule");
            builder.ToTable("DinPreRule", table => table.ExcludeFromMigrations());
            builder.Ignore(x => x.Id);
            builder.HasKey(x => x.RuleId);
            builder.Property(x => x.Description).HasMaxLength(200);
            builder.Property(x => x.AllowAbcCurve).HasMaxLength(3);
            builder.Property(x => x.RuleId).HasColumnName("IdRule");
            builder.Property(x => x.CreatedDate).HasColumnName("DataHoraCriacao");
            builder.Property(x => x.UpdatedDate).HasColumnName("DataHoraUltimaAlteracao");
        }
    }
}
