﻿using DI.Repository.Entities;
using DI.Repository.Enum;

namespace DI.Repository.Interfaces.Repositories
{
    public interface IMonthlyImpactDataRepository
    {
        IEnumerable<MonthlyImpactDataEntity> GetAll(long CompanyId, int startYearMonth, int endYearMonth, MonthlyImpactDataType dataType);
        Task<IEnumerable<MonthlyImpactDataEntity>> GetAll(long CompanyId, int YearMonth, MonthlyImpactDataType dataType, CancellationToken cancellationToken);
    }
}