﻿using Domain.BackgroundTasks.Models;
using Domain.Models;
using Services.PredifyAPI.Models;
using Services.SearchAPI.Models;

namespace PredimonitorAPI.Extensions
{
    public static class OptionsExtensions
    {
        public static IServiceCollection AddCustomOptions(this IServiceCollection services, IConfiguration configuration)
        {
            services.Configure<AppsettingsOptions>(configuration);
            services.Configure<PredifyAPIOptions>(configuration.GetSection("Services").GetSection("PredifyAPI"));
            services.Configure<SearchAPIOptions>(configuration.GetSection("Services").GetSection("SearchAPI"));
            services.Configure<QueueServiceOptions>(configuration.GetSection("BackgroundServices").GetSection("Queue"));
            services.Configure<IndexGeneratorStatusServiceOptions>(configuration.GetSection("BackgroundServices").GetSection("IndexGeneratorStatus"));
            return services;
        }
    }
}
