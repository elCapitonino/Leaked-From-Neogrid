﻿using System.Text.Json.Serialization;

namespace PredifyClientAPI.Services.PredimonitorAPI.DynamicFilter.Models
{
    public class DynamicFilterResponse
    {
        public IEnumerable<ProductData> Products { get; set; }
        public IEnumerable<string?>? Categories { get; set; }
        public IEnumerable<string?>? Sellers { get; set; }
        public IEnumerable<string?>? Brands { get; set; }
        public IEnumerable<string?>? States { get; set; }
        public IEnumerable<string?>? Years { get; set; }
        public IEnumerable<string>? Origins { get; set; }
    }

    public class ProductData
    {
        public string ProductName { get; set; }
        public long IdMonitoringItem { get; set; }
        public bool Selected { get; set; }

        [JsonIgnore]
        public int CrawlerId { get; set; }
    }
}
