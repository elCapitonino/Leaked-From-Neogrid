﻿using PredifyClientAPI.Services.DataInsightAPI.DataImpact.Models;

namespace PredifyClientAPI.Services.DataInsightAPI.DataImpact
{
    public interface IImpactDataService
    {
        Task<IEnumerable<GranularityGroupResponse>> GetGranularities(long companyId);
        Task<IEnumerable<MonthlyImpactDataResponse>> GetMonthlyImpactData(long companyId, int startDate, int endDate);
        Task<IEnumerable<ProjectionImpactDataResponse>> GetProjectionImpactData(long companyId, long priceGroupId);
    }
}
