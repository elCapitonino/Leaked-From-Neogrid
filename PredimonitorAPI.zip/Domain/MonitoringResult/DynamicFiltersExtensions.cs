﻿using Domain.MonitoringResult.Models;
using Microsoft.EntityFrameworkCore;
using Repository.Entity;
using Repository.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.MonitoringResult
{
    public static class DynamicFiltersExtensions
    {
        public static IQueryable<MonitoringItemResultsEntity> ApplyFilters(this IQueryable<MonitoringItemResultsEntity> query, DynamicFilterRequest request, long? companyId, RequestFilterType filterProduct = RequestFilterType.None)
        {

            query = query.Where(x => !x.MonitoringItem.IsDeleted);

            if (companyId.HasValue)
            {
                query = query.Where(p => p.CompanyId == companyId);
            }

            if (filterProduct != RequestFilterType.Product && request.ProductNames != null && request.ProductNames.Any())
            {
                var productNames = request.ProductNames.Select(x => x.ToUpper()).Distinct().ToHashSet();
                query = query.Where(p => productNames.Any(x => p.MonitoringItem.Description.ToUpper().Contains(x)));
            }

            if (filterProduct != RequestFilterType.Product && request.MonitoringItemIds != null && request.MonitoringItemIds.Any())
            {
                var monitoringItemIds = request.MonitoringItemIds.Distinct().ToHashSet();
                query = query.Where(p => monitoringItemIds.Contains(p.MonitoringItemId));
            }

            if (filterProduct != RequestFilterType.Category && request.Categories != null && request.Categories.Any())
            {
                var categories = request.Categories.Select(x => x.ToUpper()).Distinct().ToHashSet();
                query = query.Where(p => categories.Contains(p.Category.ToUpper()));
            }

            if (filterProduct != RequestFilterType.Seller && request.Sellers != null && request.Sellers.Any())
            {
                var sellers = request.Sellers.Select(x => x.ToUpper()).Distinct().ToHashSet();
                query = query.Where(p => sellers.Contains(p.Seller.ToUpper()));
            }

            if (filterProduct != RequestFilterType.Brand && request.Brands != null && request.Brands.Any())
            {
                var brands = request.Brands.Select(x => x.ToUpper()).Distinct().ToHashSet();
                query = query.Where(p => brands.Contains(p.Brand.ToUpper()));
            }

            if (filterProduct != RequestFilterType.State && request.States != null && request.States.Any())
            {
                var states = request.States.Select(x => x.ToUpper()).Distinct().ToHashSet();
                query = query.Where(p => states.Contains(p.State.ToUpper()));
            }

            if (filterProduct != RequestFilterType.Year && request.Years != null && request.Years.Any())
            {
                var yearSet = request.Years.Distinct().ToHashSet();
                query = query.Where(p => yearSet.Contains(p.Year));
            }

            if (filterProduct != RequestFilterType.Model && request.Models != null && request.Models.Any())
            {
                var modelSet = request.Models.Distinct().ToHashSet();
                query = query.Where(p => modelSet.Contains(p.Model));
            }

            if (filterProduct != RequestFilterType.Origin && request.Origins != null && request.Origins.Any())
            {
                var origins = request.Origins.Select(x => x.ToUpper()).Distinct().ToHashSet();
                query = query.Where(p => origins.Contains(p.MonitoringCrawler.Description.ToUpper()));
            }
            query.TagWith($"ApplyFilters_{companyId}");
            return query;
        }
    }
}
