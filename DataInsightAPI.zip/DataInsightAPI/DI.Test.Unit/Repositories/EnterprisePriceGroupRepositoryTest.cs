﻿using DI.Repository.Interfaces;

namespace DI.Test.Unit.Repositories
{
    public class EnterprisePriceGroupRepositoryTest
    {
        private readonly IUnitOfWork _unitOfWork;

        public EnterprisePriceGroupRepositoryTest(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        [Fact]
        public void TestGetById_ValidId()
        {
            long priceGroupId = 500;
            var getPriceGroup = _unitOfWork.EnterprisePriceGroupRepository.GetById(priceGroupId);

            Assert.NotNull(getPriceGroup);
            Assert.Equal(priceGroupId, getPriceGroup.EnterprisePriceGroupsId);
        }

        [Fact]
        public void TestGetById_InvalidId()
        {
            long invalidPriceGroupId = -1;
            Assert.Throws<InvalidOperationException>(() =>
            {
                var getPriceGroup = _unitOfWork.EnterprisePriceGroupRepository.GetById(invalidPriceGroupId);
            });
        }

        [Fact]
        public void TestGetById_NonExistentId()
        {
            long nonExistentPriceGroupId = 000;

            Assert.Throws<InvalidOperationException>(() =>
            {
                var getPriceGroup = _unitOfWork.EnterprisePriceGroupRepository.GetById(nonExistentPriceGroupId);
            });
        }

        [Fact]
        public void TestGetCompany_DetailsAsync()
        {
            long priceGroupId = 500;
            var getPriceGroup = _unitOfWork.EnterprisePriceGroupRepository.GetById(priceGroupId);

            Assert.NotNull(getPriceGroup);
            Assert.NotNull(getPriceGroup.Name);
            Assert.NotEqual(0, getPriceGroup.CompanyId);
        }

        [Fact]
        public async Task TestGetAllById_ValidIds()
        {

            var validPriceGroupIds = new List<long> { 500, 501 };
            var result = await _unitOfWork.EnterprisePriceGroupRepository.GetAllById(validPriceGroupIds);

            Assert.NotNull(result);
            Assert.True(result.Any(), "Expected to have results, but got none.");
            Assert.Contains(result, x => x.EnterprisePriceGroupsId == 500);
            Assert.Contains(result, x => x.EnterprisePriceGroupsId == 501);
        }

        [Fact]
        public async Task TestGetAllById_InvalidIds()
        {
            var invalidPriceGroupIds = new List<long> { -1, -2 };

            var result = await _unitOfWork.EnterprisePriceGroupRepository.GetAllById(invalidPriceGroupIds);

            Assert.NotNull(result);
            Assert.Empty(result);
        }

        [Fact]
        public async Task TestGetAllById_EmptyList()
        {
            var emptyPriceGroupIds = new List<long>();
            var result = await _unitOfWork.EnterprisePriceGroupRepository.GetAllById(emptyPriceGroupIds);

            Assert.NotNull(result);
            Assert.Empty(result);
        }

        [Fact]
        public async Task TestGetAllById_SomeIdsNotFound()
        {
            var someIdsNotFound = new List<long> { 500, 0000 };

            var result = await _unitOfWork.EnterprisePriceGroupRepository.GetAllById(someIdsNotFound);

            Assert.NotNull(result);
            Assert.Single(result);
            Assert.Contains(result, x => x.EnterprisePriceGroupsId == 500);
        }
    }
}