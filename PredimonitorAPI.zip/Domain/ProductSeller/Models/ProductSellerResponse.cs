namespace Domain.ProductSeller.Models
{
    public class ProductSellerResponse
    {
        public IEnumerable<ProductSellerPricesResponse>? SellerPrices { get; set; }
        public int TotalCount { get; set; }
    }

    public class ProductSellerPricesResponse
    {
        public string? PriceId { get; set; }
        public string? Name { get; set; }
        public string? Link { get; set; }
        public string? Brand { get; set; }
        public string? Origin { get; set; }
        public string? CrawlerName { get; set; }
        public string? SellerGroup { get; set; }
        public decimal Price { get; set; }
        public DateTime Date { get; set; }
    }
}