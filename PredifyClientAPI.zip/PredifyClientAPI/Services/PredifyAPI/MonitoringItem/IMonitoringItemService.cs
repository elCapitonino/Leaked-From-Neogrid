﻿using PredifyClientAPI.Services.PredifyAPI.Models;
using PredifyClientAPI.Services.PredifyAPI.MonitoringItem.Models;

namespace PredifyClientAPI.Services.PredifyAPI.MonitoringItem
{
    public interface IMonitoringItemService
    {
        Task<GeneralResponse<IEnumerable<MonitoringItemResponse>>> ListMonitoringItem(ListMonitoringItemRequest request);
        Task<GeneralResponse<PaginationResponse<MonitoringItemResponse>>> ListMonitoringItemResponsePaginated(ListMonitoringItemPaginatedRequest resquest);
    }
}
