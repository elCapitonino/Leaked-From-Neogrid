﻿using Microsoft.Extensions.Caching.Memory;

namespace DI.API.Utils.Cache
{
    public interface ICacheService
    {
        void ClearAll();
        void Set<TItem>(object key, TItem value, MemoryCacheEntryOptions? options = null);
        TItem Get<TItem>(object key);
        void Remove(object key);
    }
}
