﻿namespace DI.Repository.Enum
{
    public enum EGranularityType
    {
        None = 0,
        Projection = 1,
        Elasticity = 2,
        ImpactConsolidateReport = 3,
    }
}
