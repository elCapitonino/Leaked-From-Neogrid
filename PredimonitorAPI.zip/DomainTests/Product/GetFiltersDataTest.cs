using Domain.CompanyMonitoringCrawler;
using Domain.Filter;
using Domain.Filter.Models;
using Domain.MonitoringResult;
using Domain.Product;
using Domain.Status;
using DomainTests.DynamicFilter.Seed;
using DomainTests.Extensions;
using DomainTests.Product.Seed;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.DependencyInjection;
using MongoDB.Driver;
using Moq;
using Repository.DbContexts;
using Repository.Entity;
using Repository.UnitOfWork;
using System;

namespace DomainTests.Product;

//[TestClass()]
public class GetFiltersDataTest
{
    private IServiceCollection _services;
    private ServiceProvider _serviceProvider;

    //[TestInitialize]
    public void Initialize()
    {
        _services = new ServiceCollection();
        var mongo = new Mock<MongoClient>().Object;

        _services.AddTransient<IMongoClient>(provider => mongo);
        _services.SetAutoMapper();

        _services.AddDbContext<ApplicationDbContext>(options => options.UseSqlite("Filename=:memory:").ConfigureWarnings(opt => opt.Ignore(RelationalEventId.AmbientTransactionWarning)));

        _services.AddDbContext<HorusDbContext>(options => options.UseMongoDB(mongo, "Horus").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
        _services.AddDbContext<InfoPriceSaoJoaoDbContext>(options => options.UseMongoDB(mongo, "InfroPriceSaoJoao").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
        _services.AddDbContext<NormalizerDbContext>(options => options.UseMongoDB(mongo, "Normalizer").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
        _services.AddDbContext<LinxDbContext>(options => options.UseMongoDB(mongo, "Linx").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
        _services.AddDbContext<NeogridDbContext>(options => options.UseMongoDB(mongo, "Neogrid").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
        _services.AddDbContext<NielsenDbContext>(options => options.UseMongoDB(mongo, "Nielsen").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
        _services.AddDbContext<SmarketCompetitorDbContext>(options => options.UseMongoDB(mongo, "SmarketCompetitor").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
        _services.AddDbContext<OfflineDbContext>(options => options.UseMongoDB(mongo, "Offline").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);

        _services.AddTransient(provider => new DatabricsDbContext("Driver=Simba Spark ODBC Driver;Host=adb-1165720697464401.1.azuredatabricks.net;Port=443;HTTPPath=/sql/1.0/warehouses/bb3e5168ee7e6ca6;SSL=1;ThriftTransport=2;AuthMech=3;UID=token;PWD=dapib21631ae7a26d105f43b29d37237aa34;Timeout=30", "predimonitor_test"));

        _services.AddScoped<IMonitoringResultDomain, MonitoringResultDomain>();
        _services.AddScoped<ICompanyMonitoringCrawlerDomain, CompanyMonitoringCrawlerDomain>();
        _services.AddScoped<IStatusDomain, StatusDomain>();
        _services.AddScoped<IFilterDomain, FilterDomain>();
        _services.AddMemoryCache();

        _services.AddScoped<IUnitOfWork, UnitOfWork>();
        _services.AddLogging();

        _serviceProvider = _services.BuildServiceProvider();

        var context = _serviceProvider.GetRequiredService<ApplicationDbContext>();
        context.Database.OpenConnection();
        context.Database.EnsureCreated();

        RemoveOldTestData(_serviceProvider.GetService<IUnitOfWork>()!);

    }

    private void RemoveOldTestData(IUnitOfWork uow)
    {
        uow.ProductRepository.ExecuteSQL("DELETE FROM predimonitor_test.products");
        uow.ProductSellerRepository.ExecuteSQL("DELETE FROM predimonitor_test.product_sellers");
        uow.ProductPriceRepository.ExecuteSQL("DELETE FROM predimonitor_test.product_prices");
        uow.IgnoredPriceRepository.ExecuteSQL("DELETE FROM predimonitor_test.ignored_prices");
    }

    private ProductTestData GenerateTestData(IUnitOfWork uow, int crawlerId, bool generateIgnored = false)
    {
        uow.Company.AddRange(CompanySeed.GetTestData(), autosave: true);

        uow.MonitoringCrawler.Create(new MonitoringCrawlerEntity { Id = crawlerId, Description = "Teste" }, autosave: true);

        var companyCrawlers = new List<CompanyMonitoringCrawlerEntity>()
        {
            new CompanyMonitoringCrawlerEntity{
                Id = 1,
                MonitoringCrawlerId = crawlerId,
                CompanyId = 1,
                IsDeleted = false,
                IsCost = true,
                IsSale = true
            }
        };

        uow.CompanyMonitoringCrawler.AddRange(companyCrawlers, autosave: true);

        var testData = ProductSeed.GetProductTestData(crawlerId);

        uow.ProductRepository.Insert(testData.Products);
        uow.ProductSellerRepository.Insert(testData.Sellers);
        uow.ProductPriceRepository.Insert(testData.Prices);

        if (generateIgnored)
        {
            uow.IgnoredPriceRepository.Insert(testData.IgnoredPrices);
        }

        return testData;
    }

    //[TestMethod()]
    public void GetFilterShouldReturnAllData()
    {
        var uow = _serviceProvider.GetService<IUnitOfWork>()!;
        var domain = _serviceProvider.GetService<IFilterDomain>()!;

        var testData = GenerateTestData(uow, 9101);

        var request = new FilterRequest()
        {
            CompanyId = 1,
            Take = 100
        };

        var result = domain.GetFilters(request).Result;

        var products = testData.Products.Select(x => x.Name).Distinct().ToList();
        var categories = testData.Sellers.Select(x => x.Category).Distinct().ToList();
        var origins = testData.Products.Select(x => x.CrawlerId).Distinct().ToList();
        var sellerGroups = testData.Sellers.Select(x => x.SellerGroup).Distinct().ToList();
        var brands = testData.Products.Select(x => x.Brand).Distinct().ToList();
        var regions = testData.Sellers.Select(x => x.Region).Distinct().ToList();
        var states = testData.Sellers.Select(x => x.UF).Distinct().ToList();
        var segments = testData.Sellers.Select(x => x.Segment).Distinct().ToList();

        Assert.AreEqual(result.Products.Count(), products.Count(), "Não retornou os produtos esperados");
        Assert.AreEqual(result.Categories.Count(), categories.Count(), "Não retornou as categorias esperadas");
        Assert.AreEqual(result.Origins.Count(), origins.Count(), "Não retornou as origens esperadas");
        Assert.AreEqual(result.Sellers.Count(), sellerGroups.Count(), "Não retornou os sellers group esperados");
        Assert.AreEqual(result.Brands.Count(), brands.Count(), "Não retornou as marcas esperadas");
        Assert.AreEqual(result.Regions.Count(), regions.Count(), "Não retornou as regiões esperadas");
        Assert.AreEqual(result.States.Count(), states.Count(), "Não retornou os estados esperados");
        Assert.AreEqual(result.Segments.Count(), segments.Count(), "Não retornou os segmentos esperados");
    }

    //[TestMethod()]
    public void GetFilterShouldReturnDataFilteredByProductAndBrand()
    {
        var uow = _serviceProvider.GetService<IUnitOfWork>()!;
        var domain = _serviceProvider.GetService<IFilterDomain>()!;

        var testData = GenerateTestData(uow, 9102);

        var request = new FilterRequest()
        {
            CompanyId = 1,
            ProductNames = ["Maçã"],
            Brands = ["Fazenda XV"],
            Take = 100
        };

        var result = domain.GetFilters(request).Result;

        var products = testData.Products.Where(x => x.Name == "Maçã" && x.Brand == "Fazenda XV").ToList();
        var productsIds = products.Select(x => x.Id).Distinct().ToList();
        //var productsNames = products.Select(x => x.Name).Distinct().ToList();

        var categories = testData.Sellers.Where(x => productsIds.Contains(x.ProductId)).Select(x => x.Category).Distinct().ToList();
        var origins = testData.Products.Where(x => productsIds.Contains(x.Id)).Select(x => x.CrawlerId).Distinct().ToList();
        var sellerGroups = testData.Sellers.Where(x => productsIds.Contains(x.ProductId)).Select(x => x.SellerGroup).Distinct().ToList();
        var brands = testData.Products.Where(x => productsIds.Contains(x.Id)).Select(x => x.Brand).Distinct().ToList();
        var regions = testData.Sellers.Where(x => productsIds.Contains(x.ProductId)).Select(x => x.Region).Distinct().ToList();
        var states = testData.Sellers.Where(x => productsIds.Contains(x.ProductId)).Select(x => x.UF).Distinct().ToList();
        var segments = testData.Sellers.Where(x => productsIds.Contains(x.ProductId)).Select(x => x.Segment).Distinct().ToList();

        //Assert.AreEqual(result.Products.Count(), productsNames.Count(), "Não retornou os produtos esperados");
        Assert.AreEqual(result.Categories.Count(), categories.Count(), "Não retornou as categorias esperadas");
        Assert.AreEqual(result.Origins.Count(), origins.Count(), "Não retornou as origens esperadas");
        Assert.AreEqual(result.Sellers.Count(), sellerGroups.Count(), "Não retornou os sellers group esperados");
        //Assert.AreEqual(result.Brands.Count(), brands.Count(), "Não retornou as marcas esperadas");
        Assert.AreEqual(result.Regions.Count(), regions.Count(), "Não retornou as regiões esperadas");
        Assert.AreEqual(result.States.Count(), states.Count(), "Não retornou os estados esperados");
        Assert.AreEqual(result.Segments.Count(), segments.Count(), "Não retornou os segmentos esperados");
    }

    // [TestMethod()]
    public void GetFilterShouldReturnDataFilteredByCategory()
    {
        var uow = _serviceProvider.GetService<IUnitOfWork>()!;
        var domain = _serviceProvider.GetService<IFilterDomain>()!;

        var testData = GenerateTestData(uow, 9103);

        var request = new FilterRequest()
        {
            CompanyId = 1,
            Categories = ["Padarias"],
            Take = 100
        };

        var result = domain.GetFilters(request).Result;

        var categories = testData.Sellers.Where(x => x.Category == "Padarias").ToList();
        var categoriesProductIds = categories.Select(x => x.ProductId).ToList();
        var categoriesNames = categories.Select(x => x.Category).Distinct().ToList();

        var products = testData.Products.Where(x => categoriesProductIds.Contains(x.Id)).ToList();
        var productsIds = products.Select(x => x.Id).Distinct().ToList();
        var productsNames = products.Select(x => x.Name).Distinct().ToList();

        var origins = testData.Products.Where(x => productsIds.Contains(x.Id)).Select(x => x.CrawlerId).Distinct().ToList();
        var sellerGroups = testData.Sellers.Where(x => productsIds.Contains(x.ProductId)).Select(x => x.SellerGroup).Distinct().ToList();
        var brands = testData.Products.Where(x => productsIds.Contains(x.Id)).Select(x => x.Brand).Distinct().ToList();
        var regions = testData.Sellers.Where(x => productsIds.Contains(x.ProductId)).Select(x => x.Region).Distinct().ToList();
        var states = testData.Sellers.Where(x => productsIds.Contains(x.ProductId)).Select(x => x.UF).Distinct().ToList();
        var segments = testData.Sellers.Where(x => productsIds.Contains(x.ProductId)).Select(x => x.Segment).Distinct().ToList();

        Assert.AreEqual(result.Products.Count(), productsNames.Count(), "Não retornou os produtos esperados");
        //Assert.AreEqual(result.Categories.Count(), categoriesNames.Count(), "Não retornou as categorias esperadas");
        Assert.AreEqual(result.Origins.Count(), origins.Count(), "Não retornou as origens esperadas");
        Assert.AreEqual(result.Sellers.Count(), sellerGroups.Count(), "Não retornou os sellers group esperados");
        Assert.AreEqual(result.Brands.Count(), brands.Count(), "Não retornou as marcas esperadas");
        Assert.AreEqual(result.Regions.Count(), regions.Count(), "Não retornou as regiões esperadas");
        Assert.AreEqual(result.States.Count(), states.Count(), "Não retornou os estados esperados");
        Assert.AreEqual(result.Segments.Count(), segments.Count(), "Não retornou os segmentos esperados");
    }

    //[TestMethod()]
    public void GetFilterShouldReturnPaginatedProduct()
    {
        var uow = _serviceProvider.GetService<IUnitOfWork>()!;
        var domain = _serviceProvider.GetService<IFilterDomain>()!;

        var testData = GenerateTestData(uow, 9104);

        var request = new FilterRequest()
        {
            CompanyId = 1,
            Page = 2,
            Take = 2
        };

        var result = domain.GetFilters(request).Result;

        var products = testData.Products.OrderBy(x => x.Name).Skip(2).Take(2).Select(x => x.Name).Distinct().ToList();

        Assert.AreEqual(result.Products.Count(), products.Count(), "Não retornou os produtos esperados");
    }
}