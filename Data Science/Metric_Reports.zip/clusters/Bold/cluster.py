#%%
# Import necessary libraries
import numpy as np
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.cluster import KMeans
from sklearn.neighbors import KNeighborsRegressor
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
import pandas as pd
from sklearn.model_selection import cross_val_score, KFold
from sklearn.metrics import make_scorer, mean_squared_error, mean_absolute_error,silhouette_score
from sklearn.preprocessing import LabelEncoder
import seaborn as sns
#%%
pd.set_option("display.max_rows", None, "display.max_columns", None)
#%%
def mean_absolute_percentage_error(y_true, y_pred): 
    y_true, y_pred = np.array(y_true), np.array(y_pred)
    return np.mean(np.abs((y_true - y_pred) / y_true)) * 100

def elbow_method(df, target):
    inertia_score = []

    for i in range(1,11):
        pipeline = Pipeline( [
        ('scalar', StandardScaler()),
        ('kmeans', KMeans(n_clusters = i, random_state=42))
        ])
        pipeline.fit(df[[i for i in target]])
        inertia_score.append(pipeline[-1].inertia_)

    # Plot the elbow curve using silhouette scores
    plt.plot(range(1,11), inertia_score)
    plt.title('Elbow Curve for K-Means Clustering')
    plt.xlabel('Number of Clusters')
    plt.ylabel('Inertia Score')
    plt.show()


def clusters_run(df, target, n_clusters):
    pipeline = Pipeline( [
        ('scalar', StandardScaler()),
        ('kmeans', KMeans(n_clusters = n_clusters, random_state=42))
    ])
    
    pipeline.fit(df[[i for i in target]])
    new_colunm = 'Clusters'
    # pipeline.labels_
    df[new_colunm] = pipeline[-1].labels_
    return df

# %%
df = pd.read_excel('./Base Pedidos_Historico_26022024.xlsx')
#%%
df.head()
#%%
df.shape
# %%
df.dtypes
# %%
df.describe()
# %%
df.info()
# %%
df.isnull().sum()
# %%
df = df[df['Valor Faturado']>0]
# %%
df['Custo'] = df['FATMIN_VAL_CUSTO_INSUMOS'] +  df['FATMIN_VAL_CUSTO_PROCESSOS']
df = df[df['Custo']>0]
# %%
print(df.shape[0])
df = df[df['Valor Faturado']>1]
print(df.shape[0])
# %%
df['Margem'] = ((df['Valor Faturado'].divide(df['Custo']))-1)*100
print(df.shape[0])
df = df[df['Margem']>-90]
print(df.shape[0])
df = df[df['Margem']<1000]
print(df.shape[0])

#%%
df['Margem'].describe()
#%%
print(df.shape[0])
df = df[df['% Desconto']>-150]
print(df.shape[0])
# %%
df[['Valor Faturado','Custo','Margem']].describe()
# %%
df.head()
# %%
df_cliente_sem_d = df[df['% Desconto']!=0] 
# %%
df_cliente_sem_d = df_cliente_sem_d.groupby(by='Nome Cliente').agg({'% Desconto': 'mean'})


# %%
df_cliente_sem_d.head()
# %%
df_cliente_sem_d['% Desconto'].describe()
# %%
df_cliente['% Desconto_mean'].describe()
# %%
df_cliente = df.groupby(by='Nome Cliente').agg({'Valor Faturado': ['mean','sum'], '% Desconto': 'mean', 'Margem': 'mean', 'Quantidade': 'sum'})

# %%
df_cliente.columns = [col[0] + '_' + col[1] if col[1] else col[0] for col in df_cliente.columns]
# %%
df_cliente.reset_index(inplace=True)
# %%
display(df_cliente.head())
# %%
df_cliente_final = df_cliente.join(df_cliente_sem_d, on='Nome Cliente', how='left')
# %%
df_cliente_final = df_cliente_final.drop(columns=['% Desconto_mean'])
#%%
df_cliente_final['% Desconto'].fillna(0, inplace=True)
#%%
df_cliente_final['Valor Faturado_sum'].describe()
# %%
df.loc[df['Marca']=='Bold Indústria', 'Margem'].describe()
# %%
df.loc[df['Marca']=='Bold Varejo', 'Margem'].describe()
# %%
elbow_method(df_cliente_final, ['Margem_mean', 'Valor Faturado_mean', '% Desconto'])
# %%
df_cliente_final = clusters_run(df_cliente_final, ['Margem_mean', 'Valor Faturado_mean', '% Desconto'], 3)
# %%
mapping = {2: 'Bronze', 1: 'Gold', 0: 'Prata'}
df_cliente_final['Clusters'] = df_cliente_final['Clusters'].replace(mapping)
# %%
df_cliente_final.rename(columns={'Valor Faturado_mean': 'Média Valor Faturado', 'Margem_mean': 'Margem', 'Valor Faturado_sum': 'Valor Faturado Total'}, inplace=True)
# %%
df_cliente_final.head()
#%%
df_cliente_final.groupby('Clusters')[['Média Valor Faturado']].describe()
# %%
df_cliente_final.groupby('Clusters')[['Valor Faturado Total']].describe()
# %%
df_cliente_final.groupby('Clusters')[['Margem']].describe()
# %%
df_cliente_final.groupby('Clusters')[['% Desconto']].describe()

# %%
x='Margem'
y='% Desconto'
sns.scatterplot(df_cliente_final, x=x, y=y, hue='Clusters', s=100)

plt.title('Scatter Plot para Clusters')
plt.xlabel(x)
plt.ylabel(y)
plt.legend(title='Cluster Labels')

plt.show()

#%%
df_cliente_final.to_csv('cluster_clientes.csv', sep=';', index=False)
# %%
df.head()
# %%
df_cliente_final[['Nome Cliente','Clusters', '% Desconto']].sample(15)

# %%
cross_tab_result = pd.crosstab(df["Clusters"], df["Empresa"], normalize='index') * 100

# Calculate the sum of each column
column_sums = cross_tab_result.sum()

# Sort columns in descending order based on sum values
sorted_columns = column_sums.sort_values(ascending=False).index

# Reorder the columns in the crosstab
cross_tab_result_ordered = cross_tab_result[sorted_columns]

# Display the result
display(cross_tab_result_ordered)

# %%
cluster = 'Bronze'
column_name = 'Empresa'

df_cluster = df[df['Clusters']==cluster]
# Get the value counts and sort them in descending order
df_faturamento = df_cluster.groupby(by=column_name).agg({'Valor Faturado':'sum','Margem': 'mean','% Desconto': 'mean'}).sort_values(by='Valor Faturado', ascending=False)[:10]

df_faturamento['% Representatividade'] = df_faturamento['Valor Faturado'].div(df_faturamento['Valor Faturado'].sum())*100

df_faturamento = df_faturamento.drop(columns='Valor Faturado')

df_faturamento_melted = df_faturamento.reset_index().melt(id_vars=[column_name], var_name='Metric')


plt.figure(figsize=(8, 12))
ax = sns.barplot(x='value', y=column_name, hue='Metric', data=df_faturamento_melted)

plt.xlabel('Valor (%)')
plt.ylabel(column_name)
plt.title(f'Cluster {cluster} - Gráfico de Valor Faturado Relativo % VS % Desconto Por {column_name}')

plt.legend()

for p in ax.patches:
    ax.annotate(f'{p.get_width():.1f}', (p.get_width() + 1, p.get_y() + p.get_height() / 2), ha='center', va='center')
# Show the plot
plt.show()

# %%
cross_tab_result = pd.crosstab(df["Valor Faturado Cluster"], df[column_name], normalize = 'index') * 100

# Calculate the sum of each column
column_sums = cross_tab_result.sum()

# Sort columns in descending order based on sum values
sorted_columns = column_sums.sort_values(ascending=False).index

# Reorder the columns in the crosstab
cross_tab_result_ordered = cross_tab_result[sorted_columns]

# Display the result
display(cross_tab_result_ordered)

#%%
x='Empresa'
y='% Desconto'

df_sorted = df.sort_values(by=y)

plt.figure(figsize=(10, 10))
sns.scatterplot(df, x=y, y=x, s=100)

plt.title(f'Scatter Plot p/ {x} vs {y}')
plt.xlabel(y)
plt.ylabel(x)


plt.show()

# %%
