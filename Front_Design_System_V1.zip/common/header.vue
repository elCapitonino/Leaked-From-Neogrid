<template>
  <v-app-bar app color="var(--very-light-gray)">
    <v-app-bar-nav-icon
      @click="showOrHideMenu()"
      v-show="$vuetify.breakpoint.smAndDown"
    >
    </v-app-bar-nav-icon>
    <v-spacer></v-spacer>
    <template>
      <v-menu offset-y>
        <template v-slot:activator="{ on, attrs }">
          <v-btn color="primary" plain v-bind="attrs" v-on="on" fab small>
            <v-icon>mdi-translate</v-icon>
          </v-btn>
        </template>
        <v-item-group v-model="lang">
          <v-container>
            <v-row v-for="item in supportedLanguages" :key="item.code">
              <v-item v-slot="{ active, toggle }" :value="item.code">
                <v-btn
                  :color="active ? 'primary' : ''"
                  block
                  elevation="0"
                  @click="toggle"
                  class="justify-start"
                >
                  <v-img
                    class="mr-2"
                    height="12px"
                    max-width="16px"
                    width="16px"
                    :src="`/images/icons/flags/${item.flag}.svg`"
                  />
                  {{ item.text }}
                </v-btn>
              </v-item>
            </v-row>
          </v-container>
        </v-item-group>
      </v-menu>
    </template>
    <div class="mr-5">
      <v-btn color="primary" plain fab small>
        <v-icon color="#B00020">mdi-alert-outline</v-icon>
      </v-btn>
      <v-btn color="primary" plain fab small>
        <v-icon color="#000">mdi-bell-outline</v-icon>
      </v-btn>
      <v-btn color="primary" plain fab small>
        <router-link to="/main/user/user-profile">
          <v-icon color="#000">mdi-account-circle-outline</v-icon>
        </router-link>
      </v-btn>
    </div>
  </v-app-bar>
</template>

<script>
import { mapGetters } from "vuex";
export default {
  name: "headerComponent",

  data: function () {
    const lang = localStorage.getItem("lang") || "en-US";
    return {
      lang,
      supportedLanguages: [
        { text: "English", code: "en-US", flag: "us" },
        { text: "Español", code: "es-ES", flag: "es" },
        { text: "Português", code: "pt-BR", flag: "br" },
      ],
    };
  },
  watch: {
    lang(newLang) {
      localStorage.setItem("lang", newLang);
      window.location.reload();
    },
  },
  methods: {
    showOrHideMenu() {
      this.$emit("showOrHideMenu");
    },
  },
  computed: {
    ...mapGetters(["hasUser"]),
  },
  //APAGAR APOS MOSTRAR PARA O TIME
  mounted() {
    console.log("SELECT DEFAULT", this.lang);
  },
};
</script>
<style scoped lang="scss"></style>
