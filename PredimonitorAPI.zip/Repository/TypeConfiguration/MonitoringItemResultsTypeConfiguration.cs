﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Repository.Attributes;
using Repository.DbContexts;
using Repository.Entity;

namespace Repository.TypeConfiguration
{
    [DbContextTypeConfiguration(typeof(ApplicationDbContext))]
    public class MonitoringItemResultsTypeConfiguration : TypeConfigurationBase<MonitoringItemResultsEntity>, IEntityTypeConfiguration<MonitoringItemResultsEntity>
    {
        public override void Configure(EntityTypeBuilder<MonitoringItemResultsEntity> builder)
        {
            ConfigureTableName(builder, "MonitoringItem_Results");

            builder.Property(p => p.Id).IsRequired().HasColumnName("IdMonitoringItem_Results");
            builder.Property(p => p.MonitoringItemId).IsRequired().HasColumnName("IdMonitoringItem");
            builder.Property(p => p.CompanyId).IsRequired().HasColumnName("IdCompany");
            builder.Property(p => p.CrawlerId).IsRequired().HasColumnName("IdCrawler");
            builder.Property(p => p.Hash).HasMaxLength(256);
            builder.Property(p => p.Seller).HasMaxLength(256);
            builder.Property(p => p.Brand).HasMaxLength(256);
            builder.Property(p => p.State).HasMaxLength(256);
            builder.Property(p => p.Year).HasMaxLength(256);
            
            
            builder.HasOne(p => p.Company).WithMany().HasForeignKey(p => p.CompanyId);
            builder.HasOne(p => p.MonitoringItem).WithMany().HasForeignKey(p => p.MonitoringItemId);
            builder.HasOne(p => p.MonitoringCrawler).WithMany().HasForeignKey(p => p.CrawlerId);
        }
    }
}
