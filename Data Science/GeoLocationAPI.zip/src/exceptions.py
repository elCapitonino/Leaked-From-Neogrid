from fastapi import HTTPException


class ExternalAPIError(HTTPException):
    """Raise when there is an external API error."""

    def __init__(self):
        super().__init__(status_code=500, detail="External address API request failed")


class NoCoordinateFound(HTTPException):
    """Raise when no coordinate is found."""

    def __init__(self):
        super().__init__(
            status_code=500, detail="No coordinates found for this address"
        )


class MaxRetriesExceeded(HTTPException):
    """Raise when an address has exhausted the maximum number of retries."""

    def __init__(self):
        super().__init__(
            status_code=500, detail="Max retries with errors reached for this address"
        )
