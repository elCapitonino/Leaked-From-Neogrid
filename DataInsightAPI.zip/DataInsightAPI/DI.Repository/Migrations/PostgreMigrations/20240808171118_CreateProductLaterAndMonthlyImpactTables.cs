﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DI.Repository.Migrations.PostgreMigrations
{
    /// <inheritdoc />
    public partial class CreateProductLaterAndMonthlyImpactTables : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "MonthlyImpactData",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false, defaultValueSql: "uuid_generate_v4()"),
                    CompanyId = table.Column<long>(type: "bigint", nullable: false),
                    ProductId = table.Column<string>(type: "character varying(255)", maxLength: 255, nullable: false),
                    YearMonth = table.Column<int>(type: "integer", nullable: false),
                    AdoptionCount = table.Column<int>(type: "integer", nullable: false),
                    NotAdoptionCount = table.Column<int>(type: "integer", nullable: false),
                    PricingCount = table.Column<int>(type: "integer", nullable: false),
                    ProjectionDemand = table.Column<decimal>(type: "numeric(18,2)", nullable: false),
                    RealDemand = table.Column<decimal>(type: "numeric(18,2)", nullable: false),
                    ProjectionCost = table.Column<decimal>(type: "numeric(18,2)", nullable: false),
                    RealCost = table.Column<decimal>(type: "numeric(18,2)", nullable: false),
                    ProjectionRevenue = table.Column<decimal>(type: "numeric(18,2)", nullable: false),
                    RealRevenue = table.Column<decimal>(type: "numeric(18,2)", nullable: false),
                    ProjectionProfit = table.Column<decimal>(type: "numeric(18,2)", nullable: false),
                    RealProfit = table.Column<decimal>(type: "numeric(18,2)", nullable: false),
                    ProjectionRoyalty = table.Column<decimal>(type: "numeric(18,2)", nullable: false),
                    RealRoyalty = table.Column<decimal>(type: "numeric(18,2)", nullable: false),
                    ConsolidadeGroupBy = table.Column<string>(type: "character varying(255)", maxLength: 255, nullable: false),
                    MajorGranularity = table.Column<string>(type: "character varying(255)", maxLength: 255, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MonthlyImpactData", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ProductLaterPeriod",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false, defaultValueSql: "uuid_generate_v4()"),
                    ProductId = table.Column<string>(type: "character varying(255)", maxLength: 255, nullable: false),
                    PriceGroupId = table.Column<long>(type: "bigint", nullable: false),
                    LaterPeriod = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    ApprovedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    Found = table.Column<bool>(type: "boolean", nullable: false),
                    ReferenceId = table.Column<Guid>(type: "uuid", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProductLaterPeriod", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ProductLaterPeriod_ProductLaterPeriod_ReferenceId",
                        column: x => x.ReferenceId,
                        principalTable: "ProductLaterPeriod",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_MonthlyImpactData_CompanyId_ProductId",
                table: "MonthlyImpactData",
                columns: new[] { "CompanyId", "ProductId" });

            migrationBuilder.CreateIndex(
                name: "IX_MonthlyImpactData_CompanyId_YearMonth",
                table: "MonthlyImpactData",
                columns: new[] { "CompanyId", "YearMonth" });

            migrationBuilder.CreateIndex(
                name: "IX_ProductLaterPeriod_ReferenceId",
                table: "ProductLaterPeriod",
                column: "ReferenceId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "MonthlyImpactData");

            migrationBuilder.DropTable(
                name: "ProductLaterPeriod");
        }
    }
}
