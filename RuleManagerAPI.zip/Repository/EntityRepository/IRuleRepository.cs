﻿using Repository.Entity;

namespace Repository.EntityRepository
{
    public interface IRuleRepository : IGenericRepository<DinPreRule_ConditionEntity>
    {
    }
}
