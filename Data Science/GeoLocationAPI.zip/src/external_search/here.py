import json
import os
from typing import Any, Dict, Optional, Tuple
from urllib.parse import quote_plus

import aiohttp

from models.internal import Coordinate
from src.env import config
from src.external_search.enum import ExternalSearchStatus
from src.logger import logger


async def search_address(
    address: str,
) -> Tuple[Optional[Coordinate], Optional[Dict[str, Any]], ExternalSearchStatus]:
    logger.debug("searching address << %s >> in HERE address API", address)
    quoted_address = quote_plus(address)
    api_key = config.get("HERE_API_KEY")
    timeout = aiohttp.ClientTimeout(total=60)

    async with aiohttp.ClientSession(timeout=timeout) as session:
        async with session.get(
            f"https://geocode.search.hereapi.com/v1/geocode?q={quoted_address}&apiKey={api_key}",
            timeout=30,
        ) as res:
            if res.status != 200:
                logger.error(
                    "address API request failed with status %d:\n%s",
                    res.status,
                    await res.text(),
                )
                return None, None, ExternalSearchStatus.HTTP_ERROR

            res_json = await res.json()

    return _parse_here_geocode_json(address, res_json)


async def discover_place(
    query: str, lat: float, long: float
) -> Tuple[Optional[Dict[str, Any]], ExternalSearchStatus]:
    logger.debug("searching place info of << %s >>", query)
    api_key = config.get("HERE_API_KEY")
    timeout = aiohttp.ClientTimeout(total=60)

    async with aiohttp.ClientSession(timeout=timeout) as session:
        async with session.get(
            f"https://discover.search.hereapi.com/v1/discover?q={quote_plus(query)}&at={lat},{long}&apiKey={api_key}",
            timeout=30,
        ) as res:
            if res.status != 200:
                logger.error(
                    "discover API request failed with status %d:\n%s",
                    res.status,
                    await res.text(),
                )
                return None, ExternalSearchStatus.HTTP_ERROR

            res_json = await res.json()

    return res_json, ExternalSearchStatus.SUCESS


async def mock_search_address(
    address: str,
) -> Tuple[Optional[Coordinate], Optional[Dict[str, Any]], ExternalSearchStatus]:
    logger.info("searching address << %s >> in !MOCK! HERE address API", address)
    with open("./examples/here_sample_response.json", "r", encoding="utf-8") as f:
        res_json = json.load(f)

    coord, address_dict, status = _parse_here_geocode_json(address, res_json)
    return coord, address_dict, status


def _parse_here_geocode_json(
    address: str, res_json
) -> Tuple[Optional[Coordinate], Optional[Dict[str, Any]], ExternalSearchStatus]:
    logger.debug(
        "-> address << %s >> result:\n%s", address, json.dumps(res_json, indent=2)
    )
    items = res_json.get("items") or []
    if not items:
        logger.error(
            "address API request didn't return valid coordinates for address << %s >>",
            address,
        )
        return None, None, ExternalSearchStatus.NO_ADDRESS_ERROR

    item = items[0]
    position = item.get("position")
    if not position:
        logger.error(
            "address API request didn't return valid coordinates for address << %s >>",
            address,
        )
        return None, None, ExternalSearchStatus.NO_ADDRESS_ERROR

    address_dict = item.get("address") or {}
    coordinate = Coordinate(
        latitude=position["lat"],
        longitude=position["lng"],
    )
    return (
        coordinate,
        address_dict,
        ExternalSearchStatus.SUCESS,
    )
