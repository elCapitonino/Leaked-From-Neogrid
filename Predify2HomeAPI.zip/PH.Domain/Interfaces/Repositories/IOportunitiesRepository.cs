﻿using PH.Domain.DTO;

namespace PH.Domain.Interfaces.Repositories
{
    public interface IOportunitiesRepository
    {
        Task<OportunitiesMainDTO> Get(long idCompany, long idPriceGroup);
    }
}
