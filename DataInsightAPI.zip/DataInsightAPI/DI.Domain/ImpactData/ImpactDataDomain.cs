﻿using AutoMapper;
using DI.Domain.ImpactData.Models;
using DI.Domain.Utils;
using DI.Repository.Enum;
using DI.Repository.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace DI.Domain.ImpactData
{
    public class ImpactDataDomain : IImpactDataDomain
    {
        private readonly IUnitOfWork _uow;
        private readonly IMapper _mapper;

        public ImpactDataDomain(IUnitOfWork uow, IMapper mapper)
        {
            _uow = uow;
            _mapper = mapper;
        }

        public IEnumerable<GranularityGroupResponse> GetGranularities(long companyId)
        {
            var result = _uow.GranularityGroupRepository.GetByCompanyId(companyId)
                .Include(x => x.GranularityLevels);

            return _mapper.Map<IEnumerable<GranularityGroupResponse>>(result);
        }

        public IEnumerable<MonthlyImpactDataResponse> GetMonthlyImpactData(long companyId, YearMonth startDate, YearMonth endDate)
        {
            var result = _uow.MonthlyImpactDataRepository.GetAll(companyId, startDate.Value, endDate.Value, MonthlyImpactDataType.Normal);

            return _mapper.Map<IEnumerable<MonthlyImpactDataResponse>>(result);
        }

        public IEnumerable<ProjectionImpactDataResponse> GetProjectionImpactData(long companyId, long priceGroupId)
        {
            if (!_uow.EnterprisePriceGroupRepository.HasAccess(companyId, priceGroupId))
                throw new UnauthorizedAccessException();

            var result = _uow.ProjectionImpactDataRepository.GetAllByPriceGroupId(priceGroupId);

            return _mapper.Map<IEnumerable<ProjectionImpactDataResponse>>(result);
        }
    }
}
