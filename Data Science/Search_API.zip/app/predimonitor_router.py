import datetime
from fastapi import Query, Response, APIRouter, Body
import predimonitor_requets as PR
import predimonitor_projecao
from generic_response import Result, Messages, TypeErrors

router = APIRouter()

@router.post('/predimonitor/projecao', tags=['predimonitor'])
async def projecao(params: PR.PredimonitorProjectionRequest = Body(None, description='List of data to search')):
    try:
        result, projection_msg = predimonitor_projecao.pred_sem(params.json())

        list_msg = []
        # Apenas passando para o modelo Messages
        for msg in projection_msg:
            list_msg.append({
            'type': TypeErrors.warning.value,
            'code': 1,
            'message': msg
        })
        return Result(result=result, success=True, messages=list_msg)

    except Exception as e:
        list_msg = []
        list_msg.append({
            'type': TypeErrors.error.value,
            'code': 1,
            'message': str(e)
        })
        return Result(result='', success=False, messages=list_msg)