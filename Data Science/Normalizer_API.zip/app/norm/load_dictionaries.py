import threading
from datetime import datetime
from norm.conect_mongo import MongoConnect
from norm.memorycache import MemoryCache


class Load_dictionaries(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)
        self.dbMongo = MongoConnect()
        self.memory = MemoryCache()
        self._event = threading.Event()
        self.status_dictionary = False
        # self.dict = Dictionaries()

    ############## Controle da thread #####################################

    def set_status(self, status):
        self.status_dictionary = status

    def pause(self):
        self.status_dictionary = True
        print("Dicionário pausa : ",
              datetime.now().strftime('%d-%m-%Y %H:%M:%S.%f'))
        self._event.clear()
        self._event.wait()

    def resume(self):
        self.status_dictionary = False
        print("Carregando dicionários  : ",
              datetime.now().strftime('%d-%m-%Y %H:%M:%S.%f'))
        self._event.set()

    ##################################################

    def dict_brands(self):
        brands = self.dbMongo.get_dict_brands()
        brands_ready = {}

        for i in brands:
            brands_list = []
            for j in i["data"]:
                brands_list.append(j["name"])
            brands_ready.update({i["_id"]: brands_list})

        self.memory.set_brands(brands_ready)

    ##############################################

    def dict_products(self):
        products = self.dbMongo.get_dict_products()

        product_final = {}

        for i in products:
            #print("i : ", i)
            products_ready = {}
            for j in i["data"]:
                products_ready.update({j["name"]: j["synonyms"]})

            product_final.update({i['_id']: products_ready})

        #print("product_final:", product_final)

        self.memory.set_products(product_final)
    ##############################################

    # def dict_products_synonyms(self):
    #     self.products_synonyms = self.dbMongo.get_dict_products_synonyms()
    #     products_synonyms__ready = {}
    #     for i in self.products_synonyms:
    #         if i["synonyms"] != []:
    #             products_synonyms__ready.update({i["name"]: i["synonyms"]})
    #     # Mapeamento dos sinonimos
    #     # print("products_synonyms_ready:", products_synonyms__ready)
    #     sub_sinonimo_map = {v: k for k, V in products_synonyms__ready.items()
    #                         for v in V}
    #     self.memory.set_products_synonyms(sub_sinonimo_map)
    #     # print("products_synonyms:", sub_sinonimo_map)
    ##############################################

    def dict_categories(self):
        self.categories = self.dbMongo.get_dict_categories()
        categories_ready = {}
        categories_final = {}
        for i in self.categories:
            dict_categories = {}
            for j in i['data']:
                dict_categories[j['name']] = j['products']

            categories_final[i['_id']] = dict_categories

        # print(categories_ready)
        self.memory.set_categories(categories_final)
    ##############################################

    def dict_voltage(self):
        self.voltage = self.dbMongo.get_dict_voltage()
        voltage_ready = {}
        for i in self.voltage:
            dict_voltage = {}
            for voltage in i['data']:
                dict_voltage[voltage['name']] = voltage['similar']

            voltage_ready[i['_id']] = dict_voltage
        #print("voltage:", voltage_ready)
        self.memory.set_voltage(voltage_ready)
    ############################################

    def dict_materials(self):
        self.materials = self.dbMongo.get_dict_materials()
        materials_ready = {}

        for i in self.materials:
            dict_materials = {}
            for material_name in i['data']:
                dict_materials[material_name['name']
                               ] = material_name['similar']
            materials_ready[i['_id']] = dict_materials
        self.memory.set_materials(materials_ready)
        # print("materials:", materials_ready)
    ############################################

    def dict_metric_units(self):
        self.metric_units = self.dbMongo.get_dict_metric_units()
        metric_units_ready = {}
        for i in self.metric_units:
            dict_metric = {}
            for metric_name in i['data']:
                dict_metric[metric_name['name']] = metric_name['similar']

            metric_units_ready[i['_id']] = dict_metric

        self.memory.set_metric_units(metric_units_ready)
        # print("metric_units:", metric_units_ready)
    ############################################

    def dict_power(self):
        self.power = self.dbMongo.get_dict_power()
        power_ready = {}
        for i in self.power:
            dict_power = {}
            for power_name in i['data']:
                dict_power[power_name['name']] = power_name['similar']

            power_ready[i['_id']] = dict_power

        self.memory.set_power(power_ready)
        # print("power:", power_ready)
    #####################################################

    def dict_dimensions(self):
        self.dimensions = self.dbMongo.get_dict_dimensions()
        dimensions_ready = {}
        for i in self.dimensions:
            dict_dimension = {}
            for dimension_name in i['data']:
                dict_dimension[dimension_name['name']
                               ] = dimension_name['similar']

            dimensions_ready[i['_id']] = dict_dimension
        self.memory.set_dimensions(dimensions_ready)
    ##############################################################

    def dict_energy_source(self):
        self.energy_source = self.dbMongo.get_dict_energy_source()
        energy_source_ready = {}
        for i in self.energy_source:
            dict_energy = {}
            for energy_name in i['data']:
                dict_energy[energy_name['name']] = energy_name['similar']

            energy_source_ready[i['_id']] = dict_energy
        self.memory.set_energy_source(energy_source_ready)

    ##############################################################
    def dict_size(self):
        """
        retorna um dicionário de tamanho (size)
        """
        self.size = self.dbMongo.get_dict_size()
        size_ready = {}
        for i in self.size:
            dict_size = {}
            for size_name in i['data']:
                dict_size[size_name['name']] = size_name['similar']

            size_ready[i['_id']] = dict_size
        # print("size_ready: ", size_ready)
        self.memory.set_size(size_ready)

    #############################################################
    def dict_state(self):
        """
        retorna um dicionário de estado (state)
        """
        self.state = self.dbMongo.get_dict_state()
        state_ready = {}
        for i in self.state:
            dict_state = {}
            for state_name in i['data']:
                dict_state[state_name['name']] = state_name['similar']

            state_ready[i['_id']] = dict_state
        #print("state_ready: ", state_ready)
        self.memory.set_state(state_ready)

    #############################################################

    def run(self):
        # time.sleep(2)
        while True:
            if self.status_dictionary == True:
                self.pause()

            # print(" 1 inicio  dicionários...### ")
            self.dict_brands()
            self.dict_products()
            # self.dict_products_synonyms()
            self.dict_categories()
            self.dict_voltage()
            self.dict_materials()
            self.dict_metric_units()
            self.dict_power()
            self.dict_dimensions()
            self.dict_energy_source()
            self.dict_size()
            self.dict_state()
            # print(" 2 Dicionários carregados ##### ")
            self.pause()
