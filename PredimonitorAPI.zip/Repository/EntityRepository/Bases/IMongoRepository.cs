﻿using MongoDB.Driver;

namespace Repository.EntityRepository.Bases
{
    public interface IMongoRepository
    {
        IMongoClient Client { get; }
    }
}
