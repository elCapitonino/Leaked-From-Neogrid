﻿namespace CS.Domain.Domain
{
    public class EnterpriseElasticit
    {
        public EnterpriseElasticit(string time, string product, double elasticity, double mean_Quantity, double mean_Price, double last_Quantity, double last_Price, string affiliate)
        {
            Time = time;
            Product = product;
            Elasticity = elasticity;
            Mean_Quantity = mean_Quantity;
            Mean_Price = mean_Price;
            Last_Quantity = last_Quantity;
            Last_Price = last_Price;
            Affiliate = affiliate;
        }

        public string Time { get; set; }
        public string Product { get; set; }
        public double Elasticity { get; set; }
        public double Mean_Quantity { get; set; }
        public double Mean_Price { get; set; }
        public double Last_Quantity { get; set; }
        public double Last_Price { get; set; }
        public string Affiliate { get; set; }

    }
}
