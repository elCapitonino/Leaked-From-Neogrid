using Domain.Product;
using Domain.ProductPrice;
using Domain.ProductPrice.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;

namespace PredimonitorAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductPriceController : ControllerBase
    {
        private readonly ILogger<ProductPriceController> _logger;
        private readonly IProductPriceDomain _domain;

        public ProductPriceController(ILogger<ProductPriceController> logger, IProductPriceDomain domain)
        {
            _logger = logger;
            _domain = domain;
        }

        [HttpPost("Ignore")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status401Unauthorized, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
        [SwaggerOperation(Summary = "Add the product price to the ignored list", Description = "Add the product price to the ignored list")]

        public async Task<IActionResult> Ignore(bool ignore, int companyId, string priceId)
        {
            if (companyId == 0 || string.IsNullOrEmpty(priceId))
            {
                _logger.LogDebug("Invalid data received.");
                return BadRequest("CompanyId and priceId cannot be null.");
            }

            try
            {
                if (ignore)
                {
                    _domain.IgnoreProductPrice(companyId, priceId);
                }
                else
                {
                    await _domain.UnignoreProductPrice(companyId, priceId);
                }

                return Ok();
            }
            catch (UnauthorizedAccessException ex)
            {
                _logger.LogError(ex, "Unauthorized access");
                return Unauthorized("Unauthorized access.");
            }
            catch (ArgumentException ex)
            {
                _logger.LogError(ex, "Bad request");
                return BadRequest("Invalid argument: " + ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error executing the request");
                return StatusCode(StatusCodes.Status500InternalServerError, "An unexpected error occurred.");
            }
        }

        [HttpGet("GetIgnoredPrices")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<IgnoredProductPriceResponse>))]
        [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status401Unauthorized, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
        [SwaggerOperation(Summary = "Gets the ignored product prices", Description = "Gets the ignored product prices")]

        public async Task<IActionResult> Ignore(int companyId, string productId)
        {
            if (companyId == 0 || string.IsNullOrEmpty(productId))
            {
                _logger.LogDebug("Invalid data received.");
                return BadRequest("CompanyId and productId cannot be null.");
            }

            try
            {
                var ignordPrices = await _domain.GetIgnoredPrices(companyId, productId);

                return Ok(ignordPrices);
            }
            catch (UnauthorizedAccessException ex)
            {
                _logger.LogError(ex, "Unauthorized access");
                return Unauthorized("Unauthorized access.");
            }
            catch (ArgumentException ex)
            {
                _logger.LogError(ex, "Bad request");
                return BadRequest("Invalid argument: " + ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error executing the request");
                return StatusCode(StatusCodes.Status500InternalServerError, "An unexpected error occurred.");
            }
        }
    }
}