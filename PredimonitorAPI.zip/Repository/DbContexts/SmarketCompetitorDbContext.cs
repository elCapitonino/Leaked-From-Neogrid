﻿using Microsoft.EntityFrameworkCore;
using MongoDB.Driver;
using Repository.DbContexts.Bases;

namespace Repository.DbContexts
{
    public class SmarketCompetitorDbContext : MongoDbContextBase
    {
        public SmarketCompetitorDbContext(DbContextOptions<SmarketCompetitorDbContext> options, IMongoClient mongoClient) : base(options, mongoClient)
        {

        }
        public override string DbContextName => nameof(SmarketCompetitorDbContext);
    }

}
