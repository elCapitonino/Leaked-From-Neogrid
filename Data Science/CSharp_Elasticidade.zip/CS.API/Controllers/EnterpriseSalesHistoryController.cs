﻿using CS.Domain.DTO;
using CS.Domain.Interfaces.Services;
using Microsoft.AspNetCore.Mvc;

namespace CS.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EnterpriseSalesHistoryController : ControllerBase
    {
        private readonly IEnterpriseSalesHistoryService _service;
        private readonly ILogger<EnterpriseSalesHistoryController> _log;

        public EnterpriseSalesHistoryController(IEnterpriseSalesHistoryService service,
            ILogger<EnterpriseSalesHistoryController> log)
        {
            _service = service;
            _log = log;
        }

        [HttpGet]
        public async Task<IActionResult> SimpleElasticSearch()
        {
            try
            {
                _log.LogInformation("Iniciando logs");
                SimpleSearchDTO searchFilter = new SimpleSearchDTO();
                searchFilter.idCompany = 2550;
                searchFilter.pricegroup = 484;
                searchFilter.referenceStartDate = "2022-11-01";
                searchFilter.referenceEndDate = "2022-12-01";

                var result = await _service.SimpleElasticSearch(searchFilter);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _log.LogError(ex, ex.Message);
                return BadRequest(ex.Message);
                throw;
            }

        }
    }
}
