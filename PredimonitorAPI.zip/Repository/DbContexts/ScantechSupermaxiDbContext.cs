﻿using Microsoft.EntityFrameworkCore;
using MongoDB.Driver;
using Repository.DbContexts.Bases;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.DbContexts
{
    public class ScantechSupermaxiDbContext : MongoDbContextBase
    {
        public ScantechSupermaxiDbContext(DbContextOptions<ScantechSupermaxiDbContext> options, IMongoClient mongoClient) : base(options, mongoClient)
        {

        }
        public override string DbContextName => nameof(ScantechSupermaxiDbContext);
    }
}
