﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Product.Models
{
    public class CompetitivenessIndexResponse
    {
        public decimal AverageCompetitiveness { get; set; }
        public CompetitivenessIndexHistory CompetitivenessIndexHistory { get; set; } = new();
    }

    public class CompetitivenessIndexHistory
    {
        public List<string> Dates { get; set; } = [];
        public List<CompetitivenessIndexHistoryProduct> Products { get; set; } = [];

    }

    public class CompetitivenessIndexHistoryProduct
    {
        public string Name { get; set; } = string.Empty;
        public List<decimal?> CompetitivenessIndex { get; set; } = [];
    }

    public class CompetitivenessQueryResponse
    {
        public string Name { get; set; } = string.Empty;
        public DateTime Date { get; set; }
        public decimal AveragePrice { get; set; }
        public decimal LatestPrice { get; set; }
        public decimal CompetitivenessIndex { get; set; }
    }
}