﻿using ClosedXML.Excel;
using DI.Domain.Models.ImpactReport;

namespace DI.Domain.Utils.ImpactReport
{
    public static class ExcelReportRawUtil
    {
        public static XLWorkbook CreateWorkbook(IEnumerable<IGrouping<string, ImpactReportModel>> groupedReports, string? userResourceType, bool hasRoyalty = false)
        {
            var workbook = new XLWorkbook();
            bool excludeRoyalty = string.Equals(userResourceType, "Consultor", StringComparison.OrdinalIgnoreCase);

            foreach (var affiliateGroup in groupedReports)
            {
                CreateWorksheet(workbook, affiliateGroup, excludeRoyalty, hasRoyalty);
            }

            return workbook;
        }

        public static int SetHeader(IXLWorksheet worksheet, bool hasRoyalty = false, bool hasRoyaltyByUser = false)
        {
            string[] headers = {
                "Identificador da Precificação", "Data da Precificação", "Nome da loja", "Grupo/categoria",
                "Subgrupo/subcategoria", "Codigo do produto", "EAN", "Descrição",
                "Custo antes da precificação", "Custo projetado", "Custo realizado",
                "Média preço aplicado antes da precificação", "Preço ajustado da Predify", "Média do preço realizado",
                "Adoção do preço ajustado", "Aprovação de preços ajustados",
                "Demanda antes da precificação", "Demanda projetada", "Demanda realizada",
                "Elasticidade", "Curva ABC",
                "Receita antes da precificação", "Receita projetada", "Receita realizada",
                "Variação de receita (Depois - Antes)", "Variação da receita (Depois - Projetada)",
                "Lucro bruto antes da precificação", "Lucro bruto projetado", "Lucro bruto realizado",
                "Variação lucro bruto (Depois - Antes)", "Variação lucro bruto (Depois - Projetado)",
                "Margem bruta antes da precificação", "Margem bruta projetada", "Margem bruta realizada",
                "Variação margem bruta (Depois - Antes)", "Variação da margem bruta (Depois - Projetado)"};

            int headersCount = headers.Length;

            for (int i = 0; i < headersCount; i++)
                worksheet.Cell(1, i + 1).Value = headers[i];

            if (hasRoyalty && !hasRoyaltyByUser) worksheet.Cell(1, ++headersCount).Value = "Royalty";

            return headersCount;
        }

        //Criação das planilhas
        private static void CreateWorksheet(XLWorkbook workbook, IGrouping<string, ImpactReportModel> affiliateGroup, bool hasRoyaltyByUser = false, bool hasRoyalty = false)
        {
            var sheetName = TruncateSheetName(affiliateGroup.Key);
            var worksheet = workbook.Worksheets.Add(sheetName);

            int headersCount = SetHeader(worksheet, hasRoyalty, hasRoyaltyByUser);
            int itemsCountRow = affiliateGroup.Count() + 1;

            int currentRow = 2;
            foreach (var report in affiliateGroup)
            {
                FillWorksheetRow(worksheet, currentRow, report, hasRoyalty, hasRoyaltyByUser);
                currentRow++;
            }

            //--- General Styles
            ////COLORS
            //Headers
            SetCellsBackgroundColor(worksheet, "V1:Z1", "#B4A7D6");
            SetCellsBackgroundColor(worksheet, "AA1:AE1", "#F9CB9C");
            SetCellsBackgroundColor(worksheet, "AF1:AJ1", "#B6D7A8");
            if (hasRoyalty && !hasRoyaltyByUser) SetCellsBackgroundColor(worksheet, "AK1", "#B6D7A8");

            //Cost
            SetCellsBackgroundColor(worksheet, $"I1:I{itemsCountRow}", "#E0FFFF");
            SetCellsBackgroundColor(worksheet, $"J1:J{itemsCountRow}", "#E0FFFF");
            SetCellsBackgroundColor(worksheet, $"K1:K{itemsCountRow}", "#E0FFFF");

            //Price
            SetCellsBackgroundColor(worksheet, $"L1:L{itemsCountRow}", "#FFE0E0");
            SetCellsBackgroundColor(worksheet, $"M1:M{itemsCountRow}", "#FFE0E0");
            SetCellsBackgroundColor(worksheet, $"N1:N{itemsCountRow}", "#FFE0E0");

            //Adoção
            SetCellsBackgroundColor(worksheet, $"O1:O{itemsCountRow}", "#E0E0FF");
            SetCellsBackgroundColor(worksheet, $"P1:P{itemsCountRow}", "#E0E0FF");

            //Demand
            SetCellsBackgroundColor(worksheet, $"Q1:Q{itemsCountRow}", "#CECE9E");
            SetCellsBackgroundColor(worksheet, $"R1:R{itemsCountRow}", "#CECE9E");
            SetCellsBackgroundColor(worksheet, $"S1:S{itemsCountRow}", "#CECE9E");

            // RED GREEN Condition
            SetCollumnRedGreen(worksheet, $"Y2:Y{itemsCountRow}");
            SetCollumnRedGreen(worksheet, $"Z2:Z{itemsCountRow}");
            SetCollumnRedGreen(worksheet, $"AD2:AD{itemsCountRow}");
            SetCollumnRedGreen(worksheet, $"AE2:AE{itemsCountRow}");
            SetCollumnRedGreen(worksheet, $"AI2:AI{itemsCountRow}");
            SetCollumnRedGreen(worksheet, $"AJ2:AJ{itemsCountRow}");

            ////FONTS
            worksheet.Range(1, 1, 1, headersCount).Style.Font.FontName = "Calibri";
            worksheet.Range(1, 1, 1, headersCount).Style.Font.FontSize = 13;
            worksheet.Range(1, 1, 1, headersCount).Style.Font.Bold = true;
            worksheet.Range(1, 1, 1, headersCount).SetAutoFilter();
            worksheet.FirstRow().Height = 60;
            worksheet.SheetView.FreezeRows(1);

            worksheet.Range(1, 1, itemsCountRow, headersCount).Style.Alignment.Vertical = XLAlignmentVerticalValues.Center;
            worksheet.Range(1, 1, itemsCountRow, headersCount).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
            worksheet.Range(1, 1, itemsCountRow, headersCount).Style.Border.OutsideBorder = XLBorderStyleValues.Thin;
            worksheet.Range(1, 1, itemsCountRow, headersCount).Style.Border.InsideBorder = XLBorderStyleValues.Thin;
            worksheet.Range(1, 1, itemsCountRow, headersCount).Style.Border.OutsideBorderColor = XLColor.Black;
            worksheet.Range(1, 1, itemsCountRow, headersCount).Style.Border.InsideBorderColor = XLColor.Black;

            //Formating Text
            worksheet.Range($"Q2:S{itemsCountRow}").Style.NumberFormat.Format = "0";
            worksheet.Range($"I2:N{itemsCountRow}").Style.NumberFormat.Format = "R$ #,##0.00";
            worksheet.Range($"V2:AE{itemsCountRow}").Style.NumberFormat.Format = "R$ #,##0.00";
            worksheet.Range($"AF2:AJ{itemsCountRow}").Style.NumberFormat.Format = "#,##0.00%";
            if (hasRoyalty && !hasRoyaltyByUser) worksheet.Range($"AK2:AK{itemsCountRow}").Style.NumberFormat.Format = "R$ #,##0.00";

            worksheet.Columns().AdjustToContents();
        }

        private static void SetCollumnRedGreen(IXLWorksheet worksheet, string rangeAddress)
        {
            worksheet.Range(rangeAddress).AddConditionalFormat().WhenLessThan(0).Fill.SetBackgroundColor(XLColor.FromHtml("c0504d"));
            worksheet.Range(rangeAddress).AddConditionalFormat().WhenEqualOrGreaterThan(0).Fill.SetBackgroundColor(XLColor.FromHtml("9bbb59"));
        }

        //Validação para o nome da planilha não estourar + de 30 caracteres 
        private static string TruncateSheetName(string sheetName)
        {
            return sheetName.Length > 31 ? sheetName.Substring(0, 30) : sheetName;
        }

        //Preenche os dados planilha
        private static void FillWorksheetRow(IXLWorksheet worksheet, int row, ImpactReportModel report, bool hasRoyalty = false, bool hasRoyaltyByUser = false)
        {
            DateTime publishedDate = Convert.ToDateTime(report.PublishedDate);

            decimal? variationRealRevenue = report.RealRevenue - report.PriorRevenue;
            decimal? variationProjRevenue = report.RealRevenue - report.ProjectionRevenue;
            decimal? variationRealProfit = report.RealProfit - report.PriorProfit;
            decimal? variationProjProfit = report.RealProfit - report.ProjectionProfit;
            decimal? variationRealMargin = report.RealMargin - report.PriorMargin;
            decimal? variationProjMargin = report.RealMargin - report.ProjectionMargin;

            worksheet.Cell(row, "A").Value = report.EnterprisePriceGroupsName;
            worksheet.Cell(row, "B").Value = publishedDate.ToString("dd/MM/yyyy");
            worksheet.Cell(row, "C").Value = report.AffiliateName;
            worksheet.Cell(row, "D").Value = report.Category;
            worksheet.Cell(row, "E").Value = report.SubCategory;
            worksheet.Cell(row, "F").Value = report.Product;
            worksheet.Cell(row, "G").Value = report.PackageDescription;
            worksheet.Cell(row, "H").Value = report.ProductName;
            worksheet.Cell(row, "I").Value = report.PriorCost;
            worksheet.Cell(row, "J").Value = report.ProjectionCost;
            worksheet.Cell(row, "K").Value = report.RealCost;
            worksheet.Cell(row, "L").Value = report.PriorPrice;
            worksheet.Cell(row, "M").Value = report.ProjectionPrice;
            worksheet.Cell(row, "N").Value = report.RealPrice;
            worksheet.Cell(row, "O").Value = (report.Adopted == null ? "" : (report.Adopted == true ? "VERDADEIRO" : "FALSO"));
            worksheet.Cell(row, "P").Value = report.ActionResult;
            worksheet.Cell(row, "Q").Value = report.PriorDemand;
            worksheet.Cell(row, "R").Value = report.ProjectionDemand;
            worksheet.Cell(row, "S").Value = report.RealDemand;
            worksheet.Cell(row, "T").Value = report.ElasticityResult;
            worksheet.Cell(row, "U").Value = report.SalePriceInferiorLimit_Demand_CurveABC;
            worksheet.Cell(row, "V").Value = report.PriorRevenue;
            worksheet.Cell(row, "W").Value = report.ProjectionRevenue;
            worksheet.Cell(row, "X").Value = report.RealRevenue;
            worksheet.Cell(row, "Y").Value = variationRealRevenue;
            worksheet.Cell(row, "Z").Value = variationProjRevenue;
            worksheet.Cell(row, "AA").Value = report.PriorProfit;
            worksheet.Cell(row, "AB").Value = report.ProjectionProfit;
            worksheet.Cell(row, "AC").Value = report.RealProfit;
            worksheet.Cell(row, "AD").Value = variationRealProfit;
            worksheet.Cell(row, "AE").Value = variationProjProfit;
            worksheet.Cell(row, "AF").Value = report.PriorMargin;
            worksheet.Cell(row, "AG").Value = report.ProjectionMargin;
            worksheet.Cell(row, "AH").Value = report.RealMargin;
            worksheet.Cell(row, "AI").Value = variationRealMargin;
            worksheet.Cell(row, "AJ").Value = variationProjMargin;
            if (hasRoyalty && !hasRoyaltyByUser) worksheet.Cell(row, "AK").Value = report.RealRevenue * report.Royalty;
        }

        private static void SetCellsBackgroundColor(IXLWorksheet worksheet, string rangeAddress, string color)
        {
            worksheet.Range(rangeAddress).Style.Fill.BackgroundColor = XLColor.FromHtml(color);
        }

        //Salvar no fluxo de memoria
        public static MemoryStream SaveWorkbookToMemoryStream(XLWorkbook workbook)
        {
            var stream = new MemoryStream();
            workbook.SaveAs(stream);
            stream.Position = 0;
            return stream;
        }
    }
}
