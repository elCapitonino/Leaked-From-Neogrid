﻿using PH.Domain.Domain;
using PH.Domain.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PH.Domain.Interfaces.Repositories
{
    public interface IGraficoICRepository
    {
        Task<FiltroCategoriaGraficoICDTO> GetAllFilterCategories();
        Task<List<GraficoICDTO>> GetGraficoIC(string category, string compType, string? state, string period, string? coordinator);
        Task<EstadoGraficoICDTO> GetStateByIdGroup(long idPriceGroup);
        Task<List<IntervaloMargemDTO>> GetMarginByIdCompany(long idCompany);
    }
}
