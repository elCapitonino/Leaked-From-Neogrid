from async_mongo import AsyncMongoConnect


class RestrictionSearchCompany():

    __instance = None

    def __new__(cls, *args, **kwargs):
        if not RestrictionSearchCompany.__instance:
            RestrictionSearchCompany.__instance = super(
                RestrictionSearchCompany, cls).__new__(cls, *args, **kwargs)
        return RestrictionSearchCompany.__instance

    def __init__(self):
        pass

    async def load_company(self):
        db_mongo = AsyncMongoConnect()
        company = await db_mongo.load_list_company()
        self.list_company = []
        for r in company:
            self.list_company.append(r['id_company'])
        #print("load_restriction", self.list_company)

    def get_company(self):
        if(len(self.list_company) > 0):
            return self.list_company
        if(len(self.list_company) == 0):
            return []
