﻿using System.Security.Claims;

namespace Domain.Models
{
    public interface ICurrentUser
    {
        string AccessToken { get; }
        bool IsAuthenticated { get; }
        string? Name { get; }
        Guid UserId { get; }
        ClaimsIdentity? Identity { get; }

    }
}
