# Comandos para gerar relatórios

## VEM

**Atenção ao parâmetro --interval, pode ser necessário usar outro.**

1. Relatório completo

```bash
python get_report_published_agg.py --id-company 3026 --granularity Description Affiliate --group-granularity Affiliate Category1 --last-price-lookback 180 --agg-order Category1 Affiliate --env producao --interval 7
```

2. Relatório completo (precificações automáticas)

```bash
python get_report_selected_agg.py --id-company 3026 --granularity Description Affiliate --group-granularity Affiliate Category1 Category2 AffiliateState --last-price-lookback 180 --agg-order Category1 Affiliate --env producao --interval 0 --price-groups 4978 4979 4980 4981 4982 4983 4984 4985 4986 4987 4988 4989 4990 4991 4992 4993 4994 4995 4996 4997 4998 4999 5000 5001 5003 5005 5007 5008 5009 5010 5011 5012 5013 5014 5015 5016 5017 5018 5019 5020 5021 5022 5023 5024 5025 5026 5027 5028 5029 5030 5031 5032 5033 5034 5035 5036 5037 5038 5039 5040 5041 5042 5043 5044 5045 5046 5047 5048 5049 5050 5051 5052 5053 5054 5055 5056 5057 5058 5059 5060 5061 5062 5063 5064 5065 5066 5067 5068 5069 5070 5071 5072 5073 5074 5075 5076 5077 5078 5079 5080 5081 5082 5083 5084 5085 5086 5087 5088 5089 5090 5091 5092 5093 5094 5095 5096 5097 5098 5099 5100 5101 5102 5103 5104 5105 5106 5107 5108 5109 5110 5111 5112 5113 5114 5115 5116 5117 5118 5119 5120 5121 5122 5123 5124 5125 5126 5127 5128 5129 5130 5131 5132 5133 5134 5135 5136 5137 5138 5139 5140 5141 5142 5143 5144 5145 5146 5147 5148 5149 5150 5151 5152 5153 5154 5155 5156 5157 5158 5159 5160 5161 5162 5163 5164 5165 5166 5167 5168 5169 5170 5171 5172 5173 5174 5175 5176 5177 5178 5179 5180 5181 5182 5183 5184 5185 5186 5187 5188 5189 5190 5191 5225 5227 5228 5230 --no-summary
```

```bash
# 19/10/2023
python get_report_selected_agg.py --id-company 3026 --granularity Description Affiliate --group-granularity Affiliate Category1 Category2 AffiliateState --last-price-lookback 180 --agg-order Category1 Affiliate --env producao --interval 0 --price-groups 5488 5487 5486 5484 5479 5478 5477 5476 5475 5474 5473 5472 5471 5470 5469 5468 5467 5466 5465 5464 5463 5462 5461 5460 5459 5458 5457 5456 5455 5454 5453 5452 5451 5449 5448 5447 5446 5445 5444 5443 5442 5441 5440 5439 5438 5437 5436 5435 5434 5432 5431 5430 5429 5428 5427 5426 5425 5424 5423 5422 5421 5420 5419 5418 5416 5414 5413 5412 5411 5410 5409 5408 5407 5406 5405 5404 5403 5402 5401 5400 5399 5398 5397 5396 5395 5394 5393 5392 5391 5390 5389 5388 5387 5386 5385 5384 5383 5382 5381 5380 5379 5378 5377 5376 5375 5374 5373 5372 5371 5370 5369 5368 5367 5366 5365 5364 5363 5362 5361 5360 5359 5358 5357 5356 5355 5354 5353 5352 5351 5350 5349 5348 5347 5346 5345 5344 5343 5342 5341 5340 5339 5338 5337 5336 5335 5334 5333 5332 5331 5330 5329 5328 5327 5326 5325 5324 5323 5322 5321 5320 5319 5318 5317 5316 5315 5313 5312 5311 5310 5308 5307 5306 5305 5304 5302 5301 5300 5299 5298 5297 5296 5295 5294 5293 5292 5291 5290 5289 5288 5287 5286 5285 5284 5283 5282 5281 5280 5279 5278 5277 5276 5275 5274 5273 5272 5271 5270 5269 5268 5267 5266 5265 5264 5263 5262 --no-summary --only-date

python get_report_selected_agg.py --id-company 3026 --granularity Description Affiliate --group-granularity Affiliate Category1 Category2 AffiliateState --last-price-lookback 180 --agg-order Category1 Affiliate --env producao --interval 0 --price-groups 5595 5596 5597 5598 5599 5600 5601 5602 5603 5604 5605 5606 5607 5608 5609 5610 5611 5612 5613 5614 5615 5616 5617 5618 5619 5620 5621 5622 5623 5624 5625 5626 5627 5628 5629 5630 5631 5632 5633 5634 5635 5636 5637 5638 5639 5640 5641 5642 5643 5644 5645 5646 5647 5648 5649 5650 5651 5652 5653 5654 5655 5656 5657 5658 5659 5660 5661 5662 5663 5664 5665 5666 5667 5668 5669 5670 5671 5672 5674 5675 5676 5677 5679 5680 5681 5682 5683 5684 5685 5686 5687 5688 5689 5690 5692 5693 5694 5695 5696 5697 5698 5699 5700 5701 5702 5703 5704 5705 5706 5707 5708 5709 5710 5711 5712 5713 5714 5715 5716 5717 5718 5719 5720 5721 5722 5723 5724 5725 5726 5727 5728 5729 5730 5731 5732 5733 5734 5735 5736 5737 5738 5739 5740 5741 5742 5743 5744 5745 5746 5747 5748 5749 5750 5751 5752 5753 5754 5755 5756 5757 5758 5759 5760 5761 5762 5763 5764 5765 5766 5767 5768 5769 5770 5771 5772 5773 5774 5775 5776 5777 5778 5779 5780 5781 5782 5783 5784 5785 5786 5787 5788 5789 5790 5791 5792 5793 5794 5795 5796 5797 5798 5799 5800 5801 5802 5803 5804 5805 5806 5807 5808 5817 5818 5819 5821 --no-summary --only-date
```

```bash
python get_report_selected_agg.py --id-company 3026 --granularity Description Affiliate --group-granularity Affiliate Category1 Category2 AffiliateState --last-price-lookback 180 --agg-order Category1 Affiliate --env producao --interval 7 --price-groups 18480 18515 18516 18483 18484 --no-summary --only-date
```

3. Relatório de adesão (menos colunas)

```bash
python get_report_published_agg.py --id-company 3026 --granularity Description Affiliate --group-granularity Affiliate Category1 Category2 AffiliateState --last-price-lookback 180 --agg-order Category1 Affiliate --env producao --interval 7 --col-blocklist ./vem_adocao_blocked_cols.yaml --no-summary
```

4. Relatório de impacto para filiais do _case_ da VEM

```bash
python get_report_selected_agg.py --id-company 3026 --granularity Description Affiliate --group-granularity Affiliate --last-price-lookback 180 --agg-order Category1 Affiliate --env producao --interval 7 --price-groups 18480 18515 18516 18483 18484 --no-summary --only-date --col-blocklist ./vem_impacto_blocked_cols.yaml --product-info Category3 Category4 --group-info Category1 Category2 AffiliateState
```

## Bobs

1. Relatório Completo

```bash
python get_report_selected.py --id-company 2550 --granularity Affiliate Product EconomicGroupCode --price-groups 4310 4653 --env producao --filters-json bobs_filters.json
```


## Peralta

1. Relatório Completo

```bash
python get_report_selected.py --id-company 2941 --granularity Product Affiliate --price-groups 4652 4747 5243 --last-price-lookback 90 --env producao --preco ClientSalesPrice --filters-json peralta_filters.json
```

2. Relatório completo (precificações automáticas)

```bash
python get_report_selected_agg.py --id-company 2941 --granularity Product Affiliate --group-granularity EconomicGroup --agg-order EconomicGroup --env producao --price-groups 4652 4747 5243 --last-price-lookback 90 --preco ClientSalesPrice --filters-json peralta_filters.json
```