﻿using Dapper;
using Microsoft.Extensions.Configuration;
using PH.Domain.DTO;
using PH.Domain.Interfaces.Repositories;
using System.Data;
using System.Data.SqlClient;

namespace PH.Data.Repositories
{
    public class OportunitiesRepository : IOportunitiesRepository
    {
        private string _sQLConnectionString;
        private readonly IConfiguration _configuration;

        public OportunitiesRepository(IConfiguration configuration)
        {
            _configuration = configuration;
            _sQLConnectionString = _configuration.GetConnectionString("SQLConnectionString");
        }

        public async Task<OportunitiesMainDTO> Get(long idCompany, long idPriceGroup)
        {
            OportunitiesMainDTO oportunities = new OportunitiesMainDTO();

            try
            {
                IDbConnection connection = CreateSqlConnection();
                var parametros = new { IDCOMPANY = idCompany, IDPRICEGROUP = idPriceGroup };
                var result = connection.Query<OportunitiesSQLDTO>("VEM_Oportunidades_Aumento_Lucro", parametros, commandType: CommandType.StoredProcedure);

                if (result != null && result.Any())
                {
                    oportunities.IncreaseProfit = new OportunitiesDTO()
                    {
                        TotalItems = result.FirstOrDefault().Itens,
                        ActualPriceProfit = Math.Round(result.FirstOrDefault().PrecoAtual, 2),
                        TotalItemsProfit = Math.Round(result.FirstOrDefault().PrecoNovo, 2),
                    };
                }

                result = connection.Query<OportunitiesSQLDTO>("VEM_Oportunidades_Aumento_Magem", parametros, commandType: CommandType.StoredProcedure);

                if (result != null && result.Any())
                {
                    oportunities.IncreaseMargin = new OportunitiesDTO()
                    {
                        TotalItems = result.FirstOrDefault().Itens,
                        ActualPriceProfit = Math.Round(result.FirstOrDefault().PrecoAtual, 2),
                        TotalItemsProfit = Math.Round(result.FirstOrDefault().PrecoNovo, 2)
                    };
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return oportunities;
        }

        private IDbConnection CreateSqlConnection() => new SqlConnection(_sQLConnectionString);
    }
}
