﻿using Asp.Versioning;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PredifyClientAPI.Services.PredimonitorAPI;
using PredifyClientAPI.Services.PredimonitorAPI.DynamicFilter.Models;

namespace PredifyClientAPI.Controllers
{
    [ApiController]
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiVersion("1.0")]
    [Authorize]
    public class PredimonitorController : ControllerBase
    {
        private readonly ILogger<PredimonitorController> _logger;
        private readonly PredimonitorAPIManager _predimonitorAPIManager;

        public PredimonitorController(ILogger<PredimonitorController> logger, PredimonitorAPIManager predimonitorAPIManager)
        {
            _logger = logger;
            _predimonitorAPIManager = predimonitorAPIManager;
        }

        [HttpPost("GetFilter")]
        [MapToApiVersion("1.0")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(DynamicFilterResponse))]
        [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status401Unauthorized, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
        public async Task<IActionResult> GetFilter(long companyId, [FromBody] DynamicFilterRequest request)
        {
            try
            {
                var response = await _predimonitorAPIManager.DynamicFilterService.GetFilter(companyId, request);

                return Ok(response);
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized(ex.Message);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("GetResult")]
        [MapToApiVersion("1.0")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(SeeResultResponse))]
        [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status401Unauthorized, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
        public async Task<IActionResult> GetResult([FromBody] ResultFilterRequest request)
        {
            try
            {
                var response = await _predimonitorAPIManager.DynamicFilterService.GetResult(request);

                return Ok(response);
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized(ex.Message);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
