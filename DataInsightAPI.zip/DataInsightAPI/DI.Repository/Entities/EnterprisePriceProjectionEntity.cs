﻿namespace DI.Repository.Entities
{
    public sealed class EnterprisePriceProjectionEntity : BaseNoKeyEntity
    {
        public long EnterprisePricesProjectionId { get; set; }

        public long? EnterprisePriceGroupsId { get; set; }

        public EnterprisePriceGroupEntity? PriceGroup { get; set; }

        public long? ProductPredifyId { get; set; }

        public int PriceSendingStatus { get; set; }

        public string? Product { get; set; }

        public string? ProductName { get; set; }

        #region [ SaleHistoryData ]

        public string? Store { get; set; }

        public string? Customer { get; set; }

        public string? CustomerName { get; set; }

        public DateTime Issuance { get; set; }

        public string? Affiliate { get; set; }

        public string? AffiliateName { get; set; }

        public string? Document { get; set; }

        public string? CodSegment { get; set; }

        public string? NameSegment { get; set; }

        public decimal ShippingValue { get; set; }

        public string? ProductGroup { get; set; }

        public string? EconomicGroupCode { get; set; }

        public string? EconomicGroup { get; set; }

        public string? InvoceNumber { get; set; }

        public decimal? ClientSalesPrice { get; set; }

        public string? SupplierCode { get; set; }

        public string? SupplierName { get; set; }

        public string? PackageDescription { get; set; }

        public string? PackageUnity { get; set; }

        public long NBM { get; set; }

        public bool Promotional { get; set; }

        public string? Segment2 { get; set; }

        public string? StatusProduct { get; set; }

        public string? TypeOfShipping { get; set; }

        public string? ClientCountry { get; set; }

        public string? ClientState { get; set; }

        public string? ClientCity { get; set; }

        public string? TypeOfStore { get; set; }

        public string? ClientType { get; set; }

        public string? AffiliateCountry { get; set; }

        public string? AffiliateState { get; set; }

        public string? AffiliateCity { get; set; }

        public string? AffiliatePostalCode { get; set; }

        public string? DistributionCenter { get; set; }

        public string? Category1 { get; set; }

        public string? Category2 { get; set; }

        public string? Category3 { get; set; }

        public string? Category4 { get; set; }

        public string? Category5 { get; set; }

        public string? Category1Id { get; set; }

        public string? Category2Id { get; set; }

        public string? Category3Id { get; set; }

        public string? Category4Id { get; set; }

        public string? Category5Id { get; set; }

        public decimal? LastSaleRevenue { get; set; }

        #endregion

        public decimal PbCost { get; set; }

        public decimal Quantity { get; set; }

        public decimal Total { get; set; }

        #region [ Sale Price ]

        public decimal SalePrice { get; set; }

        public decimal SalePrice_Margin { get; set; }

        public decimal? SalePrice_Variation { get; set; }

        public decimal? SalePrice_Demand { get; set; }

        public decimal? SalePrice_Demand_Variation { get; set; }

        public string? SalePrice_Demand_CurveABC { get; set; }

        #endregion

        #region [ SalePriceInferiorLimit ]

        public decimal? SalePriceInferiorLimit { get; set; }

        public decimal? SalePriceInferiorLimit_Margin { get; set; }

        public decimal? SalePriceInferiorLimit_Variation { get; set; }

        public decimal? SalePriceInferiorLimit_Demand { get; set; }

        public decimal? SalePriceInferiorLimit_Demand_Variation { get; set; }

        public string? SalePriceInferiorLimit_Demand_CurveABC { get; set; }

        #endregion

        #region [ SalePriceSuperiorLimit ]

        public decimal? SalePriceSuperiorLimit { get; set; }

        public decimal? SalePriceSuperiorLimit_Margin { get; set; }

        public decimal? SalePriceSuperiorLimit_Variation { get; set; }

        public decimal? SalePriceSuperiorLimit_Demand { get; set; }

        public decimal? SalePriceSuperiorLimit_Demand_Variation { get; set; }

        public string? SalePriceSuperiorLimit_Demand_CurveABC { get; set; }

        #endregion

        #region [ LastSalePrice ]

        public decimal? LastSalePrice { get; set; }

        public decimal? LastSalePrice_Margin { get; set; }

        public decimal? LastSaleQuantity { get; set; }

        #endregion

        #region [ Others Values ]

        public decimal? MeanPrice_Margin { get; set; }

        public decimal? SaleTax { get; set; }

        public decimal? Margin { get; set; }

        #endregion

        public decimal Accuracy { get; set; }

        public DateTime? Outdated { get; set; }

        public decimal? StockQuantity { get; set; }

        public string? ProjectionsReference { get; set; }

        public long? ProductMarketResultId { get; set; }

        public decimal? ManualMaxPriceMarketResult { get; set; }
        public decimal? ManualAvgPriceMarketResult { get; set; }
        public decimal? ManualMinPriceMarketResult { get; set; }

        public bool IsPublished { get; set; } = false;

        public decimal? SalePrice_Margin_Bonus { get; set; }

        public decimal? SalePrice_Margin_Discount { get; set; }

        public long? ElasticityId { get; set; }

        public EnterpriseElasticityNewEntity? Elasticity { get; set; }

        public long? DistributionCenterId { get; set; }


        public long? EnterprisePolicyMarginPositioningId { get; set; }

        public long? PriceReplicateId { get; set; }

        public long? SaleTaxId { get; set; }


        public long? EnterpriseActivityLevelId { get; set; }

        public decimal? RegularPrice { get; set; }
        public decimal? IdealDiscount { get; set; }

        public decimal? Price1 { get; set; }

        public decimal? Price2 { get; set; }

        public decimal? Price3 { get; set; }

        public decimal? Price1_Margin { get; set; }

        public decimal? Price2_Margin { get; set; }

        public decimal? Price3_Margin { get; set; }

        public decimal? Price1_Demand { get; set; }

        public decimal? Price2_Demand { get; set; }

        public decimal? Price3_Demand { get; set; }

        public ICollection<EnterprisePriceProjection_WorkflowEntity> Workflows { get; set; }
    }
}
