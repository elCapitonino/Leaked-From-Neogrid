﻿namespace PredifyClientAPI.Services.PredifyAPI.Models
{
    public class PaginationAnswer : AnswerModel<object>
    {
        /// <summary>
        /// Pagina atual
        /// </summary>
        public int currentPage { get; set; }

        /// <summary>
        /// Total de páginas
        /// </summary>
        public int totalPages { get { return (int)Math.Ceiling(totalRecords / (decimal)(recordsPerPage != 0 ? recordsPerPage : 1)); } }

        /// <summary>
        /// Registros por página
        /// </summary>
        public int recordsPerPage { get; set; }

        /// <summary>
        /// Quantidade de registros na página atual.
        /// </summary>
        public int numberOfRecords { get; set; }

        /// <summary>
        /// Total de registros.
        /// </summary>
        public int totalRecords { get; set; }
    }

    public class PaginationAnswer<T> : AnswerModel<T>
    {
        /// <summary>
        /// Pagina atual
        /// </summary>
        public int currentPage { get; set; }

        /// <summary>
        /// Total de páginas
        /// </summary>
        public int totalPages
        {
            get
            {
                if (recordsPerPage != 0)
                    return (int)Math.Ceiling(totalRecords / (decimal)recordsPerPage);
                return 0;
            }
        }

        /// <summary>
        /// Registros por página
        /// </summary>
        public int recordsPerPage { get; set; }

        /// <summary>
        /// Quantidade de registros na página atual.
        /// </summary>
        public int numberOfRecords { get; set; }

        /// <summary>
        /// Total de registros.
        /// </summary>
        public int totalRecords { get; set; }
    }

    public class PaginationResponse<T>
    {
        /// <summary>
        /// Pagina atual
        /// </summary>
        public int CurrentPage { get; set; }

        /// <summary>
        /// Total de páginas
        /// </summary>
        public int TotalPages { get { return (int)Math.Ceiling(TotalRecords / (decimal)(RecordsPerPage != 0 ? RecordsPerPage : 1)); } }

        /// <summary>
        /// Registros por página
        /// </summary>
        public int RecordsPerPage { get; set; }

        /// <summary>
        /// Quantidade de registros na página atual.
        /// </summary>
        public int NumberOfRecords { get { return Records == null ? 0 : Records.Count(); } }

        /// <summary>
        /// Total de registros.
        /// </summary>
        public int TotalRecords { get; set; }

        /// <summary>
        /// Dados a serem listados
        /// </summary>
        public List<T> Records { get; set; }
    }

}
