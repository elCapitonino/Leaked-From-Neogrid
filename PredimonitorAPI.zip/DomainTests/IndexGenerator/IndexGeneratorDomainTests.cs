﻿using Domain.BackgroundTasks;
using Domain.IndexGenerator;
using Domain.IndexGenerator.DataSourceDomains.Interfaces;
using Domain.IndexGenerator.DataSourceDomains;
using Domain.IndexGenerator.Models;
using Domain.Models;
using Domain.Status;
using DomainTests.Extensions;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using MongoDB.Driver;
using Moq;
using Moq.Protected;
using Repository.DbContexts;
using Repository.Entity;
using Repository.UnitOfWork;
using Services.SearchAPI;
using System.Net;
using System.Text;
using Microsoft.EntityFrameworkCore.Diagnostics;

namespace DomainTests.IndexGenerator
{
    [TestClass()]
    public class IndexGeneratorDomainTests
    {
        private ServiceProvider _serviceProvider;

        [TestInitialize]
        public void Initialize()
        {
            var services = new ServiceCollection();
            var mongo = new Mock<MongoClient>().Object;

            services.AddTransient<IMongoClient>(provider => mongo);
            services.SetAutoMapper();

            services.AddDbContext<ApplicationDbContext>(options => options.UseSqlite("Filename=:memory:").ConfigureWarnings(opt => opt.Ignore(RelationalEventId.AmbientTransactionWarning)));

            services.AddDbContext<HorusDbContext>(options => options.UseMongoDB(mongo, "Horus").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            services.AddDbContext<InfoPriceSaoJoaoDbContext>(options => options.UseMongoDB(mongo, "InfroPriceSaoJoao").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            services.AddDbContext<NormalizerDbContext>(options => options.UseMongoDB(mongo, "Normalizer").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            services.AddDbContext<LinxDbContext>(options => options.UseMongoDB(mongo, "Linx").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            services.AddDbContext<NeogridDbContext>(options => options.UseMongoDB(mongo, "Neogrid").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            services.AddDbContext<NielsenDbContext>(options => options.UseMongoDB(mongo, "Nielsen").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            services.AddDbContext<SmarketCompetitorDbContext>(options => options.UseMongoDB(mongo, "SmarketCompetitor").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            services.AddDbContext<OfflineDbContext>(options => options.UseMongoDB(mongo, "Offline").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            services.AddDbContext<ScantechSupermaxiDbContext>(options => options.UseMongoDB(mongo, "Scantech").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);

            services.AddTransient(provider => new DatabricsDbContext("", ""));

            services.AddScoped<IIndexGeneratorDomain, IndexGeneratorDomain>();

            services.AddScoped<IIndexGeneratorHorusDomain, IndexGeneratorHorusDomain>();
            services.AddScoped<IIndexGeneratorInfoPriceDomain, IndexGeneratorInfoPriceDomain>();
            services.AddScoped<IIndexGeneratorIndiretaDomain, IndexGeneratorIndiretaDomain>();
            services.AddScoped<IIndexGeneratorSmarketDomain, IndexGeneratorSmarketDomain>();
            services.AddScoped<IIndexGeneratorNielsenPeraltaDomain, IndexGeneratorNielsenPeraltaDomain>();
            services.AddScoped<IIndexGeneratorNielsenVemDomain, IndexGeneratorNielsenVemDomain>();
            services.AddScoped<IIndexGeneratorPredifyDomain, IndexGeneratorPredifyDomain>();

            services.AddScoped<IStatusDomain, StatusDomain>();
            services.AddMemoryCache();

            services.Configure<AppsettingsOptions>(AppsettingsOptions =>
            {
                AppsettingsOptions.IndexConfiguration.PeriodyInMonthToIndexing = 6;
            });

            services.AddScoped<IIndexGeneratorDomain, IndexGeneratorDomain>();
            services.AddScoped<IBackgroundTaskQueue, BackgroundTaskQueue>();
            services.AddScoped<QueuedService>();


            var mockv4SearchResponseContent = File.ReadAllText("IndexGenerator/Assets/SearchAPIResponse.json");
            var mockv4SearchResponse = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                Content = new StringContent(mockv4SearchResponseContent, Encoding.UTF8, "application/json")
            };

            var handler = new Mock<HttpMessageHandler>();
            handler.Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.Is<HttpRequestMessage>(req => req.RequestUri.AbsolutePath.EndsWith("v4/search")),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(mockv4SearchResponse);


            services.AddHttpClient<ISearchAPIService, SearchAPIService>((service, client) => { client.BaseAddress = new Uri("http://yourapi.com"); })
                .ConfigurePrimaryHttpMessageHandler(() => handler.Object);


            services.AddScoped<IUnitOfWork, UnitOfWork>();
            services.AddLogging();
            _serviceProvider = services.BuildServiceProvider();

            var context = _serviceProvider.GetRequiredService<ApplicationDbContext>();
            context.Database.OpenConnection();
            context.Database.EnsureCreated();
        }
        [TestMethod()]
        public async Task GenerateIndexTest()
        {
            var domain = _serviceProvider.GetRequiredService<IIndexGeneratorDomain>();
            var uow = _serviceProvider.GetRequiredService<IUnitOfWork>();
            uow.Company.Create(new CompanyEntity() { Id = 3026, Company = "Teste" });
            uow.CompanyMonitoringCrawler.Create(new CompanyMonitoringCrawlerEntity()
            {
                CompanyId = 3026,
                IsDeleted = false,

                MonitoringCrawler = new MonitoringCrawlerEntity()
                {
                    IsDeleted = false,
                    Description = "Teste",
                    CompanyMonitorings = new List<CompanyMonitoringCrawlerEntity>()
                    {
                        new CompanyMonitoringCrawlerEntity()
                        {
                            IsDeleted = false,
                        }
                    },
                    Source = Repository.Enums.CrawlerSourceType.Predify,
                }
            });


            await domain.GenerateIndexAsync(new IndexGeneratorRequest()
            {
                CompanyId = 3026,
                TaskId = Guid.NewGuid(),
                UpdatedMonitoringItems = new List<MonitoringItemTags>()
                {
                    new MonitoringItemTags()
                    {
                        MonitoringItemId = 269393,
                    }
                }
            });
            Assert.Inconclusive();
        }
    }
}