﻿namespace PredifyClientAPI.Services.PredifyAPI.Models
{
    public enum EnterprisePriceProjectionSemaphoreType
    {
        Blue = 0,
        Green = 1,
        Yellow = 2,
        Red = 3,
        Purple = 4,
    }
}
