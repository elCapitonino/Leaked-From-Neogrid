import json

import requests

V1_REQUEST = """
{
  "start_date": "2023-01-06T12:28:16.674Z",
  "end_date": "2023-02-06T12:28:16.674Z",
  "id_company": 2648,  
  "data_source": 0,
  "products": [
    {
      "id": "101",
      "name": "CAFE CABOCLO EXTRA FORTE 500G",
      "code": "foobar",
      "price_range": {"lower": 1, "upper": 1000},
      "language": "pt-br"
    }
  ],
  "idcrawlers": [
    148, 150, 163, 164, 177, 190
  ],
  "fuzzy_threshold": 0.5,
  "language": "pt-br"
}
"""

V2_REQUEST = """
{
  "start_date": "2023-01-01T15:08:37.596Z",
  "end_date": "2023-01-14T15:08:37.596Z",
  "period_type": 0,
  "id_company": 2647,
  "idcrawlers": [
    148,150,163,164,177
  ], 
  "data_source": 0,
  "filters": {
    "products": [
      "CAFE CABOCLO EXTRA FORTE 500G"
    ],
    "language": "pt-br"
  }
}
"""
V2_Request_WithRequiredWords = '''
{
  "start_date": "2023-07-01T13:02:48.171Z",
  "end_date": "2023-07-30T13:02:48.171Z",
  "period_type": 0,
  "id_company": 2652,
  "idcrawlers": [
    210,
    212,
    213,
    214,
    215,
    216,
    148,
    224,
    209,
    185
  ],
  "data_source": 0,
  "filters": {
    "products": [
      "cartucho"
    ],
    "language": "pt-br",
    "required_words": [
      "hp",
      "664xl",
      "tinta;"
    ],
    "restricted_words": [],
    "exactVector": true
  },
  "relative_threshold": 0.9,
  "fuzzy_threshold": 0.5,
  "restrictive_fuzzy_threshold": 0.9,
  "use_top_word": true,
  "use_cosine": true,
  "cache": false
}
'''
LOCAL_URL = "http://localhost:8081"


def test_v3_v1():
    body = json.loads(V1_REQUEST)
    response = requests.post(LOCAL_URL + "/v3/search/v1", json=body)
    assert response.status_code == 200
    assert isinstance(response.json(), list)


def test_v3_v1_cache():
    body = json.loads(V1_REQUEST)
    body["cache"] = True
    response = requests.post(LOCAL_URL + "/v3/search/v1", json=body)
    assert response.status_code == 200
    assert isinstance(response.json(), list)
    # response_2 = requests.post(LOCAL_URL + "/v3/search/v1", json=body)
    # assert response.json() == response_2.json()
    # assert response.elapsed.total_seconds() >= response_2.elapsed.total_seconds()


def test_v3_v1_cache_diff():
    body = json.loads(V1_REQUEST)
    body["cache"] = True
    response = requests.post(LOCAL_URL + "/v3/search/v1", json=body)
    assert response.status_code == 200
    assert isinstance(response.json(), list)
    body["id_company"] = 0
    response_2 = requests.post(LOCAL_URL + "/v3/search/v1", json=body)
    assert response.json() != response_2.json()


def test_v3_v1_fuzzy_threshold():
    body = json.loads(V1_REQUEST)
    body["cache"] = True
    response = requests.post(LOCAL_URL + "/v3/search/v1", json=body)
    assert response.status_code == 200
    body["fuzzy_threshold"] = 1.0
    response_2 = requests.post(LOCAL_URL + "/v3/search/v1", json=body)
    result_2 = response_2.json()[0] if response_2 else {}
    result_2 = result_2.get("results") or []
    assert len(response.json()[0]["results"]) > len(result_2)


def test_v3_v2():
    body = json.loads(V2_REQUEST)
    response = requests.post(LOCAL_URL + "/v3/search/v2", json=body)
    assert response.status_code == 200
    assert isinstance(response.json(), list)


def test_v3_v2_cache():
    body = json.loads(V2_REQUEST)
    body["cache"] = True
    response = requests.post(LOCAL_URL + "/v3/search/v2", json=body)
    assert response.status_code == 200
    assert isinstance(response.json(), list)
    # response_2 = requests.post(LOCAL_URL + "/v3/search/v2", json=body)
    # assert response.json() == response_2.json()
    # assert response.elapsed.total_seconds() >= response_2.elapsed.total_seconds()


def test_v3_v2_cache_diff():
    body = json.loads(V2_REQUEST)
    body["cache"] = True
    response = requests.post(LOCAL_URL + "/v3/search/v2", json=body)
    assert response.status_code == 200
    assert isinstance(response.json(), list)
    body["id_company"] = 0
    response_2 = requests.post(LOCAL_URL + "/v3/search/v2", json=body)
    assert response.json() != response_2.json()

def test_check_required_words_cartesian_product_v3_v2():
    body = json.loads(V2_Request_WithRequiredWords)
    print(body)
    response = requests.post(LOCAL_URL + "/v3/search/v2", json=body)
    response_json = response.json()
    print(response_json)
    assert response.status_code  == 200
    for result in response_json[0]["result"]:
        assert "664" in result["product_name"]
def test_v3_v2_fuzzy_threshold():
    body = json.loads(V2_REQUEST)
    body["cache"] = True
    response = requests.post(LOCAL_URL + "/v3/search/v2", json=body)
    assert response.status_code == 200
    body["fuzzy_threshold"] = 1.0
    response_2 = requests.post(LOCAL_URL + "/v3/search/v2", json=body)
    result_2 = response_2.json()[0] if response_2 else {}
    result_2 = result_2.get("result") or []
    assert len(response.json()[0]["result"]) > len(result_2)

