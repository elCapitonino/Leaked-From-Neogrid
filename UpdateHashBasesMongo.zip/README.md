# Update Hash Bases Mongo
Este � um projeto Console desenvolvido em C# com .NET Core 8.0. O objetivo � atualizar as bases de monitoramento offline para add um campo novo.

## Execu��o
Para executar o projeto, voc� pode debuggar utilizando o Visual Studio ou o Visual Studio Code ou basta abrir a terminal e esta dentro da pasta executar o projeto passando os seguintes comando:

```
-s, --star-date         Required. Digite a data de in�cio (formato: AAAA-MM-DD)

-e, --end-date          Required. Digite a data de fim (formato: AAAA-MM-DD)

-c, --connection-string Required. Coloque a string de conex�o do Mongo

-b, --base              Required. Coloque a Base do Mongo que deseja acessar

--collection            Required. Coloque a Collection da base para consultar valores

--batch-size            (Default: 1000000) Coloque a quantidade de produtos que deseja atualizar em lote

--dry-run               (Default: false) Executar o comando em modo de simula��o. Nenhuma altera��o ser� feita

--base-type             Required. Coloque qual base deseja atualizar

--help                  Display this help screen.

--version               Display version information.
```

Exemplo de um comando

```
UpdateHash.exe -s 2024-03-01 -e 2024-03-19 -c suaConnectionString -b smarket_competitor --collection abv --batch-size 1 --dry-run true --base-type 6
```
