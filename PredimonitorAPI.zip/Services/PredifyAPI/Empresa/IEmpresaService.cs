﻿using Services.PredifyAPI.Empresa.Models;

namespace Services.PredifyAPI.Empresa
{
    public interface IEmpresaService
    {
        Task<IEnumerable<EmpresaSelecionarResponse>> GetEmpresaAsync();
    }
}
