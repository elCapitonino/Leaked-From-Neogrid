from datetime import datetime
from typing import List

from pydantic import BaseModel


class getAllDataModelRequest(BaseModel):
    start_date: datetime = None
    end_date: datetime = None
    ids_crawler: List[int] = None
    database: str = 'default'