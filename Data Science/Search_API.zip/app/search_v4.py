"""
Módulo com funções e classes do search V4. O search V4 busca apenas em bases oneline
(crawlers) por meio de similaridade de strings. O retorno usa o campo product_link
(do MongoDB) como identificador, o qual pode ser usado para buscar mais informações
sobre o produto no MongoDB.

As funções usam conexões assíncronas com o mongo e, na medida do possível, usam
expressões lazy para reduzir o uso de memória. Como cada chamada aos endpoints
pode gerar vários processos de busca (por dia), usamos um semáforo para limitar
a concorrência e uma fila para armazenar a saída das buscas.
"""

import itertools
import re
from asyncio import Queue, Semaphore
from dataclasses import dataclass
from datetime import date
from functools import partial
from typing import Any, Callable, Dict, Iterator, List, Optional

import numpy as np
from pydantic import BaseModel, confloat
from sklearn.metrics.pairwise import cosine_similarity

from app.fuzzy_vectorizer import FuzzyCountVectorizer
from app.logger import logger
from app.processing import Processing
from app.vectorizer import BM25, SimpleVectorizer, Vectorizer


class Tag(BaseModel):
    description: str


class Product(BaseModel):
    tags: List[Tag]
    id_monitoring_item: int
    required_words: Optional[List[str]] = None
    restricted_words: Optional[List[str]] = None


@dataclass
class PreparedTag:
    description: str
    top_word: str


@dataclass
class PreparedProduct:
    tags: List[PreparedTag]
    id_monitoring_item: int
    required_words: Optional[List[str]] = None
    restricted_words: Optional[List[str]] = None


def prepare_product(
    product_model: Product, string_processor: Callable[[str], str]
) -> PreparedProduct:
    tags = []
    for tag in product_model.tags:
        description = string_processor(tag.description)
        top_word = find_top_word(description)
        prepared_tag = PreparedTag(description, top_word)
        tags.append(prepared_tag)

    required_words = restricted_words = None

    if product_model.required_words is not None:
        required_words = [
            string_processor(word) for word in product_model.required_words
        ]
    if product_model.restricted_words is not None:
        restricted_words = [
            string_processor(word) for word in product_model.restricted_words
        ]
    prepared_product = PreparedProduct(
        tags=tags,
        required_words=required_words,
        restricted_words=restricted_words,
        id_monitoring_item=product_model.id_monitoring_item,
    )
    return prepared_product


class BaseSearchV4Request(BaseModel):
    id_company: int
    products: List[Product]
    language: str = "pt-br"
    relative_threshold: confloat(gt=0.0, le=1.0) = 0.9
    fuzzy_threshold: confloat(gt=0.0, le=1.0) = 0.75
    restrictive_fuzzy_threshold: confloat(gt=0.0, le=1.0) = 0.9
    use_top_word: bool = True
    use_cosine: bool = True
    vectorizer_mode: str = "bm25"


class DateSearchV4Request(BaseSearchV4Request):
    start_date: date
    end_date: date
    id_crawlers: List[int]


class TaskSearchV4Request(BaseSearchV4Request):
    task_ids: List[str]


class SearchV4Result(BaseModel):
    id_monitoring_item: int
    product_link: str
    crawler_id: int
    company_id: int
    seller: str
    category: Optional[str]
    brand: Optional[str]
    year: Optional[str]
    region: Optional[str]
    product_model: Optional[str]

    def __hash__(self):
        return hash(
            (
                self.id_monitoring_item,
                self.product_link,
                self.crawler_id,
                self.company_id,
                self.seller,
                self.category,
                self.brand,
                self.year,
                self.region,
                self.product_model,
            )
        )


def unwind_documents(
    docs: List[Dict[str, Any]], id_company: int
) -> List[SearchV4Result]:
    out = []
    for doc in docs:
        product_link = doc.get("product_link")
        id_crawler = doc.get("id_crawler")
        id_monitoring_item = doc.get("id_monitoring_item")
        if product_link is None:
            logger.warning(
                "skipping document (ID: %s) without product_link", doc.get("_id")
            )
            continue
        if id_crawler is None:
            logger.warning(
                "skipping document (ID: %s) without id_crawler", doc.get("_id")
            )
            continue
        if id_monitoring_item is None:
            logger.warning(
                "skipping document (ID: %s) without id_monitoring_item", doc.get("_id")
            )
            continue

        product_local = doc.get("product_local") or {}
        sellers = doc.get("sellers")
        if not sellers:
            logger.debug(
                "skipping document (ID: %s) without seller information", doc.get("_id")
            )
            continue

        for seller in sellers:
            region = seller.get("state_uf") or product_local.get("state")
            seller_name = seller.get("seller_name")
            if seller_name is None:
                logger.debug(
                    "skipping document (ID: %s) without seller_name", doc.get("_id")
                )
                continue

            result = SearchV4Result(
                id_monitoring_item=id_monitoring_item,
                product_link=product_link,
                crawler_id=id_crawler,
                company_id=id_company,
                seller=seller_name,
                category=doc.get("product_category"),
                brand=doc.get("product_brand"),
                year=doc.get("product_vehicle_year_model"),
                region=region,
                product_model=doc.get("product_model")
            )
            out.append(result)

    return out


def _prepare_document(
    doc: Dict[str, Any], string_processor: Callable[[str], str]
) -> Optional[Dict[str, Any]]:
    product_name_mongo = doc.get("product_name") or ""
    if not product_name_mongo:
        logger.warning(
            "skipping document (ID: %s) with no product_name", doc.get("_id")
        )
        return None

    product_name_mongo = string_processor(product_name_mongo)
    product_model_mongo = doc.get("product_model") or ""
    if product_model_mongo:
        product_model_mongo = string_processor(product_model_mongo)
        if product_model_mongo not in product_name_mongo:
            product_name_mongo += f" {product_model_mongo}"

    fields_to_process = [
        "product_name",
        "trash",
        "product_ean",
        "product_model",
        "product_description",
        "site_sku",
    ]
    check_string = " ".join(
        str(doc.get(field) or " ") for field in fields_to_process
    ).strip()
    check_string = string_processor(check_string)
    doc["check_string"] = check_string
    doc["processed_name"] = product_name_mongo
    return doc


def _set_similarity(matrix: np.ndarray) -> float:
    """
    Similaridade: tokens em comum / número de tokens em text_1.
    """
    overlap = (matrix[0] * matrix[1] > 0).sum()
    reference = (matrix[0] > 0).sum()
    return overlap / reference


def fuzzy_similarity(text_1: str, text_2: str, use_cosine: bool = True) -> float:
    """Calcula a similaridade utilizando um vetorizador fuzzy."""
    if len(text_1) == 0 or len(text_2) == 0:
        return 0.0

    vectorizer = FuzzyCountVectorizer()
    matrix, lengths = vectorizer.fit_transform([text_1, text_2])

    if use_cosine and lengths[0] >= 4:
        return cosine_similarity(matrix, matrix)[0, 1]
    return _set_similarity(matrix)


def find_top_word(name: str) -> Optional[str]:
    """
    Encontra a primeira palavra relevante de um nome.
    Provavelmente trata-se de uma palavra crucial para o produto.

    Palavra relevante: pelo menos três caracteres e com apenas letras.
    """
    words = re.findall(r"\b[^\W\d_]{3,}\b", name)
    if not words:
        return None
    return words[0].strip()


def _unnest(items: List[List[Any]]) -> List[Any]:
    return (subitem for item in items for subitem in item)


def check_required_words(
    doc: Dict[str, Any],
    prepared_product: PreparedProduct,
) -> bool:
    """Checa se as palavras exigidas estão presentes no nome."""
    if prepared_product.required_words is None or prepared_product.required_words == []:
        return True

    check_string = doc["check_string"]
    matrix = []
    lowercase_required_words = [
        word.lower() for word in prepared_product.required_words
    ]
    combinations = itertools.product(
        *[words.split(";") for words in lowercase_required_words]
    )

    for combination in combinations:
        vector = []
        for word in combination:
            if word != "":
                vector.append(word)
        matrix.append(vector)
    for vector in matrix:
        if all(word in check_string for word in vector):
            return True

    logger.debug(
        "required words %s not found in name <%s> (ID: %s)",
        lowercase_required_words,
        check_string,
        doc.get("_id"),
    )
    return False


def check_restricted_words(
    doc: Dict[str, Any],
    prepared_product: PreparedProduct,
) -> bool:
    """Checa se as palavras restritas estão presentes no nome."""
    if (
        prepared_product.restricted_words is None
        or prepared_product.restricted_words == []
    ):
        return False

    check_string = doc["check_string"]
    lowercase_restricted_words = [
        word.lower() for word in prepared_product.restricted_words
    ]
    found = any(word in check_string.lower() for word in lowercase_restricted_words)
    if found:
        logger.debug(
            "restricted words %s found in name %s (ID: %s)",
            lowercase_restricted_words,
            check_string,
            doc.get("_id"),
        )
    return found


def _fuzzy_similarity(
    doc: Dict[str, Any], prepared_product: PreparedProduct, request: BaseSearchV4Request
) -> Iterator[Dict[str, Any]]:
    name = doc["processed_name"]
    for tag in prepared_product.tags:
        fuzzy_sim = fuzzy_similarity(tag.description, name, request.use_cosine)
        adjuted_threshold = request.fuzzy_threshold
        if (
            request.use_top_word
            and tag.top_word is not None
            and tag.top_word not in name
        ):
            logger.debug(
                "top word %s not found in name <%s>, using restrictive threshold",
                tag.top_word,
                name,
            )
            adjuted_threshold = request.restrictive_fuzzy_threshold

        doc["tag"] = tag.description
        doc["fuzzy_score"] = fuzzy_sim
        doc["fuzzy_threshold"] = adjuted_threshold
        doc["id_monitoring_item"] = prepared_product.id_monitoring_item
        yield doc


def filter_fuzzy(doc: Dict[str, Any]) -> bool:
    valid = doc["fuzzy_score"] >= doc["fuzzy_threshold"]
    if not valid:
        logger.debug(
            "fuzzy_score de %.2f entre strings abaixo do threshold de %.2f: %s -- %s",
            doc["fuzzy_score"],
            doc["fuzzy_threshold"],
            doc["processed_name"],
            doc["tag"],
        )
    return valid


def _build_vectorizer(mongo_docs: List[Dict], vectorizer_mode: str) -> Vectorizer:
    queries = [doc["processed_name"] for doc in mongo_docs]

    if vectorizer_mode == "simple":
        return SimpleVectorizer(queries)
    return BM25(queries)


def _prefilter_by_score(doc_score, threshold: float) -> bool:
    doc, score = doc_score
    valid = score >= threshold
    if not valid:
        logger.debug(
            "excluindo o nome <%s> (ID: %s) no pre-filtro (relative_threshold)",
            doc.get("processed_name", "[empty name]"),
            doc["_id"],
        )
    return valid


def prefilter(
    docs: List[Dict[str, Any]],
    product: PreparedProduct,
    vectorizer: Vectorizer,
    request: BaseSearchV4Request,
):
    for tag in product.tags:
        scores = vectorizer.get_scores(tag.description)
        doc_scores = list(zip(docs, scores))
        prefilter_threshold = min(0.001, request.relative_threshold * max(scores))
        prefilter_fn = partial(_prefilter_by_score, threshold=prefilter_threshold)
        docs = filter(prefilter_fn, doc_scores)
        docs = (doc for (doc, _) in docs)
        yield docs


async def process_search_v4(
    request: BaseSearchV4Request,
    output_queue: Queue,
    get_docs_function,
    semaphore: Semaphore,
) -> None:
    logger.info("processing V4 search")
    logger.debug("V4 request %s", request)
    prep = Processing()
    string_processor = partial(prep.run, language=request.language)
    products = [
        prepare_product(product_model, string_processor)
        for product_model in request.products
    ]

    async with semaphore:
        docs = await get_docs_function(request)
        logger.info("search V4: loaded %d documents from mongo", len(docs))

    if not docs:
        return

    docs = (_prepare_document(doc, string_processor) for doc in docs)
    docs = [doc for doc in docs if doc is not None]
    vectorizer = _build_vectorizer(docs, request.vectorizer_mode)

    matched_docs = []
    for product in products:
        product_docs = prefilter(docs, product, vectorizer, request)
        product_docs = _unnest(product_docs)
        product_docs = ((doc, product) for doc in product_docs)

        product_docs = filter(
            lambda doc_product: check_required_words(*doc_product),
            product_docs,
        )
        product_docs = filter(
            lambda doc_product: not check_restricted_words(*doc_product),
            product_docs,
        )
        product_docs = (
            _fuzzy_similarity(doc, product, request) for (doc, product) in product_docs
        )
        product_docs = _unnest(product_docs)
        product_docs = filter(filter_fuzzy, product_docs)
        matched_docs.extend(list(product_docs))

    result = unwind_documents(matched_docs, request.id_company)

    for item in result:
        await output_queue.put(item)
