﻿using System.Diagnostics.CodeAnalysis;

namespace DI.Domain.ValueObjects
{
    [ExcludeFromCodeCoverage]
    public class ImpactReport
    {
        public string? ImagePath { get; set; }
        public IEnumerable<ImpactReportWorksheet> ImpactPreDataConsolidateds { get; set; }
    }
}
