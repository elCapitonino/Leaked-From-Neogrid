"""
Script para gerar relatório com preços sugeridos para filiais novas da VEM.
Os preços sugeridos são a mediana das modas dos preços das filiais da região.
A região é definida como a própria cidade, caso haja filiais nela, ou então
cidades próximas com filiais em um raio progressivamente maior.

Exemplo de uso:
python -m scripts.synthetic_prices --env producao --affiliate-info ./data/affiliate_info.xlsx --new-affiliates ./data/Pipeline\ 2023.xlsx
"""

import argparse
import math
import re
import warnings
from collections import defaultdict
from datetime import datetime, timedelta
from typing import NamedTuple, Optional

import numpy as np
import pandas as pd
from openpyxl.styles.numbers import FORMAT_NUMBER_00, FORMAT_PERCENTAGE_00
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.worksheet import Worksheet
from unidecode import unidecode

from geral import config

ID_COMPANY = 3026
PCT_SIGN = "%"
warnings.filterwarnings("ignore")


def distance_coords(coord1, coord2):
    """Distance between two coordinates in km."""
    lat1, lon1 = coord1
    lat2, lon2 = coord2
    radius = 6371  # km

    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = math.sin(dlat / 2) * math.sin(dlat / 2) + math.cos(
        math.radians(lat1)
    ) * math.cos(math.radians(lat2)) * math.sin(dlon / 2) * math.sin(dlon / 2)
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    d = radius * c

    return d


class City(NamedTuple):
    city: str
    uf: str


def clean_string(string):
    string = unidecode(string).lower().strip()
    string = re.sub(r"[^a-z\s]", " ", string)
    string = " ".join(string.split())
    return string


def nearest_cities(
    city: City,
    n: int,
    max_distance: int,
    available_cities: list[City],
    city_coords: dict[City, tuple[float, float]],
) -> list[City]:
    distances = [
        distance_coords(city_coords[city], city_coords[x]) for x in available_cities
    ]
    closest = [
        available_cities[i]
        for i in np.argsort(distances)[:n]
        if distances[i] <= max_distance
    ]
    return closest


def agg_histogram(prices: pd.Series):
    counts, bounds = np.histogram(prices)
    max_idx = np.argwhere(counts == np.max(counts)).ravel()
    full_price = count = 0
    for idx in max_idx:
        modal_prices = prices[(prices >= bounds[idx]) & (prices <= bounds[idx + 1])]
        full_price += modal_prices.sum()
        count += len(modal_prices)
    return full_price / count


def mean_mode(prices: pd.Series):
    counter = {}
    for p in prices.values:
        counter.setdefault(p, 0)
        counter[p] += 1
    max_count = max(c for c in counter.values())
    return np.mean([p for p, c in counter.items() if c == max_count])


def median_mode(prices: pd.Series):
    counter = {}
    for p in prices.values:
        counter.setdefault(p, 0)
        counter[p] += 1
    max_count = max(c for c in counter.values())
    return np.median([p for p, c in counter.items() if c == max_count])


# FIXME código duplicado do relatório geral
def _adjust_cell_width(
    worksheet: Worksheet, multiplier: float = 1.15, constant: int = 2
) -> None:
    dims = {}
    for row in worksheet.rows:
        for cell in row:
            if not cell.value or str(cell.value).startswith("="):  # ignorar fórmulas
                continue
            dims[cell.column_letter] = max(
                (
                    dims.get(cell.column_letter, 0),
                    constant + math.ceil(multiplier * len(str(cell.value))),
                ),
            )
    for col, value in dims.items():
        worksheet.column_dimensions[col].width = value


def _format_float_cols(worksheet: Worksheet, float_cols: list[int]) -> None:
    for col_loc in float_cols:
        col_letter = get_column_letter(col_loc + 1)
        for cell in worksheet[col_letter]:
            cell.number_format = FORMAT_NUMBER_00


def _format_pct_cols(worksheet: Worksheet, float_cols: list[int]) -> None:
    for col_loc in float_cols:
        col_letter = get_column_letter(col_loc + 1)
        for cell in worksheet[col_letter]:
            cell.number_format = FORMAT_PERCENTAGE_00


def float_columns(df: pd.DataFrame) -> list[int]:
    """Função para descobrir quais são as colunas de `df` com tipo `float`."""
    float_cols = [
            i
            for i, (type, col) in enumerate(zip(df.dtypes, df.columns))
            if type == "float" and PCT_SIGN not in col
        ]
    return float_cols


def pct_columns(df: pd.DataFrame) -> list[int]:
    """Função para descobrir quais são as colunas de `df` com o símbolo `PCT_SIGN` no nome."""
    pct_cols = [i for i, col in enumerate(df.columns) if PCT_SIGN in col]
    return pct_cols


class Task(NamedTuple):
    zbrm: str
    city: str
    uf: str


class Report(NamedTuple):
    zbrm: str
    city: str
    uf: str
    data: pd.DataFrame
    near_cities: list[City]
    distance: int


def generate_report(
    conn,
    task: Task,
    city_aff: dict[City, list[str]],
    av_cities: list[City],
    city_coords: dict[City, tuple[float, float]],
    lookback: int = 10,
) -> Optional[Report]:
    city = clean_string(task.city)
    uf = clean_string(task.uf)
    aff_city = City(city, uf)
    max_dist = 0
    near_cities = []
    for _ in range(20):
        near_cities = nearest_cities(aff_city, 3, max_dist, av_cities, city_coords)
        if near_cities:
            break
        max_dist += 50

    cities = [aff_city]
    if aff_city not in av_cities:
        cities = near_cities
        print(f"WARNING: city {aff_city} - using nearest cities {cities}")

    affiliates = [zbrm for city in cities for zbrm in city_aff[city]]
    print(f"zbrm: {task.zbrm} | near affiliates: {affiliates}")
    if not affiliates:
        print(f"ERROR: no affiliates for {task}")
        return None

    placeholder = ",".join("?" for _ in range(len(affiliates)))
    min_date = datetime.today() - timedelta(days=lookback)

    df_price_groups = pd.read_sql_query(
        f"""
        SELECT pg.*, F.Value AS Affiliate FROM Enterprise_Price_Groups AS pg
        JOIN Enterprise_Price_Groups_Filter F
        ON pg.IdEnterprisePriceGroups = F.IdEnterprisePriceGroups
        JOIN EnterprisePriceGroups_DefaultFilter DF
        ON F.IdEnterprisePriceGroups_DefaultFilter = DF.IdEnterprisePriceGroups_DefaultFilter
        WHERE pg.IdCompany = ?
        AND pg.Automatic = 1
        AND pg.DataHoraCriacao >= ?
        AND F.IsDeleted = 0
        AND DF.dbField = 7 -- Affiliate
        AND F.Value IN ({placeholder})
        """,
        conn,
        params=[ID_COMPANY, min_date.date(), *affiliates],
    )

    price_groups = (
        df_price_groups.sort_values("DataHoraCriacao", ascending=False)
        .groupby("Affiliate")
        .head(1)["IdEnterprisePriceGroups"]
        .tolist()
    )

    placeholder = ",".join("?" for _ in range(len(price_groups)))

    df_pp = pd.read_sql_query(
        f"""
        SELECT
            pp.ProductName,
            pp.Affiliate,
            CASE
                WHEN ppwa.Action = 0 THEN coalesce(vo.price, pp.SalePrice)
                ELSE pp.LastSalePrice
            END AS SuggestedPrice,
            pp.SalePrice AS IAPrice,
            coalesce(vo.price, pp.SalePrice) AS RulesPrice, 
            pp.LastSalePrice AS LastPrice,
            pp.PbCost,
            pp.Category3,
            pp.Category4,
            pp.Category5
        FROM Enterprise_Prices_Projection AS pp
        LEFT JOIN enterprise_values_overrides vo
        ON vo.projectionsreference = pp.projectionsreference
        JOIN enterprisepriceprojection_workflow ppw
        ON ppw.identerprisepriceprojection = pp.IdEnterprisePricesProjection
        JOIN enterprisepriceprojection_workflowaction ppwa
        ON ppwa.idpriceprojection_workflow = ppw.IdEnterprisePriceProjection_Workflow
        WHERE pp.IdEnterprisePriceGroups IN ({placeholder})
        """,
        conn,
        params=price_groups,
    )

    df_pp["margin"] = (df_pp["SuggestedPrice"] - df_pp["PbCost"]) / df_pp["SuggestedPrice"]

    df_agg = (
        df_pp.groupby(["ProductName"])["SuggestedPrice"]
        .agg([np.mean, np.median, np.histogram, agg_histogram, np.max, median_mode, mean_mode])
        .reset_index()
    )
    df_agg["diff"] = np.abs(df_agg["median"] - df_agg["agg_histogram"])
    df_agg["diff_pct"] = df_agg["diff"] / df_agg["median"]


    df_cost = (
        df_pp.groupby(["ProductName"])["PbCost"]
        .agg(median_mode)
        .reset_index()
    )

    df_cat = df_pp.groupby("ProductName").first().reset_index()
    df_out = pd.merge(
        df_agg,
        df_cat[["ProductName", "Category3", "Category4", "Category5"]],
        on="ProductName",
        how="inner",
    )

    df_out = pd.merge(df_out, df_cost, on="ProductName", how="inner")
    df_out["margin"] = (df_out["median_mode"] - df_out["PbCost"]) / df_out["median_mode"]

    df_out_filtered = df_out[df_out["margin"] > 0]
    if df_out_filtered.shape != df_out.shape:
        removed_lines = df_out.shape[0] - df_out_filtered.shape[0]
        all_lines = df_out.shape[0]
        print(f"--> WARNING: removing {removed_lines} lines ({removed_lines / all_lines:.2%}) with negative margin")
        print(df_out[df_out["margin"] <= 0]["ProductName"])
        df_out = df_out_filtered

    print()
    df_out = df_out[
        ["ProductName", "median_mode", "PbCost", "margin", "Category3", "Category4", "Category5"]
    ].rename(
        columns={
            "ProductName": "Descrição",
            "median_mode": "Preço Sugerido",
            "margin": "Margem do micromercado (%)",
            "PbCost": "Custo do micromercado",
            "Category3": "Categoria",
            "Category4": "Subcategoria",
            "Category5": "Grupo",
        }
    )
    return Report(task.zbrm, task.city, task.uf, df_out, cities, max_dist)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--env", required=True, type=str, choices=["producao", "preproducao"]
    )
    parser.add_argument(
        "--affiliate-info",
        required=True,
        type=str,
        help="caminho para planilha (XLSX) com informações sobre filiais existentes",
    )
    parser.add_argument(
        "--new-affiliates",
        required=True,
        type=str,
        help="caminho para planilha (XLSX) com informações sobre novas filiais",
    )
    parser.add_argument("--lookback", type=int, default=15)
    args = parser.parse_args()

    conn = config.getDadosAWSSession(args.env)

    ibge_cidades = pd.read_csv("./data/ibge_cidades.csv")
    codigo_uf = pd.read_csv("./data/codigo_uf.csv")
    ibge_cidades = pd.merge(
        ibge_cidades, codigo_uf[["codigo_uf", "uf"]], on="codigo_uf"
    )
    ibge_cidades = ibge_cidades.drop(columns=["codigo_uf", "siafi_id", "ddd"])
    ibge_cidades.head()

    city_coords = {
        City(clean_string(row.nome), clean_string(row.uf)): (
            row.latitude,
            row.longitude,
        )
        for row in ibge_cidades.itertuples()
    }

    df_aff = pd.read_excel(args.affiliate_info)
    df_aff["FINALIZADA"] = df_aff["FINALIZADA"].astype(bool)
    df_aff["SUCEDIDA"] = df_aff["SUCEDIDA"].astype(bool)
    df_aff["PARALISADA"] = df_aff["PARALISADA"].astype(bool)
    df_aff = df_aff[~df_aff["FINALIZADA"] & ~df_aff["PARALISADA"] & ~df_aff["SUCEDIDA"]]
    de_para = {"armacao de buzios": "armacao dos buzios"}
    av_cities = set()
    city_aff = defaultdict(list)
    for _, row in df_aff.iterrows():
        mun = clean_string(row["MUNICÍPIO"])
        mun = de_para.get(mun, mun)
        city = City(mun, clean_string(row["UF"]))
        if city not in city_coords:
            print(f"WARNING: unknown city {city}")
            continue
        av_cities.add(city)
        city_aff[city].append(str(row["ZBRM"]))

    av_cities = sorted(av_cities)

    df_pipeline = pd.read_excel(args.new_affiliates)
    df_pipeline = df_pipeline.replace(np.nan, "NA")
    tasks = []

    num_na = 0
    for _, row in df_pipeline.iterrows():
        zbrm = str(row["ZBRM"]).split(".")[0].strip()
        if zbrm == "NA":
            num_na += 1
            zbrm = f"NA {num_na}"
        task = Task(zbrm, row["MUNICÍPIO"], row["UF"])
        tasks.append(task)

    reports = []
    no_data = []
    for task in tasks:
        report = generate_report(
            conn, task, city_aff, av_cities, city_coords, args.lookback
        )
        if report is None:
            no_data.append(task)
            continue
        reports.append(report)

    fpath = "./data/new_affiliate_report.xlsx"
    with pd.ExcelWriter(fpath, engine="openpyxl") as writer:
        workbook = writer.book
        reports = sorted(reports, key=lambda x: x.zbrm)

        cities = []
        for report in reports:
            for city in report.near_cities:
                cities.append(
                    {
                        "ZBRM": report.zbrm,
                        "Município": report.city.title(),
                        "UF": report.uf.upper(),
                        "Distância Máxima": f"{report.distance} km",
                        "Município Vizinho": city.city.title(),
                        "UF Vizinha": city.uf.upper(),
                    }
                )

        df_cities = pd.DataFrame(cities)
        df_cities.to_excel(writer, sheet_name="Filiais", index=False)
        ws = workbook["Filiais"]
        _adjust_cell_width(ws)

        for report in reports:
            df_report = report.data
            zbrm = str(report[0]).split(".")[0]
            print(zbrm)
            df_report.to_excel(
                writer, sheet_name=zbrm, index=False, float_format="%.2f"
            )

            sheets = workbook.sheetnames
            for sheet in sheets:
                ws = workbook[sheet]
                _adjust_cell_width(ws)  # NOTE precisa ser feito antes de usar fórmulas

            for sheet in sheets:
                ws: Worksheet = workbook[sheet]
                _format_float_cols(ws, float_columns(df_report))
                _format_pct_cols(ws, pct_columns(df_report))

    print("filiais sem dados:")
    print("\n".join([f"{task}" for task in no_data]))

    print(f"arquivo salvo em {fpath}")


if __name__ == "__main__":
    main()
