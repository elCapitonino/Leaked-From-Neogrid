﻿using Newtonsoft.Json;
using Repository.Enums;
using Swashbuckle.AspNetCore.Annotations;

namespace Domain.Status.Models
{
    public class MonitoringItemResultsStatusRequest
    {
        public long CompanyId { get; set; }
        public string Message { get; set; }
        public int Step { get; set; }
        public Guid? TaskId { get; set; }
        [SwaggerSchema(ReadOnly = true)]
        [JsonIgnore]
        internal MonitoringItemResultsStatusType Status { get; set; } = MonitoringItemResultsStatusType.None;
    }
}
