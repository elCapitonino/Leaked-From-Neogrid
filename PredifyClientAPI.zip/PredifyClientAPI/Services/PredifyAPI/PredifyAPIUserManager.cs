﻿using Microsoft.Extensions.Options;
using PredifyClientAPI.Services.PredifyAPI.Access;
using PredifyClientAPI.Services.PredifyAPI.Empresa;
using PredifyClientAPI.Services.PredifyAPI.Models;
using PredifyClientAPI.Services.PredifyAPI.MonitoringItem;
using PredifyClientAPI.Services.PredifyAPI.PriceGroup;
using PredifyClientAPI.Services.PredifyAPI.PriceProjection;
using PredifyClientAPI.Services.PredifyAPI.SaleHistory;
using System.Net.Http.Headers;

namespace PredifyClientAPI.Services.PredifyAPI
{
    public class PredifyAPIUserManager
    {
        private readonly HttpClient client;

        public PredifyAPIUserManager(HttpClient client, IOptions<PredifyAPIOptions> options)
        {
            EmpresaService = new EmpresaService(client);
            AccessService = new AccessService(client);
            MonitoringItemService = new MonitoringItemService(client);
            SaleHistoryService = new SaleHistoryService(client);
            PriceGroupService = new PriceGroupService(client);
            PriceProjectionService = new PriceProjectionService(client);
            this.client = client;
        }

        public void SetAuthorization(string token) => client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
        public IEmpresaService EmpresaService { get; }
        public IAccessService AccessService { get; }
        public IMonitoringItemService MonitoringItemService { get; }
        public ISaleHistoryService SaleHistoryService { get; }
        public IPriceGroupService PriceGroupService { get; }
        public IPriceProjectionService PriceProjectionService { get; }
    }
}
