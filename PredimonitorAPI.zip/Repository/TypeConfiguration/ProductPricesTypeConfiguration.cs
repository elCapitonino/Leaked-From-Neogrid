﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using MongoDB.EntityFrameworkCore.Extensions;
using Repository.Attributes;
using Repository.DbContexts;
using Repository.Entity;

namespace Repository.TypeConfiguration
{
    [DbContextTypeConfiguration(typeof(NormalizerDbContext))]
    public class ProductPricesTypeConfiguration : TypeConfigurationBase<ProductPricesEntity>, IEntityTypeConfiguration<ProductPricesEntity>
    {
        public override void Configure(EntityTypeBuilder<ProductPricesEntity> builder)
        {
            builder.ToTable("product_prices").ToCollection("product_prices");
        }
    }
}
