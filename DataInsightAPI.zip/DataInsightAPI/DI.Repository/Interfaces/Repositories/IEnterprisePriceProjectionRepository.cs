﻿using DI.Repository.Entities;

namespace DI.Repository.Interfaces.Repositories
{
    public interface IEnterprisePriceProjectionRepository
    {
        IEnumerable<EnterprisePriceProjectionEntity> GetByIdPriceGroup(long priceGroupId);
        IEnumerable<EnterprisePriceProjectionEntity> GetByIdPriceGroup(List<long> priceGroupId);
    }
}