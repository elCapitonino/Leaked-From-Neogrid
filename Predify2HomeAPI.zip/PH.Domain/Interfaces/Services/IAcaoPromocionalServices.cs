﻿using Microsoft.AspNetCore.Http;
using PH.Domain.Domain;
using PH.Domain.DTO;

namespace PH.Domain.Interfaces.Services
{
    public interface IAcaoPromocionalServices
    {
        Task<AcaoPromocionalMainResponseDTO> GetAll(long idCompany);
        Task<AcaoPromocional> GetById(string AcaoPromocionalId);
        Task Add(AcaoPromocional AcaoPromocionalRequestDTO);
        Task Remove(string AcaoPromocionalId);
        Task Update(string AcaoPromocionalId, AcaoPromocional newAcaoPromocional);
        Task<ImportProdutoAcaoPromocional> ImportAcao(IFormFile file, long idCompany);
    }
}
