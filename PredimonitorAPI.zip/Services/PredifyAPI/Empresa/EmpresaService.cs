﻿using Newtonsoft.Json;
using Services.PredifyAPI.Empresa.Models;

namespace Services.PredifyAPI.Empresa
{
    public class EmpresaService: IEmpresaService
    {
        private readonly HttpClient _client;

        public EmpresaService(HttpClient client)
        {
            _client = client;
        }
        public async Task<IEnumerable<EmpresaSelecionarResponse>> GetEmpresaAsync()
        {
            var response = await _client.GetAsync("/api/Empresa/GetEmpresasSelecionar");
            var content = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
            {
                if (content.Contains("Acesso não autorizado", StringComparison.InvariantCultureIgnoreCase))
                {
                    throw new Exception("Acesso não autorizado");
                }

                return JsonConvert.DeserializeObject<IEnumerable<EmpresaSelecionarResponse>>(content);
            }

            throw new Exception(content);
        }
    }
}
