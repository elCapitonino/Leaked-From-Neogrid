﻿using Domain.IndexGenerator.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.IndexGenerator.DataSourceDomains.Interfaces
{
    public interface IIndexGeneratorScantechSupermaxiDomain
    {
        Task GenerateIndexScantechSupermaxiAsync(long companyId, int crawlerId, IEnumerable<MonitoringItemTags> monitoringItems, DateTime startDate, DateTime endDate, Guid? taskId, List<long> monitoringResultIdsDelete);
    }
}
