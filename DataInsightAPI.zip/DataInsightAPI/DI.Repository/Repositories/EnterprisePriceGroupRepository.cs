﻿using DI.Repository.Attributes;
using DI.Repository.Contexts;
using DI.Repository.Entities;
using DI.Repository.Interfaces.Repositories;
using DI.Repository.Repositories.Base;
using Microsoft.EntityFrameworkCore;

namespace DI.Repository.Repositories
{
    [UseSQLContext]
    public class EnterprisePriceGroupRepository : SqlGenericNoModifyRepository<EnterprisePriceGroupEntity>, IEnterprisePriceGroupRepository
    {
        public EnterprisePriceGroupRepository(SqlContext dbContext) : base(dbContext)
        {
        }

        public bool HasAccess(long companyId, long priceGroupId)
        {
            return _dbContext.Set<EnterprisePriceGroupEntity>().Any(x => x.EnterprisePriceGroupsId == priceGroupId && companyId == x.CompanyId);
        }

        public EnterprisePriceGroupEntity GetById(long PriceGroupId)
        {
            return _dbContext.Set<EnterprisePriceGroupEntity>().First(x => x.EnterprisePriceGroupsId == PriceGroupId);
        }

        public async Task<IEnumerable<EnterprisePriceGroupEntity>> GetAllById(IEnumerable<long> PriceGroupId)
        {
            var entities = await _dbContext
                .Set<EnterprisePriceGroupEntity>()
                .Where(x => PriceGroupId.Contains(x.EnterprisePriceGroupsId))
                .ToListAsync();

            return entities;
        }

        public async Task<IEnumerable<EnterprisePriceGroupEntity>> GetByYearMonth(DateTime date)
        {
            var entities = await _dbContext
                .Set<EnterprisePriceGroupEntity>()
                .Where(x => x.Published && x.PublishedDate.Value.Month == date.Month && x.PublishedDate.Value.Year == date.Year && !x.IsDeleted)
                .ToListAsync();

            return entities;
        }
    }
}
