﻿namespace Domain.IndexGenerator.Models
{
    public class IndexGeneratorForCrawlerRequest
    {
        public int CompanyId { get; set; }
        public Guid TaskId { get; set; }
    }
}
