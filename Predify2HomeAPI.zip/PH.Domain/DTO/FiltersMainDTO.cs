﻿namespace PH.Domain.DTO
{
    public class FiltersMainDTO
    {
        public FiltersDTO Loja { get; set; }
        public FiltersDTO Curva { get; set; }
        public FiltersDTO Categoria { get; set; }
    }

    public class FiltersDTO
    {
        public FiltersDTO()
        {
            Items = new List<FiltersItemsDTO>();
        }
        public List<FiltersItemsDTO> Items { get; set; }
    }

    public class FiltersItemsDTO
    {
        public string Text { get; set; }
        public string Value { get; set; }
    }
}
