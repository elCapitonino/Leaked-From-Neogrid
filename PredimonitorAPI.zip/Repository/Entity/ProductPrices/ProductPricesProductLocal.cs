﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;
using MongoDB.Driver.GeoJsonObjectModel;

namespace Repository.Entity.ProductPrices
{
    public class ProductPricesProductLocal
    {
        [BsonElement("generic_address")]
        public string? GenericAddress { get; set; }

        [BsonElement("country")]
        public string? Country { get; set; }

        [BsonElement("state")]
        public string? State { get; set; }

        [BsonElement("city")]
        public string? City { get; set; }

        [BsonElement("address")]
        public string? Address { get; set; }

        [BsonElement("neighbourhood")]
        public string? Neighbourhood { get; set; }

        [BsonElement("number")]
        public string? Number { get; set; }

        [BsonElement("complement")]
        public string? Complement { get; set; }

        [BsonElement("zip_code")]
        public string? ZipCode { get; set; }

        [BsonElement("coordinates")]
        public GeoJson2DGeographicCoordinatesWrapper? Coordinates { get; set; }

    }
}
