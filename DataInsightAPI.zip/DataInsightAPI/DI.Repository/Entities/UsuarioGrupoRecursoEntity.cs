﻿namespace DI.Repository.Entities
{
    public class UsuarioGrupoRecursoEntity : BaseEntity
    {
        public long IdUsuario_GrupoRecurso { get; set; }
        public string IdUsuario { get; set; }
        public long IdGrupoRecurso { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime DataHoraCriacao { get; set; }
        public DateTime DataHoraUltimaAlteracao { get; set; }

        public GrupoRecursoEntity? GrupoRecurso { get; set; }
    }
}
