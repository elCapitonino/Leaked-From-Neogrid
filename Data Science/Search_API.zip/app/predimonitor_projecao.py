import pandas as pd
import catboost as cat
from sklearn.preprocessing import SplineTransformer, OneHotEncoder, StandardScaler
import warnings
warnings.filterwarnings('ignore')
   
def pred_sem(json):

    #variavel para armazenar mensagens
    list_msg = []

    # print('json:', json)
    # print('data:', json['products'])
    json = pd.read_json(json)

    produtos = len(json['products'])
    print("Dentro do script do modelo, tamanho do data: ", produtos)
    df=pd.DataFrame()
    lista_key =[]
    lista_data=[]
    lista_value=[]
    for i in range(produtos):
    # for i in json['products']:
        json1 = json['products'].iloc[i]
        # print(json1)
        for j in range(len(json1['priceResults'])):
            # print(json1['productName'])
            # print(json1['priceResults'][j]['crawlerDate'])
            # print(json1['priceResults'][j]['price'])
            lista_key.append(json1['productName'])
            lista_data.append(json1['priceResults'][j]['crawlerDate'])
            lista_value.append(json1['priceResults'][j]['price'])
    df=pd.DataFrame({'products':lista_key,'data':lista_data,'price':lista_value})
    df['data'] = pd.to_datetime(df['data'])
    # Criação do dia '0'
    df["t_dias"] = (
    df["data"] - min(df["data"])
    ).dt.total_seconds() / (24 * 60 * 60)
    print(df['t_dias'])
    # Criação dos Splines
    spl_trans = SplineTransformer(n_knots=24, extrapolation="constant")
    spl_trans.fit(df[["t_dias"]])
    spl_names = ["S" + str(i) for i in range(spl_trans.n_features_out_)]
    df = pd.concat(
    [
        df.reset_index(),
        pd.DataFrame(
            spl_trans.transform(df[["t_dias"]]),
            columns=spl_names,
        ),
    ],
    axis=1,
    )
    df =df.drop(columns= 'index')
    # Criação Mês/Dia da semana
    df["mes"] = df["data"].dt.month.astype(str)
    df["dia_semana"] = df["data"].dt.weekday.astype(str)
    lista_dummie=["mes", "dia_semana"]
    #Criação Dummies Mês e dia_semana
    ohe_fit = OneHotEncoder(drop="first", sparse=False, handle_unknown= 'ignore')
    ohe_fit.fit(df[lista_dummie])
    df = pd.concat(
    [
        df,
        pd.DataFrame(
            ohe_fit.transform(df[lista_dummie]),
            columns=ohe_fit.get_feature_names_out(input_features = lista_dummie),

        ),
    ],
    axis=1,
    )
    dummy_names = list(ohe_fit.get_feature_names_out())
    # Treinando o modelo

    
    df_final=pd.DataFrame()
    for produto in df['products'].unique():
        try:
            df_pred_aux=pd.DataFrame()
            df_pred_aux = df[df['products']==produto]
            final_list = spl_names + dummy_names + ["t_dias"] 
            X =     df_pred_aux[final_list]
            y = df_pred_aux['price']
            scaler = StandardScaler()
            scaler.fit(X)
            cat_fit = cat.CatBoostRegressor(iterations=5000, od_wait = 500, silent=True, allow_const_label=True)
            cat_fit.fit(scaler.transform(X), y)

            # Realizando a previsão
            ##Criação da tabela
            X_pred = range(int(max(df['t_dias']+1)), int(max(df['t_dias'])) + 7)
            print(X_pred)
            min_date = min(df['data'])
            tb_pred = pd.DataFrame({'t_dias' : X_pred, 'aux':1})
            df_aux = pd.DataFrame({'product':df['products'].unique(), 'aux':1})
            tb_pred =tb_pred.merge(df_aux, on='aux', how='left')
            tb_pred=tb_pred.drop(columns='aux')
            tb_pred['data'] = pd.to_timedelta(tb_pred['t_dias'], 'd') + min_date
            tb_pred["mes"] = tb_pred["data"].dt.month.astype(str)
            tb_pred["dia_semana"] = tb_pred["data"].dt.weekday.astype(str)
            tb_pred = pd.concat(
                [
                    tb_pred,
                    pd.DataFrame(
                        ohe_fit.transform(tb_pred[lista_dummie]),
                        columns=dummy_names,
                    ),
                ],
                axis=1,
            )

            tb_pred = pd.concat(
                [
                    tb_pred,
                    pd.DataFrame(
                        spl_trans.transform(tb_pred[["t_dias"]]),
                        columns=spl_names,
                    ),
                ],
                axis=1,
            )
            ## Previsão 
            tb_pred_aux= tb_pred[tb_pred['product']==produto]
            tb_pred_aux['pred'] = cat_fit.predict(scaler.transform(tb_pred_aux[final_list]))
            df_final=df_final.append(tb_pred_aux)
        except Exception as e:
            list_msg.append(str(e))

    # agrupando para transformar em lista
    df_final = df_final[['product','data','pred']]
    df_final['data'] =df_final['data'].astype(str)
    grouped = df_final.groupby('product')

    response_list = []
    for name, group in grouped:
        group_result ={'key':name,'priceResults':[]}        
        for index,item in group.iterrows():
            group_result['priceResults'].append({'data':item['data'], 'price':item['pred']})
        response_list.append(group_result)

    return response_list, list_msg
