from models.search_v3_models import SearchProductsPredmonitorBM25
from predimonitor_type import *
from async_mongo import AsyncMongoConnect
from logger import logger

class Search_horus():

    def __init__(self):
        self.dbMongo = AsyncMongoConnect()

    async def search_get(self, id_crawlers_offline, data_source, ean, start_date, end_date):

        result_list_horus = []

        num_ean = None
        if (ean != None):
            if ((ean[0].ean != None) and (len(ean[0].ean) != 0)):
                num_ean = ean[0].ean
        if (id_crawlers_offline != None):
            for i in id_crawlers_offline:
                # print(i)
                idcrawlers = None
                city_off = None
                state_off = None
                network_off = None
                cnpj_off = None
                if (i.idcrawlers != None):
                    idcrawlers = i.idcrawlers
                if ((i.city != None) and (len(i.city) != 0)):
                    city_off = i.city
                if (i.state != None):
                    state_off = i.state
                if (i.networks != None):
                    network_off = i.networks
                if ((i.cnpj != None) and (len(i.cnpj) != 0)):
                    cnpj_off = i.cnpj

                if ((state_off == None) or (num_ean == None) or (network_off == None)):
                    continue

                if ((data_source == data_source.Horus_search) and (state_off != None) and (num_ean != None)):
                    try:

                        result_horus = await self.dbMongo.get_products_pred_monitor_horus(
                            city_off, state_off, network_off, cnpj_off, start_date, end_date, num_ean)
                        state_off = None
                        num_ean = None
                        for i_horus in result_horus:
                            result_list_horus.append({
                                'id': str(i_horus['_id']),
                                'id_crawler': idcrawlers,
                                "product_name": i_horus['description'],
                                "product_link": str(i_horus['_id']),
                                "site_sku": 0,
                                "source": "Horus",
                                "language": "pt-br",
                                "product_brand": None,
                                "id_product_normalized": None,
                                "trash_score": 0,
                                "crawler_date": i_horus["date"],
                                "seller_name": i_horus["brand"],
                                "prices": [
                                    {
                                        'price': float(str(i_horus["price"]))
                                    }
                                ],
                                "product_local":
                                    {
                                        'state': i_horus["uf"],
                                        'city': i_horus["city"]
                                    },
                                "product_manufacture_year": None,
                                "product_used_hours": None
                            })
                    except Exception as ex:
                        logger.error(" ------ Erro dados horus  ------")
                        logger.error(ex)

            return result_list_horus

    async def search_get_V1(self, id_crawlers_offline, data_source, ean, start_date, end_date):

        result_list_horus = []

        num_ean = None
        if (ean != None):
            if ((ean[0].ean != None) and (len(ean[0].ean) != 0)):
                num_ean = ean[0].ean
        if (id_crawlers_offline != None):
            for i in id_crawlers_offline:
                # print(i)
                idcrawlers = None
                city_off = None
                state_off = None
                network_off = None
                cnpj_off = None
                if (i.idcrawlers != None):
                    idcrawlers = i.idcrawlers
                if ((i.city != None) and (len(i.city) != 0)):
                    city_off = i.city
                if (i.state != None):
                    state_off = i.state
                if (i.networks != None):
                    network_off = i.networks
                if ((i.cnpj != None) and (len(i.cnpj) != 0)):
                    cnpj_off = i.cnpj

                if ((state_off == None) or (num_ean == None) or (network_off == None)):
                    continue

                if ((data_source == data_source.Horus_search) and (state_off != None) and (num_ean != None)):
                    try:

                        result_horus = await self.dbMongo.get_products_pred_monitor_horus(
                            city_off, state_off, network_off, cnpj_off, start_date, end_date, num_ean)
                        state_off = None
                        num_ean = None
                        for i_horus in result_horus:
                            result_list_horus.append({
                                'id': str(i_horus['_id']),
                                'id_crawler': idcrawlers,
                                "product_name": i_horus['description'],
                                "product_link": str(i_horus['_id']),
                                "product_ean": str(i_horus['ean']),
                                "site_sku": 0,
                                "source": "Horus",
                                "language": "pt-br",
                                "product_brand": None,
                                "id_product_normalized": None,
                                "trash_score": 0,
                                "crawler_date": i_horus["date"],
                                "sellers": [
                                    {
                                        "seller_name": i_horus["brand"],
                                        "prices":[
                                            {
                                                'price': float(str(i_horus["price"])),
                                                "price_currency": "BRL"
                                            }
                                        ]
                                    }
                                ],
                                "product_local":
                                    {
                                        'state': i_horus["uf"],
                                        'city': i_horus["city"]
                                    },
                                "product_manufacture_year": None,
                                "product_used_hours": None
                            })
                    except Exception as ex:
                        logger.error(" ------ Erro dados horus  ------")
                        logger.error(ex)

            return result_list_horus

    async def search_get_V1_Peralta(self, products):
        full_result = []
        result_list = []

        cnpjs = None
        if (products.idcrawlers_offline is not None):
            cnpjs = [obj.cnpj for obj in products.idcrawlers_offline]
            cnpjs = list(filter(lambda x: x is not None and x !=
                          '' and x.strip() != '', cnpjs))

        ean = None
        start_date = products.start_date
        end_date = products.end_date
        if products is None or products.products[0].ean is None or not products.products[0].ean:
            return []

        ean = products.products[0].ean
        try:
            result_horus = await self.dbMongo.get_products_horus_market_inteligence_by_ean(start_date, end_date, ean, cnpjs)

            for documento in result_horus:

                item = documento["documento"]
                name = item['description']
                result_list.append(
                    {
                        'id': str(item['_id']),
                        'id_crawler': 85,
                        "product_name": name,
                        "product_link": item['ean']+item['cnpj'],
                        "product_ean": item['ean'],
                        "site_sku": 0,
                        "source": "Offline",
                        "language": "pt-br",
                        "product_brand": item['brand'],
                        "id_product_normalized": None,
                        "trash_score": 0,
                        "crawler_date": item["date"],
                        "sellers": [
                            {
                                "seller_name": item["brand"],
                                "prices":[{
                                    'price': str(item['price']),
                                    "price_currency": "BRL"
                                }]
                            }
                        ],
                        "product_local": {
                            'state': item['uf'],
                            'city': item['city']
                            },
                        "product_manufacture_year": None,
                        "product_used_hours": None
                    })

            full_result.append({
                "name": products.products[0].name,
                "results": result_list
            })

        except Exception as ex:
            print(" ------ Erro dados Horus  ------")
            print(str(ex))

        return full_result
    

    async def search_get_V2(self, products: SearchProductsPredmonitorBM25):
        full_result = []
        result_list = []

        cnpjs = None
        if (products.idcrawlers_offline is not None):
            cnpjs = [obj.cnpj for obj in products.idcrawlers_offline]
            cnpjs = list(filter(lambda x: x is not None and x !=
                          '' and x.strip() != '', cnpjs))
            
        start_date = products.start_date
        end_date = products.end_date

        t_produtos = products.filters.products
        t_eans = products.filters.eans
        t_brand = products.filters.brands
        t_categories = products.filters.categories
        t_sellers = products.filters.sellers

        # Crie um dicionário para armazenar os registros pelos nomes
        mapeamento = {objeto.description: objeto.ean for objeto in t_eans}


        eans = []
        # Agora, você pode acessar os registros usando os nomes da lista
        for p in t_produtos:
            ean = mapeamento.get(p, None)  # Use get() para lidar com nomes ausentes
            if ean is not None:
                eans.append(ean)

        try:
            for ean in eans:
                result_list = []
                result_horus = await self.dbMongo.get_products_horus_v2_by_ean(start_date, end_date, ean, cnpjs, t_brand, t_categories, t_sellers)

                for documento in result_horus:
                    item = documento
                    try:
                        name = item['description']
                        result_list.append({
                            'id': str(item['_id']),
                            'id_crawler': 85,
                            "product_name": name,
                            "product_link": item['ean']+item['cnpj'],
                            "product_ean": item['ean'],
                            "site_sku": 0,
                            "source": "Horus",
                            "language": "pt-br",
                            "product_brand": item['brand'],
                            "id_product_normalized": None,
                            "trash_score": 0,
                            "crawler_date": item["date"],
                            "seller_name": item["brand"],
                            "format_market": item.get("format_market"),
                            "coordinates": {
                                "longitude": item['coordinates']['coordinates'][0],
                                "latitude": item['coordinates']['coordinates'][1],
                            } if 'coordinates' in item and 'coordinates' in item['coordinates'] and len(item['coordinates']['coordinates']) == 2 else None,
                            "prices": [
                                {
                                    'price': str(item['price'])
                                }
                            ],
                            "product_local":
                            {
                                'state': item['uf'],
                                'city': item['city']
                            },
                            "product_manufacture_year": None,
                            "product_used_hours": None
                        })
                        
                    except Exception as ex:
                        print(" ------ Erro dados Horus  ------")
                        print(str(ex))

                full_result.append({
                    "product": ean,
                    "result": result_list
                })

        except Exception as ex:
            print(" ------ Erro dados Horus  ------")
            print(str(ex))

        return full_result
    
    async def search_get_V2_cost(self, products: SearchProductsPredmonitorBM25):
        full_result = []
        result_list = []

        cnpjs = None
        if (products.idcrawlers_offline is not None):
            cnpjs = [obj.cnpj for obj in products.idcrawlers_offline]
            cnpjs = list(filter(lambda x: x is not None and x !=
                          '' and x.strip() != '', cnpjs))
            
        start_date = products.start_date
        end_date = products.end_date

        t_produtos = products.filters.products
        t_eans = products.filters.eans
        t_brand = products.filters.brands
        t_categories = products.filters.categories
        t_sellers = products.filters.sellers

        # Crie um dicionário para armazenar os registros pelos nomes
        mapeamento = {objeto.description: objeto.ean for objeto in t_eans}


        eans = []
        # Agora, você pode acessar os registros usando os nomes da lista
        for p in t_produtos:
            ean = mapeamento.get(p, None)  # Use get() para lidar com nomes ausentes
            if ean is not None:
                eans.append(ean)

        try:
            for ean in eans:
                result_list = []
                result_horus = await self.dbMongo.get_products_horus_v2_cost_by_ean(start_date, end_date, ean, cnpjs, t_brand, t_categories, t_sellers)

                for documento in result_horus:
                    item = documento
                    try:
                        name = item['description']
                        result_list.append({
                            'id': str(item['_id']),
                            'id_crawler': 85,
                            "product_name": name,
                            "product_link": item['ean']+item['cnpj'],
                            "product_ean": item['ean'],
                            "site_sku": 0,
                            "source": "Horus",
                            "language": "pt-br",
                            "product_brand": item['brand'],
                            "id_product_normalized": None,
                            "trash_score": 0,
                            "crawler_date": item["date"],
                            "seller_name": item["brand"],
                            "format_market": item.get("format_market"),
                            "coordinates": {
                                "longitude": item['coordinates']['coordinates'][0],
                                "latitude": item['coordinates']['coordinates'][1],
                            } if 'coordinates' in item and 'coordinates' in item['coordinates'] and len(item['coordinates']['coordinates']) == 2 else None,
                            "prices": [
                                {
                                    'price': str(item['price'])
                                }
                            ],
                            "product_local":
                            {
                                'state': item['uf'],
                                'city': item['city']
                            },
                            "product_manufacture_year": None,
                            "product_used_hours": None
                        })
                        
                    except Exception as ex:
                        print(" ------ Erro dados Horus  ------")
                        print(str(ex))

                full_result.append({
                    "product": ean,
                    "result": result_list
                })

        except Exception as ex:
            print(" ------ Erro dados Horus  ------")
            print(str(ex))

        return full_result


