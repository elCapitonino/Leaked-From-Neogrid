class MemoryCache:

    __instance = None

    def __new__(cls, *args, **kwargs):
        if not MemoryCache.__instance:
            MemoryCache.__instance = super(
                MemoryCache, cls).__new__(cls, *args, **kwargs)
        return MemoryCache.__instance

    def __init__(self):
        pass

    def set_brands(self, brands):
        # print("set_brand:", brands)
        self.brands = brands
        # print("brands:", self.brands)
        print("brand:", len(self.brands))

    def set_products(self, products):
        self.products = products
        # print("products:", self.products)
        print("products:", len(self.products))

    def set_categories(self, categories):
        self.categories = categories
        print("categories:", len(self.categories))

    def set_voltage(self, voltage):
        self.voltage = voltage
        print("voltage:", len(self.voltage))

    def set_materials(self, materials):
        self.materials = materials
        print("materials:", len(self.materials))

    def set_metric_units(self, metric_unit):
        self.metric_units = metric_unit
        print("metric_units:", len(self.metric_units))

    def set_power(self, power):
        self.power = power
        print("power:", len(self.power))

    def set_dimensions(self, dimensions):
        self.dimensions = dimensions
        print("dimensions:", len(self.dimensions))

    def set_energy_source(self, energy_source):
        self.energy_source = energy_source
        print("energy_source:", len(self.energy_source))

    def set_size(self, size):
        self.size = size
        print("size:", len(self.size))

    def set_state(self, state):
        self.state = state

    def set_products_nomalized(self, products_normalized):
        #print("set_products_nomalized:", products_normalized)
        self.products_normalized = products_normalized

    #####################################################

    def get_brands(self, language):
        if language in self.brands:
            return self.brands[language]
        else:
            #print("não tem brands para o idioma:", language)
            brands_vazio = {}
            return brands_vazio

    def get_products(self, language):
        if language in self.products:
            return self.products[language]
        else:
            #print("não tem products para o idioma:", language)
            products_vazio = {}
            return products_vazio

    def get_categories(self, language):
        if language in self.categories:
            return self.categories[language]
        else:
            #print("não tem categories para o idioma:", language)
            categories_vazio = {}
            return categories_vazio

    def get_voltage(self, language):
        if language in self.voltage:
            return self.voltage[language]
        else:
            #print("não tem voltage para o idioma:", language)
            voltage_vazio = {}
            return voltage_vazio

    def get_materials(self, language):
        if language in self.materials:
            return self.materials[language]
        else:
            #print("não tem materials para o idioma:", language)
            materials_vazio = {}
            return materials_vazio

    def get_metric_units(self, language):
        if language in self.metric_units:
            return self.metric_units[language]
        else:
            #print("não tem metric_units para o idioma:", language)
            metric_units_vazio = {}
            return metric_units_vazio

    def get_power(self, language):
        if language in self.power:
            return self.power[language]
        else:
            #print("não tem power para o idioma:", language)
            power_vazio = {}
            return power_vazio

    def get_dimensions(self, language):
        if language in self.dimensions:
            return self.dimensions[language]
        else:
            #print("não tem dimensões para o idioma:", language)
            dimensions_vazio = {}
            return dimensions_vazio

    def get_energy_source(self, language):
        if language in self.energy_source:
            return self.energy_source[language]
        else:
            #print("não tem energy_source para o idioma:", language)
            energy_source_vazio = {}
            return energy_source_vazio

    def get_size(self, language):
        if language in self.size:
            return self.size[language]
        else:
            #print("não tem size para o idioma:", language)
            size_vazio = {}
            return size_vazio

    def get_state(self, language):
        if language in self.state:
            return self.state[language]
        else:
            #print("não tem state para o idioma:", language)
            state_vazio = {}
            return state_vazio

    def get_products_normalized(self, language):
        if language in self.products_normalized:
            return self.products_normalized[language]
        else:
            #print("não tem products_normalized para o idioma:", language)
            products_normalized_vazio = {}
            return products_normalized_vazio

    ###################################################

    # def update_brand(self, brand):
    #     # print("update_brand:", brand)
    #     self.brands.add(brand)

    def update_products_nomal(self, i):

        list_product_update = []
        list_product_update.append({"_id": i["_id"], "product": i["product"], "brands": i["brands"],
                                    "category": i["category"], "materials": i["materials"], "voltage": i["voltage"],
                                    "metric_units": i["metric_units"], "power": i["power"], "ean": i["ean"], "ncm": ["ncm"],
                                    "model": i["model"], "trash": i["trash"], "dimensions": i["dimensions"],
                                    "energy_source": i["energy_source"], "size": i["size"], 'language': i["language"]})

        if i["language"] in self.products_normalized:
            '''
            Apenas atualiza o produto se o idioma existir
            '''
            self.products_normalized[i["language"]].append({"_id": i["_id"], "product": i["product"], "brands": i["brands"],
                                                            "category": i["category"], "materials": i["materials"], "voltage": i["voltage"],
                                                            "metric_units": i["metric_units"], "power": i["power"], "ean": i["ean"], "ncm": ["ncm"],
                                                            "model": i["model"], "trash": i["trash"], "dimensions": i["dimensions"],
                                                            "energy_source": i["energy_source"], "size": i["size"], 'language': i["language"]})
        else:
            '''
            Adiciona o idioma ao dicionário
            '''
            self.products_normalized[i["language"]] = list_product_update
            self.products_normalized.update(
                {i["language"]: list_product_update})

        #print("products_normalized : ",  self.products_normalized)

    def monitor_dictionary_normalized(self):

        return ({"brands": len(self.brands), "products": len(self.products), "categories": len(self.categories),
                "voltage": len(self.voltage), "materials": len(self.materials), "metric_units": len(self.metric_units),
                 "power": len(self.power), "dimensions": len(self.dimensions), "energy_source": len(self.energy_source),
                 "size": len(self.size), "products_normalized": len(self.products_normalized)})
