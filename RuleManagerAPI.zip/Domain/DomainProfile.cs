﻿using AutoMapper;

namespace Domain
{
    public class DomainProfile:Profile
    {
    }
}
