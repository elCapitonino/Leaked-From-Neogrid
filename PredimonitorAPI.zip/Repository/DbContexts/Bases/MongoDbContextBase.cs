﻿using Microsoft.EntityFrameworkCore;
using MongoDB.Driver;

namespace Repository.DbContexts.Bases
{
    public abstract class MongoDbContextBase : DbContextBase
    {
        private readonly IMongoClient _mongoClient;
        protected MongoDbContextBase(DbContextOptions options, IMongoClient mongoClient) : base(options)
        {
            _mongoClient = mongoClient;
        }
        public IMongoClient Client => _mongoClient;
        
    }
}
