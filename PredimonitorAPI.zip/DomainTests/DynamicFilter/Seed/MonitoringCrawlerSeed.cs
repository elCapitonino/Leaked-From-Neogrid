﻿using Repository.Entity;

namespace DomainTests.DynamicFilter.Seed
{
    public class MonitoringCrawlerSeed
    {

        public static List<MonitoringCrawlerEntity> GetTestData()
        {
            return new List<MonitoringCrawlerEntity>
            {
                new MonitoringCrawlerEntity { Id = 1, Description = "Americanas" },
                new MonitoringCrawlerEntity { Id = 2, Description = "Mercado Livre" },
                new MonitoringCrawlerEntity { Id = 3, Description = "Amazon" },
                new MonitoringCrawlerEntity { Id = 4, Description = "Carrefour" },
                new MonitoringCrawlerEntity { Id = 5, Description = "OLX" },
                new MonitoringCrawlerEntity { Id = 6, Description = "eBay" },
                new MonitoringCrawlerEntity { Id = 7, Description = "Walmart" },
                new MonitoringCrawlerEntity { Id = 8, Description = "Submarino" },
                new MonitoringCrawlerEntity { Id = 9, Description = "Magazine Luiza" },
                new MonitoringCrawlerEntity { Id = 10, Description = "Casas Bahia" },
                new MonitoringCrawlerEntity { Id = 11, Description = "Shoptime" },
                new MonitoringCrawlerEntity { Id = 12, Description = "Extra" },
                new MonitoringCrawlerEntity { Id = 13, Description = "Ponto Frio" },
                new MonitoringCrawlerEntity { Id = 14, Description = "Fast Shop" },
                new MonitoringCrawlerEntity { Id = 15, Description = "Kabum" },
                new MonitoringCrawlerEntity { Id = 16, Description = "Lojas Americanas" },
                new MonitoringCrawlerEntity { Id = 17, Description = "Leroy Merlin" },
                new MonitoringCrawlerEntity { Id = 18, Description = "Netshoes" },
                new MonitoringCrawlerEntity { Id = 19, Description = "Centauro" },
                new MonitoringCrawlerEntity { Id = 20, Description = "Decathlon" },
                new MonitoringCrawlerEntity { Id = 21, Description = "AliExpress" },
                new MonitoringCrawlerEntity { Id = 22, Description = "Zoom" },
                new MonitoringCrawlerEntity { Id = 23, Description = "Buscapé" },
                new MonitoringCrawlerEntity { Id = 24, Description = "Cnova" },
                new MonitoringCrawlerEntity { Id = 25, Description = "Fnac" },
                new MonitoringCrawlerEntity { Id = 26, Description = "Dell" },
                new MonitoringCrawlerEntity { Id = 27, Description = "Ricardo Eletro" },
                new MonitoringCrawlerEntity { Id = 101, Description = "Linx" },
                new MonitoringCrawlerEntity { Id = 102, Description = "Nielsen" },
                new MonitoringCrawlerEntity { Id = 103, Description = "Smarket" },
                new MonitoringCrawlerEntity { Id = 104, Description = "Neogrid" },
                new MonitoringCrawlerEntity { Id = 105, Description = "InfoPrice" },
                new MonitoringCrawlerEntity { Id = 106, Description = "Horus" },
                new MonitoringCrawlerEntity { Id = 107, Description = "Normalizer" },
                new MonitoringCrawlerEntity { Id = 108, Description = "Predify" },
                new MonitoringCrawlerEntity { Id = 109, Description = "Indireta" },
                new MonitoringCrawlerEntity { Id = 110, Description = "Vem" },
            };
        }
    }
}
