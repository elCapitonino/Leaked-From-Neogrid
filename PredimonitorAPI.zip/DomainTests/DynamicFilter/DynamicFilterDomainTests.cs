﻿using Domain.CompanyMonitoringCrawler;
using Domain.MonitoringResult;
using Domain.MonitoringResult.Models;
using Domain.Status;
using DomainTests.DynamicFilter.Seed;
using DomainTests.Extensions;
using MathNet.Numerics;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.DependencyInjection;
using MongoDB.Driver;
using Moq;
using Repository.DbContexts;
using Repository.Entity;
using Repository.UnitOfWork;

namespace DomainTests.DynamicFilter
{
    [TestClass()]
    public class DynamicFilterDomainTests
    {
        private IServiceCollection _services;
        private ServiceProvider _serviceProvider;

        [TestInitialize]
        public void Initialize()
        {
            _services = new ServiceCollection();
            var mongo = new Mock<MongoClient>().Object;

            _services.AddTransient<IMongoClient>(provider => mongo);
            _services.SetAutoMapper();

            _services.AddDbContext<ApplicationDbContext>(options => options.UseSqlite("Filename=:memory:").ConfigureWarnings(opt => opt.Ignore(RelationalEventId.AmbientTransactionWarning)));

            _services.AddDbContext<HorusDbContext>(options => options.UseMongoDB(mongo, "Horus").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            _services.AddDbContext<InfoPriceSaoJoaoDbContext>(options => options.UseMongoDB(mongo, "InfroPriceSaoJoao").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            _services.AddDbContext<NormalizerDbContext>(options => options.UseMongoDB(mongo, "Normalizer").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            _services.AddDbContext<LinxDbContext>(options => options.UseMongoDB(mongo, "Linx").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            _services.AddDbContext<NeogridDbContext>(options => options.UseMongoDB(mongo, "Neogrid").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            _services.AddDbContext<NielsenDbContext>(options => options.UseMongoDB(mongo, "Nielsen").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            _services.AddDbContext<SmarketCompetitorDbContext>(options => options.UseMongoDB(mongo, "SmarketCompetitor").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            _services.AddDbContext<OfflineDbContext>(options => options.UseMongoDB(mongo, "Offline").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            _services.AddDbContext<ScantechSupermaxiDbContext>(options => options.UseMongoDB(mongo, "Scantech").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);

            _services.AddTransient(provider => new DatabricsDbContext("", ""));

            _services.AddScoped<ICompanyMonitoringCrawlerDomain, CompanyMonitoringCrawlerDomain>();
            _services.AddScoped<IMonitoringResultDomain, MonitoringResultDomain>();
            _services.AddScoped<IStatusDomain, StatusDomain>();

            _services.AddMemoryCache();

            _services.AddScoped<IUnitOfWork, UnitOfWork>();
            _services.AddLogging();

            _serviceProvider = _services.BuildServiceProvider();

            var context = _serviceProvider.GetRequiredService<ApplicationDbContext>();
            context.Database.OpenConnection();
            context.Database.EnsureCreated();

        }

        [TestMethod()]
        public void GetSimpleRelationship()
        {
            var uow = _serviceProvider.GetService<IUnitOfWork>()!;
            var domain = _serviceProvider.GetService<IMonitoringResultDomain>();

            uow.Company.AddRange(CompanySeed.GetTestData(), autosave: true);
            uow.MonitoringCrawler.AddRange(MonitoringCrawlerSeed.GetTestData(), autosave: true);
            uow.MonitoringItem.AddRange(MonitoringItemSeed.GetTestData(), autosave: true);
            uow.MonitoringItemResults.AddRange(MonitoringItemResultsSeed.GetTestData(), autosave: true);
            uow.CompanyMonitoringCrawler.AddRange(CompanyMonitoringCrawlerSeed.GetTestData(), autosave: true);

            var result = domain.GetMonitoringResultFilteredData(1, new DynamicFilterRequest() { Categories = new List<string>() { "Fruta" } }).Result;

            Assert.IsTrue(result.Sellers.All(s => s.Contains("Supermarket")), "Todos os sellers devem estar relacionados à categoria 'Fruta'");
            Assert.IsTrue(result.States.All(s => s == "SP" || s == "MG" || s == "RJ" || s == "RS" || s == "SC" || s == "BA" || s == "CE" || s == "PR"), "Todos os estados devem estar relacionados à categoria 'Fruta'");
            Assert.IsTrue(result.Brands.All(b => b.Contains("Brand")), "Todas as marcas devem estar relacionadas à categoria 'Fruta'");
            Assert.IsTrue(result.Years.All(y => y == "2023" || y == "2022"), "Todos os anos devem estar relacionados à categoria 'Fruta'");

            Assert.AreEqual(result.Sellers.Distinct().Count(), result.Sellers.Count(), "Todos os itens de Sellers retornados devem ser únicos");
            Assert.AreEqual(result.States.Distinct().Count(), result.States.Count(), "Todos os itens de States retornados devem ser únicos");
            Assert.AreEqual(result.Brands.Distinct().Count(), result.Brands.Count(), "Todos os itens de Brands retornados devem ser únicos");
            Assert.AreEqual(result.Years.Distinct().Count(), result.Years.Count(), "Todos os itens de Years retornados devem ser únicos");


            Assert.IsFalse(result.Categories.Any(item => item != "Fruta" && item != "Eletrônicos" && item != "Vegetais"), "Nenhum item deve ter uma categoria diferente de 'Fruta'");

            Assert.AreEqual(3, result.Categories.Count(), "A contagem de itens deve ser 3 para a categoria 'Fruta' ,'Eletrônicos' , 'Vegetais'");

            Assert.IsTrue(result.States.All(item => !string.IsNullOrEmpty(item)), "Todos os itens devem ter um estado não vazio");
            Assert.IsTrue(result.Brands.All(item => !string.IsNullOrEmpty(item)), "Todos os itens devem ter uma marca não vazia");
            Assert.IsTrue(result.Years.All(item => !string.IsNullOrEmpty(item)), "Todos os itens devem ter um ano não vazio");

        }

        [TestMethod()]
        public void FilterWithAPreFilterSetted()
        {
            var uow = _serviceProvider.GetService<IUnitOfWork>()!;
            var domain = _serviceProvider.GetService<IMonitoringResultDomain>();

            uow.Company.AddRange(CompanySeed.GetTestData(), autosave: true);
            uow.MonitoringCrawler.AddRange(MonitoringCrawlerSeed.GetTestData(), autosave: true);
            uow.MonitoringItem.AddRange(MonitoringItemSeed.GetTestData(), autosave: true);
            uow.MonitoringItemResults.AddRange(MonitoringItemResultsSeed.GetTestData(), autosave: true);
            uow.CompanyMonitoringCrawler.AddRange(CompanyMonitoringCrawlerSeed.GetTestData(), autosave: true);

            var result = domain.GetMonitoringResultFilteredData(1, new DynamicFilterRequest()
            {
                ProductNames = new List<string>() { "Framboesa", "Vaso de ceramica", "Televisao" },
                Categories = new List<string>() { "Fruta" }
            }).Result;

            Assert.IsNotNull(result, "O método precisa retornar um objeto");

            Assert.IsTrue(result.Categories.All(item => item == "Fruta" || item == "Eletrônicos"), "Todos os itens devem estar na categoria 'Fruta' ou 'Eletrônicos'");
            Assert.IsFalse(result.Categories.Any(item => item == "Vegetais"), "Nenhum item deve estar nas categorias 'Vegetais'");
            Assert.IsFalse(result.Products.Any(item => item.ProductName =="Vaso de ceramica"|| item.ProductName == "Televisao"), "Nenhum item deve ser 'Vaso de ceramica' ou 'Televisao'");
            Assert.AreEqual(10,result.Products.Count(), "Deve retonar 10 produtos que são da categoria frutas");
            Assert.IsTrue(result.States.All(item => !string.IsNullOrEmpty(item)), "Todos os itens devem ter um estado não vazio");
            Assert.IsTrue(result.Brands.All(item => !string.IsNullOrEmpty(item)), "Todos os itens devem ter uma marca não vazia");
            Assert.IsTrue(result.Years.All(item => !string.IsNullOrEmpty(item)), "Todos os itens devem ter um ano não vazio");
            Assert.AreEqual(2, result.Categories.Distinct().Count(), "A contagem de categorias únicas deve ser 1 ('Fruta' ou 'Televisão')");
            Assert.AreEqual(result.Sellers.Select(item => item).Distinct().Count(), result.Sellers.Count(), "A contagem de sellers únicos deve ser igual à contagem de itens para a categoria 'Fruta'");

        }

        [TestMethod()]
        public void MultiRelationship()
        {
            var uow = _serviceProvider.GetService<IUnitOfWork>()!;
            var domain = _serviceProvider.GetService<IMonitoringResultDomain>();

            uow.Company.AddRange(CompanySeed.GetTestData(), autosave: true);
            uow.MonitoringCrawler.AddRange(MonitoringCrawlerSeed.GetTestData(), autosave: true);
            uow.MonitoringItem.AddRange(MonitoringItemSeed.GetTestData(), autosave: true);
            uow.MonitoringItemResults.AddRange(MonitoringItemResultsSeed.GetTestData(), autosave: true);
            uow.CompanyMonitoringCrawler.AddRange(CompanyMonitoringCrawlerSeed.GetTestData(), autosave: true);

            var resultAfterFirstFilter = domain.GetMonitoringResultFilteredData(1, new DynamicFilterRequest() { Categories = new List<string>() { "Vegetais" } }).Result;

            Assert.IsTrue(resultAfterFirstFilter.Categories.Contains("Vegetais"), "A categoria 'Vegetais' deve estar presente.");

            var resultAfterSecondFilter = domain.GetMonitoringResultFilteredData(1, new DynamicFilterRequest()
            {
                Categories = new List<string>() { "Vegetais" },
                ProductNames = new List<string>() { "Cenoura" }
            }).Result;

            Assert.IsTrue(resultAfterSecondFilter.Categories.Contains("Vegetais"), "A categoria 'Vegetais' deve estar presente.");
            Assert.IsTrue(resultAfterSecondFilter.Brands.All(b => b.Contains("Brand")), "Todas as marcas devem estar relacionadas à categoria 'Vegetais'");
            Assert.IsTrue(resultAfterSecondFilter.States.All(s => s == "SP" || s == "MG" || s == "RJ" || s == "RS" || s == "SC" || s == "BA" || s == "CE" || s == "PR"), "Todos os estados devem estar relacionados à categoria 'Vegetais'");

            Assert.AreEqual(resultAfterSecondFilter.Sellers.Distinct().Count(), resultAfterSecondFilter.Sellers.Count(), "Todos os itens de Sellers retornados devem ser únicos para a categoria 'Vegetais'");
            Assert.AreEqual(resultAfterSecondFilter.States.Distinct().Count(), resultAfterSecondFilter.States.Count(), "Todos os itens de States retornados devem ser únicos para a categoria 'Vegetais'");
            Assert.AreEqual(resultAfterSecondFilter.Brands.Distinct().Count(), resultAfterSecondFilter.Brands.Count(), "Todos os itens de Brands retornados devem ser únicos para a categoria 'Vegetais'");
        }


        [TestMethod()]
        public void ExceptionForProductField()
        {
            var uow = _serviceProvider.GetService<IUnitOfWork>()!;
            var domain = _serviceProvider.GetService<IMonitoringResultDomain>();

            uow.Company.AddRange(CompanySeed.GetTestData(), autosave: true);
            uow.MonitoringCrawler.AddRange(MonitoringCrawlerSeed.GetTestData(), autosave: true);
            uow.MonitoringItem.AddRange(MonitoringItemSeed.GetTestData(), autosave: true);
            uow.MonitoringItemResults.AddRange(MonitoringItemResultsSeed.GetTestData(), autosave: true);
            uow.CompanyMonitoringCrawler.AddRange(CompanyMonitoringCrawlerSeed.GetTestData(), autosave: true);

            var resultAfterFirstProduct = domain.GetMonitoringResultFilteredData(1, new DynamicFilterRequest() { ProductNames = new List<string>() { "Laranja" } }).Result;

            Assert.IsTrue(resultAfterFirstProduct.Categories.Contains("Fruta"), "A categoria 'Fruta' deve estar presente para o produto 'Laranja'");
            Assert.IsTrue(resultAfterFirstProduct.Products.Any(p => p.ProductName == "Laranja"), "O produto 'Laranja' deve estar presente na lista de produtos");

            var resultAfterSecondProduct = domain.GetMonitoringResultFilteredData(1, new DynamicFilterRequest() { ProductNames = new List<string>() { "Laranja", "Notebook" } }).Result;

            Assert.IsTrue(resultAfterSecondProduct.Categories.Contains("Fruta") && resultAfterSecondProduct.Categories.Contains("Eletrônicos"), "As categorias 'Fruta' e 'Eletrônicos' devem estar presentes para os produtos 'Laranja' e 'Notebook'");
            Assert.IsTrue(resultAfterSecondProduct.Products.Any(p => p.ProductName == "Laranja"), "O produto 'Laranja' deve estar presente na lista de produtos");
            Assert.IsTrue(resultAfterSecondProduct.Products.Any(p => p.ProductName == "Notebook"), "O produto 'Notebook' deve estar presente na lista de produtos");

            Assert.AreEqual(resultAfterSecondProduct.Sellers.Distinct().Count(), resultAfterSecondProduct.Sellers.Count(), "Todos os itens de Sellers retornados devem ser únicos para os produtos 'Laranja' e 'Notebook'");
            Assert.AreEqual(resultAfterSecondProduct.States.Distinct().Count(), resultAfterSecondProduct.States.Count(), "Todos os itens de States retornados devem ser únicos para os produtos 'Laranja' e 'Notebook'");
            Assert.AreEqual(resultAfterSecondProduct.Brands.Distinct().Count(), resultAfterSecondProduct.Brands.Count(), "Todos os itens de Brands retornados devem ser únicos para os produtos 'Laranja' e 'Notebook'");
        }

        [TestMethod()]
        public void FilterWithAPreFilterSettedWithIds()
        {
            var uow = _serviceProvider.GetService<IUnitOfWork>()!;
            var domain = _serviceProvider.GetService<IMonitoringResultDomain>();

            uow.Company.AddRange(CompanySeed.GetTestData(), autosave: true);
            uow.MonitoringCrawler.AddRange(MonitoringCrawlerSeed.GetTestData(), autosave: true);
            uow.MonitoringItem.AddRange(MonitoringItemSeed.GetTestData(), autosave: true);
            uow.MonitoringItemResults.AddRange(MonitoringItemResultsSeed.GetTestData(), autosave: true);
            uow.CompanyMonitoringCrawler.AddRange(CompanyMonitoringCrawlerSeed.GetTestData(), autosave: true);

            var result = domain.GetMonitoringResultFilteredData(1, new DynamicFilterRequest()
            {
                MonitoringItemIds = new List<long?>() { 20, 38, 31 },  // IDs correspondentes a "Framboesa", "Vaso de cerâmica", "Televisão"
                Categories = new List<string>() { "Fruta" }
            }).Result;

            Assert.IsNotNull(result, "O método precisa retornar um objeto");

            Assert.IsTrue(result.Categories.All(item => item == "Fruta" || item == "Eletrônicos"), "Todos os itens devem estar na categoria 'Fruta' ou 'Eletrônicos'");
            Assert.IsFalse(result.Categories.Any(item => item == "Vegetais"), "Nenhum item deve estar nas categorias 'Vegetais'");
            Assert.IsFalse(result.Products.Any(item => item.ProductName == "Vaso de ceramica" || item.ProductName == "Televisao"), "Nenhum item deve ser 'Vaso de ceramica' ou 'Televisao'");
            Assert.AreEqual(10, result.Products.Count(), "Deve retonar 10 produtos que são da categoria frutas");
            Assert.IsTrue(result.States.All(item => !string.IsNullOrEmpty(item)), "Todos os itens devem ter um estado não vazio");
            Assert.IsTrue(result.Brands.All(item => !string.IsNullOrEmpty(item)), "Todos os itens devem ter uma marca não vazia");
            Assert.IsTrue(result.Years.All(item => !string.IsNullOrEmpty(item)), "Todos os itens devem ter um ano não vazio");
            Assert.AreEqual(2, result.Categories.Distinct().Count(), "A contagem de categorias únicas deve ser 1 ('Fruta' ou 'Televisão')");
            Assert.AreEqual(result.Sellers.Select(item => item).Distinct().Count(), result.Sellers.Count(), "A contagem de sellers únicos deve ser igual à contagem de itens para a categoria 'Fruta'");
        }

        [TestMethod()]
        public void MultiRelationshipWithIds()
        {
            var uow = _serviceProvider.GetService<IUnitOfWork>()!;
            var domain = _serviceProvider.GetService<IMonitoringResultDomain>();

            uow.Company.AddRange(CompanySeed.GetTestData(), autosave: true);
            uow.MonitoringCrawler.AddRange(MonitoringCrawlerSeed.GetTestData(), autosave: true);
            uow.MonitoringItem.AddRange(MonitoringItemSeed.GetTestData(), autosave: true);
            uow.MonitoringItemResults.AddRange(MonitoringItemResultsSeed.GetTestData(), autosave: true);
            uow.CompanyMonitoringCrawler.AddRange(CompanyMonitoringCrawlerSeed.GetTestData(), autosave: true);

            var resultAfterFirstFilter = domain.GetMonitoringResultFilteredData(1, new DynamicFilterRequest() { Categories = new List<string>() { "Vegetais" } }).Result;

            Assert.IsTrue(resultAfterFirstFilter.Categories.Contains("Vegetais"), "A categoria 'Vegetais' deve estar presente.");

            var resultAfterSecondFilter = domain.GetMonitoringResultFilteredData(1, new DynamicFilterRequest()
            {
                Categories = new List<string>() { "Vegetais" },
                MonitoringItemIds = new List<long?>() { 22 }  // ID correspondente a "Cenoura"
            }).Result;

            Assert.IsTrue(resultAfterSecondFilter.Categories.Contains("Vegetais"), "A categoria 'Vegetais' deve estar presente.");
            Assert.IsTrue(resultAfterSecondFilter.Brands.All(b => b.Contains("Brand")), "Todas as marcas devem estar relacionadas à categoria 'Vegetais'");
            Assert.IsTrue(resultAfterSecondFilter.States.All(s => s == "SP" || s == "MG" || s == "RJ" || s == "RS" || s == "SC" || s == "BA" || s == "CE" || s == "PR"), "Todos os estados devem estar relacionados à categoria 'Vegetais'");

            Assert.AreEqual(resultAfterSecondFilter.Sellers.Distinct().Count(), resultAfterSecondFilter.Sellers.Count(), "Todos os itens de Sellers retornados devem ser únicos para a categoria 'Vegetais'");
            Assert.AreEqual(resultAfterSecondFilter.States.Distinct().Count(), resultAfterSecondFilter.States.Count(), "Todos os itens de States retornados devem ser únicos para a categoria 'Vegetais'");
            Assert.AreEqual(resultAfterSecondFilter.Brands.Distinct().Count(), resultAfterSecondFilter.Brands.Count(), "Todos os itens de Brands retornados devem ser únicos para a categoria 'Vegetais'");
        }

        [TestMethod()]
        public void ExceptionForProductFieldWithIds()
        {
            var uow = _serviceProvider.GetService<IUnitOfWork>()!;
            var domain = _serviceProvider.GetService<IMonitoringResultDomain>();

            uow.Company.AddRange(CompanySeed.GetTestData(), autosave: true);
            uow.MonitoringCrawler.AddRange(MonitoringCrawlerSeed.GetTestData(), autosave: true);
            uow.MonitoringItem.AddRange(MonitoringItemSeed.GetTestData(), autosave: true);
            uow.MonitoringItemResults.AddRange(MonitoringItemResultsSeed.GetTestData(), autosave: true);
            uow.CompanyMonitoringCrawler.AddRange(CompanyMonitoringCrawlerSeed.GetTestData(), autosave: true);

            var resultAfterFirstProduct = domain.GetMonitoringResultFilteredData(1, new DynamicFilterRequest() { MonitoringItemIds = new List<long?>() { 3 } }).Result;  // ID correspondente a "Laranja"

            Assert.IsTrue(resultAfterFirstProduct.Categories.Contains("Fruta"), "A categoria 'Fruta' deve estar presente para o produto 'Laranja'");
            Assert.IsTrue(resultAfterFirstProduct.Products.Any(p => p.ProductName == "Laranja"), "O produto 'Laranja' deve estar presente na lista de produtos");

            var resultAfterSecondProduct = domain.GetMonitoringResultFilteredData(1, new DynamicFilterRequest() { MonitoringItemIds = new List<long?>() { 3, 32 } }).Result;  // IDs correspondentes a "Laranja" e "Notebook"

            Assert.IsTrue(resultAfterSecondProduct.Categories.Contains("Fruta") && resultAfterSecondProduct.Categories.Contains("Eletrônicos"), "As categorias 'Fruta' e 'Eletrônicos' devem estar presentes para os produtos 'Laranja' e 'Notebook'");
            Assert.IsTrue(resultAfterSecondProduct.Products.Any(p => p.ProductName == "Laranja"), "O produto 'Laranja' deve estar presente na lista de produtos");
            Assert.IsTrue(resultAfterSecondProduct.Products.Any(p => p.ProductName == "Notebook"), "O produto 'Notebook' deve estar presente na lista de produtos");

            Assert.AreEqual(resultAfterSecondProduct.Sellers.Distinct().Count(), resultAfterSecondProduct.Sellers.Count(), "Todos os itens de Sellers retornados devem ser únicos para os produtos 'Laranja' e 'Notebook'");
            Assert.AreEqual(resultAfterSecondProduct.States.Distinct().Count(), resultAfterSecondProduct.States.Count(), "Todos os itens de States retornados devem ser únicos para os produtos 'Laranja' e 'Notebook'");
            Assert.AreEqual(resultAfterSecondProduct.Brands.Distinct().Count(), resultAfterSecondProduct.Brands.Count(), "Todos os itens de Brands retornados devem ser únicos para os produtos 'Laranja' e 'Notebook'");
        }

        [TestMethod()]
        public async Task ProductCanNotFilterProductTestAsync()
        {
            var uow = _serviceProvider.GetService<IUnitOfWork>()!;
            var domain = _serviceProvider.GetService<IMonitoringResultDomain>();


            var company = new CompanyEntity()
            {
                Id = 1,
                Company = "Teste"
            };
            var companyMonitoringCrawler = new CompanyMonitoringCrawlerEntity()
            {
                Id = 1,
                CompanyId = 1,                
                MonitoringCrawler = new MonitoringCrawlerEntity() { Id = 1, Description = "Crawler 1" },
                IsCost=false,
                IsSale =true,
                IsDeleted=false
            };
            uow.CompanyMonitoringCrawler.Create(companyMonitoringCrawler);
            uow.MonitoringItemResults.AddRange(new[] {
                new MonitoringItemResultsEntity()
                {
                    Brand = "Brand 1",
                    Category = "Fruta",
                    Company =company,
                    CrawlerId = 1,
                    MonitoringItem = new MonitoringItemEntity() { Id = 1, Description = "Laranja" },
                    Seller = "Seller 1",
                    State = "SP",
                    Hash = "hash_test_1"
                },
                new MonitoringItemResultsEntity()
                {
                    Brand = "Brand 1",
                    Category = "Fruta",
                    Company =company,
                    CrawlerId = 1,
                    MonitoringItem = new MonitoringItemEntity() { Id = 2, Description = "Limão" },
                    Seller = "Seller 1",
                    State = "SP",
                    Hash = "hash_test_2"
                },
                new MonitoringItemResultsEntity()
                {
                    Brand = "Brand 1",
                    Category = "Fruta",
                    Company =company,
                    CrawlerId = 1,
                    MonitoringItem = new MonitoringItemEntity() { Id = 3, Description = "Uva" },
                    Seller = "Seller 1",
                    State = "SP",
                    Hash = "hash_test_3"
                },
                new MonitoringItemResultsEntity()
                {
                    Brand = "Brand 1",
                    Category = "Fruta",
                    Company =company,
                    CrawlerId = 1,
                    MonitoringItem = new MonitoringItemEntity() { Id = 4, Description = "Abacaxi" },
                    Seller = "Seller 1",
                    State = "SP",
                    Hash = "hash_test_4"
                },
                new MonitoringItemResultsEntity()
                {
                    Brand = "Brand 1",
                    Category = "Fruta",
                    Company =company,
                    CrawlerId = 1,
                    MonitoringItem = new MonitoringItemEntity() { Id = 5, Description = "Pitaia" },
                    Seller = "Seller 1",
                    State = "SP",
                    Hash = "hash_test_5"
                },
                new MonitoringItemResultsEntity()
                {
                    Brand = "Brand 2",
                    Category = "Eletrônicos",
                    Company =company,
                    CrawlerId = 1,
                    MonitoringItem = new MonitoringItemEntity() { Id = 32, Description = "Notebook" },
                    Seller = "Seller 2",
                    State = "MG",
                    Hash = "hash_test_6"
                },
                new MonitoringItemResultsEntity()
                {
                    Brand = "Brand 3",
                    Category = "Fruta",
                    Company =company,
                    CrawlerId = 1,
                    MonitoringItemId =1,
                    Seller = "Seller 3",
                    State = "RJ",
                    Hash = "hash_test_7"
                },
                new MonitoringItemResultsEntity()
                {
                    Brand = "Brand 4",
                    Category = "Eletrônicos",
                    Company =company,
                    CrawlerId = 1,
                    MonitoringItemId = 32,
                    Seller = "Seller 4",
                    State = "RS",
                    Hash = "hash_test_8"
                },
                new MonitoringItemResultsEntity()
                {
                    Brand = "Brand 5",
                    Category = "Fruta",
                    Company =company,
                    CrawlerId = 1,
                    MonitoringItemId =1,
                    Seller = "Seller 5",
                    State = "SC",
                    Hash = "hash_test_9"
                },

            }, autosave: true);

            var result = await domain.GetMonitoringResultFilteredData(1, new DynamicFilterRequest() { ProductNames = new List<string?>() { "Laranja" } });

            Assert.IsTrue(result.Categories.All(item => item == "Fruta"), "Todos os itens devem estar na categoria 'Fruta'");
            Assert.IsFalse(result.Categories.Any(item => item == "Eletrônicos"), "Nenhum item deve estar na categoria 'Eletrônicos'");
            Assert.AreEqual(6, result.Products.Count(), "A contagem de produtos deve ser 5 sempre que o productNames é filtrado");

        }

        [TestMethod()]
        public async Task ProductNeedsBeFilterWhenCategoryIsPresentTestAsync()
        {
            var uow = _serviceProvider.GetService<IUnitOfWork>()!;
            var domain = _serviceProvider.GetService<IMonitoringResultDomain>();

            var company = new CompanyEntity()
            {
                Id = 1,
                Company = "Teste"
            };
            var companyMonitoringCrawler = new CompanyMonitoringCrawlerEntity()
            {
                Id = 1,
                CompanyId = 1,
                MonitoringCrawler = new MonitoringCrawlerEntity() { Id = 1, Description = "Crawler 1" },
                IsCost = false,
                IsSale = true,
                IsDeleted = false
            };
            uow.CompanyMonitoringCrawler.Create(companyMonitoringCrawler);
            uow.MonitoringItemResults.AddRange(new[] {
                new MonitoringItemResultsEntity()
                {
                    Brand = "Brand 1",
                    Category = "Fruta",
                    Company =company,
                    CrawlerId = 1,
                    MonitoringItem = new MonitoringItemEntity() { Id = 1, Description = "Laranja" },
                    Seller = "Seller 1",
                    State = "SP",
                    Hash = "Laranja"
                },
                new MonitoringItemResultsEntity()
                {
                    Brand = "Brand 1",
                    Category = "Fruta",
                    Company =company,
                    CrawlerId = 1,
                    MonitoringItem = new MonitoringItemEntity() { Id = 2, Description = "Limão" },
                    Seller = "Seller 1",
                    State = "SP",
                    Hash = "Limão"
                },
                new MonitoringItemResultsEntity()
                {
                    Brand = "Brand 1",
                    Category = "Fruta",
                    Company =company,
                    CrawlerId = 1,
                    MonitoringItem = new MonitoringItemEntity() { Id = 3, Description = "Uva" },
                    Seller = "Seller 1",
                    State = "SP",
                    Hash = "Uva"
                },
                new MonitoringItemResultsEntity()
                {
                    Brand = "Brand 1",
                    Category = "Fruta",
                    Company =company,
                    CrawlerId = 1,
                    MonitoringItem = new MonitoringItemEntity() { Id = 4, Description = "Abacaxi" },
                    Seller = "Seller 1",
                    State = "SP",
                    Hash = "Abacaxi"
                },
                new MonitoringItemResultsEntity()
                {
                    Brand = "Brand 1",
                    Category = "Fruta",
                    Company =company,
                    CrawlerId = 1,
                    MonitoringItem = new MonitoringItemEntity() { Id = 5, Description = "Pitaia" },
                    Seller = "Seller 1",
                    State = "SP",
                    Hash = "Pitaia"
                },
                new MonitoringItemResultsEntity()
                {
                    Brand = "Brand 2",
                    Category = "Eletronicos",
                    Company =company,
                    CrawlerId = 1,
                    MonitoringItem = new MonitoringItemEntity() { Id = 32, Description = "Notebook" },
                    Seller = "Seller 2",
                    State = "MG",
                    Hash = "Notebook"
                },
                new MonitoringItemResultsEntity()
                {
                    Brand = "Brand 3",
                    Category = "Fruta",
                    Company =company,
                    CrawlerId = 1,
                    MonitoringItemId =1,
                    Seller = "Seller 3",
                    State = "RJ",
                    Hash = "Laranja"
                },
                new MonitoringItemResultsEntity()
                {
                    Brand = "Brand 4",
                    Category = "Eletronicos",
                    Company =company,
                    CrawlerId = 1,
                    MonitoringItemId = 32,
                    Seller = "Seller 4",
                    State = "RS",
                    Hash = "Notebook"
                },
                new MonitoringItemResultsEntity()
                {
                    Brand = "Brand 5",
                    Category = "Fruta",
                    Company =company,
                    CrawlerId = 1,
                    MonitoringItemId =1,
                    Seller = "Seller 5",
                    State = "SC",
                    Hash = "Laranja"
                },

            }, autosave: true);

            var result = await domain.GetMonitoringResultFilteredData(1, new DynamicFilterRequest() { Categories = new List<string?>() { "Eletronicos" } });

            Assert.IsTrue(result.Categories.All(item => item == "Eletronicos" || item == "Fruta"), "Todos os itens devem estar na categoria 'Eletrônicos' ou 'Fruta'");
            Assert.IsFalse(result.Categories.Any(item => item == "Verduras"), "Nenhum item deve estar na categoria 'Verduras'");
            Assert.AreEqual(1, result.Products.Count(), "A contagem de produtos deve ser 2 sempre que o Categoria é filtrado e produto não");

        }

    }
}