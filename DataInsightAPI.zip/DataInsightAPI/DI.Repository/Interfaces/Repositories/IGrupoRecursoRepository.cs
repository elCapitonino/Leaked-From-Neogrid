﻿using DI.Repository.Entities;

namespace DI.Repository.Interfaces.Repositories
{
    public interface IGrupoRecursoRepository
    {
        IEnumerable<GrupoRecursoEntity> GetAllByCompanyId(long companyId);
        GrupoRecursoEntity? GetByNameAndCompanyId(string nome, long companyId);
        string GetHierarchyUserById(long companyId, string userId);

    }
}
