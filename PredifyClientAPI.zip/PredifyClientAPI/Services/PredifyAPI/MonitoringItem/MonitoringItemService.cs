﻿using Newtonsoft.Json;
using PredifyClientAPI.Services.PredifyAPI.Models;
using PredifyClientAPI.Services.PredifyAPI.MonitoringItem.Models;
using System.Text;

namespace PredifyClientAPI.Services.PredifyAPI.MonitoringItem
{
    public class MonitoringItemService : IMonitoringItemService
    {
        private readonly HttpClient _client;

        public MonitoringItemService(HttpClient client)
        {
            _client = client;
        }

        public async Task<GeneralResponse<IEnumerable<MonitoringItemResponse>>> ListMonitoringItem(ListMonitoringItemRequest request)
        {
            string jsonPayload = JsonConvert.SerializeObject(request);

            StringContent payload = new StringContent(jsonPayload, Encoding.UTF8, "application/json");

            var response = await _client.PostAsync($"/api/V2/Monitoring/ListMonitoringItems", payload);
            var content = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
                return JsonConvert.DeserializeObject<GeneralResponse<IEnumerable<MonitoringItemResponse>>>(content);
            else if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                throw new UnauthorizedAccessException();

            throw new Exception(content);
        }

        public async Task<GeneralResponse<PaginationResponse<MonitoringItemResponse>>> ListMonitoringItemResponsePaginated(ListMonitoringItemPaginatedRequest request)
        {
            string jsonPayload = JsonConvert.SerializeObject(request);

            // Converta o payload para StringContent com o tipo de mídia apropriado (application/json)
            StringContent payload = new StringContent(jsonPayload, Encoding.UTF8, "application/json");

            var response = await _client.PostAsync($"/api/V2/Monitoring/ListMonitoringItemPaginated", payload);
            var content = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
                return JsonConvert.DeserializeObject<GeneralResponse<PaginationResponse<MonitoringItemResponse>>>(content);
            else if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                throw new UnauthorizedAccessException();

            throw new Exception(content);
        }
    }
}
