﻿using AutoMapper;
using Domain.MonitoringResult.Models;
using Repository.Entity;
using Repository.Enums;

namespace Domain.MonitoringResult.Converters
{
    public class NielsenVemToResultFilterResponseConverter : ITypeConverter<VemEntity, ResultFilterResponse>
    {
        public ResultFilterResponse Convert(VemEntity source, ResultFilterResponse destination, ResolutionContext context)
        {
            var dest = new ResultFilterResponse()
            {
                ProductName = source.ProductDescription,
                ProductLink = source.Hash,
                ProductBrand = source.Brand,
                SellerName = source.StoreName,
                Marketplace = (string)context.Items["CrawlerName"],
                Price = source.WeeklyPrice,
                PaymentType = "-",
                Price_unit_type = PriceUnitType.UNITARIO,
                CrawlerDate = source.Date,
                Disregarded = false,               
                IdCrawler = (int)context.Items["CrawlerId"],
                Format_market = source.MarketFormat,
                City = source.City,             
                State = source.StateUf,
                Coordinates = source.Coordinates == null ? null : new PrediMonitorProduct_CoordinatesModel()
                {
                    Longitude = (decimal)source.Coordinates.Coordinates[0],
                    Latitude = (decimal)source.Coordinates.Coordinates[1],
                },
            };

            return dest;
        }
    }
}
