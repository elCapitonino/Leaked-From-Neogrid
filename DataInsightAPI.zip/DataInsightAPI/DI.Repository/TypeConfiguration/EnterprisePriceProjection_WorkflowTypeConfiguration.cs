﻿using DI.Repository.Attributes;
using DI.Repository.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DI.Repository.TypeConfiguration
{
    [UseSQLContext]
    public class EnterprisePriceProjection_WorkflowTypeConfiguration : TypeConfigurationBase<EnterprisePriceProjection_WorkflowEntity>, IEntityTypeConfiguration<EnterprisePriceProjection_WorkflowEntity>
    {
        public override void Configure(EntityTypeBuilder<EnterprisePriceProjection_WorkflowEntity> builder)
        {
            ConfigureTableName(builder, "EnterprisePriceProjection_Workflow");
            builder.ToTable("EnterprisePriceProjection_Workflow", table => table.ExcludeFromMigrations());
            builder.HasKey(x => x.EnterprisePriceProjection_WorkflowId);
            builder.Ignore(x => x.Id);
            builder.Ignore(x => x.UpdatedDate);
            builder.Ignore(x => x.CreatedDate);

            builder.HasOne(x => x.EnterprisePriceProjection).WithMany(x => x.Workflows).HasForeignKey(x => x.EnterprisePriceProjectionId);
            builder.HasOne(x => x.LastAction).WithMany().HasForeignKey(x => x.LastActionId);

            builder.Property(x => x.EnterprisePriceProjection_WorkflowId).HasColumnName("IdEnterprisePriceProjection_Workflow");
            builder.Property(x => x.EnterprisePriceProjectionId).HasColumnName("IdEnterprisePriceProjection");
            builder.Property(x => x.WorkflowId).HasColumnName("IdWorkflow");
            builder.Property(x => x.FirstActionId).HasColumnName("IdFirstAction");
            builder.Property(x => x.LastActionId).HasColumnName("IdLastAction");
            builder.Property(x => x.CurrentNodeId).HasColumnName("IdCurrentNode");
            builder.Property(x => x.IsDeleted).HasColumnName("IsDeletado");
        }
    }
}
