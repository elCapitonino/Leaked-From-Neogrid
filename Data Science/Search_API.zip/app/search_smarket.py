from predimonitor_type import *
from async_mongo import AsyncMongoConnect


class Search_smarket():

    def __init__(self):
        self.dbMongo = AsyncMongoConnect()

    def search_get(self, id_crawlers_offline, data_source, products, start_date, end_date):

        result_list = []

        return result_list

    async def search_get_V1(self, id_crawlers_offline, data_source, products, start_date, end_date):

        result_list = []

        code = None
        if (products != None):
            if ((products[0].code != None) and (len(products[0].code) != 0)):
                code = products[0].code

        for crawler in id_crawlers_offline:
            if crawler.idcrawlers != 248:
                continue

        try:
            # print('produto init')
            result_produto = await self.dbMongo.get_product_search_smarket_imperatriz(code)
            # print('produto:', result_produtos)

            result_smarket = await self.dbMongo.get_concorrente_search_smarket_imperatriz(start_date, end_date, code)

            for documento in result_smarket:
                
                item = documento['documento']
                if 'url' not in item:
                    item['url'] = item['seqproduto']

                name = item['seqproduto']
                if result_produto != None:
                    name = result_produto['descricao']
                    
                result_list.append({'id': str(item['_id']),
                                            'id_crawler': 248,
                                            "product_name": name,
                                            "product_link": str(item['url']),
                                            "product_ean": None,
                                            "site_sku": 0,
                                            "source": "Smarket Imperatriz",
                                            "language": "pt-br",
                                            "product_brand": None,
                                            "id_product_normalized": None,
                                            "trash_score": 0,
                                            "crawler_date": item["dt_pesquisa"],
                                            "sellers": [
                    {"seller_name": item["seqconcorrente_description"],
                        "prices":[{'price': float(str(item["preco_varejo"])),
                                "price_currency": "BRL"}]
                        }],
                    # "product_local":
                    # {'state': item["uf"],
                    #     'city': item["city"]},
                    "product_manufacture_year": None,
                    "product_used_hours": None
                })
        except Exception as ex:
            print(" ------ Erro dados smarket  ------")
            print(str(ex))
                    
        return result_list
