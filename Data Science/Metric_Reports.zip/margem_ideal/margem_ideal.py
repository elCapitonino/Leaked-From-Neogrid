# ---
# jupyter:
#   jupytext:
#     formats: ipynb,py:percent
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.16.0
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
#   title: Estudo de Margem Ideal
# ---

# %%
import json
import sys
import warnings
from datetime import datetime

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy.stats as sps
import seaborn as sns
from IPython.display import Markdown as md

sys.path.append("../")  # go to parent dir
warnings.filterwarnings("ignore")

# %%
THRESHOLD = 0.5

from geral.config import getDadosAWSSession

CONFIG_FILE = ".config_ipynb"
with open(CONFIG_FILE) as f:
    args = json.load(f)

args["start_date"] = datetime.strptime(args["start_date"], "%Y-%m-%d")

# %% [markdown]
# # Análise de margem por categoria
#
# O objetivo é analisar as margens praticadas historicamente para cada categoria dos produtos e determinar uma faixa ideal para cada uma delas.
#
# ## Dados
# %%
md(
    f"Foram usados dados de venda de todas as filiais a partir do dia {args['start_date'].strftime('%d/%m/%Y')}. As vendas com margem negativa foram excluídas da análise."
)


# %% [markdown]
# ## Metodologia
#
# - A margem é calculada como `(preço de venda - custo unitário) / preço de venda`
# - Como filiais diferentes apresentam receitas diferentes, as receitas foram normalizadas por filial e produto
# - A margem ideal é o intervalo de margens suficiente para delimitar a região de maior densidade do gráfico de margem _versus_ receita normalizada. Ou seja, esses valores delimitam um intervalo para o qual, historicamente, há o maior número de vendas com lucro.
#
# ## Gráficos
#
# Para cada combinação de categoria e subcategoria, apresentam-se dois gráficos:
#
# - Histograma de valores de margem: representa a frequência de cada margem para a categoria em questão.
# - Relação entre receita normalizada e margem: permite visualizar a região de maior concentração de vendas (cor mais escura). A escala da receita normalizada está em _log_ para facilitar a visualização.
#
# Em ambos os gráficos, o intervalo de margem considerado ideal de acordo com os dados históricos está representado por duas linhas verticais.
#
# ## Interpretação
# %%
md(
    f"A faixa de margem sugerida reflete o comportamento histórico dos dados de forma a englobar pelo menos {THRESHOLD:.0%} das vendas registradas. "
    "É possível obter regras menos rígidas aumentando essa porcentagem e, por consequência, o intervalo."
)
# %% [markdown]
# Algumas categorias apresentam poucos itens ou poucas vendas e talvez não seja vantajoso adotar um intervalo de margem específicos para elas.
#
# Vale notar que o processo de obter um preço competitivo capaz de gerar boas receitas e lucros depende de outros fatores. A margem está diretamente atrelada ao custo unitário. Já a receita final projetada depende também, por exemplo, do comportamento histórico da vendas do produto, do histórico da filial, do histórico recente de preços para aquele produto e dos preços dos competidores. Os intervalos apresentados são balizadores para as regras de limite de margem de contribuição.

# %%
conn = getDadosAWSSession("producao")


def load_data(args) -> pd.DataFrame:
    cat_str = ",".join(args["cat_fields"])
    df_margins = pd.read_sql_query(
        f"""
        SELECT
            Issuance, Product, Affiliate, Quantity, SalePrice,
            PbCost, (SalePrice - PbCost) / SalePrice AS Margin,
            {cat_str}
        FROM Enterprise_Sales_History
        WHERE IdCompany = ? AND IsDeletado = 0
        AND Issuance >= ?;
        """,
        conn,
        params=(args["id_company"], args["start_date"]),
    )
    return df_margins


if args["debug"]:
    print(
        "!!!WARNING!!!: modo DEBUG, usando dados LOCAIS se disponíveis. Apenas para desenvolvimento."
    )
    fname = f"data_{args['id_company']}_{datetime.today().date().isoformat()}.parquet"
    try:
        df_margins = pd.read_parquet(fname)
    except Exception:
        df_margins = load_data(args)
        df_margins.to_parquet(fname, index=False)
else:
    df_margins = load_data(args)


# %%
# FIXME granularidade como parametro
df_margins["issuance_day"] = df_margins["Issuance"].dt.ceil("D")

agg_map = {"Quantity": "sum", "SalePrice": "mean", "Margin": "mean", "PbCost": "mean"}
for col in args["cat_fields"]:
    agg_map[col] = "first"

df_margins = (
    df_margins.groupby(["Product", "Affiliate", "issuance_day"])
    .agg(agg_map)
    .reset_index()
)

df_margins = df_margins[~df_margins[args["cat_fields"]].isna().any(axis=1)]
df_margins = df_margins[df_margins["Quantity"] > 0]
df_margins = df_margins[df_margins["SalePrice"] > 0]

df_margins["cat_str"] = df_margins[args["cat_fields"]].agg(" | ".join, axis=1)
df_margins["Revenue"] = df_margins["Quantity"] * df_margins["SalePrice"]
df_margins["Profit"] = df_margins["Quantity"] * (
    df_margins["SalePrice"] - df_margins["PbCost"]
)

df_mean = (
    df_margins.groupby(["Product"])[["Quantity", "SalePrice", "Revenue", "Profit"]]
    .mean()
    .reset_index()
    .rename(
        columns={
            "Revenue": "mean_rev",
            "Profit": "mean_profit",
            "Quantity": "mean_q",
            "SalePrice": "mean_p",
        }
    )
)

df_mean_aff = (
    df_margins.groupby(["Affiliate"])[["Quantity", "SalePrice", "Revenue", "Profit"]]
    .mean()
    .reset_index()
    .rename(
        columns={
            "Revenue": "mean_rev_aff",
            "Profit": "mean_profit_aff",
            "Quantity": "mean_q_aff",
            "SalePrice": "mean_p_aff",
        }
    )
)

df_margins = pd.merge(df_margins, df_mean, on=["Product"])
df_margins = pd.merge(df_margins, df_mean_aff, on=["Affiliate"])

df_margins["norm_rev"] = (
    100 * df_margins["Revenue"] / (df_margins["mean_rev"] * df_margins["mean_rev_aff"])
)
df_margins["norm_profit"] = (
    100
    * df_margins["Profit"]
    / (df_margins["mean_profit"] * df_margins["mean_rev_aff"])
)

# %% [markdown]
# Categorias Analisadas:

# %%
print("\n".join(sorted(df_margins["cat_str"].unique().tolist())))

# %%


def plot_and_project(df, cat: str):
    df_cat = df[(df["cat_str"] == cat) & (df["Margin"] > 0)].copy()

    # KDE empirical interval
    sample_size = min(df_cat.shape[0], 20_000)
    df_tiny = df_cat.sample(sample_size, random_state=42)

    if df_tiny.shape[0] < 20:
        print(
            f"Ignorando categoria {cat} -- há apenas {df_tiny.shape[0]} vendas na categoria"
        )
        return

    if abs(df_tiny["Margin"].max() - df_tiny["Margin"].min()) < 0.01:
        print(
            f"Ignorando categoria {cat} -- não há nenhuma variação de margem. Margem: {df_tiny['Margin'].max():.2%}"
        )
        return

    kde = sps.gaussian_kde(df_tiny[["Margin", "norm_rev"]].values.T)
    xx, yy = np.meshgrid(
        np.linspace(0, 1, 100),
        np.linspace(0, df_tiny["norm_rev"].max(), 100),
    )
    z = kde.pdf([xx.ravel(), yy.ravel()]).reshape(xx.shape)
    zi = z >= np.max(z) * THRESHOLD
    zmax = z >= np.max(z) * 0.95
    interval_kde = (min(xx[zi]), max(xx[zi]))
    center_point = round((min(xx[zmax]) + max(xx[zmax])) / 2, 2)

    _, ax = plt.subplots(nrows=1, ncols=2, figsize=(9, 4))
    ax[0].title.set_text("Frequência de margens")

    sns.histplot(df_cat, x="Margin", fill=True, ax=ax[0], alpha=0.5, stat="probability")
    ax[0].set(xlabel="Margem", ylabel="Frequência")

    ax[0].axvline(x=interval_kde[0], ymin=0, ymax=1)
    ax[0].axvline(x=interval_kde[1], ymin=0, ymax=1)

    ax[1].title.set_text("Relação margem x receita normalizada")
    sns.kdeplot(
        df_tiny,
        x="Margin",
        y="norm_rev",
        ax=ax[1],
        levels=8,
        log_scale=(False, True),
        fill=True,
    )
    ax[1].set(xlabel="Margem", ylabel="Receita Normalizada (log)")

    ax[1].axvline(x=interval_kde[0], ymin=0, ymax=1)
    ax[1].axvline(x=interval_kde[1], ymin=0, ymax=1)

    plt.suptitle(
        f"{cat}\nMargem Ideal: {round(interval_kde[0], 2):.2%} - {round(interval_kde[1], 2):.2%}, centro: {center_point:.2%}"
    )
    plt.tight_layout()
    plt.show()


# %%
cats = sorted(df_margins["cat_str"].unique())
for cat in cats:
    plot_and_project(df_margins, cat)
