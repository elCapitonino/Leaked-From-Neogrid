﻿using DI.Repository.Enum;
using DI.Repository.Interfaces.Repositories;
using System.Transactions;

namespace DI.Repository.Interfaces
{
    public interface IUnitOfWork : IDisposable
    {
        IMonthlySaleHistoryDataRepository MonthlySaleHistoryDataRepository { get; }
        IProjectionImpactDataRepository ProjectionImpactDataRepository { get; }
        IMonthlyProjectionDataRepository MonthlyProjectionDataRepository { get; }
        IEnterprisePriceProjectionRepository EnterprisePriceProjectionRepository { get; }
        IEnterprisePriceGroupRepository EnterprisePriceGroupRepository { get; }
        IImpactReportConfigurationRepository ImpactReportConfigurationRepository { get; }
        IMonthlyImpactDataRepository MonthlyImpactDataRepository { get; }
        ICompanyDataRepository CompanyDataRepository { get; }
        IGrupoRecursoRepository GrupoRecursosRepository { get; }
        IGranularityGroupRepository GranularityGroupRepository { get; }

        TransactionScope CreateTransactionScope();
        TransactionScope CreateTransactionScope(TransactionScopeAsyncFlowOption asyncFlowOption);
        int SaveChanges(EContextType contextType = EContextType.All);
        Task<int> SaveChangesAsync(EContextType contextType = EContextType.All);
    }
}
