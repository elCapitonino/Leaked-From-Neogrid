﻿using MongoDB.Bson.Serialization.Attributes;

namespace Repository.Entity.Abv
{
    public class StoreEntity
    {
        [BsonElement("SEQLOJA")]
        public long? SeqLoja { get; set; }
    }

}
