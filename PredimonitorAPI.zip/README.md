# Predimonitor API
Este � um projeto de API RESTful desenvolvido em C# com .NET Core 8.0. O objetivo � fornecer uma API para gest�o do monitoramento de pre�os.

## Tecnologias
- .NET Core 8.0
- Entity Framework Core
- SQL Server
- Swagger
- Docker
- MongoDB


## Execu��o
Para executar o projeto, voc� pode utilizar o Visual Studio ou o Visual Studio Code. Basta abrir a solu��o e executar o projeto ou utilizar o comando `dotnet run` no terminal.
Tamb�m � poss�vel executar o projeto utilizando Docker. Para isso, basta seguir os passos abaixo:
1. Execute o comando para fazer o build da imagem:
```
docker build -t predimonitor-api .
```
2. Execute o comando para rodar o container:
```
docker run -d -p 8080:80 --name predimonitor-api predimonitor-api
```

## Documenta��o
A documenta��o da API foi feita utilizando o Swagger. Para acessar a documenta��o, basta acessar a URL `http://localhost:8080/swagger`.


### Arquitetura
A arquitetura do projeto foi baseada no padr�o DDD (Domain-Driven Design) em uma vers�o minimalista utilizando uma vers�o da Arquitetura em Camadas (Layered Architecture), tamb�m conhecida com [Arquitetura N-Tier](0).
A estrutura de pastas foi organizada da seguinte forma:

- **PredimonitorAPI**: Projeto de API, respons�vel por receber as requisi��es HTTP e chamar os m�todos dos Domains.
- **Domain**: Projeto de dom�nio, respons�vel pela regra de neg�cios.
- **Repository**: Projeto de reposit�rio, respons�vel por conter as entidades e os acessos ao banco.
- **Services**: Projeto de servi�os, respons�vel por conter as classes de servi�os para comunica��o externa entre outros tipos de servi�os.



[0]:https://stackify.com/n-tier-architecture/