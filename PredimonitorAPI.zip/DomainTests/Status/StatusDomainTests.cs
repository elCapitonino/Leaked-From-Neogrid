﻿using Domain.BackgroundTasks;
using Domain.IndexGenerator.DataSourceDomains.Interfaces;
using Domain.Models;
using Domain.Status;
using Domain.Status.Models;
using DomainTests.Extensions;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.DependencyInjection;
using MongoDB.Driver;
using Moq;
using Moq.Protected;
using Repository.DbContexts;
using Repository.Entity;
using Repository.UnitOfWork;
using Services.SearchAPI;
using System.Net;
using System.Text;

namespace DomainTests.Status
{
    [TestClass()]
    public class StatusDomainTests
    {
        private ServiceProvider _serviceProvider;

        [TestInitialize]
        public void Initialize()
        {
            var services = new ServiceCollection();
            var mongo = new Mock<MongoClient>().Object;

            services.AddTransient<IMongoClient>(provider => mongo);
            services.SetAutoMapper();

            services.AddDbContext<ApplicationDbContext>(options => options.UseInMemoryDatabase("TestDb").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            
            services.AddDbContext<HorusDbContext>(options => options.UseMongoDB(mongo, "Horus").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            services.AddDbContext<InfoPriceSaoJoaoDbContext>(options => options.UseMongoDB(mongo, "InfroPriceSaoJoao").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            services.AddDbContext<NormalizerDbContext>(options => options.UseMongoDB(mongo, "Normalizer").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            services.AddDbContext<LinxDbContext>(options => options.UseMongoDB(mongo, "Linx").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            services.AddDbContext<NeogridDbContext>(options => options.UseMongoDB(mongo, "Neogrid").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            services.AddDbContext<NielsenDbContext>(options => options.UseMongoDB(mongo, "Nielsen").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            services.AddDbContext<SmarketCompetitorDbContext>(options => options.UseMongoDB(mongo, "SmarketCompetitor").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            services.AddDbContext<OfflineDbContext>(options => options.UseMongoDB(mongo, "Offline").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            services.AddDbContext<ScantechSupermaxiDbContext>(options => options.UseMongoDB(mongo, "Scantech").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);

            services.AddTransient(provider => new DatabricsDbContext("", ""));

            services.Configure<AppsettingsOptions>(AppsettingsOptions =>
            {
                AppsettingsOptions.IndexConfiguration.PeriodyInMonthToIndexing = 6;
            });

            services.AddScoped<IStatusDomain, StatusDomain>();
            services.AddScoped<IBackgroundTaskQueue, BackgroundTaskQueue>();
            services.AddHostedService<QueuedService>();

            services.AddMemoryCache();



            services.AddScoped<IUnitOfWork, UnitOfWork>();
            services.AddLogging();
            _serviceProvider = services.BuildServiceProvider();
            
        }
        [TestMethod()]
        public void InsertStatusTest()
        {
            var domain = _serviceProvider.GetRequiredService<IStatusDomain>();

            var uow = _serviceProvider.GetRequiredService<IUnitOfWork>();

            var result = domain.AddOrUpdate(new MonitoringItemResultsStatusRequest()
            {
                CompanyId = 3026,
                Message = "Teste",
                Step = 0,
            });

            Assert.IsNotNull(result, "Status não inserido corretamente");
            Assert.AreEqual(3026, result.CompanyId, "CompanyId não corresponde ao esperado");
            Assert.IsNotNull(result.TaskId, "TaskId não foi gerado corretamente");

            Assert.AreEqual(1, uow.MonitoringItemResultsStatus.GetAll().Count(), "Status não foi inserido no banco de dados corretamente");

        }

        [TestMethod()]
        public void UpdateTheLastStatusTest()
        {
            var domain = _serviceProvider.GetRequiredService<IStatusDomain>();

            var uow = _serviceProvider.GetRequiredService<IUnitOfWork>();
            uow.MonitoringItemResultsStatus.GetAll().Select(x => x.Id).ForEachAsync(x => uow.MonitoringItemResultsStatus.Delete(x));
            Guid? taskId = Guid.Parse("83a1705f-b841-4b3b-8ffc-f6464b9c847d");
            uow.Company.Create(new CompanyEntity()
            {
                Id = 3026,
                Company = "Teste"
            });

            uow.MonitoringItemResultsStatus.Create(new MonitoringItemResultsStatusEntity()
            {
                CurrentStep = 0,
                CompanyId = 3026,
                CreateDate = DateTime.Now,
                Status = Repository.Enums.MonitoringItemResultsStatusType.Running,
                TaskId = taskId.Value
            });


            var result = domain.AddOrUpdate(new MonitoringItemResultsStatusRequest()
            {
                CompanyId = 3026,
                Message = "Teste",
                Step = 1,
                TaskId = taskId
            });

            Assert.AreEqual(1, uow.MonitoringItemResultsStatus.GetAll().Count(), "Status não foi inserido no banco de dados corretamente");
            Assert.AreEqual(1, uow.MonitoringItemResultsStatus.GetAll().Where(x => x.CurrentStep == 1).Count(), "Status não foi atualizado corretamente");
            Assert.AreEqual(taskId, result.TaskId, "TaskId não foi gerado corretamente");


        }
    }
}