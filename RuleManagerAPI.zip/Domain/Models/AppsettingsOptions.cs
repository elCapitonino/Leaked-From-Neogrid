﻿namespace Domain.Models
{
    public class AppsettingsOptions
    {
        public string ConnectionString { get; set; }
        public AppsettingsWebSocketOptions WebSocket { get; set; }
        public AppsettingsAuthOptions Auth { get; set; }


    }
    public class AppsettingsAuthOptions
    {
        public string Host { get; set; }
    }
    public class AppsettingsWebSocketOptions
    {
        public AppsettingsCorsOptions Cors { get; set; }
    }

    public class AppsettingsCorsOptions
    {
        public string[] Origins { get; set; }
    }
}
