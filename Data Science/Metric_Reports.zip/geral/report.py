"""
Módulo para criar um estilo para relatório.
"""

from __future__ import annotations
from typing import Any, Callable, NamedTuple, Optional
from uuid import UUID, uuid4

import pandas as pd
from numpy.typing import ArrayLike
from pandas.io.formats.style import Styler

PCT_SIGN = "%"


class CellStyle(NamedTuple):
    color: str = "#000000"  # hexadecimal
    bg_color: str = "#FFFFFF"  # hexadecimal
    align: str = "center"
    font_weight: str = "normal"

    def to_css(self, hyperlink: bool = False) -> str:
        css = []
        color = self.color
        if hyperlink:
            color = "#2A00FF"
            css.append("text-decoration: underline")
        css.append(f"color: {color}")
        css.append(f"background-color: {self.bg_color}")
        css.append(f"text-align: {self.align}")
        css.append("vertical-align: text-top")
        css.append(f"font-weight: {self.font_weight}")
        return "; ".join(css)


class ReportStyle(NamedTuple):
    """
    Parâmetros:
    - default_style: estilos padrões aplicados de forma rotativa.
        Exemplo: 2 estilos.
            - Primeiro é aplicado nas linhas 1, 3, 5, ...
            - Segundo é aplicado nas linhas 2, 4, 6, ...
    - substring_map: estilos (valores) aplicados em colunas contendo a substring (chave) de forma rotativa (ver acima).
    - exact_map: estilos (valores) aplicados pelo nome da coluna (chave) de forma rotativa (ver acima).
    - title_style: estilo da linha com nomes das colunas.
    """

    default_style: tuple[CellStyle, ...] = (CellStyle(), CellStyle(bg_color="#B0E0E6"))
    substring_map: Optional[dict[str, tuple[CellStyle, ...]]] = None
    exact_map: Optional[dict[str, tuple[CellStyle, ...]]] = None
    title_style: CellStyle = CellStyle("#FFFFFF", "#4682B4", align="center", font_weight="bold")
    fill_na_value: Optional[str] = None


class Report:
    def __init__(
        self,
        data: pd.DataFrame,
        metadata: dict[str, Any],
        raw: bool = False,
        final: bool = False,
        _id: Optional[UUID] = None
    ) -> None:
        self.data = data
        self.metadata = metadata
        self.final = final
        self.raw = raw
        self.__id = uuid4() if _id is None else _id
        self.__name = None

    @property
    def id(self) -> UUID:
        return self.__id

    @property
    def name(self) -> str:
        return "Geral" if self.final else (self.__name or str(self.id)[:10])

    def float_columns(self) -> list[int]:
        return float_columns(self.data)

    def pct_columns(self) -> list[int]:
        return pct_columns(self.data)

    def get_ref_ids(self) -> Optional[ArrayLike]:
        if "ref_id" not in self.data.columns:
            return None
        return self.data["ref_id"].values

    def remove_columns(self, blocked_cols: list[str]) -> Report:
        df = self.data.copy()
        df = df.drop(columns=blocked_cols, errors="ignore")
        return Report(df, self.metadata.copy(), raw=self.raw, final=self.final, _id=self.__id)

    def get_report(
        self,
        col_mapping: Optional[dict[str, str]] = None,
        drop_ref_id: bool = True,
    ) -> pd.DataFrame:
        df = self.data.copy()

        if drop_ref_id:
            df = df.drop(columns=["ref_id"], errors="ignore")
        if self.raw:
            df.sort_values(["Data de Precificação", "Descrição do Produto"], inplace=True)
        else:
            df.sort_values(df.columns[0], inplace=True)

        df.reset_index(inplace=True, drop=True)
        if col_mapping is not None:
            df.rename(columns=col_mapping, inplace=True)
        return df

    def get_styled_report(
        self,
        report_style: ReportStyle,
        col_mapping: Optional[dict[str, str]] = None,
    ) -> Styler:
        # TODO periogoso pegar coluna errada
        df = self.get_report(col_mapping=col_mapping, drop_ref_id=True)
        if report_style.fill_na_value is not None:
            df.fillna(report_style.fill_na_value, inplace=True)
        hyperlink_col = df.columns[0] if "ref_id" in self.data.columns else None
        styler_fn = _get_styler_fn(report_style, hyperlink_col=hyperlink_col)
        df_styler = df.style.apply(styler_fn, axis=None)
        df_styler = df_styler.applymap_index(lambda _: report_style.title_style.to_css(), axis=1)
        return df_styler

    def use_as_name(self, key: str) -> None:
        """Usar valor de key em metadata como nome do relatório."""
        self.__name = self.metadata[key]

    @staticmethod
    def merge_reports(reports) -> Report:
        data = []
        metadata = {}
        raw = True
        for report in reports:
            data.append(report.get_report())
            metadata.update(report.metadata)
            raw = raw and report.raw
        data = pd.concat(data)
        return Report(data, metadata, raw=raw)

    def get_summaries(self) -> dict[str, list[pd.DataFrame]]:
        if not self.raw:
            return {}

        df = self.get_report()
        return get_summaries(df)
    


def float_columns(df: pd.DataFrame) -> list[int]:
    """Função para descobrir quais são as colunas de `df` com tipo `float`."""
    float_cols = [
            i
            for i, (type, col) in enumerate(zip(df.dtypes, df.columns))
            if type == "float" and PCT_SIGN not in col
        ]
    return float_cols


def pct_columns(df: pd.DataFrame) -> list[int]:
    """Função para descobrir quais são as colunas de `df` com o símbolo `PCT_SIGN` no nome."""
    pct_cols = [i for i, col in enumerate(df.columns) if PCT_SIGN in col]
    return pct_cols


def get_summaries(df: pd.DataFrame) -> dict[str, list[pd.DataFrame]]:
    """Função para criar as tabelas resumidas de Erros e Alterações, com base em `df`."""
    # erros do modelo
    tb_erros, tb_erros_2 = get_tb_erros(df, "Preço Sem Regras")
    tb_erros_3, tb_erros_4 = get_tb_erros(df, "Preço Ajustado")

    # alterações entre uma semana e outra
    df["Resultado"] = "Lucro"
    df.loc[(df["Alteração de Lucro (Semanal)"] < 0), "Resultado"] = "Prejuizo"
    preju = df.loc[(df["Alteração de Lucro (Semanal)"] < 0), :]
    lucro = df.loc[(df["Alteração de Lucro (Semanal)"] >= 0), :]
    df.drop("Resultado", axis=1, inplace=True)

    tb_alts = (
        pd.concat(
            [
                (
                    preju[(preju["Influência da IA (Preço Ajustado)"] == "VERDADEIRO")]
                    .groupby(["Data de Precificação", "Resultado"])
                    .agg(
                        a=pd.NamedAgg("Alteração de Margem (Semanal) - %", "mean"),
                        b=pd.NamedAgg("Alteração de Volume (Semanal)", "sum"),
                        c=pd.NamedAgg("Alteração de Receita (Semanal)", "sum"),
                        d=pd.NamedAgg("Alteração de Lucro (Semanal)", "sum"),
                    )
                    .rename(
                        columns={
                            "a": "Alteração de Margem Agregada",
                            "b": "Alteração de Volume Agregada",
                            "c": "Alteração de Receita Agregada",
                            "d": "Alteração de Lucro Agregada",
                        }
                    )
                ),
                (
                    lucro[(lucro["Influência da IA (Preço Ajustado)"] == "VERDADEIRO")]
                    .groupby(["Data de Precificação", "Resultado"])
                    .agg(
                        a=pd.NamedAgg("Alteração de Margem (Semanal) - %", "mean"),
                        b=pd.NamedAgg("Alteração de Volume (Semanal)", "sum"),
                        c=pd.NamedAgg("Alteração de Receita (Semanal)", "sum"),
                        d=pd.NamedAgg("Alteração de Lucro (Semanal)", "sum"),
                    )
                    .rename(
                        columns={
                            "a": "Alteração de Margem Agregada",
                            "b": "Alteração de Volume Agregada",
                            "c": "Alteração de Receita Agregada",
                            "d": "Alteração de Lucro Agregada",
                        }
                    )
                ),
            ],
            axis=0,
            ignore_index=False,
        )
        .groupby(["Data de Precificação", "Resultado"])
        .mean(numeric_only=True)
    )
    tb_alts_2 = tb_alts.groupby("Resultado").sum()
    tb_alts_2 = pd.concat(
        [tb_alts_2, pd.DataFrame(tb_alts_2.sum(), columns=["Final"]).transpose()], axis=0, ignore_index=False
    )

    # contagem de valores
    df["aux"] = 1
    tb_qtd_aprov = df.pivot_table(
        "aux", index="Data de Precificação", columns="Preço Ajustado Aprovado?", aggfunc="sum"
    )
    tb_qtd_ia_sem_regra = df.pivot_table(
        "aux", index="Data de Precificação", columns="Influência da IA (Preço Sem Regras)", aggfunc="sum"
    )
    tb_qtd_ia = df.pivot_table(
        "aux", index="Data de Precificação", columns="Influência da IA (Preço Ajustado)", aggfunc="sum"
    )
    tb_qtd_ia_new = df.pivot_table(
        "aux",
        index="Data de Precificação",
        columns="Influência da IA - Preços Novos (Preço Ajustado)",
        aggfunc="sum",
    )
    df.drop("aux", axis=1, inplace=True)

    return {
        "erros": [tb_erros, tb_erros_2, tb_erros_3, tb_erros_4],
        "consolidado": [tb_alts, tb_alts_2, tb_qtd_aprov, tb_qtd_ia_sem_regra, tb_qtd_ia, tb_qtd_ia_new],
    }


def _get_styler_fn(report_style: ReportStyle, hyperlink_col: Optional[str] = None) -> Callable:
    substring_map = report_style.substring_map or {}
    exact_map = report_style.exact_map or {}

    def styler(df: pd.DataFrame) -> pd.DataFrame:
        df_style = df.copy()

        # default style
        n_styles = len(report_style.default_style)
        for i, style in enumerate(report_style.default_style):
            df_style.loc[i::n_styles, :] = style.to_css()

        # hyperlink style
        if hyperlink_col is not None:
            for i, style in enumerate(report_style.default_style):
                df_style[hyperlink_col][i::n_styles] = style.to_css(hyperlink=True)

        # substring map
        for substring, styles in substring_map.items():
            for col in df_style.columns:
                if substring.lower() in col.lower():
                    n_styles = len(styles)
                    for i, style in enumerate(styles):
                        df_style[col][i::n_styles] = style.to_css()

        # exact map
        for col, styles in exact_map.items():
            if col not in df_style.columns:
                continue
            n_styles = len(styles)
            for i, style in enumerate(styles):
                df_style[col][i::n_styles] = style.to_css()

        return df_style

    return styler


def get_tb_erros(df: pd.DataFrame, tipo: str) -> tuple:
    """Função auxiliar para puxar as tabelas de erros de acordo com o `tipo` de influência da IA."""
    tb_erros = (
        df.groupby(["Data de Precificação", f"Influência da IA ({tipo})"])
        .agg(
            a=pd.NamedAgg("Erro de Projeção de Preço", "mean"),
            b=pd.NamedAgg("Erro de Projeção de Demanda", "mean"),
            c=pd.NamedAgg("Erro de Projeção de Receita", "mean"),
            d=pd.NamedAgg("Erro de Projeção de Preço", "size"),
        )
        .rename(
            columns={
                "a": "Média do Erro de Preço",
                "b": "Média do Erro de Demanda",
                "c": "Média do Erro de Receita",
                "d": "Quantidade de Registros",
            }
        )
    )
    tb_erros_2 = (
        tb_erros.reset_index()
        .drop("Data de Precificação", axis=1)
        .groupby(f"Influência da IA ({tipo})")
        .agg(
            a=pd.NamedAgg("Média do Erro de Preço", "mean"),
            b=pd.NamedAgg("Média do Erro de Demanda", "mean"),
            c=pd.NamedAgg("Média do Erro de Receita", "mean"),
            d=pd.NamedAgg("Quantidade de Registros", "sum"),
        )
        .rename(
            columns={
                "a": "Média do Erro de Preço",
                "b": "Média do Erro de Demanda",
                "c": "Média do Erro de Receita",
                "d": "Quantidade de Registros",
            }
        )
    )
    return tb_erros, tb_erros_2
