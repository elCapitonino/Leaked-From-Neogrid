﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Repository.Attributes;
using Repository.DbContexts;
using Repository.Entity;

namespace Repository.TypeConfiguration
{
    [DbContextTypeConfiguration(typeof(ApplicationDbContext))]
    public class CompanyTypeConfiguration : TypeConfigurationBase<CompanyEntity>, IEntityTypeConfiguration<CompanyEntity>
    {
        public override void Configure(EntityTypeBuilder<CompanyEntity> builder)
        {
            ConfigureTableName(builder, "Empresa");

            builder.Property(p => p.Id).HasColumnName("IdEmpresa");
            builder.Property(p => p.Company).IsRequired().HasMaxLength(80).HasColumnName("NomeRazaoSocial");
            builder.Property(p => p.CityId).HasColumnName("IdMunicipio");
            builder.Property(p => p.Cnpj).HasMaxLength(14);
            builder.Property(p => p.IsFinalizedForm).HasDefaultValue(false).HasColumnName("IsFormularioFinalizado");
            builder.Property(p => p.MainCompanyId).HasColumnName("IdEmpresaPrincipal").HasColumnName("EmpresaPrincipalId");
            builder.Property(p => p.IntelligentPricing).HasColumnName("PrecificacaoInteligente");
            builder.Property(p => p.RoutineCompleted).HasColumnName("RotinaCompletada");
            builder.Property(p => p.MonitoringLanguage).HasMaxLength(5);
            builder.Property(p => p.PartnerId).HasColumnName("IdParceiro");
            builder.Property(p => p.CountryId).HasColumnName("IdContry");

        }
       
    }
}
