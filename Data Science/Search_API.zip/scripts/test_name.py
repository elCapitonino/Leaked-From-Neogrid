"""
Script para testar uma query de busca com BM25.
"""

import argparse
import json
from datetime import datetime, timedelta
from typing import Dict, List

import requests


def call_endpoint(
    name: str, start_date: datetime, end_date: datetime, crawler_ids: List[int], language: str
) -> Dict:
    body = {
        "start_date": start_date.isoformat(),
        "end_date": end_date.isoformat(),
        "period_type": 0,
        "id_company": None,
        "idcrawlers": crawler_ids,
        "data_source": 0,
        "filters": {"products": [name], "language": language},
    }
    response = requests.post("http://localhost:8081/v3/search/bm25", json=body, timeout=120)
    return response.json()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("name")
    parser.add_argument("--crawler-ids", nargs="+", type=int, required=True)
    parser.add_argument("--n-days", type=int, default=7)
    parser.add_argument("--language", default="pt-br")
    args = parser.parse_args()

    end_date = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    start_date = end_date - timedelta(days=args.n_days)

    print(args.crawler_ids)
    response = call_endpoint(
        args.name,
        start_date,
        end_date,
        crawler_ids=args.crawler_ids,
        language=args.language,
    )

    print(f"Nome: {args.name}")
    print(json.dumps(response, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
