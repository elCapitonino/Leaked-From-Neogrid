using AutoMapper;
using Domain.IndexGenerator.DataSourceDomains.Interfaces;
using Domain.IndexGenerator.Models;
using Microsoft.Extensions.Logging;
using Repository.Entity;
using Repository.UnitOfWork;
using Services.SearchAPI;
using Services.SearchAPI.Models;
using Microsoft.Extensions.Caching.Memory;
using Domain.Status;
using Repository.Enums;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System.ComponentModel.Design;
using System.Diagnostics;
using System.Collections.Concurrent;
using System.Collections.Generic;

namespace Domain.IndexGenerator.DataSourceDomains
{
    public class IndexGeneratorPredifyDomain : IndexGeneratorBase, IIndexGeneratorPredifyDomain
    {
        private readonly ILogger<IndexGeneratorPredifyDomain> _logger;
        private readonly IUnitOfWork _uow;
        private readonly IMapper _mapper;
        private readonly ISearchAPIService _searchAPIService;

        public IndexGeneratorPredifyDomain(ILogger<IndexGeneratorPredifyDomain> logger, IUnitOfWork uow, IMapper mapper, ISearchAPIService searchAPIService, IStatusDomain statusDomain)
            : base(statusDomain)
        {
            ArgumentNullException.ThrowIfNull(logger);
            ArgumentNullException.ThrowIfNull(uow);
            ArgumentNullException.ThrowIfNull(mapper);
            ArgumentNullException.ThrowIfNull(searchAPIService);

            _logger = logger;
            _uow = uow;
            _mapper = mapper;
            _searchAPIService = searchAPIService;
        }

        public async Task GenerateIndexAsync(long companyId, IEnumerable<int> crawlerIds, IEnumerable<MonitoringItemTags> monitoringItems, DateTime startDate, DateTime endDate, Guid? taskId, List<long> listIdsDelete)
        {
            try
            {
                _logger.LogInformation($"Iniciando Gera��o de index da Predify");
                var total = monitoringItems.Count();
                var count = 1;
                UpdateStatus(taskId, CrawlerSourceType.Predify, MonitoringItemResultsStatusType.Running, total, 0);
                EnsureAllMonitoringItemId(monitoringItems);

                foreach (var monitoringItem in monitoringItems)
                {
                    try
                    {
                        ConcurrentBag<SearchAPIResponse> products = new ConcurrentBag<SearchAPIResponse>();
                        List<Task> searchTasks = new List<Task>();
                        var time = new Stopwatch();

                        time.Start();

                        List<MonitoringItemTags> monitoringItemTags = new List<MonitoringItemTags>();
                        monitoringItemTags.Add(monitoringItem);

                        var requestSearch = await GenerateSearchAPIRequestBodyAsync(companyId, monitoringItemTags);
                        requestSearch.CrawlersIds = crawlerIds;

                        using (var semaphore = new SemaphoreSlim(5))
                        {
                            for (var date = endDate; date > startDate; date = date.AddDays(-1))
                            {
                                await semaphore.WaitAsync();

                                var start = date.AddDays(-1);
                                var end = date;

                                var task = Task.Run(async () =>
                                {
                                    try
                                    {
                                        var searchRequest = requestSearch.Clone();
                                        searchRequest.StartDate = start;
                                        searchRequest.EndDate = end;

                                        var result = await _searchAPIService.SearchV4(searchRequest);
                                        _logger.LogInformation("Search Monitoring Item Base Predify for monitoringItem: {MonitoringItemId} - Date: {Start} - {End} - Total: {Count}", monitoringItem.MonitoringItemId, start.ToString("dd/MM/yyyy"),end.ToString("dd/MM/yyyy"),result.Count());
                                        foreach (var item in result)
                                        {
                                            products.Add(item);
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        _logger.LogError(ex, "Error Search {Message}", ex.Message);
                                    }
                                    finally
                                    {
                                        semaphore.Release();
                                    }
                                });

                                searchTasks.Add(task);
                            }

                            await Task.WhenAll(searchTasks);
                        }

                        var productDistinct = products.ToList()
                        .GroupBy(x => $"{x.MonitoringItemId}{x.ProductLink}{x.CrawlerId}{x.CompanyId}{x.Seller}{x.Category}{x.Brand}{x.Year}{x.Region}{x.Model}")
                        .Select(x => x.First()).ToList();

                        time.Stop();

                        SaveMonitoringItemResults(productDistinct);
                        UpdateStatus(taskId, CrawlerSourceType.Predify, MonitoringItemResultsStatusType.Running, total, count);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "Error Search Monitoring Item Base Predify for monitoringItem: {MonitoringItemId}",monitoringItem.MonitoringItemId);
                        UpdateStatus(taskId, CrawlerSourceType.Predify, MonitoringItemResultsStatusType.Error, total, count);
                    }
                    count++;
                }

                _uow.MonitoringItemResults.DeleteAll(listIdsDelete);

                UpdateStatus(taskId, CrawlerSourceType.Predify, MonitoringItemResultsStatusType.Finished, total, --count);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error {MethodName}", nameof(GenerateIndexAsync));
                throw;
            }
        }

        public async Task GenerateIndexForCrawlersAsync(long companyId, IEnumerable<MonitoringItemTags> monitoringItems, Guid? crawlerTaskId)
        {
            _logger.LogInformation($"Iniciando Gera��o de index da Predify - Crawlers");

            try
            {
                var requestSearch = await GenerateSearchAPIRequestBodyAsync(companyId, monitoringItems);
                requestSearch.TaskIds = new List<Guid> { crawlerTaskId.Value };


                var products = await _searchAPIService.SearchV4WithTask(requestSearch);

                SaveMonitoringItemResults(products);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error Search Monitoring Item Base Predify");
            }
        }

        private List<string> SearchRequestFromItemParseRequired(string text)
        {
            if (string.IsNullOrWhiteSpace(text)) return new List<string>();

            List<string> result = new List<string>();
            int startIndex = 0;
            int parenCount = 0;

            if (!text.Contains("("))
                return text.Split(';').ToList();

            var itens = System.Text.RegularExpressions.Regex.Split(text, @"; *(?![^()]*\))").Select(x => x.Replace("(", "").Replace(")", "").Trim()).ToList();

            return itens;
        }
        private async Task<CompanyConfigurationEntity?> GetCompanyConfigurationAsync(long companyId)
        {
            return await _uow.CompanyConfiguration.GetAll()
                .Where(x => x.CompanyId == companyId && !x.IsDeleted)
                .FirstOrDefaultAsync();
        }

        private void SaveMonitoringItemResults(IEnumerable<SearchAPIResponse> products)
        {
            var entities = products.GroupBy(x => $"{x.ProductLink}-{x.Seller}-{x.Region}").Select(x => x.First()).Select(x =>
            {
                var mapper = _mapper.Map<MonitoringItemResultsEntity>(x);
                mapper.Hash = x.ProductLink;

                return mapper;
            });
            _logger.LogInformation("Total de registros a serem inseridos: {Count}", entities.Count());

            _uow.MonitoringItemResults.AddRange(entities, true);
        }
        private async Task<SearchAPIRequest> GenerateSearchAPIRequestBodyAsync(long companyId, IEnumerable<MonitoringItemTags> monitoringItems)
        {
            var configuration = await GetCompanyConfigurationAsync(companyId);

            return new SearchAPIRequest()
            {

                CompanyId = companyId,
                Language = "pt-br",
                RelativeThreshold = configuration?.SearchThresholdRelative ?? 0.9m,
                FuzzyThreshold = configuration?.SearchThresholdFuzzy ?? 0.75m,
                RestrictiveFuzzyThreshold = 0.9m,
                UseTopWord = configuration?.SearchUseTopWord ?? true,
                UseCosine = configuration?.SearchUseCosine ?? true,
                VectorizerMode = "bm25",
                Products = monitoringItems.Select(x => new Products()
                {
                    MonitoringItemId = x.MonitoringItemId,
                    RequiredWords = SearchRequestFromItemParseRequired(x?.RequiredWords) ?? new List<string>(),
                    RestrictedWords = x.RestrictedWords != null ? x.RestrictedWords?.Split(';').Where(y => !string.IsNullOrWhiteSpace(y)).Select(z => z.Replace("(", "").Replace(")", "").Trim()) : new List<string>(),
                    Tags = x.Tags.Select(z => new Tags() { Description = z }).ToList()
                }).ToList(),
            };
        }
    }
}
