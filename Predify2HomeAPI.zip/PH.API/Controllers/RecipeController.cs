﻿using Microsoft.AspNetCore.Mvc;
using PH.Domain.Interfaces.Services;

namespace PH.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RecipeController : ControllerBase
    {
        private readonly ILogger<RecipeController> _logger;
        private readonly IRecipeServices _service;

        public RecipeController(ILogger<RecipeController> logger,
                                IRecipeServices service)
        {
            _logger = logger;
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> Get(string? loja, string? curva, string? categoria)
        {
            _logger.LogInformation("Controller: Buscando todos os Recipes");

            try
            {
                if (String.IsNullOrEmpty(loja) || loja.ToUpper() == "NULL")
                    loja = null;

                var recipes = await _service.Get(loja, curva, categoria);
                return Ok(recipes);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Controller: Erro ao buscar todos os Recipes. {ex.Message}");
                return StatusCode(500, "Erro ao buscar todos os Recipes");
            }
        }

        [HttpGet("lastMonth")]
        public async Task<IActionResult> LastMonth(string? loja, string? curva, string? categoria)
        {
            _logger.LogInformation("Controller: Buscando último mes");

            try
            {
                if (String.IsNullOrEmpty(loja) || loja.ToUpper() == "NULL")
                    loja = null;

                var recipes = await _service.GetLastMonthSales(loja, curva, categoria);
                return Ok(recipes);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Controller: Erro ao buscar todos os Recipes. {ex.Message}");
                return StatusCode(500, "Erro ao buscar todos os Recipes");
            }
        }

    }
}
