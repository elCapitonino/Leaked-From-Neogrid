namespace Repository.Entity.Databricks
{
    public class ProductEntity
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public string? Brand { get; set; }
        public string? EAN { get; set; }
        public int Year { get; set; }
        public int CrawlerId { get; set; }
        public string? Model { get; set; }
        public int UsedHours { get; set; }
        public int FuelTankCapacity { get; set; }
        public string? FuelTankCapacitySymbol { get; set; }
        public int Mileage { get; set; }
        public int MileageSymbol { get; set; }
        public int Axles { get; set; }
        public string? BodyType { get; set; }
        public DateTime ManufactureYear { get; set; }
    }
}