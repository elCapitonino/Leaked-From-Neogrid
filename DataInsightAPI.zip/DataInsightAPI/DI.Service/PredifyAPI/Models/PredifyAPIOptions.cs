﻿namespace DI.Service.PredifyAPI.Models
{
    public class PredifyAPIOptions
    {
        public Uri BaseAddress { get; set; }
        public string ClientId { get; set; }
        public string GrantType { get; set; }
        public string Password { get; set; }
        public string Username { get; set; }
    }
}
