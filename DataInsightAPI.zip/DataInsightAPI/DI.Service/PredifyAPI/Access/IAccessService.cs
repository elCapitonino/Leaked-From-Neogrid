﻿namespace DI.Service.PredifyAPI.Access
{
    public interface IAccessService
    {
        Task<bool> UserHasAccess(long companyId);
    }
}
