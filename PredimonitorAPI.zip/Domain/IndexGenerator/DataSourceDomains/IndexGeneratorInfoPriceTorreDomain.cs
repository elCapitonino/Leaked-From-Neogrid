﻿using AutoMapper;
using Domain.IndexGenerator.DataSourceDomains.Interfaces;
using Domain.IndexGenerator.Models;
using Domain.Status;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using MongoDB.Bson;
using Repository.Entity;
using Repository.Enums;
using Repository.UnitOfWork;
using System.Diagnostics;

namespace Domain.IndexGenerator.DataSourceDomains
{
    public class IndexGeneratorInfoPriceTorreDomain : IndexGeneratorBase, IIndexGeneratorInfoPriceTorreDomain
    {
        private readonly ILogger<IndexGeneratorInfoPriceTorreDomain> _logger;
        private readonly IUnitOfWork _uow;
        private readonly IMapper _mapper;
        private readonly IStatusDomain _statusDomain;

        public IndexGeneratorInfoPriceTorreDomain(ILogger<IndexGeneratorInfoPriceTorreDomain> logger, IUnitOfWork uow, IMapper mapper, IStatusDomain statusDomain)
            : base(statusDomain)
        {
            _logger = logger;
            _uow = uow;
            _mapper = mapper;
            _statusDomain = statusDomain;
        }

        public async Task GenerateIndexInfoPriceTorreAsync(long companyId, int crawlerId, IEnumerable<MonitoringItemTags> monitoringItems, DateTime startDate, DateTime endDate, Guid? taskId, List<long> monitoringResultIdsDelete)
        {
            try
            {
                _logger.LogInformation($"Iniciando Geração de index da InfoPrice Torre");
                var total = monitoringItems.Count();
                var count = 1;
                UpdateStatus(taskId, CrawlerSourceType.InfoPriceTorre, MonitoringItemResultsStatusType.Running, total, 0);
                Stopwatch totalStopwatch = new Stopwatch();
                totalStopwatch.Start();
                _logger.LogInformation("InfoPrice Torre - Total de monitoring items para serem processados: {total}", total);
                List<ObjectId> listUpdateHash = new List<ObjectId>();
                EnsureAllMonitoringItemId(monitoringItems);
                foreach (var monitoringItem in monitoringItems)
                {
                    try
                    {
                        if (!monitoringItem.Eans.Any())
                            continue;

                        var products = await _uow.InfoPriceTorreRepository.GetAll()
                            .Where(x => x.DataPreco >= startDate && x.DataPreco <= endDate && monitoringItem.Eans.Contains(x.IdentificadorProduto))
                            .Select(x => new
                            {
                                x.Id,
                                EAN = x.IdentificadorProduto,
                                x.Hash,
                                x.Categoria,
                                Seller = x.IdentificadorLoja,
                                Brand = x.Marca,
                                x.UF,
                                x.CNPJ
                            })
                            .ToListAsync();

                        listUpdateHash.AddRange(products.Where(x => string.IsNullOrEmpty(x.Hash)).Select(x => x.Id));

                        var entities = products.GroupBy(x => $"{GetOrGenerateHash(x.Hash, $"{x.EAN}|{x.CNPJ}")}{x.Seller}{x.UF}{x.Categoria}{x.Brand}")
                            .Select(x => x.First()).Select(x => new MonitoringItemResultsEntity()
                            {
                                Brand = x.Brand,
                                Category = x.Categoria,
                                Hash = GetOrGenerateHash(x.Hash, $"{x.EAN}|{x.CNPJ}"),
                                CompanyId = companyId,
                                CrawlerId = crawlerId,
                                MonitoringItemId = monitoringItem.MonitoringItemId,
                                Seller = x.Seller,
                                State = x.UF,
                            });

                        _uow.MonitoringItemResults.AddRange(entities, true);
                        UpdateStatus(taskId, CrawlerSourceType.InfoPriceTorre, MonitoringItemResultsStatusType.Running, total, count);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, $"Error Search Monitoring Item {monitoringItem.MonitoringItemId} InfoPrice Torre");
                        UpdateStatus(taskId, CrawlerSourceType.InfoPriceTorre, MonitoringItemResultsStatusType.Error, total, count);
                    }
                    count++;
                }

                if (monitoringResultIdsDelete != null && monitoringResultIdsDelete.Any())
                {
                    _uow.MonitoringItemResults.DeleteAll(monitoringResultIdsDelete);
                }

                if (listUpdateHash.Any())
                {
                    var productsToUpdate = _uow.InfoPriceTorreRepository
                              .GetAll()
                              .Where(x => listUpdateHash.Contains(x.Id))
                              .ToList();

                    foreach (var product in productsToUpdate)
                    {
                        product.Hash = CalculateSHA256($"{product.IdentificadorProduto}|{product.CNPJ}");
                    }

                    _uow.InfoPriceTorreRepository.Update(productsToUpdate, true);
                }

                totalStopwatch.Stop();
                _logger.LogInformation($"Finalizado Geração de index da InfoPrice Torre - {totalStopwatch.Elapsed.TotalSeconds}s");
                UpdateStatus(taskId, CrawlerSourceType.InfoPriceTorre, MonitoringItemResultsStatusType.Finished, total, --count);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error {MethodName}", nameof(GenerateIndexInfoPriceTorreAsync));
                throw;
            }
        }
    }
}
