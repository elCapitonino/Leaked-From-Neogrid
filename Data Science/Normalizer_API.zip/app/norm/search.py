from norm.memorycache import MemoryCache
import re


class Search:
    def __init__(self):
        self.memory = MemoryCache()
        self.score = 0
        #print(" ------ Inicio  pesquisa ------ ")

    ################################ 1º camada ################################
    def search_ean(self, ean, model, product):
        #print("----------------------", product)
        """
        - Busca pelo numero EAN do produto e verifica produto informado com o produto do banco de dados
        - Verifica se categoria e marca existe para o numero EAN informado        
        """
        #print("product:", product)
        list_product = []
        for i in self.memory.get_products_normalized(i["language"]):
            if i["ean"] == ean:
                if i["product"] == product and i["category"] != None and i["brands"] != None:
                    # print("ean")
                    self.cal_score(10.0)
                    i.update({"score": self.score})
                    list_product.append(i)
                    self.score = 0
        return list_product

    def search_ncm(self, ncm, model, product):
        """
        - Busca pelo numero  ncm do produto e verifica produto informado com o produto do banco de dados
        - Verifica se categoria e marca existe        
        """
        #print("ncm ----------- ", ncm)
        list_product = []
        for i in self.memory.products_normalized:
            # print(i)
            # Varificar se o ncm é igual ao ncm do produto informado aqui
            #print("i[ncm] ", i["ncm"], " ncm", ncm)
            if i["ncm"] != None and i["ncm"] != "":
                #print("i[ncm] ", i["ncm"], " ncm", ncm)
                if i["ncm"] == ncm:
                    # print(i)
                    if i["product"] == product and i["category"] != None and i["brands"] != None:
                        # print("ncm")
                        self.cal_score(8.0)
                        i.update({"score": self.score})
                        list_product.append(i)
                        self.score = 0
        return list_product

    def search_model(self, model, product, brands):
        """
        - Busca pelo modelo do produto 
        - Verifica nome do produto informado com o produto do banco de dados
        - Verifica se a marca esta cadastrada para o modelo informado
        """
        list_product = []
        for i in self.memory.products_normalized:
            if "model" in i:
                if i["model"] == model:
                    if(i["product"] == product and i["brands"] == brands and i["category"] != None):
                        # print("model")
                        self.cal_score(6.0)
                        i.update({"score": self.score})
                        list_product.append(i)
                        self.score = 0
        return list_product

    def search_product(self, product, brands):
        """
        - Busca pelo nome do produto
        - Verifica se a marca e categoria
        - retorna uma lista de produtos 
        """
        list_product = []
        for i in self.memory.products_normalized:
            if i["product"] == product:
                if(i["brands"] == brands and i["category"] != None):
                    self.cal_score(5.0)
                    i.update({"score": self.score})
                    list_product.append(i)
                    self.score = 0

        #print("produto e marca", list_product)
        return list_product

    ################################ 2º camada ################################

    def cal_score(self, num):
        """
        - Calcula o score do produto
        """
        # print(type(num))

        self.score = (self.score + num)
        # print(self.score)
    '''
    def search_full(self, product, brands, voltage, materials, metric_units, power, trash=None, dimensions=None, energy_source=None, size=None, language=None):
        """  
        Busca por nome do produto, marca, categoria, material, tensão, unidade de medida, potência e 
        adiciona pontuação a cada caractetistica encontrada 
        """
        #print("search_full", product, brands)
        # score cliente
         
        score_must_be = 0
        if len(product) != 0:
            score_must_be += 1
        if brands != None:
            score_must_be += 1
        if voltage != None:
            score_must_be += 1
        if materials != None:
            score_must_be += 1
        if len(metric_units) != 0:
            score_must_be += 1
        if power != None:
            score_must_be += 1
        if dimensions != None:
            score_must_be += 1
        if energy_source != None:
            score_must_be += 1
        # if size != None:
        #     score_must_be += 1

        list_produts = []
        if score_must_be >= 1:
            for i in self.memory.get_products_normalized(language):

                if (len(product) != 0):
                    if(sorted(i["product"]) == sorted(product)):
                        self.cal_score(1.0)
                        #print(" i[product] ", i["product"])
                    if(i["brands"] == brands and brands != None):
                        self.cal_score(1.0)
                    if i["voltage"] == voltage and voltage != None:
                        self.cal_score(1.0)
                    if i["materials"] == materials and materials != None:
                        self.cal_score(1.0)
                    if metric_units != None:
                        for metric in i["metric_units"]:
                            if (metric in metric_units):
                                self.cal_score(1.0)
                    if i["power"] == power and power != None:
                        self.cal_score(1.0)
                    if i["dimensions"] == dimensions and dimensions != None:
                        self.cal_score(1.0)
                    if i["energy_source"] == energy_source and energy_source != None:
                        self.cal_score(1.0)
                    # if i["size"] == size and size != None:
                    #     self.cal_score(1.0)

                    #print(i, "score: ", self.score)
                    # print("----------")
                    # if self.score >= score_must_be:
                    if self.score >= score_must_be:
                        if (self.score == 1 and trash != None):
                            i.update(
                                {"score": self.score, "search_name_trash": trash})

                            list_produts.append(i)
                        elif(self.score >= 2):
                            i.update(
                                {"score": self.score, "search_name_trash": trash})

                            list_produts.append(i)
                        #self.score = 0

                    # diferente de 3 não entra

                    #print("lesta d ", i)

                    self.score = 0
        #print("lista de produtos", list_produts)
        return list_produts
        '''

    def search_full_pred_monitor(self, list_product, language, exactVector:bool = True):
        """_summary_ 
            -recebe produto e os atributos do produto
        Args:
            list_product (dicionario): atributos do produto
            language (_type_): idioma

        Returns:
            _type_: lista de id dos produtos mais o trash
        """

        #print("list_product", list_product)
        list_produts_return = []
        for product in list_product:
            # print(product)
            # score cliente
            score_must_be = 0
            if (len(product["product"]) != 0):
                score_must_be += 1
            if product["brands"] != None:
                score_must_be += 1
            if product["voltage"] != None:
                score_must_be += 1
            if product["materials"] != None:
                score_must_be += 1
            if len(product["metric_units"]) != 0:
                score_must_be += 1
            if product["power"] != None:
                score_must_be += 1
            if product["dimensions"] != None:
                score_must_be += 1
            if product["energy_source"] != None:
                score_must_be += 1
            # if size != None:
            #     score_must_be += 1
            #list_produts_return = []
            if score_must_be >= 1:

                for i in self.memory.get_products_normalized(language):
                    # if i["product"] == product["product"] and product["product"] != None:
                    #     self.cal_score(1.0)
                    qtde_termos = len(product["product"])
                    matches = 0
                    for termo in product["product"]:
                        # Tamanho se encontrado, sempre igual a 1
                        tamanho = [x for x in i["product"] if re.match(termo, x)]
                        matches = matches + len(tamanho)
                    if(matches == qtde_termos and (exactVector == False or qtde_termos == len(i["product"]))):
                        self.cal_score(1.0)
                        #print(" i[product] ", i["product"])
                    if "brands" in i and i["brands"] != None:
                        if(str(i["brands"]).lower() == str(product["brands"]).lower() and product["brands"] != None):
                            self.cal_score(1.0)
                    if "voltage" in i and i["voltage"] != None: 
                        if i["voltage"] == product["voltage"] and product["voltage"] != None:
                            self.cal_score(1.0)
                    if "materials" in i and i["materials"] != None:
                        if i["materials"] == product["materials"] and product["materials"] != None:
                            self.cal_score(1.0) 
                    if product["metric_units"] != None:
                        if "metric_units" in i and i["metric_units"] != None: 
                            for metric in i["metric_units"]:
                                if (metric in product["metric_units"]):
                                    self.cal_score(1.0)                                  
                    if "power" in i and i["power"] != None:
                        if i["power"] == product["power"] and product["power"] != None:
                            self.cal_score(1.0)
                    if "dimensions" in i and i["dimensions"] != None: 
                        if i["dimensions"] == product["dimensions"] and product["dimensions"] != None:
                            self.cal_score(1.0)
                    if "energy_source" in i and i["energy_source"] != None:
                        if i["energy_source"] == product["energy_source"] and product["energy_source"] != None:
                            self.cal_score(1.0)

                    if self.score >= score_must_be:

                        if (self.score == 1 and product["trash"] != None):
                            i.update(
                                {"score": self.score, "search_name_trash": product["trash"]})

                            list_produts_return.append(i)
                        elif(self.score >= 2):

                            i.update(
                                {"score": self.score, "search_name_trash": product["trash"]})

                            list_produts_return.append(i)
                    self.score = 0

        #print("lista de produtos", list_produts_return)
        return list_produts_return

    # def search_full_pred_monitor(self, list_product, language):
    #     list_produts = []
    #     for i in self.memory.get_products_normalized(language):
    #         for product in list_product:
    #             if product["product"] != None and product["product"] != '':
    #                 if product["product"] != i["product"]:
    #                     continue

    #             if product["brands"] != None and product["brands"] != '':
    #                 if product["brands"] != i["brands"]:
    #                     continue

    #             if product["voltage"] != None and product["voltage"] != '':
    #                 if product["voltage"] != i["voltage"]:
    #                     continue

    #             if product["power"] != None and product["power"] != '':
    #                 if product["power"] != i["power"]:
    #                     continue

    #             if product["energy_source"] != None and product["energy_source"] != '':
    #                 if product["energy_source"] != i["energy_source"]:
    #                     continue

    #             if product["language"] != None and product["language"] != '':
    #                 if product["language"] != i["language"]:
    #                     continue

    #             # if product["size"] != None and product["size"] != '':
    #             #     if product["size"] != i["size"]:
    #             #         continue

    #             if product["dimensions"] != None and product["dimensions"] != '':
    #                 if product["dimensions"] != i["dimensions"]:
    #                     continue

    #             if product["category"] != None and product["category"] != '':
    #                 if product["category"] != i["category"]:
    #                     continue

    #             if product["metric_units"] != None and product["metric_units"] != '':
    #                 match_metric_units = True
    #                 for metric_unit in product["metric_units"]:
    #                     if metric_unit not in i["metric_units"]:
    #                         match_metric_units = False
    #                         break

    #                 if not match_metric_units:
    #                     continue

    #             i.update(
    #                 {"score": 0, "search_name_trash": product['trash']})

    #             list_produts.append(i)

    #     #print("list_produts", list_produts)
    #     return list_produts

    def search_brand_pred_monitor(self, list_product, language):

        list_produts = []
        for i in self.memory.get_products_normalized(language):
            for product in list_product:
                #print("product", product, " i :", i)
                if(product["brands"] == i["brands"] and product["category"] == i["category"] and product["language"] == i["language"]):

                    # print(i["_id"])
                    i.update(
                        {"score": 0, "search_name_trash": product['trash']})
                    list_produts.append(i)

        #print("list_produts brand", list_produts)
        return list_produts

    def search_category_pred_monitor(self, list_product, language):

        list_produts = []
        for i in self.memory.get_products_normalized(language):
            for product in list_product:
                #print("product", product, " i :", i)
                if(product["category"] == i["category"] and product["language"] == i["language"]):

                    # print(i["_id"])
                    i.update(
                        {"score": 0, "search_name_trash": product['trash']})
                    list_produts.append(i)

        #print("list_produts categoria", list_produts)
        return list_produts

        # list_produts = []
        # for i in self.memory.get_products_normalized(language):
        #     for product in list_product:
        #         for brand in product['brands']:
        #             if(product["product"] == i["product"] and brand == i["brands"] and
        #                     i["category"] == product["category"] and product['power'] == i["power"] and
        #                     product['voltage'] == i["voltage"] and product['language'] == i["language"]):
        #                 # print(i["_id"])
        #                 i.update(
        #                     {"score": 0, "search_name_trash": product['trash']})

        #                 list_produts.append(i)

        # return list_produts
