﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.IndexGenerator.Models
{
    public class HorusMonitoringRequest
    {
        public long CompanyId { get; set; }
        public int CrawlerId { get; set; }
        public IEnumerable<MonitoringItemTags> MonitoringItems { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public IEnumerable<string?> Cnpjs { get; set; }
        public IEnumerable<string?> Cities { get; set; }
        public IEnumerable<string?> States { get; set; }
        public IEnumerable<string?> StoreType { get; set; }
        public Guid? TaskId { get; set; }
        public List<long> MonitoringResultIdsDelete { get; set; }
    }
}
