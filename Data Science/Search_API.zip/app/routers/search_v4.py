"""
Endpoints do search V4.

Exemplo de requisição do endpoint /search:

```json
{
  "id_company": 2648,
  "products": [
    {
      "tags": [
        {
          "description": "SHAMPOO CLEAR ANTICASPA"
        }
      ],
      "restricted_words": ["clear"],
      "id_monitoring_item": 12
    },
    {
      "tags": [
        {
          "description": "SHAMPOO SEDA"
        }
      ],
      "required_words": ["seda"],
      "id_monitoring_item": 13
    }
  ],
  "language": "pt-br",
  "relative_threshold": 0.8,
  "fuzzy_threshold": 0.5,
  "restrictive_fuzzy_threshold": 0.9,
  "use_top_word": true,
  "use_cosine": true,
  "vectorizer_mode": "bm25",
  "start_date": "2023-02-01",
  "end_date": "2023-02-02",
  "id_crawlers": [148,150,163,164,177, 190]
}
```
"""

import asyncio
from datetime import timedelta
from functools import partial
from time import perf_counter
from typing import List

from fastapi import APIRouter
from fastapi.exceptions import HTTPException

from app.async_mongo import AsyncMongoConnect
from app.logger import logger
from app.search_v4 import (
    BaseSearchV4Request,
    DateSearchV4Request,
    SearchV4Result,
    TaskSearchV4Request,
    process_search_v4,
)

router = APIRouter()

MAX_CONCURRENCY = 3


def get_daily_requests(request: DateSearchV4Request) -> List[DateSearchV4Request]:
    num_days = (request.end_date - request.start_date).days
    out = []
    for i in range(num_days):
        new_request = request.copy(
            update={
                "start_date": request.start_date + timedelta(days=i),
                "end_date": request.start_date + timedelta(days=i + 1),
            }
        )
        out.append(new_request)

    return out


def _mongo_get_documents_by_date(
    request: DateSearchV4Request, mongo_client: AsyncMongoConnect
):
    return mongo_client.get_documents_search_v4(
        request.start_date, request.end_date, request.id_crawlers, request.id_company
    )


def _mongo_get_documents_by_task_id(
    request: TaskSearchV4Request, mongo_client: AsyncMongoConnect
):
    return mongo_client.get_documents_search_v4_task(request.task_ids)


async def _v4_endpoint(
    requests: List[BaseSearchV4Request], get_docs_function
) -> List[SearchV4Result]:
    """Endpoint genérico para search V4.
    Processa as requisições e deduplica o resultado (registros distintos)."""
    init = perf_counter()
    output_queue = asyncio.Queue()
    semaphore = asyncio.Semaphore(MAX_CONCURRENCY)

    logger.debug("processing the following requests: %s", requests)
    tasks = [
        asyncio.create_task(
            process_search_v4(request, output_queue, get_docs_function, semaphore)
        )
        for request in requests
    ]
    await asyncio.gather(*tasks)

    result = []
    while not output_queue.empty():
        result.append(await output_queue.get())

    result = list(set(result))
    logger.debug("search V4 request took %.2f ms", 1000 * (perf_counter() - init))
    return result


@router.post("/search")
async def date_search(request: DateSearchV4Request) -> List[SearchV4Result]:
    """
    Busca produtos nas bases online (crawlers) de acordo com faixa de datas, id_compnay
    e id_crawler especificados. A requisição é quebrada em processos diários, ou seja,
    um processo de busca por dia do intervalo.

    O intervalo de data é inclusivo no primeiro valor e exclusivo no segundo, ou seja:
    start_date <= crawler_date < end_date
    """
    try:
        mongo_client = AsyncMongoConnect()
        get_docs_function = partial(
            _mongo_get_documents_by_date, mongo_client=mongo_client
        )
        daily_requests = get_daily_requests(request)
        logger.debug("split search request into %d daily requests", len(daily_requests))
        return await _v4_endpoint(daily_requests, get_docs_function)
    except HTTPException as exc:
        raise exc
    except Exception as exc:
        logger.error("search V4 by date failed", exc_info=True)
        raise HTTPException(500, f"unexpected internal server error: {exc}") from exc


@router.post("/search_task")
async def task_search(request: TaskSearchV4Request) -> List[SearchV4Result]:
    """
    Busca produtos nas bases online (crawlers) filtrando apenas pelo task_id da
    execução do crawler.
    """
    try:
        mongo_client = AsyncMongoConnect()
        get_docs_function = partial(
            _mongo_get_documents_by_task_id, mongo_client=mongo_client
        )
        return await _v4_endpoint([request], get_docs_function)
    except HTTPException as exc:
        raise exc
    except Exception as exc:
        logger.error("search V4 by task_id failed", exc_info=True)
        raise HTTPException(500, f"unexpected internal server error: {exc}") from exc
