﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;

namespace Repository.Entity.ProductPrices
{
    public class ProductPricesSellerPriceInstallment
    {
        [BsonElement("quantity")]
        public int? Quantity { get; set; }

        [BsonElement("total_price")]
        public decimal? TotalPrice { get; set; }

        [BsonElement("price")]
        public decimal? Price { get; set; }

        [BsonElement("price_currency")]
        public string? PriceCurrency { get; set; }

        [BsonElement("price_payment_type")]
        public string? PricePaymentType { get; set; }
    }
}
