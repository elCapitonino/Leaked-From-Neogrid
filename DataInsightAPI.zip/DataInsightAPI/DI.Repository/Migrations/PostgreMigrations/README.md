Update-Database -Context PostgreContext
Add-Migration NOME-DA-MIGRATION -Context PostgreContext -o Migrations/PostgreMigrations