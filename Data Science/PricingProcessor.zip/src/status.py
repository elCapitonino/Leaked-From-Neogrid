from contextlib import contextmanager
from datetime import date, datetime, timezone
from typing import Optional
from uuid import UUID

from sqlalchemy import MetaData, Table, func, select

from src.db import PostgreSQLConnection, PostgreSQLEngine
from src.exceptions import DatabaseResultError
from src.logger import logger


@contextmanager
def status_manager(
    pg_engine: PostgreSQLEngine,
    metadata: MetaData,
    import_id: UUID,
):
    try:
        yield
    except Exception as exc:
        logger.error("import with ID %s, failed: %s", import_id, exc)
        with pg_engine.begin() as pg_conn:
            _update_failed_status(
                pg_conn=pg_conn, metadata=metadata, import_id=import_id
            )
        raise exc
    else:
        with pg_engine.begin() as pg_conn:
            _update_success_status(
                pg_conn=pg_conn, metadata=metadata, import_id=import_id
            )
        logger.debug("import with ID %s completed successfully", import_id)
    finally:
        with pg_engine.begin() as pg_conn:
            _finish_task(pg_conn=pg_conn, metadata=metadata, import_id=import_id)
        logger.debug("import with ID %s marked as finished", import_id)


def insert_date_range_import(
    pg_conn: PostgreSQLConnection,
    metadata: MetaData,
    id_company: int,
    initial_date: date,
    final_date: date,
) -> UUID:
    return _insert_import(
        pg_conn, metadata, id_company, initial_date=initial_date, final_date=final_date
    )


def insert_price_group_import(
    pg_conn: PostgreSQLConnection,
    metadata: MetaData,
    id_company: int,
    price_group: int,
) -> UUID:
    return _insert_import(pg_conn, metadata, id_company, price_group=price_group)


def _insert_import(
    pg_conn: PostgreSQLConnection,
    metadata: MetaData,
    id_company: int,
    price_group: Optional[int] = None,
    initial_date: Optional[date] = None,
    final_date: Optional[date] = None,
) -> UUID:
    table = Table("ProjectionImpactImportStatus", metadata, autoload_with=pg_conn)

    now = datetime.now(timezone.utc)
    stmt = (
        table.insert()
        .values(
            CompanyId=id_company,
            PriceGroupId=price_group,
            startDateRequest=initial_date,
            endDateRequest=final_date,
            Status="running",
            CreatedDate=now,
        )
        .returning(table.c.Id)
    )

    logger.debug("insert task statement:\n%s\nparams: %s", stmt, stmt.compile().params)
    result = pg_conn.execute(stmt).fetchone()
    if not result:
        raise DatabaseResultError(
            f"no task ID returned after insertion of id_company {id_company} task"
        )

    return result[0]


def _update_failed_status(
    pg_conn: PostgreSQLConnection, metadata: MetaData, import_id: UUID
):
    table = Table("ProjectionImpactImportStatus", metadata, autoload_with=pg_conn)
    now = datetime.now(timezone.utc)
    stmt = (
        table.update()
        .where(table.c.Id == import_id)
        .values(Status="failed", UpdatedDate=now)
    )
    logger.debug(
        "update failed task statement:\n%s\nparams: %s", stmt, stmt.compile().params
    )
    result = pg_conn.execute(stmt)
    logger.info(
        "marked task ID %s as failed with %d rows affected", import_id, result.rowcount
    )


def _finish_task(pg_conn: PostgreSQLConnection, metadata: MetaData, import_id: UUID):
    table = Table("ProjectionImpactImportStatus", metadata, autoload_with=pg_conn)
    now = datetime.now(timezone.utc)
    stmt = (
        table.update()
        .where(table.c.Id == import_id, table.c.Status == "running")
        .values(Status="interrupted", UpdatedDate=now)
    )
    logger.debug("finish task statement:\n%s\nparams: %s", stmt, stmt.compile().params)
    result = pg_conn.execute(stmt)
    logger.info(
        "finished task ID %s. %d rows affected in status table",
        import_id,
        result.rowcount,
    )


def _update_success_status(
    pg_conn: PostgreSQLConnection, metadata: MetaData, import_id: UUID
):
    table = Table("ProjectionImpactImportStatus", metadata, autoload_with=pg_conn)
    now = datetime.now(timezone.utc)
    stmt = (
        table.update()
        .where(table.c.Id == import_id)
        .values(Status="success", UpdatedDate=now)
    )
    logger.debug(
        "update success task statement:\n%s\nparams: %s", stmt, stmt.compile().params
    )
    result = pg_conn.execute(stmt)
    logger.info(
        "marked task ID %s as sucessful with %d rows affected",
        import_id,
        result.rowcount,
    )


def get_date_range_task_status(
    pg_conn: PostgreSQLConnection, metadata: MetaData, import_id: UUID
):
    table = Table("ProjectionImpactImportStatus", metadata, autoload_with=pg_conn)
    stmt = select(
        table.c.CompanyId,
        table.c.Status,
        table.c.startDateRequest,
        table.c.endDateRequest,
        func.coalesce(table.c.UpdatedDate, table.c.CreatedDate).label("timestamp"),
    ).where(table.c.Id == import_id, table.c.startDateRequest.isnot(None))
    result = pg_conn.execute(stmt).fetchone()
    if not result:
        return None
    return {
        "id_company": result[0],
        "status": result[1],
        "start_date_request": result[2],
        "end_date_request": result[3],
        "last_change": result[4],
    }


def get_price_group_task_status(
    pg_conn: PostgreSQLConnection, metadata: MetaData, import_id: UUID
):
    table = Table("ProjectionImpactImportStatus", metadata, autoload_with=pg_conn)
    stmt = select(
        table.c.CompanyId,
        table.c.Status,
        table.c.PriceGroupId,
        func.coalesce(table.c.UpdatedDate, table.c.CreatedDate).label("timestamp"),
    ).where(table.c.Id == import_id, table.c.PriceGroupId.isnot(None))
    result = pg_conn.execute(stmt).fetchone()
    if not result:
        return None
    return {
        "id_company": result[0],
        "status": result[1],
        "price_group_id": result[2],
        "last_change": result[3],
    }
