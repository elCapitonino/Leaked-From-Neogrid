﻿using MongoDB.Bson;
using Repository.Entity;
using Repository.EntityRepository.Bases;

namespace Repository.EntityRepository
{
    public interface IInfoPricePeraltaRepository : IGenericRepository<InfoPricePeraltaEntity, ObjectId>, IMongoRepository
    {
    }
}