﻿using DI.Repository.Enum;
using DI.Repository.Interfaces;

namespace DI.Test.Unit.Repositories
{
    public class MonthlySaleHistoryDataRepositoryTest
    {
        private readonly IUnitOfWork _unitOfWork;

        public MonthlySaleHistoryDataRepositoryTest(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        [Fact]
        public void TestGetAll_ReturnsData()
        {
            long companyId = 3026;
            int startYearMonth = 202401;
            int endYearMonth = 202404;
            EGranularityType granularityType = EGranularityType.None;

            var result = _unitOfWork.MonthlySaleHistoryDataRepository.GetAll(companyId, startYearMonth, endYearMonth, granularityType);
            var resultGetAll = _unitOfWork.MonthlySaleHistoryDataRepository.GetAll(companyId, granularityType);



            Assert.NotNull(result);
            Assert.NotEmpty(result);
            Assert.All(result, item => Assert.Equal(companyId, item.CompanyId));
            Assert.All(result, item => Assert.InRange(item.YearMonth, startYearMonth, endYearMonth));
            Assert.NotNull(resultGetAll);
            Assert.NotEmpty(resultGetAll);
            Assert.All(resultGetAll, item => Assert.Equal(companyId, item.CompanyId));
        }

        [Fact]
        public void TestGetAll_NoDataReturned()
        {
            long companyId = 00000;
            int startYearMonth = 202301;
            int endYearMonth = 202312;
            EGranularityType granularityType = EGranularityType.None;

            var result = _unitOfWork.MonthlySaleHistoryDataRepository.GetAll(companyId, startYearMonth, endYearMonth, granularityType);
            var resultGetAll = _unitOfWork.MonthlySaleHistoryDataRepository.GetAll(companyId, granularityType);


            Assert.NotNull(result);
            Assert.Empty(result);
            Assert.NotNull(resultGetAll);
            Assert.Empty(resultGetAll);
        }

        [Fact]
        public void TestGetAll_FilterByYearMonth()
        {
            long companyId = 1;
            int startYearMonth = 202301;
            int endYearMonth = 202306;
            EGranularityType granularityType = EGranularityType.None;

            var result = _unitOfWork.MonthlySaleHistoryDataRepository.GetAll(companyId, startYearMonth, endYearMonth, granularityType);
            var resultGetAll = _unitOfWork.MonthlySaleHistoryDataRepository.GetAll(companyId, granularityType);


            Assert.NotNull(result);
            Assert.All(result, item => Assert.InRange(item.YearMonth, startYearMonth, endYearMonth));
            Assert.NotNull(resultGetAll);
            Assert.All(resultGetAll, item => Assert.InRange(item.YearMonth, startYearMonth, endYearMonth));
        }

        [Fact]
        public void TestGetAll_FilterByGranularityType()
        {
            long companyId = 3026;
            int startYearMonth = 202401;
            int endYearMonth = 202404;
            EGranularityType granularityType = EGranularityType.Elasticity;

            var result = _unitOfWork.MonthlySaleHistoryDataRepository.GetAll(companyId, startYearMonth, endYearMonth, granularityType);
            var resultGetAll = _unitOfWork.MonthlySaleHistoryDataRepository.GetAll(companyId, startYearMonth, endYearMonth, granularityType);


            Assert.NotNull(result);
            Assert.All(result, item => Assert.Equal(granularityType, item.GranularityGroup.GranularityType));
            Assert.NotNull(resultGetAll);
            Assert.All(resultGetAll, item => Assert.Equal(granularityType, item.GranularityGroup.GranularityType));
        }
    }
}