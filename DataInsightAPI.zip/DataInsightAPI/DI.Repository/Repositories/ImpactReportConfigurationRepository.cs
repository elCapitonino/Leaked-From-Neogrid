﻿using DI.Repository.Attributes;
using DI.Repository.Contexts;
using DI.Repository.Entities;
using DI.Repository.Interfaces.Repositories;
using DI.Repository.Repositories.Base;

namespace DI.Repository.Repositories
{
    [UsePostgreContext]
    public sealed class ImpactReportConfigurationRepository : PostgreGenericNoModifyRepository<ImpactReportConfigurationEntity>, IImpactReportConfigurationRepository
    {
        public ImpactReportConfigurationRepository(PostgreContext dbContext) : base(dbContext)
        {
        }

        public ImpactReportConfigurationEntity? GetByCompanyId(long companyId)
        {
            var config = _dbContext
                .Set<ImpactReportConfigurationEntity>()
                .FirstOrDefault(x => x.CompanyId == companyId);

            if (config == null)
                throw new NullReferenceException("Configuration do not exist.");

            return config;
        }
        List<ImpactReportConfigurationEntity> IImpactReportConfigurationRepository.GetAll()
        {
            var config = _dbContext.Set<ImpactReportConfigurationEntity>().ToList();
            if (config.Count == 0)
                throw new InvalidOperationException("No configurations found.");

            return config;
        }
    }
}
