﻿namespace PredifyClientAPI.Services.PredifyAPI.Models
{
    public class AnswerModel<T>
    {
        //
        // Resumo:
        //     Status da chamada.
        //
        //     0 - Success: Informa que a requisição foi executada corretamente.
        //
        //     1 - Info: Informa que a requisição foi executada corretamente, mas retorna alguma
        //     informação.
        //
        //     2 - Warning: Informa que a requisição foi executada parcialmente.
        //
        //     3 - Error: Informa que ocorreu um erro na requisição.
        public AnswerType AnswerType { get; set; }

        //
        // Resumo:
        //     Dados da resposta.
        public T Answer { get; set; }

        //
        // Resumo:
        //     Listas de mensagems de avisos.
        public List<string> warningMessages { get; } = new List<string>();

    }
}
