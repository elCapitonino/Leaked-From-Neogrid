# %% - IMPORTS
import pandas as pd
import datetime as dt
import config

# %% - CONSTANTES
#NOTE é necessário apenas mudar o numero do price_groups e a data que foi feita a precificação, o resto será feito automaticamente
NUM_PRICE_GROUPS   = 7904 # numero do grupo de precificação de referencia
DATA_REFERENCIA = dt.datetime.fromisoformat("2023-11-29") # data da precificação de referencia

# %% Calculando variáveis dos dias de lookback e projeção
data_referencia_lookback = DATA_REFERENCIA - dt.timedelta(days=1) # data limite da projeção anterior
data_projetada = DATA_REFERENCIA + dt.timedelta(weeks=2) # data limite da projeção superior
data_lookback = DATA_REFERENCIA - dt.timedelta(weeks=2) # data limite do lookback

def formato_consulta(input_date):
    formatted_date = input_date.strftime("%Y-%m-%d")
    return formatted_date

# %% - Configuracoes de display para conferencia
pd.set_option('display.float_format', '{:.2f}'.format)
pd.set_option("display.max_rows", 30)
pd.set_option("display.max_columns", None)
pd.set_option('display.expand_frame_repr', False)

produtos_selecionados = DATA_REFERENCIA
b = data_projetada
periodo_projecao = (data_projetada - DATA_REFERENCIA).days

# %% - Puxando os dados do lookback
query_dados_lookback = f"""
Select Product, PbCost, ClientSalesPrice, Quantity, Category5,
    ROW_NUMBER() OVER (PARTITION BY Product ORDER BY Issuance DESC) as ordem
From Enterprise_Sales_History with (nolock)
Where idcompany=2941 and Affiliate=237
    and Issuance >= '{formato_consulta(data_lookback)}'
    and Issuance < '{formato_consulta(DATA_REFERENCIA)}'
"""

with config.getDadosAWSSession("producao") as conn:
    dados_lookback = pd.read_sql_query(query_dados_lookback, conn)

    last_price = dados_lookback[dados_lookback["ordem"] == 1].copy()
    last_price.drop(["Quantity", "ordem"], axis=1, inplace=True)
    last_price["Category5"] = pd.to_numeric(last_price["Category5"].str.replace(",", "."), errors='coerce')
    
    qtd = dados_lookback.groupby("Product", as_index=False).agg(
        q_antes_sum = pd.NamedAgg("Quantity", "sum"),
        q_antes_mean = pd.NamedAgg("Quantity", "mean")
    )
    dados_lookback = qtd.merge(last_price, on="Product", how="inner")
    dados_lookback.rename(columns={
        "PbCost": "custo_antes",
        "ClientSalesPrice": "p_antes",
        "Category5": "Preco_Adotado_antes"
    }, inplace=True)

del last_price, qtd
print(dados_lookback.head())

# %% coletando os dados de sugestão predify
query_dados_projecao_predify = f"""
With tb_base as (
    SELECT *
    FROM Enterprise_Prices_Projection
    WHERE IdEnterprisePriceGroups = {NUM_PRICE_GROUPS}
    AND IsDeletado = 0
),
tb_num as (
    SELECT PP.SalePrice as p_sem_regra_projecao, PP.SalePrice_Demand_CurveABC,
        CASE WHEN VO.IsManual IS NULL THEN PP.SalePrice
            WHEN VO.IsManual in (0, 1) THEN VO.Price
            END AS p_projecao,
        COALESCE(VO.Price_Demand, PP.SalePrice_Demand) AS d_projecao,
        PP.PbCost as custo_projecao,
        Product, Affiliate, Customer, IdElasticity,
        ProductName as Description
    FROM tb_base AS PP
    LEFT JOIN Enterprise_Values_Overrides AS VO
    ON VO.ProjectionsReference = PP.ProjectionsReference
),
tb_str as (
    select --DISTINCT
        Product, Affiliate, EconomicGroup, NBM,
        CASE WHEN ppwa.[Action] = 0 THEN 'Aprovado'
            WHEN ppwa.[Action] = 1 THEN 'Reprovado'
            ELSE 'Escalado' END AS Aproval
    FROM tb_base AS PP
    JOIN enterprisepriceprojection_workflow ppw
    ON ppw.identerprisepriceprojection = PP.IdEnterprisePricesProjection
    JOIN enterprisepriceprojection_workflowaction ppwa
    ON ppwa.idpriceprojection_workflow = ppw.IdEnterprisePriceProjection_Workflow
)
SELECT t2.*, t1.Customer, t1.Description, t1.SalePrice_Demand_CurveABC,
    t1.custo_projecao, t1.p_sem_regra_projecao, t1.p_projecao, t1.d_projecao,
    Case When t1.Customer = 0 Then 'ÓRFÃO'
        When t1.Customer = t1.Product Then 'PAI'
        Else 'FILHO' End as Category4,
    Case When ABS(t3.Elasticity) <= 1 THEN 'Inelástico'
        Else 'Elástico' END AS [Elasticidade]
FROM tb_num AS t1
JOIN tb_str AS t2
ON t1.Product = t2.Product AND t1.Affiliate = t2.Affiliate
LEFT JOIN enterprise_ElasticityNew as t3
ON t1.IdElasticity = t3.Identerprise_ElasticityNew
"""

with config.getDadosAWSSession("producao") as conn:
    dados_projecao_predify = pd.read_sql_query(query_dados_projecao_predify, conn)

print(dados_projecao_predify.head())

# %% Consultando preços posteriores a data de referencia
query_dados_posteriores = f"""
Select Product, PbCost, ClientSalesPrice, Quantity, Category5,
    ROW_NUMBER() OVER (PARTITION BY Product ORDER BY Issuance DESC) as ordem
From Enterprise_Sales_History with (nolock)
Where idcompany=2941 and Affiliate=237
    and Issuance >= '{formato_consulta(DATA_REFERENCIA)}'
    and Issuance <= '{formato_consulta(data_projetada)}'
"""

with config.getDadosAWSSession("producao") as conn:
    dados_posteriores = pd.read_sql_query(query_dados_posteriores, conn)
    
    last_price = dados_posteriores[dados_posteriores["ordem"] == 1].copy()
    last_price.drop(["Quantity", "ordem"], axis=1, inplace=True)
    last_price["Category5"] = pd.to_numeric(last_price["Category5"].str.replace(",", "."), errors='coerce')

    qtd = dados_posteriores.groupby("Product", as_index=False).agg(
        q_dps_sum = pd.NamedAgg("Quantity", "sum"),
        q_dps_mean = pd.NamedAgg("Quantity", "mean")
    )
    dados_posteriores = qtd.merge(last_price, on="Product", how="inner")
    dados_posteriores.rename(columns={
        "PbCost": "custo_dps",
        "ClientSalesPrice": "p_dps",
        "Category5": "Preco_Adotado_dps"
    }, inplace=True)

del last_price, qtd
print(dados_posteriores.head())

# %% - Unificando o Dataframe
dataframe_unificado = (
    dados_projecao_predify
    .merge(dados_lookback, on="Product", how="left")
    .merge(dados_posteriores, on="Product", how="left")
)

dataframe_unificado["Data da Precificação"] = DATA_REFERENCIA

dataframe_unificado["d_projecao_mes"] = dataframe_unificado["d_projecao"] * periodo_projecao

dataframe_unificado["q_antes_sum"] = dataframe_unificado["q_antes_sum"].fillna(0)
dataframe_unificado["q_antes_mean"] = dataframe_unificado["q_antes_mean"].fillna(0)
dataframe_unificado["q_dps_sum"] = dataframe_unificado["q_dps_sum"].fillna(0)
dataframe_unificado["q_dps_mean"] = dataframe_unificado["q_dps_mean"].fillna(0)
print(dataframe_unificado.head(10))

# %% - Filtro de produtos selecionados (útimos 30 dias)
data_produtos_selecionados_lookback = DATA_REFERENCIA - dt.timedelta(days=30)
data_produtos_selecionados_lookback = formato_consulta(data_produtos_selecionados_lookback)
query_produtos_selecionados = f"""
Select DISTINCT Product
from Enterprise_Sales_History WITH (NOLOCK)
WHERE idCompany=2941 and Issuance >= '{data_produtos_selecionados_lookback}'
and ISNULL(Category5, '') <> ''
"""

with config.getDadosAWSSession("producao") as conn:
    produtos = pd.read_sql_query(query_produtos_selecionados, conn)
    produtos['Product'] = produtos['Product'].astype(int)
    produtos_selecionados = produtos['Product'].tolist()

dataframe_unificado["Product"] = dataframe_unificado["Product"].astype(int)
filtro = dataframe_unificado[dataframe_unificado["Product"].isin(produtos_selecionados)].copy()
print(filtro.shape)

# %% Tratando datas para nomear as colunas automaticamente
def formato_xlsx(input_date):
    formatted_date = input_date.strftime("%d/%m")
    return formatted_date

DATA_REFERENCIA = formato_xlsx(DATA_REFERENCIA)
data_referencia_lookback = formato_xlsx(data_referencia_lookback)
data_lookback = formato_xlsx(data_lookback)
data_projetada = formato_xlsx(data_projetada)

# %% - Regras
dataframe_unificado = filtro
dataframe_unificado["ref.regra"] = abs(dataframe_unificado["p_projecao"] - dataframe_unificado["p_dps"]) / dataframe_unificado["p_dps"]
dataframe_unificado["ref.regra.2"] = abs(dataframe_unificado["p_projecao"] - dataframe_unificado["Preco_Adotado_dps"]) / dataframe_unificado["Preco_Adotado_dps"]
dataframe_unificado["Influência da IA"] = dataframe_unificado["ref.regra"] <= 0.01
dataframe_unificado["Influência da IA - 2"] = dataframe_unificado["ref.regra.2"] <= 0.01
dataframe_unificado = dataframe_unificado[[
    "Data da Precificação", "Affiliate", "EconomicGroup", "Product", "Description", "NBM", "Customer", "Category4",
    "custo_antes", "custo_projecao", "custo_dps", "p_antes", "p_projecao", #"Preco_Adotado_antes", "p_sem_regra_projecao", 
    "p_dps","Influência da IA", "ref.regra", "Aproval", # "Influência da IA - 2", "ref.regra.2", "Preco_Adotado_dps"
    "q_antes_sum", "d_projecao_mes", "q_dps_sum", "Elasticidade", #"q_antes_mean", "d_projecao", "q_dps_mean",
    "SalePrice_Demand_CurveABC", # "Freq_Venda"
]].copy()


dataframe_unificado.rename(columns={
    "Affiliate": "Filial",
    "Product": "Cod. Produto",
    "Description": "Descrição",
    "EconomicGroup": "Seção",
    "NBM": "EAN",
    "Customer": "Cod. Pai",
    "Category4": "Hierarquia",
    "custo_antes": "Custo Semana Anterior ("+data_lookback+" a "+data_referencia_lookback+")",
    "custo_projecao": "Custo na Projeção",
    "custo_dps": "Custo Semana Posterior ("+DATA_REFERENCIA+" a "+data_projetada+")",
    "p_antes": "Preço Aplicado Semana Anterior ("+data_lookback+" a "+data_referencia_lookback+")",
    # "Preco_Adotado_antes": "Preço Predify Adotado (Antes)",
    # "p_sem_regra_projecao": "Preço Sugerido (Sem Regra)",
    "p_projecao": "Preço Sugerido (IA com regra)",
    "p_dps": "Preço Aplicado Semana Posterior ("+DATA_REFERENCIA+" a "+data_projetada+")",
    # "Preco_Adotado_dps": "Preço Predify Adotado (Depois)",
    "Aproval": "Preço Aprovado?",
    "q_antes_sum": "Quantidade Vendida Semana Anterior ("+data_lookback+" a "+data_referencia_lookback+")",
    # "q_antes_mean": "Média de Itens por dia",
    # "d_projecao": "Demanda Projetada por Dia", #antes: "Demanda Projetada por Venda",
    "d_projecao_mes": "Quantidade Projetada",
    "q_dps_sum": "Quantidade Vendida Semana Posterior ("+DATA_REFERENCIA+" a "+data_projetada+")",
    # "q_dps_mean": "Média de Itens por dia (Depois)",
    # "Freq_Venda": "Prob. de Vender em um Dia",
    "SalePrice_Demand_CurveABC": "Curva ABC",
}, inplace=True)

print(dataframe_unificado.head(10))
print(dataframe_unificado.isna().sum())

# # %% - filtrando pelos produtos utilizados
# filtro = pd.read_excel("Results.xlsx")
# print("Filtro-Shape:", filtro.shape, "\t #-prods:", filtro["Product"].nunique())

# tudo = tudo[tudo['Cod. Produto'].isin(filtro["Product"].unique())]
# print("Tudo-Shape:", tudo.shape)

# aux = filtro[~filtro["Product"].isin(tudo["Cod. Produto"].unique())]
# print("\nProdutos selecionados mas nao precificados:\n",aux["Product"].unique())

# %% - to excel
DATA_REFERENCIA = DATA_REFERENCIA.replace('/', '_')
dataframe_unificado.to_excel("Relatorio-Peralta_"+DATA_REFERENCIA+".xlsx", index=False)