from norm.memorycache import MemoryCache
from norm.processing import Processing
from norm.extraction import Extraction
from unidecode import unidecode


class NormalizerExtraction:
    def __init__(self):
        self.memory = MemoryCache()
        self.prep = Processing()
        self.extr = Extraction()

    # def normalize_preprocessing(self, texto: str):

    #     processed_texto = self.prep.run(texto)
    #     return processed_texto

    def normalizer_extraction(self, texto, language):

        processed_texto = self.prep.run(texto, language)
        dic = {}

        # print(" 1", texto)
        # print(" 2", processed_texto)

        # print(self.memory.products)
        # print("language: ", language)
        #print("products_dicionario: ", self.memory.products[language])

        leftoverproduct, product = self.extr.normalize_products(
            processed_texto, self.memory.get_products(language))

        processed_texto = self.extr.normalize_leftover_unique(
            processed_texto, leftoverproduct)

        brands = self.extr.normalize_brands(
            processed_texto, self.memory.get_brands(language))

        processed_texto = self.extr.normalize_leftover_unique(
            processed_texto, brands)

        categories = self.extr.normalize_categories(
            product, self.memory.get_categories(language))

        leftovermaterials, materials = self.extr.normalize_materials(
            processed_texto, self.memory.get_materials(language))

        processed_texto = self.extr.normalize_leftover_unique(
            processed_texto, leftovermaterials)

        voltage_to_leftover, voltage = self.extr.normalize_voltage(
            processed_texto, self.memory.get_voltage(language))

        processed_texto = self.extr.normalize_leftover_unique(
            processed_texto, voltage_to_leftover)

        leftovermetric_units, metric_units = self.extr.normalize_metric_units(
            processed_texto, self.memory.get_metric_units(language))

        processed_texto = self.extr.normalize_leftover_unique(
            processed_texto, leftovermetric_units)

        leftover_power, power = self.extr.normalize_power(
            processed_texto, self.memory.get_power(language))

        processed_texto = self.extr.normalize_leftover_unique(
            processed_texto, leftover_power)

        leftover_d_dimensions, dimensions = self.extr.normalize_dimensions(
            processed_texto, self.memory.get_dimensions(language))

        processed_texto = self.extr.normalize_leftover_unique(
            processed_texto, leftover_d_dimensions)

        energy_source_leftover, energy_source = self.extr.normalize_energy_source(
            processed_texto, self.memory.get_energy_source(language))

        processed_texto = self.extr.normalize_leftover_unique(
            processed_texto, energy_source_leftover)

        # size_leftover, size = self.extr.normalize_size(
        #     processed_texto, self.memory.get_size(language))

        leftover = processed_texto.strip()
        if leftover == '':
            leftover = None
        # leftover = self.extr.normalize_leftover_unique(
        #     processed_texto, size_leftover)

        # leftover = self.extr.normalize_leftover(
        #     processed_texto, leftoverproduct, brands, leftovermaterials, voltage_to_leftover, leftovermetric_units, leftover_power,
        #     dimensions, energy_source_leftover, size_leftover).strip()

        # print("leftover : ", leftover)
        if leftover != None:
            # leftover = leftover.replace(",", "")
            # leftover = leftover.replace(".", "")
            leftover = leftover.replace(",", ".")
            leftover = leftover.strip()

        dic.update({'product': product, 'brands': brands, 'category': categories, 'materials': materials,
                    'voltage': voltage, 'metric_units': metric_units, 'power': power, 'dimensions': dimensions,
                    'energy_source': energy_source, 'size': None, 'language': language,  'trash': leftover})
        #print(" 1 ", dic)
        return dic

    def normalizer_extraction_brand_voltage(self, texto, language):

        processed_texto = self.prep.run(texto, language)
        dic = {}

        brands = self.extr.normalize_brands(
            processed_texto, self.memory.get_brands(language))

        voltage_to_leftover, voltage = self.extr.normalize_voltage(
            processed_texto, self.memory.get_voltage(language))

        dic.update({'brands': brands, 'voltage': voltage, 'language': language})
        #print(" 2 ", dic)
        return dic

    def normalizer_extraction_state(self, state, language):
        """_summary_

        Args:
            state (_type_): Estado do produto
            language (_type_): linguagem do estado

        Returns:
            _type_: retorna o estado normalizado
        """
        if state == None:
            return None
        processed_state = unidecode(state.lower())
        normalize_state = self.extr.normalize_state(
            processed_state, self.memory.get_state(language))

        return normalize_state

    def normalizer_extraction_hours(self, hours):
        """_summary_

        Args:
            hours (_type_): Horas de uso do produto

        Returns:
            _type_: retorna as horas normalizadas e validado 
        """
        if hours == None:
            return None
        normalize_hours = self.extr.normalize_hours(hours)
        return normalize_hours

    def normalizer_extraction_year(self, year):
        """_summary_

        Args:
            year (_type_): Ano de fabricação do produto

        Returns:
            _type_: retorna o ano normalizado e validado
        """
        if year == None:
            return None
        normalize_year = self.extr.normalize_year(year)

        return normalize_year

    def normalizer_extraction_category_dafiti(self, category, language):
        category = self.prep.run(category, language)
        category = self.extr.normalize_category_dafiti(category)
        return category

    def update_brand_pred_monitor(self, brand, dic_prod):
        # atualiza brand
        dic_brand = dic_prod.copy()

        brand = self.prep.run(brand)

        dic_brand.update({'brands': brand})

        #print("dic01: ", dic01)

        return dic_brand

    def update_category_pred_monitor(self, category, dic_prod):
        # atualiza categoria
        dic_category = dic_prod.copy()

        dic_category.update({'category': category})

        #print("dic01: ", dic01)

        return dic_category

    def update_category_unique_pred_monitor(self, category, language):

        dict_cat = {}
        dict_cat.update({'product': None, 'brands': None, 'category': category, 'materials': None,
                         'voltage': None, 'metric_units': None, 'power': None, 'dimensions': None,
                         'energy_source': None, 'size': None, 'language': language,  'trash': None})

        return dict_cat
