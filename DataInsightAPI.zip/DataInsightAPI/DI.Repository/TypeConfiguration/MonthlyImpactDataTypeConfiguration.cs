﻿using DI.Repository.Attributes;
using DI.Repository.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DI.Repository.TypeConfiguration
{
    [UsePostgreContext]
    public sealed class MonthlyImpactDataTypeConfiguration : TypeConfigurationBase<MonthlyImpactDataEntity>, IEntityTypeConfiguration<MonthlyImpactDataEntity>
    {
        public override void Configure(EntityTypeBuilder<MonthlyImpactDataEntity> builder)
        {
            ConfigureTableName(builder, "MonthlyImpactData");

            builder.HasKey(x => x.Id);
            builder.Property(x => x.Id).ValueGeneratedOnAdd().HasDefaultValueSql("uuid_generate_v4()").IsRequired();

            builder.Property(x => x.CompanyId).IsRequired();
            builder.Property(x => x.ProductId).HasMaxLength(255).IsRequired();
            builder.Property(x => x.YearMonth).IsRequired();

            builder.Property(x => x.AdoptionCount).IsRequired();
            builder.Property(x => x.NotAdoptionCount).IsRequired();
            builder.Property(x => x.PricingCount).IsRequired();

            builder.Property(x => x.PriorDemand).HasColumnType("decimal(18,2)").IsRequired();
            builder.Property(x => x.ProjectionDemand).HasColumnType("decimal(18,2)").IsRequired();
            builder.Property(x => x.RealDemand).HasColumnType("decimal(18,2)").IsRequired();

            builder.Property(x => x.PriorCost).HasColumnType("decimal(18,2)").IsRequired();
            builder.Property(x => x.ProjectionCost).HasColumnType("decimal(18,2)").IsRequired();
            builder.Property(x => x.RealCost).HasColumnType("decimal(18,2)").IsRequired();

            builder.Property(x => x.PriorRevenue).HasColumnType("decimal(18,2)").IsRequired();
            builder.Property(x => x.ProjectionRevenue).HasColumnType("decimal(18,2)").IsRequired();
            builder.Property(x => x.RealRevenue).HasColumnType("decimal(18,2)").IsRequired();

            builder.Property(x => x.PriorProfit).HasColumnType("decimal(18,2)").IsRequired();
            builder.Property(x => x.ProjectionProfit).HasColumnType("decimal(18,2)").IsRequired();
            builder.Property(x => x.RealProfit).HasColumnType("decimal(18,2)").IsRequired();

            builder.Property(x => x.PriorRoyalty).HasColumnType("decimal(18,2)").IsRequired();
            builder.Property(x => x.ProjectionRoyalty).HasColumnType("decimal(18,2)").IsRequired();
            builder.Property(x => x.RealRoyalty).HasColumnType("decimal(18,2)").IsRequired();

            builder.Property(x => x.ConsolidadeGroupBy).HasMaxLength(255).IsRequired();
            builder.Property(x => x.MajorGranularity).HasMaxLength(255).IsRequired();

            builder.HasIndex(x => new { x.CompanyId, x.YearMonth });
            builder.HasIndex(x => new { x.CompanyId, x.ProductId });
        }
    }
}
