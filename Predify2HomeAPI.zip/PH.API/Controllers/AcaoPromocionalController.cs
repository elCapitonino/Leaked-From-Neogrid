﻿using ClosedXML.Excel;
using k8s.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Net.Http.Headers;
using Newtonsoft.Json;
using PH.Domain.Domain;
using PH.Domain.Interfaces.Services;
using PU.Service.Services;
using Serilog;
using System.Net;

namespace PH.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AcaoPromocionalController : ControllerBase
    {
        private readonly ILogger<AcaoPromocionalController> _logger;
        private readonly IAcaoPromocionalServices _acaoPromocionalServices;

        public AcaoPromocionalController(ILogger<AcaoPromocionalController> logger,
                                 IAcaoPromocionalServices AcaoPromocionalServices)
        {
            _logger = logger;
            _acaoPromocionalServices = AcaoPromocionalServices;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll(long idCompany)
        {
            var accessToken = Request.Headers[HeaderNames.Authorization];
            _logger.LogInformation("Controller: Buscando todos os AcaoPromocionals");

            try
            {
                var AcaoPromocionals = await _acaoPromocionalServices.GetAll(idCompany);
                return Ok(AcaoPromocionals);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Controller: Erro ao buscar todos os AcaoPromocionals. {ex.Message}");
                return StatusCode(500, "Erro ao buscar todos os AcaoPromocionals");
            }
        }


        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(string id)
        {
            _logger.LogInformation($"Controller: Buscando AcaoPromocional por id {id}");

            try
            {
                var AcaoPromocional = await _acaoPromocionalServices.GetById(id);
                return Ok(AcaoPromocional);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Controller: Erro ao buscar AcaoPromocional por id. {ex.Message}");
                return StatusCode(500, "Erro ao buscar AcaoPromocional por id");
            }
        }

        [HttpPost]
        public async Task<IActionResult> Insert(AcaoPromocional acaoPromocional)
        {
            _logger.LogInformation($"Controller: Inserindo AcaoPromocional {JsonConvert.SerializeObject(acaoPromocional)}");

            try
            {
                await _acaoPromocionalServices.Add(acaoPromocional);
                return StatusCode(201);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Controller: Erro ao inserir AcaoPromocional. {ex.Message}");
                return StatusCode(500, "Erro ao inserir AcaoPromocional");
            }
        }

        [HttpPut("{acaoPromocionalId}")]
        public async Task<IActionResult> Update(string acaoPromocionalId, AcaoPromocional acaoPromocional)
        {
            _logger.LogInformation($"Controller: Atualizando AcaoPromocional {JsonConvert.SerializeObject(acaoPromocional)}");

            try
            {
                await _acaoPromocionalServices.Update(acaoPromocionalId, acaoPromocional);
                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Controller: Erro ao atualizar AcaoPromocional. {ex.Message}");
                return StatusCode(500, "Erro ao atualizar AcaoPromocional");
            }
        }

        [HttpDelete("{acaoPromocionalId}")]
        public async Task<IActionResult> Delete(string acaoPromocionalId)
        {
            _logger.LogInformation($"Controller: Removendo AcaoPromocional {acaoPromocionalId}");

            try
            {
                await _acaoPromocionalServices.Remove(acaoPromocionalId);
                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Controller: Erro ao remover AcaoPromocional {acaoPromocionalId}. {ex.Message}");
                return StatusCode(500, "Erro ao remover AcaoPromocional");
            }
        }

        [HttpGet("Relatorio")]
        public async Task<IActionResult> DownloadRelatorioFile(long idCompany)
        {
            try
            {
                var relatorio = await _acaoPromocionalServices.GetAll(idCompany);

                relatorio.NextActions = relatorio.NextActions?.OrderBy(c => c.InitialDate).ToList();
                relatorio.CurrentActions = relatorio.CurrentActions?.OrderBy(c => c.InitialDate).ToList();
                string fullPath = ExcelService.GetFileName();

                using var workbook = new XLWorkbook();

                if (!relatorio.CurrentActions.Any() && !relatorio.NextActions.Any())
                {
                    IXLWorksheet worksheet = ExcelService.CriandoCabecalhoExcel(workbook);
                }

                foreach (var acao in relatorio.CurrentActions)
                {
                    IXLWorksheet worksheet = ExcelService.CriandoCabecalhoExcel(workbook);
                    ExcelService.FillingExcel(acao.Products, worksheet);
                }

                foreach (var acao in relatorio.NextActions)
                {
                    IXLWorksheet worksheet = ExcelService.CriandoCabecalhoExcel(workbook);
                    ExcelService.FillingExcel(acao.Products, worksheet);
                }

                workbook.SaveAs(fullPath);

                byte[] fileByteArray = System.IO.File.ReadAllBytes(fullPath);
                System.IO.File.Delete(fullPath);

                return File(fileByteArray, "application/vnd.ms-excel", ExcelService.FILE_NAME);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Erro ao gerar relatório: {ex.Message}");
                throw;
            }
        }

        [HttpPost("Import")]
        [DisableRequestSizeLimit]
        [RequestFormLimits(MultipartBodyLengthLimit = int.MaxValue, ValueLengthLimit = int.MaxValue)]
        public async Task<IActionResult> FileImport(IFormFile file, long idCompany)
        {
            _logger.LogInformation("Iniciando import de arquivo");

            try
            {
                var result = await _acaoPromocionalServices.ImportAcao(file, idCompany);

                if (!result.Success)
                {
                    return StatusCode(500, new { message = result.Errors });
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Erro ao importar arquivo. Erro {ex.Message}");
                return StatusCode(500, "Erro ao importar arquivo");
            }

            return StatusCode(201, "Sucesso ao salvar arquivo no banco");
        }
    }
}
