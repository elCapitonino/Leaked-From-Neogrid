﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver.GeoJsonObjectModel;

namespace Repository.Entity
{
    public class IndiretaEntity : BaseMongoEntity
    {
        [BsonElement("ANO MES MOVIMENTO")]
        public int? YearMonthMovement { get; set; }

        [BsonElement("CNPJ DISTRIBUIDOR")]
        public string? DistributorCnpj { get; set; }

        [BsonElement("NOME DISTRIBUIDOR")]
        public string? DistributorName { get; set; }

        [BsonElement("ULTIMA VENDA")]
        public DateTime? LastSale { get; set; }

        [BsonElement("SETOR")]
        public string? Sector { get; set; }

        [BsonElement("DESCRICAOO PRODUTO")]
        public string? ProductDescription { get; set; }

        [BsonElement("EAN PRODUTO")]
        public string? ProductEan { get; set; }

        [BsonElement("VALOR VENDA")]
        public decimal? SaleValue { get; set; }

        [BsonElement("PRECO MEDIO")]
        public decimal? AveragePrice { get; set; }

        [BsonElement("QTD VENDA")]
        public int? SaleQuantity { get; set; }

        [BsonElement("CEP")]
        public string? PostalCode { get; set; }

        [BsonElement("ENDERECO")]
        public string? Address { get; set; }

        [BsonElement("BAIRRO")]
        public string? Neighborhood { get; set; }

        [BsonElement("CIDADE")]
        public string? City { get; set; }

        [BsonElement("UF")]
        public string? State { get; set; }

        [BsonElement("CUSTO ITEM")]
        public decimal? ItemCost { get; set; }

        [BsonElement("UF2")]
        public string? State2 { get; set; }

        [BsonElement("id_import")]
        public string? ImportId { get; set; }

        [BsonElement("HASH")]
        public string? Hash { get; set; }
        [BsonElement("coordinates")]
        public GeoJson2DGeographicCoordinatesWrapper? Coordinates { get; set; }
    }

}
