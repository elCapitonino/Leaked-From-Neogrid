﻿using Microsoft.Extensions.Configuration;
using PH.Domain.Interfaces.Repositories;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using PH.Domain.DTO;
using System.Globalization;

namespace PH.Data.Repositories
{
    public class GraficoMargemMediaRepository : IGraficoMargemMediaRepository
    {
        private string _sQLConnectionString;
        private readonly IConfiguration _configuration;
        private IDbConnection CreateSqlConnection() => new SqlConnection(_sQLConnectionString);

        public GraficoMargemMediaRepository(IConfiguration configuration)
        {
            _configuration = configuration;
            _sQLConnectionString = _configuration.GetConnectionString("SQLConnectionString");
        }

        public async Task<List<GraficoMargemMediaDTO>> GetGraficoMargem(string loja)
        {
            try
            {
                IDbConnection connection = CreateSqlConnection();
                var parametros = new { Filial = loja };
                var result = connection.Query<GraficoMargemMedia>("VEM_Busca_Grafico_Margem_Media_Semanal", parametros, commandType: CommandType.StoredProcedure, commandTimeout: 600);

                List<GraficoMargemMediaDTO> listResult = new List<GraficoMargemMediaDTO>();

                foreach (var item in result)
                {
                    DateTime jan1 = new DateTime(item.Year, 1, 1);
                    DateTime firstDayWeek = jan1.AddDays((item.Week - 1) * 7 - (int)jan1.DayOfWeek + (int)CultureInfo.CurrentCulture.DateTimeFormat.FirstDayOfWeek);
                    DateTime ultimaDataSemana20 = firstDayWeek.AddDays(6);

                    listResult.Add(new GraficoMargemMediaDTO()
                    { 
                        Date = ultimaDataSemana20,
                        Description = item.Description,
                        Category = item.Category,
                        SubCategory = item.SubCategory,
                        Margin = item.Margin * 100,
                    });
                }

                return listResult;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
