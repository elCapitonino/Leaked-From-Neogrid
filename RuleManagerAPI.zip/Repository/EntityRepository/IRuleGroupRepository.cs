﻿using Repository.Entity;

namespace Repository.EntityRepository
{
    public interface IRuleGroupRepository : IGenericRepository<DinPreRuleEntity>
    {
    }
}
