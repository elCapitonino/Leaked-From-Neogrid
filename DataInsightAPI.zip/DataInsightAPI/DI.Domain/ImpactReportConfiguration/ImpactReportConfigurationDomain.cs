﻿using DI.Domain.Models.ImpactReportConfiguration;
using DI.Repository.Interfaces;

namespace DI.Domain.ImpactReportConfiguration
{
    public class ImpactReportConfigurationDomain : IImpactReportConfigurationDomain
    {
        private readonly IUnitOfWork _uow;

        public ImpactReportConfigurationDomain(IUnitOfWork uow)
        {
            _uow = uow;
        }
        public IEnumerable<ImpactReportConfigurationModel> GetImpactReportConfig()
        {
            return _uow.ImpactReportConfigurationRepository.GetAll()
                .GroupBy(entity => entity.CompanyId)
                .Select(group => group.First())
                .Select(entity => new ImpactReportConfigurationModel
                {
                    CompanyId = entity.CompanyId,
                    ConsolidateReportRoyalty = entity.ConsolidateReportRoyalty,
                    HasRawReportRoyalty = entity.HasRawReportRoyalty,
                    ConsolidateFieldGroupBy = entity.ConsolidateFieldGroupBy,
                    RawCategoryField = entity.RawCategoryField,
                    RawSubCategoryField = entity.RawSubCategoryField,
                    PriceVariableToCalc = entity.PriceVariableToCalc,
                    Goal = entity.Goal,
                    Royalty = entity.Royalty
                })
                .ToList();
        }
    }
}
