import logging
import os
from logging import handlers

os.makedirs("./logs/", exist_ok=True)

# Create a logger object
logger = logging.getLogger("pricing_processor")
logger.setLevel(logging.DEBUG if os.environ.get("DEBUG") else logging.INFO)

# Create a console handler
console_handler = logging.StreamHandler()
file_handler = handlers.TimedRotatingFileHandler(
    "logs/data_processor.log", encoding="utf-8", when="h", interval=24
)

# Create a formatter and add it to the console handler
formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
console_handler.setFormatter(formatter)
file_handler.setFormatter(formatter)

logger.addHandler(console_handler)
logger.addHandler(file_handler)
