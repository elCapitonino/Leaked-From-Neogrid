﻿using MongoDB.Bson;

namespace UpdateHash.Models
{
    public class InfoPriceProducts
    {
        public ObjectId _id { get; set; }
        public DateTime? data_preco { get; set; }
        public string origem_preco { get; set; }
        public string uf { get; set; }
        public string regiao { get; set; }
        public string cidade { get; set; }
        public string rede { get; set; }
        public string tipo_loja { get; set; }
        public string loja { get; set; }
        public string cnpj { get; set; }
        public string cep { get; set; }
        public string logradouro { get; set; }
        public string numero_logradouro { get; set; }
        public string complemento { get; set; }
        public string bairro { get; set; }
        public string categoria { get; set; }
        public string secao { get; set; }
        public string descricao { get; set; }
        public int? conteudo_qtd { get; set; }
        public string conteudo_unidade { get; set; }
        public string conteudo_descricao { get; set; }
        public string conteudo_qtd_padronizada { get; set; }
        public string conteudo_unidade_padronizada { get; set; }
        public string gtin { get; set; }
        public string id_produto { get; set; }
        public string id_loja { get; set; }
        public string tipo_produto { get; set; }
        public string tipo_promocao { get; set; }
        public bool? flag_promocao { get; set; }
        public double? latitude { get; set; }
        public double? longitude { get; set; }
        public string fabricante { get; set; }
        public string cnpj_fabricante { get; set; }
        public bool? marca_propria { get; set; }
        public double? preco_pago { get; set; }
        public double? preco_regular { get; set; }
        public double? preco_unidade_padrao { get; set; }
        public double? valor_promocao { get; set; }
        public string gtin_formated { get; set; }
    }
}
