﻿using Microsoft.EntityFrameworkCore;
using MongoDB.Driver;
using Repository.DbContexts.Bases;

namespace Repository.DbContexts
{
    public class InfoPriceSaoJoaoDbContext : MongoDbContextBase
    {
        public InfoPriceSaoJoaoDbContext(DbContextOptions<InfoPriceSaoJoaoDbContext> options, IMongoClient mongoClient) : base(options, mongoClient)
        {

        }
        public override string DbContextName => nameof(InfoPriceSaoJoaoDbContext);
    }
}
