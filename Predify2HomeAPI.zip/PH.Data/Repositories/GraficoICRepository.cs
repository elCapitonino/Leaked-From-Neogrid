﻿using Microsoft.Extensions.Configuration;
using PH.Domain.DTO.Graficos;
using PH.Domain.DTO;
using PH.Domain.Interfaces.Repositories;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using System.Data.SqlClient;
using MongoDB.Driver;
using PH.Domain.Domain;
using Microsoft.Extensions.Options;
using PH.Domain.Settings;

namespace PH.Data.Repositories
{
    public class GraficoICRepository : IGraficoICRepository
    {
        private string _sQLConnectionString;
        private readonly IConfiguration _configuration;
        private readonly IMongoCollection<IntervaloMargem> _collectionMargin;
        private readonly IMongoCollection<VEMCoordinatorState> _collectionStateCoodinator;
        private static string COLLECTION_NAME_MARGIN = "IntervaloMargem";
        private static string COLLECTION_NAME_STATECOORDINATOR = "VEMCoordinatorState";
        private IDbConnection CreateSqlConnection() => new SqlConnection(_sQLConnectionString);

        public GraficoICRepository(IConfiguration configuration, IOptions<MongoSettings> mongoSettings)
        {
            _configuration = configuration;
            _sQLConnectionString = _configuration.GetConnectionString("SQLConnectionString");
            var mongoClient = new MongoClient(mongoSettings.Value.ConnectionString);
            var mongoDatabase = mongoClient.GetDatabase(mongoSettings.Value.DatabaseName);
            _collectionMargin = mongoDatabase.GetCollection<IntervaloMargem>(COLLECTION_NAME_MARGIN);
            _collectionStateCoodinator = mongoDatabase.GetCollection<VEMCoordinatorState>(COLLECTION_NAME_STATECOORDINATOR);
        }

        public async Task<FiltroCategoriaGraficoICDTO> GetAllFilterCategories()
        {
            FiltroCategoriaGraficoICDTO filtroCategorias = new FiltroCategoriaGraficoICDTO();
            try
            {
                IDbConnection connection = CreateSqlConnection();
                var result = connection.Query<FiltroCategoriaGraficoIC>("VEM_Busca_Filtro_Grafico_IC", commandType: CommandType.StoredProcedure, commandTimeout: 600);

                List<string> listResult = new List<string>();

                foreach (var item in result)
                {
                    listResult.Add(item.Categories.ToUpper());
                }

                filtroCategorias.Categories = listResult;

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return filtroCategorias;
        }

        public async Task<List<GraficoICDTO>> GetGraficoIC(string category, string compType, string? state, string period, string? coordinator)
        {
            List<GraficoICDTO> graficoDTO = new List<GraficoICDTO>();

            try
            {
                string ListState = null;

                if (string.IsNullOrEmpty(coordinator))
                    ListState = state;
                else
                {
                    var states = await GetStateByCoordinator(coordinator);

                    ListState = String.Join(",", states.Select(x => x.State));
                }

                category = category.ToUpper();
                compType = compType.ToUpper();
                period = period.ToUpper();

                if (period == "SEMANAL")
                {
                    IDbConnection connection = CreateSqlConnection();
                    var parametros = new { Category = category, CompType = compType, States = ListState };
                    var result = connection.Query<GraficoIC>("VEM_Busca_Dados_Grafico_IC", parametros, commandType: CommandType.StoredProcedure, commandTimeout: 60000);

                    graficoDTO.AddRange(result.Select(x => new GraficoICDTO()
                    {
                        Date = x.Date,
                        IC = x.IC * 100
                    }));
                }
                else
                {
                    IDbConnection connection = CreateSqlConnection();
                    var parametros = new { Category = category, CompType = compType, States = ListState };
                    var result = connection.Query<GraficoIC>("VEM_Busca_Dados_Mensal_Grafico_IC", parametros, commandType: CommandType.StoredProcedure, commandTimeout: 60000);

                    graficoDTO.AddRange(result.Select(x => new GraficoICDTO()
                    {
                        Date = x.Date,
                        IC = x.IC * 100
                    }));
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return graficoDTO.OrderBy(x => x.Date).ToList();
        }

        public async Task<EstadoGraficoICDTO> GetStateByIdGroup(long idPriceGroup)
        {
            try
            {
                IDbConnection connection = CreateSqlConnection();
                var parametros = new { IDPRICEGROUP = idPriceGroup };
                var result = connection.Query<EstadoGraficoIC>("VEM_Busca_Estado_Grafico_IC", parametros, commandType: CommandType.StoredProcedure, commandTimeout: 60000);

                var response = new EstadoGraficoICDTO()
                {
                    Estado = result.Select(x => x.Estado).FirstOrDefault()
                };

                return response;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<IntervaloMargemDTO>> GetMarginByIdCompany(long idCompany)
        {
            var margens = await _collectionMargin.FindAsync(c => c.IdCompany == idCompany);

            var result = margens.ToList();         
                
            List<IntervaloMargemDTO> listMargens = new List<IntervaloMargemDTO>();

            listMargens.AddRange(result.Select(x => new IntervaloMargemDTO()
            {
                ValueType = x.ValueType,
                Max = x.Max,
                Min = x.Min,
            }));

            return listMargens;
        }

        public async Task<List<VEMCoordinatorState>> GetStateByCoordinator(string Coordinator)
        {
            var result = await _collectionStateCoodinator.FindAsync(c => c.Coordinator == Coordinator);

            return result.ToList();
        }
    }
}
