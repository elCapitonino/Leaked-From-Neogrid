﻿using PH.Domain.DTO;

namespace PH.Domain.Interfaces.Services
{
    public interface IPredifyAPIService
    {
        Task<ApiPredifyFilterResponse> GetFilters(string token);
    }
}
