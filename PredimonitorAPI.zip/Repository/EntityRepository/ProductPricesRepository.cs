﻿using Repository.DbContexts;
using Repository.Entity;
using Repository.EntityRepository.Bases;

namespace Repository.EntityRepository
{
    public class ProductPricesRepository : GenericMongoRepository<ProductPricesEntity>,IProductPricesRepository
    {
        public ProductPricesRepository(NormalizerDbContext dbContext) : base(dbContext)
        {
        }
        public static string DbContextName => nameof(NormalizerDbContext);
    }
}
