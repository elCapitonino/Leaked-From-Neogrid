from predimonitor_type import *
from async_mongo import AsyncMongoConnect
import re

class Search_mercantil_nova_era():

    def __init__(self):
        self.dbMongo = AsyncMongoConnect()

    def search_get(self, id_crawlers_offline, data_source, products, start_date, end_date):

        result_list = []

        return result_list

    async def search_get_V1_mercantil_nova_era(self, products):
        full_result = []
        result_list = []

        ean = None
        start_date = products.start_date
        end_date = products.end_date
        if products is None or products.products[0].ean is None or not products.products[0].ean:
            return []

        ean = products.products[0].ean
        result_mercantil_nova_era = await self.dbMongo.get_product_search_v1_nova_era(start_date, end_date, ean)

        for documento in result_mercantil_nova_era:
            try:
                item = documento["documento"]
                name = item['DESC_PRODC']
                result_list.append({'id': str(item['_id']),
                                    'id_crawler': 283,
                                    "product_name": name,
                                    "product_link": item['EAN']+item['CONCORRENTE']+item['DESC_PRODC'],
                                    "product_ean": item['EAN'],
                                    "site_sku": 0,
                                    "source": "Mercantil Nova Era",
                                    "language": "pt-br",
                                    "product_brand": None,
                                    "id_product_normalized": None,
                                    "trash_score": 0,
                                    "crawler_date": item["DATA_PESQ"],
                                    "sellers": [
                                        {
                                            "seller_name": item["CONCORRENTE"],
                                            "prices":[
                                                {
                                                    'price': str(item['PRECO_C']),
                                                    "price_currency": "BRL"
                                                }
                                            ]
                                        }],
                                    "product_manufacture_year": None,
                                    "product_used_hours": None
                })

            except Exception as ex:
                print(" ------ Erro dados Mercantil Nova Era  ------")
                print(str(ex))
            
        full_result.append({
            "name": products.products[0].name,
            "results": result_list
        })

        return full_result

    async def search_get_V2_mercantil_nova_era(self, products):
        ean_where = []
        start_date = ""
        end_date = ""
        full_result = []
        lista_result = []
        result_list = []

        if (products.filters.eans != None and len(products.filters.eans) != 0):
            filtered_eans = []
            if (len(products.filters.products) > 0):
                for ean_obj in products.filters.eans:
                    if ean_obj.description is not None:
                        for product in products.filters.products:
                            if re.match(ean_obj.description, product):
                                filtered_eans.append(ean_obj.ean)
                ean_where.extend(filtered_eans)

        if (products.start_date is not None and products.end_date is not None):
            start_date = products.start_date
            end_date = products.end_date

        if (ean_where is not None and ean_where and start_date != "" and end_date != ""):
            try:
                for ean in ean_where:
                    result_list = []
                    result_ean = await self.dbMongo.get_product_search_v2_nova_era(start_date, end_date, ean)

                    for documento in result_ean:
                        try:
                            item = documento
                            name = item['DESC_PRODC']
                            result_list.append({'id': str(item['_id']),
                                                'id_crawler': 283,
                                                "product_name": name,
                                                "product_link": item['EAN']+item['CONCORRENTE']+item['DESC_PRODC'],
                                                "product_ean": item['EAN'],
                                                "site_sku": 0,
                                                "source": "Mercantil Nova Era",
                                                "language": "pt-br",
                                                "product_brand": None,
                                                "id_product_normalized": None,
                                                "trash_score": 0,
                                                "crawler_date": item["DATA_PESQ"],
                                                "seller_name": item["CONCORRENTE"],
                                                "prices": [{'price': str(item['PRECO_C'])}],
                                                "product_manufacture_year": None,
                                                "product_used_hours": None
                                                })
                        except Exception as ex:
                            print(" ------ Erro dados Mercantil Nova Era inserir item", str(ex))

                    full_result.append({
                        "product": ean,
                        "result": result_list
                    })

            except Exception as ex:
                print(" ------ Erro dados Mercantil Nova Era coleta mongo", str(ex))

        print(" ------ Fim dados Mercantil Nova Era  ------")
        return full_result
