﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DI.Repository.Migrations.PostgreMigrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "GranularityGroup",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false, defaultValueSql: "uuid_generate_v4()"),
                    IdCompany = table.Column<long>(type: "bigint", nullable: false),
                    GranularityType = table.Column<int>(type: "integer", nullable: false),
                    Description = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UpdatedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_GranularityGroup", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ImpactReportConfiguration",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false, defaultValueSql: "uuid_generate_v4()"),
                    ConcolidateGroupField = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    ConsolidateReportRoyalty = table.Column<bool>(type: "boolean", nullable: false),
                    GrossReportRoyalty = table.Column<bool>(type: "boolean", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UpdatedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ImpactReportConfiguration", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "GranularityLevel",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false, defaultValueSql: "uuid_generate_v4()"),
                    GranularityGroupId = table.Column<Guid>(type: "uuid", nullable: false),
                    ParentId = table.Column<Guid>(type: "uuid", nullable: false),
                    Description = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    FieldKey = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    FieldValue = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UpdatedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_GranularityLevel", x => x.Id);
                    table.ForeignKey(
                        name: "FK_GranularityLevel_GranularityGroup_GranularityGroupId",
                        column: x => x.GranularityGroupId,
                        principalTable: "GranularityGroup",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "MonthlySaleHistoryData",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false, defaultValueSql: "uuid_generate_v4()"),
                    CompanyId = table.Column<long>(type: "bigint", nullable: false),
                    GranularityGroupId = table.Column<Guid>(type: "uuid", nullable: false),
                    ProductId = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    YearMonth = table.Column<int>(type: "integer", nullable: false),
                    Revenue = table.Column<decimal>(type: "numeric", nullable: false),
                    AverageDemand = table.Column<decimal>(type: "numeric", nullable: false),
                    TotalQuantity = table.Column<decimal>(type: "numeric", nullable: false),
                    AveragePrice = table.Column<decimal>(type: "numeric", nullable: false),
                    AverageCost = table.Column<decimal>(type: "numeric", nullable: false),
                    AverageMargin = table.Column<decimal>(type: "numeric", nullable: false),
                    FirstSale = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    LastSale = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UpdatedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MonthlySaleHistoryData", x => x.Id);
                    table.ForeignKey(
                        name: "FK_MonthlySaleHistoryData_GranularityGroup_GranularityGroupId",
                        column: x => x.GranularityGroupId,
                        principalTable: "GranularityGroup",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ProjectionImpactData",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false, defaultValueSql: "uuid_generate_v4()"),
                    PriceGroupId = table.Column<long>(type: "bigint", nullable: false),
                    PriceProjectionId = table.Column<long>(type: "bigint", nullable: false),
                    GranularityGroupId = table.Column<Guid>(type: "uuid", nullable: false),
                    ProductId = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    PriorCost = table.Column<decimal>(type: "numeric", nullable: false),
                    ProjectionCost = table.Column<decimal>(type: "numeric", nullable: false),
                    RealCost = table.Column<decimal>(type: "numeric", nullable: false),
                    PriorPrice = table.Column<decimal>(type: "numeric", nullable: false),
                    ProjectionPrice = table.Column<decimal>(type: "numeric", nullable: false),
                    RealPrice = table.Column<decimal>(type: "numeric", nullable: false),
                    PriorDemand = table.Column<decimal>(type: "numeric", nullable: false),
                    ProjectionDemand = table.Column<decimal>(type: "numeric", nullable: false),
                    RealDemand = table.Column<decimal>(type: "numeric", nullable: false),
                    PriorRevenue = table.Column<decimal>(type: "numeric", nullable: false),
                    ProjectionRevenue = table.Column<decimal>(type: "numeric", nullable: false),
                    RealRevenue = table.Column<decimal>(type: "numeric", nullable: false),
                    PriorProfit = table.Column<decimal>(type: "numeric", nullable: false),
                    ProjectionProfit = table.Column<decimal>(type: "numeric", nullable: false),
                    RealProfit = table.Column<decimal>(type: "numeric", nullable: false),
                    PriorMargin = table.Column<decimal>(type: "numeric", nullable: false),
                    ProjectionMargin = table.Column<decimal>(type: "numeric", nullable: false),
                    RealMargin = table.Column<decimal>(type: "numeric", nullable: false),
                    Adopted = table.Column<bool>(type: "boolean", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UpdatedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProjectionImpactData", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ProjectionImpactData_GranularityGroup_GranularityGroupId",
                        column: x => x.GranularityGroupId,
                        principalTable: "GranularityGroup",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_GranularityLevel_GranularityGroupId",
                table: "GranularityLevel",
                column: "GranularityGroupId");

            migrationBuilder.CreateIndex(
                name: "IX_MonthlySaleHistoryData_GranularityGroupId",
                table: "MonthlySaleHistoryData",
                column: "GranularityGroupId");

            migrationBuilder.CreateIndex(
                name: "IX_ProjectionImpactData_GranularityGroupId",
                table: "ProjectionImpactData",
                column: "GranularityGroupId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "GranularityLevel");

            migrationBuilder.DropTable(
                name: "ImpactReportConfiguration");

            migrationBuilder.DropTable(
                name: "MonthlySaleHistoryData");

            migrationBuilder.DropTable(
                name: "ProjectionImpactData");

            migrationBuilder.DropTable(
                name: "GranularityGroup");
        }
    }
}
