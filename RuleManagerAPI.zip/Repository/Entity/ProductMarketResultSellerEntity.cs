﻿namespace Repository.Entity
{
    public sealed class ProductMarketResultSellerEntity : BaseEntity
    {
        public long ProductMarketResultSellerId { get; set; }
        public long CompanyId { get; set; }
        public required string SellerName { get; set; }
        public bool IsDeleted { get; set; }
    }
}
