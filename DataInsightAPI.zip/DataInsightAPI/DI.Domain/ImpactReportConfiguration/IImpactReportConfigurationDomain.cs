﻿using DI.Domain.Models.ImpactReportConfiguration;


namespace DI.Domain.ImpactReportConfiguration
{
    public interface IImpactReportConfigurationDomain
    {
        IEnumerable<ImpactReportConfigurationModel> GetImpactReportConfig();
    }
}
