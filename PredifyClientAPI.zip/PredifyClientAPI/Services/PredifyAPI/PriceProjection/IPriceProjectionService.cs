﻿using PredifyClientAPI.Services.PredifyAPI.Models;
using PredifyClientAPI.Services.PredifyAPI.PriceProjection.Models;

namespace PredifyClientAPI.Services.PredifyAPI.PriceProjection
{
    public interface IPriceProjectionService
    {
        Task<GeneralResponse<List<EnterprisePriceProjectionExportResponse>>> ProjectionToSendERP(long idEnterprisePriceGroup);
    }
}
