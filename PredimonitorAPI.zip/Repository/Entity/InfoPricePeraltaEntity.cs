﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace Repository.Entity
{
    public class InfoPricePeraltaEntity : BaseMongoEntity
    {
        [BsonElement("data_do_preco")]
        public DateTime? DataPreco { get; set; }

        [BsonElement("regiao")]
        public string? Regiao { get; set; }

        [BsonElement("uf")]
        public string? UF { get; set; }

        [BsonElement("cidade")]
        public string? Cidade { get; set; }

        [BsonElement("bairro")]
        public string? Bairro { get; set; }

        [BsonElement("logradouro")]
        public string? Logradouro { get; set; }

        [BsonElement("numero")]
        public string? Numero { get; set; }

        [BsonElement("complemento")]
        public string? Complemento { get; set; }

        [BsonElement("cep")]
        public int? CEP { get; set; }

        [BsonElement("rede")]
        public string? Rede { get; set; }

        [BsonElement("tipo_loja")]
        public string? TipoLoja { get; set; }

        [BsonElement("identificador_loja")]
        public string? IdentificadorLoja { get; set; }

        [BsonElement("cnpj")]
        public string? CNPJ { get; set; }

        [BsonElement("secao")]
        public string? Secao { get; set; }

        [BsonElement("categoria")]
        public string? Categoria { get; set; }

        [BsonElement("identificador_produto")]
        public string? IdentificadorProduto { get; set; }

        [BsonElement("descricao")]
        public string? Descricao { get; set; }

        [BsonElement("fabricante")]
        public string? Fabricante { get; set; }

        [BsonElement("cnpj_fabricante")]
        public string? CNPJFabricante { get; set; }

        [BsonElement("marca")]
        public string? Marca { get; set; }

        [BsonElement("marca_propria")]
        public bool? MarcaPropria { get; set; }

        [BsonElement("conteudo")]
        public string? Conteudo { get; set; }

        [BsonElement("tipo_produto")]
        public string? TipoProduto { get; set; }

        [BsonElement("preco_pago")]
        public decimal? PrecoPago { get; set; }

        [BsonElement("tipo_promocao")]
        public string? TipoPromocao { get; set; }

        [BsonElement("preco_regular")]
        public double? PrecoRegular { get; set; }

        [BsonElement("preco_pago_por_unidade_de_medida_padrao")]
        public decimal? PrecoPagoUnidadeMedidaPadrao { get; set; }

        [BsonElement("unidade_de_medida_padrao")]
        public string? UnidadeMedidaPadrao { get; set; }

        [BsonElement("origem_preco")]
        public string? OrigemPreco { get; set; }

        [BsonElement("hash")]
        public string? Hash { get; set; }

        [BsonElement("coordinates")]
        public GeoJson2DGeographicCoordinatesWrapper? Coordinates { get; set; }
    }

}
