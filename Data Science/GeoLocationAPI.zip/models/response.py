from typing import Any, List, Optional

from pydantic import BaseModel, Field

from models.internal import MongoGeopoint


class GeosearchResult(BaseModel):
    coordinates: MongoGeopoint = Field(
        description="Mongo GeoJSON object with coordinate",
        examples=[{"type": "Point", "coordinates": [5, 11.3]}],
    )
    address_dict: dict[str, Any] = Field(
        description="dictionary with all address information returned by the external Geosearch API."
    )


class DiscoverResult(BaseModel):
    place_info: dict[str, Any] = Field(
        description="dictionary with all address information returned by the external Discover API."
    )
