﻿using Repository.DbContexts;
using Repository.Entity;
using Repository.EntityRepository.Bases;

namespace Repository.EntityRepository
{
    public class CompanyMonitoringCrawlerRepository : GenericRepository<CompanyMonitoringCrawlerEntity, long>, ICompanyMonitoringCrawlerRepository
    {
        public CompanyMonitoringCrawlerRepository(ApplicationDbContext dbContext) : base(dbContext)
        {
        }
        public static string DbContextName => nameof(ApplicationDbContext);
    }
}
