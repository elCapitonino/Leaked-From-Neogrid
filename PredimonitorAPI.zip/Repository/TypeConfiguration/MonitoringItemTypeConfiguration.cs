﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Repository.Attributes;
using Repository.DbContexts;
using Repository.Entity;

namespace Repository.TypeConfiguration
{
    [DbContextTypeConfiguration(typeof(ApplicationDbContext))]
    public class MonitoringItemTypeConfiguration : TypeConfigurationBase<MonitoringItemEntity>, IEntityTypeConfiguration<MonitoringItemEntity>
    {
        public override void Configure(EntityTypeBuilder<MonitoringItemEntity> builder)
        {
            builder.ToTable("MonitoringItem");
            builder.Property(x => x.Id).HasColumnName("IdMonitoringItem");
            builder.Property(x => x.EanGtin).HasColumnName("Ean_Gtin");
            builder.Property(x => x.CompanyId).HasColumnName("IdCompany");
            builder.Property(x => x.ProductId).HasColumnName("IdProduct");
        }
    }
}
