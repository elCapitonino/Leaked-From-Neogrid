﻿using MongoDB.Bson.Serialization.Attributes;
using Repository.Entity.Abv;

namespace Repository.Entity
{
    public class AbvEntity : BaseMongoEntity
    {
        [BsonElement("ImportTaskId")]
        public string? ImportTaskId { get; set; }

        [BsonElement("ImportDate")]
        public DateTime? ImportDate { get; set; }

        public ProductDescriptionEntity? ProdutoDescricao { get; set; }

        public CategoryEntity? Categoria { get; set; }

        public CompetitorEntity? Concorrente { get; set; }

        public FamilyEntity? Familia { get; set; }

        public StoreEntity? Loja { get; set; }

        public SearchEntity? Pesquisa { get; set; }

        public ProductSearchEntity? PesquisaProduto { get; set; }

        public ProductEanEntity? ProdutoEan { get; set; }

        [BsonElement("Segmento")]
        public string? Segmento { get; set; }

        [BsonElement("HASH")]
        public string? Hash { get; set; }
    }
}
