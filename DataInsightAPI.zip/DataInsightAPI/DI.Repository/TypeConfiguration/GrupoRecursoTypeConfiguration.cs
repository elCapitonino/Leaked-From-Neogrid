﻿using DI.Repository.Attributes;
using DI.Repository.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DI.Repository.TypeConfiguration
{
    [UseSQLContext]
    public sealed class GrupoRecursoTypeConfiguration : IEntityTypeConfiguration<GrupoRecursoEntity>
    {
        public void Configure(EntityTypeBuilder<GrupoRecursoEntity> builder)
        {
            builder.ToTable("GrupoRecurso");

            builder.HasKey(x => x.IdGrupoRecurso);

            builder.Ignore(x => x.Id);
            builder.Ignore(x => x.UpdatedDate);
            builder.Ignore(x => x.CreatedDate);
            builder.Property(x => x.IdEmpresa).IsRequired();
            builder.Property(x => x.Nome).HasMaxLength(256).IsRequired();
            builder.Property(x => x.Descricao).HasMaxLength(512);
            builder.Property(x => x.IdGrupoRecursoPai);
            builder.Property(x => x.IsDeleted).IsRequired().HasColumnName("IsDeletado");
            builder.Property(x => x.DataHoraCriacao).IsRequired();
            builder.Property(x => x.DataHoraUltimaAlteracao).IsRequired();

            builder.HasMany(x => x.UsuarioGrupoRecursos)
                   .WithOne(ugr => ugr.GrupoRecurso)
                   .HasForeignKey(ugr => ugr.IdGrupoRecurso);
        }
    }
}
