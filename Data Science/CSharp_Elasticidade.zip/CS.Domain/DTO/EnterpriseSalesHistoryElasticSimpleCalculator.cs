﻿namespace CS.Domain.DTO
{
    public class EnterpriseSalesHistoryElasticSimpleCalculator
    {
        public string? Issuance { get; set; }
        public string? Product { get; set; }
        public decimal? Quantity { get; set; }
        public decimal? SalePrice { get; set; }
        public string? Affiliate { get; set; }
        public string? Store { get; set; }
        public string? NameSegment { get; set; }
        public string? Customer { get; set; }
    }
}
