﻿
using Domain.Models;

namespace Domain.Copilot
{
    public interface ICopilotDomain
    {
        Task<string> SendMessageAsync(int companyId, string message);
        Task<List<GetAvailablePromptsResponse>> GetAvailablePrompts();
        void SetToken(string token);
    }
}