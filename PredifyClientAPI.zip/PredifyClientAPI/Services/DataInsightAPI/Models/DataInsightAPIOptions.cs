﻿namespace PredifyClientAPI.Services.DataInsightAPI.Models
{
    public class DataInsightAPIOptions
    {
        public Uri BaseAddress { get; set; }
        public double TimeoutMinutes { get; set; }
    }
}
