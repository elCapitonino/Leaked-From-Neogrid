﻿using Asp.Versioning;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PredifyClientAPI.Services.PredifyAPI;
using PredifyClientAPI.Services.PredifyAPI.Models;
using PredifyClientAPI.Services.PredifyAPI.SaleHistory.Models;

namespace PredifyClientAPI.Controllers
{
    [ApiController]
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiVersion("1.0")]
    [Authorize]
    public class SaleHistoryController : ControllerBase
    {
        private readonly ILogger<SaleHistoryController> _logger;
        private readonly PredifyAPIUserManager _predifyAPIUserManager;

        public SaleHistoryController(ILogger<SaleHistoryController> logger, PredifyAPIUserManager predifyAPIUserManager)
        {
            _logger = logger;
            _predifyAPIUserManager = predifyAPIUserManager;
        }

        [HttpPost("")]
        [MapToApiVersion("1.0")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(AnswerModel<string>))]
        [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status401Unauthorized, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
        public async Task<IActionResult> PostSaleHistory([FromBody] EnterpriseSalesHistoryAddRequest request)
        {
            try
            {
                var response = await _predifyAPIUserManager.SaleHistoryService.PostSaleHistory(request);

                return Ok(response);
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized(ex.Message);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
