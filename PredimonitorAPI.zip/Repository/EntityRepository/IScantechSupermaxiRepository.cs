﻿using MongoDB.Bson;
using Repository.Entity;
using Repository.EntityRepository.Bases;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.EntityRepository
{
    public interface IScantechSupermaxiRepository : IGenericRepository<ScantechSupermaxiEntity, ObjectId>, IMongoRepository
    {
    }
}
