﻿using DI.Repository.Attributes;
using DI.Repository.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DI.Repository.TypeConfiguration
{
    [UseSQLContext]
    public class EnterprisePriceGroupTypeConfiguration : TypeConfigurationBase<EnterprisePriceGroupEntity>, IEntityTypeConfiguration<EnterprisePriceGroupEntity>
    {
        public override void Configure(EntityTypeBuilder<EnterprisePriceGroupEntity> builder)
        {
            ConfigureTableName(builder, "Enterprise_Price_Groups");
            builder.ToTable("Enterprise_Price_Groups", table => table.ExcludeFromMigrations());
            builder.HasKey(x => x.EnterprisePriceGroupsId);
            builder.Ignore(x => x.Id);
            builder.Ignore(x => x.UpdatedDate);
            builder.Ignore(x => x.CreatedDate);

            builder.Property(x => x.EnterprisePriceGroupsId).HasColumnName("IdEnterprisePriceGroups");
            builder.Property(x => x.CompanyId).HasColumnName("IdCompany");
            builder.Property(x => x.AITrainingId).HasColumnName("IdAITraining");
            builder.Property(x => x.UserPublishedId).HasColumnName("IdUserPublished");
            builder.Property(x => x.IsDeleted).HasColumnName("IsDeletado");
        }
    }
}
