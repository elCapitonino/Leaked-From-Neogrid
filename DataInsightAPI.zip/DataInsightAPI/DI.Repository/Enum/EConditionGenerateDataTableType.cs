﻿namespace DI.Repository.Enum
{
    public enum EConditionGenerateDataTableType
    {
        None = 0,
        Revenue = 1,
        Demand = 2,
        Profit = 3,
        Margin = 4,
        Royalty = 5,
    }
}
