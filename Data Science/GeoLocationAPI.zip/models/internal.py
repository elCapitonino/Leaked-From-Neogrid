from __future__ import annotations

from typing import Any

from pydantic import BaseModel

from models.request import InputAddressInfo


class AddressInfo(InputAddressInfo):
    error: bool = False
    retry_count: int = 0


class MongoGeopoint(BaseModel):
    """
    Formato GeoJSON do MongoDB. Coordinates são longitude e latitude.
    https://www.mongodb.com/docs/manual/reference/geojson/#point
    """

    type: str = "Point"
    coordinates: tuple[float, float]


class Coordinate(BaseModel):
    """
    Attributes:
      - latitude (float): latitude of coordinate
      - longitude (float): longitude of coordinate
    """

    latitude: float
    longitude: float

    def to_mongo_geopoint(self) -> MongoGeopoint:
        return MongoGeopoint(coordinates=(self.longitude, self.latitude))

    @staticmethod
    def from_mongo_geopoint(geopoint: MongoGeopoint) -> Coordinate:
        return Coordinate(
            latitude=geopoint.coordinates[1], longitude=geopoint.coordinates[0]
        )


class AddressInfoCoordinates(AddressInfo):
    coordinates: Coordinate
    address_dict: dict[str, Any]
