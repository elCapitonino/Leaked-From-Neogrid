﻿public class Coordinates
{
    public string type { get; set; }
    public List<double> coordinates { get; set; }
}

