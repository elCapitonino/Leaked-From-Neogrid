﻿using DI.Domain.Models.ImpactReport;

namespace DI.Domain.Services.Interfaces.Reports
{
    public interface IGetImpactReportDataService
    {
        Task<ValueObjects.ImpactReport> GenerateImpactReportData(ImpactConsolidatedRequestModel model, CancellationToken cancellationToken, string userId);
    }
}
