﻿using DI.Repository.Attributes;
using DI.Repository.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DI.Repository.TypeConfiguration
{
    [UsePostgreContext]

    public sealed class GranularityLevelTypeConfiguration : TypeConfigurationBase<GranularityLevelEntity>, IEntityTypeConfiguration<GranularityLevelEntity>
    {
        public override void Configure(EntityTypeBuilder<GranularityLevelEntity> builder)
        {
            ConfigureTableName(builder, "GranularityLevel");
            builder.HasKey(x => x.Id);
            builder.Property(x => x.Id).ValueGeneratedOnAdd().HasDefaultValueSql("uuid_generate_v4()").IsRequired();
            builder.Property(x => x.Description).HasMaxLength(64);
            builder.Property(x => x.FieldKey).HasMaxLength(64).IsRequired();
            builder.Property(x => x.FieldValue).HasMaxLength(64);

            builder.HasOne(x => x.GranularityGroup).WithMany(x => x.GranularityLevels).HasForeignKey(x => x.GranularityGroupId);
        }
    }
}
