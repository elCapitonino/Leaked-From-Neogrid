﻿using AutoMapper;
using Domain.Exceptions;
using Domain.Models;
using Microsoft.EntityFrameworkCore;
using Repository.UnitOfWork;
using Services.PredifyAPI;

namespace Domain.RuleGroup
{
    public class RuleGroupDomain : IRuleGroupDomain
    {
        private readonly IUnitOfWork _uow;
        private readonly IMapper _mapper;
        private readonly PredifyAPIUserManager _predifyAPIUserManager;

        public RuleGroupDomain(PredifyAPIUserManager predifyAPIUserManager, IUnitOfWork uow, IMapper mapper)
        {
            _uow = uow;
            _mapper = mapper;
            _predifyAPIUserManager = predifyAPIUserManager;
        }

        public IEnumerable<RuleGroupGetAllResponse> GetAllRuleGroupByCompanyId(long companyId)
        {
            var list = _uow.RuleGroupRepository.GetAll().Where(x =>
                x.IdEmpresa == companyId
                && x.IsDeletado == false
                && x.IsBlocked == false)
                .Select(x => new RuleGroupGetAllResponse()
                {
                    Id = x.RuleId,
                    Name = x.Description,
                });

            return list;
        }

        public async Task<long> GetRuleGroupIdByName(long companyId, string name)
        {
            if (!await _predifyAPIUserManager.AccessService.UserHasAccess(companyId))
                throw new UnauthorizedAccessException($"Acesso não autorizado a empresa {companyId}");

            var entity = _uow.RuleGroupRepository.GetAll().FirstOrDefault(x =>
                x.IdEmpresa == companyId
                && x.Description.ToUpper() == name.ToUpper()
                && x.IsDeletado == false
                && x.IsBlocked == false);

            if (entity == null)
                throw new NotFoundException($"Id not found by name");

            return entity.RuleId;
        }

        public async Task<RuleGroupResponse> GetRuleGroupById(long companyId, long id)
        {
            if (!await _predifyAPIUserManager.AccessService.UserHasAccess(companyId))
                throw new UnauthorizedAccessException($"Acesso não autorizado a empresa {companyId}");

            var entity = _uow.RuleGroupRepository.GetAll()
                .Include(x => x.Filters.Where(y => !y.IsDeletado))
                .Include(x => x.Conditions.Where(y => !y.IsDeletado))
                .ThenInclude(x => x.Values.Where(z => z.IsDeletado == false))
                .FirstOrDefault(x =>
                x.IdEmpresa == companyId
                && x.RuleId == id
                && x.IsDeletado == false
                && x.IsBlocked == false);

            if (entity == null)
                throw new NotFoundException($"Id not found");

            return _mapper.Map<RuleGroupResponse>(entity);
        }
    }
}
