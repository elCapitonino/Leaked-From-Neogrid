﻿using Domain.CompanyMonitoringCrawler;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Moq;
using Repository.UnitOfWork;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainTests.CompanyMonitoringCrawler
{
    [TestClass()]
    public class CompanyMonitoringCrawlerTests
    {
        private readonly ILogger<CompanyMonitoringCrawlerDomain> _logger;
        private readonly CompanyMonitoringCrawlerDomain _domain;
        private readonly IUnitOfWork _uow;

        private Mock<ILogger<CompanyMonitoringCrawlerDomain>> _loggerMock;

        public CompanyMonitoringCrawlerTests()
        {
            _loggerMock = new Mock<ILogger<CompanyMonitoringCrawlerDomain>>();
            _uow = new Mock<IUnitOfWork>().Object;
            _logger = _loggerMock.Object;
            _domain = new CompanyMonitoringCrawlerDomain(_logger, _uow);
        }
    }
}
