﻿namespace Repository.Entity
{
    public class MonitoringItemConfigEntity : BaseEntity
    {
        public string Description { get; set; }

        public bool IsExternalSearch { get; set; }

        public int? LifeTimeMonitoring { get; set; }

        public decimal? LowerPriceRange { get; set; }

        public decimal? UpperPriceRange { get; set; }

        public long MonitoringItemId { get; set; }
        public MonitoringItemEntity MonitoringItem { get; set; }

        public bool IsDeleted { get; set; }

    }
}
