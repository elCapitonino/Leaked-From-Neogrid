﻿using Domain.MonitoringResult.Models;
using Repository.Entity;
using Repository.Entity.ProductPrices;
using Repository.Enums;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.MonitoringResult
{
    public class ProductPricesMappings
    {
        public async Task<List<ResultFilterResponse>> MappingsProductPricesToResultResponse(IEnumerable<ProductPricesEntity> datas, IEnumerable<CompanyMonitoringCrawlerEntity> companyCrawlers)
        {
            var results = new List<ResultFilterResponse>();

            foreach (var data in datas)
            {
                foreach (var seller in data.Sellers ?? new List<ProductPricesSeller>())
                {
                    foreach (var price in seller.Prices ?? new List<ProductPricesSellerPrice>())
                    {
                        if (price.Installments != null && price.Installments.Any())
                        {
                            foreach (var installments in price.Installments)
                            {
                                var item = new ResultFilterResponse()
                                {
                                    ProductName = data.ProductName,
                                    ProductLink = data.ProductLink,
                                    ProductBrand = data.ProductBrand ?? "-",
                                    SellerName = seller.SellerName ?? "-",
                                    Marketplace = companyCrawlers.FirstOrDefault(x => x.MonitoringCrawlerId == data.IdCrawler)?.MonitoringCrawler?.Description ?? "N/A",
                                    Price = price.Price ?? 0,
                                    PriceFrom = price.PriceFrom,
                                    PaymentType = price.PricePaymentType ?? "-",
                                    Price_unit_type = price.PriceUnitType != null ? price.PriceUnitType : PriceUnitType.UNITARIO,
                                    Price_unit = price.PriceUnit,
                                    Price_unit_quantity = price.PriceUnitQuantity,
                                    CrawlerDate = data.CrawlerDate,
                                    IdCrawler = data.IdCrawler,
                                    Disregarded = false,
                                    PriceAlert = null,
                                    Country = seller.CountryName != null ? seller.CountryName : data.ProductLocal?.Country != null ? data.ProductLocal.Country : null,
                                    State = seller.StateUF != null ? seller.StateUF : data.ProductLocal?.State != null ? data.ProductLocal.State : null,
                                    City = seller.City != null ? seller.City : data.ProductLocal?.City != null ? data.ProductLocal.City : null,
                                    ProductManufactureYear = data.ManufactureYear,
                                    ProductUsedHours = data.UsedHours,
                                    ProductAxles = data.ProductAxles,
                                    ProductMileage = data.ProductMileage,
                                    ProductMileageSymbol = data.ProductMileageSymbol,
                                    ProductFuelTankCapacity = data.ProductFuelTankCapacity,
                                    ProductFuelTankCapacitySymbol = data.ProductFuelTankCapacitySymbol,
                                    ProductTruckBodyType = data.ProductTruckBodyType,
                                    ProductVehicleYearModel = data.ProductVehicleYearModel,
                                    ProductManufacturer = data.ProductManufacturer,
                                    On_request = price.OnRequest,
                                    Price_tax_st = price.PriceTaxST,
                                    QuantityInstallment = installments.Quantity,
                                    Total_priceInstallment = installments.TotalPrice,
                                    PriceInstallment = installments.Price,
                                    Price_currencyInstallment = installments.PriceCurrency,
                                    DeflatedValue = null,
                                    Format_market = null,
                                    ProductModel = data.ProductModel
                                };

                                item.Coordinates = GenerateCoordinates(seller, data.ProductLocal);

                                if (price.PriceUnitType == PriceUnitType.CAIXA)
                                {
                                    if (price.PriceUnit == null || price.PriceUnit <= 0)
                                    {
                                        if (price.PriceUnitQuantity == null || price.PriceUnitQuantity == 0) continue;
                                        else
                                        {
                                            item.Price = Math.Round(price.Price.Value / price.PriceUnitQuantity.Value, 2);
                                            item.Price_unit = Math.Round(price.Price.Value / price.PriceUnitQuantity.Value, 2);
                                        }
                                    }
                                    else item.Price = price.PriceUnit.Value;
                                }

                                if (price.Price == 0)
                                {
                                    if (price.OnRequest.Value)
                                        results.Add(item);

                                    continue;
                                }

                                results.Add(item);
                            }
                        }
                        else
                        {
                            var item = new ResultFilterResponse()
                            {
                                ProductName = data.ProductName,
                                ProductLink = data.ProductLink,
                                ProductBrand = data.ProductBrand ?? "-",
                                SellerName = seller.SellerName ?? "-",
                                Marketplace = companyCrawlers.FirstOrDefault(x => x.MonitoringCrawlerId == data.IdCrawler)?.MonitoringCrawler?.Description ?? "N/A",
                                Price = price.Price ?? 0,
                                PriceFrom = price.PriceFrom,
                                PaymentType = price.PricePaymentType ?? "-",
                                Price_unit_type = price.PriceUnitType != null ? price.PriceUnitType : PriceUnitType.UNITARIO,
                                Price_unit = price.PriceUnit,
                                Price_unit_quantity = price.PriceUnitQuantity,
                                CrawlerDate = data.CrawlerDate,
                                IdCrawler = data.IdCrawler,
                                Disregarded = false,
                                PriceAlert = null,
                                Country = seller.CountryName != null ? seller.CountryName : data.ProductLocal?.Country != null ? data.ProductLocal.Country : null,
                                State = seller.StateUF != null ? seller.StateUF : data.ProductLocal?.State != null ? data.ProductLocal.State : null,
                                City = seller.City != null ? seller.City : data.ProductLocal?.City != null ? data.ProductLocal.City : null,
                                ProductManufactureYear = data.ManufactureYear,
                                ProductUsedHours = data.UsedHours,
                                ProductAxles = data.ProductAxles,
                                ProductMileage = data.ProductMileage,
                                ProductMileageSymbol = data.ProductMileageSymbol,
                                ProductFuelTankCapacity = data.ProductFuelTankCapacity,
                                ProductFuelTankCapacitySymbol = data.ProductFuelTankCapacitySymbol,
                                ProductTruckBodyType = data.ProductTruckBodyType,
                                ProductVehicleYearModel = data.ProductVehicleYearModel,
                                ProductManufacturer = data.ProductManufacturer,
                                On_request = price.OnRequest,
                                Price_tax_st = price.PriceTaxST,
                                QuantityInstallment = null,
                                Total_priceInstallment = null,
                                PriceInstallment = null,
                                Price_currencyInstallment = null,
                                DeflatedValue = null,
                                Format_market = null,
                                ProductModel = data.ProductModel
                            };

                            item.Coordinates = GenerateCoordinates(seller, data.ProductLocal);

                            if (price.PriceUnitType == PriceUnitType.CAIXA)
                            {
                                if (price.PriceUnit == null || price.PriceUnit <= 0)
                                {
                                    if (price.PriceUnitQuantity == null || price.PriceUnitQuantity == 0) continue;
                                    else
                                    {
                                        item.Price = Math.Round(price.Price.Value / price.PriceUnitQuantity.Value, 2);
                                        item.Price_unit = Math.Round(price.Price.Value / price.PriceUnitQuantity.Value, 2);
                                    }
                                }
                                else item.Price = price.PriceUnit.Value;
                            }

                            if (price.Price == 0)
                            {
                                if (price.OnRequest != null && price.OnRequest.Value)
                                    results.Add(item);

                                continue;
                            }


                            results.Add(item);
                        }
                    }
                }
            }

            return results;
        }

        private PrediMonitorProduct_CoordinatesModel GenerateCoordinates(ProductPricesSeller seller, ProductPricesProductLocal? productLocal)
        {
            PrediMonitorProduct_CoordinatesModel coordinates = null;

            if (seller.Coordinates != null)
            {
                coordinates = new PrediMonitorProduct_CoordinatesModel()
                {
                    Longitude = (decimal)seller.Coordinates.Coordinates[0],
                    Latitude = (decimal)seller.Coordinates.Coordinates[1],
                };
            }
            else if (productLocal?.Coordinates != null)
            {
                coordinates = new PrediMonitorProduct_CoordinatesModel()
                {
                    Longitude = (decimal)productLocal.Coordinates.Coordinates[0],
                    Latitude = (decimal)productLocal.Coordinates.Coordinates[1],
                };
            }

            return coordinates;
        }
    }
}
