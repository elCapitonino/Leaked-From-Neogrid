import re

from async_mongo import AsyncMongoConnect
from processing_product import Processing_product
from logger import logger
from config import *


class Search_internal:
    def __init__(self):
        try:
            logger.info(" ------ Search iniciado  ------")
            self.dbMongo = AsyncMongoConnect()
            self.proc_prep = Processing_product()
        except Exception as ex:
            logger.error(" ------ Search não iniciado  ------")
            logger.error(ex)

    async def get_products_internal(self, data_resp, start_date, end_date, idcrawlers_busca):

        list_result_final = []
        result_return = []
        #sc = []
        for item in data_resp['products_list']:
            # print(item)
            list_result_final = []
            if item == []:
                continue
            for j in item:
                #print("J ", j)
                list_restrict = ["kit", "combo",
                                 "conjunto", "atacado", "catalago", "pecas", "filtro", "filtros",
                                 "evaporador", "condensador", "regulador", "painel",
                                 "planetaria", "manual", "partida", "motor", "para-brisa", "parabrisa", "adesivos", "adesivo",
                                 "miniatura", "replica", "brinquedo", "bomba", "suporte", "acessorios", "jogo",
                                 "tanque", "silencioso", "mini", "cruzeta", "eixo", "lamina", "disco", "cubo",
                                 "turbina", "bucha", "superior", "bobina", "sensor", "valvula", "coroa", "acumulador",
                                 "vidro", "esquema", "tensor", "reparo", "inferior", "fechadura", "rolete", "retentor",
                                 "mangueira", "decalque", "separador", "faixa", "ignigcao", "emblema", "turbo",
                                 "radiador", "codigos", "lanterna", "pino", "flange", "tampa", "rolamento"]
                sc = []
                if j[5] != None:
                    parts = j[5].split(' ')
                    for s in parts:
                        if s != '':
                            x = re.search("(\A)[a-zA-Z]*\d($(\Z))", s)
                            # x = re.search("(\A)[a-zA-Z]*\d($(\Z))", s)

                            if x:
                                sc.append({"txt": s, "score": 2})
                                y = re.search("(\A)[a-zA-Z]*", x.group())
                                sc.append({"txt": y.group(), "score": 1})
                                sc.append(
                                    {"txt": s.replace(y.group(), ""), "score": 1})
                            if s in list_restrict:
                                sc.append({"txt": s, "score": 1})
                                list_restrict.remove(s)

                            else:
                                sc.append({"txt": s, "score": 1})
                    ############################################
                    for r in list_restrict:
                        sc.append({"txt": r, "score": -1})
                ############################################

                # result = self.client.normalizer.product_prices.find({"$and": [{'crawler_date': {'$gte': start_date,'$lt': end_date}}, {'id_product_normalized': j[0]}]})
                result = await self.dbMongo.get_produto_internal(
                    j[0], start_date, end_date, idcrawlers_busca)
                ##################################################
                # result = await self.dbMongo.get_products_general(
                #     j[0], start_date, end_date, idcrawlers_busca)
                #################################################
                for i in result:
                    product_name = self.proc_prep.run(i['product_name'])
                    site_sku = None
                    shippings = None
                    if 'site_sku' in i:
                        site_sku = i['site_sku']
                    if 'shippings' in i:
                        shippings = i['shippings']

                    if 'sellers' not in i:
                        continue
                    ##################################
                    t_score = 0
                    # eliminar produtos vendidos por atacado com numero no inicio da descricao
                    x_num = re.search("^(\d{1,2}\s)", product_name)
                    if x_num:
                        t_score += -1
                    # print("-------------------------------------")
                    for s in sc:
                        if s['txt'] in product_name:
                            t_score += s['score']

                    if t_score >= 0:
                        '''
                        Somente produtos com score maior ou igual a 0 serao adicionados a lista de resultados
                        '''
                        result_list = {'id': str(i['_id']),
                                       'id_crawler': i['id_crawler'],
                                       "crawler_date": i['crawler_date'],
                                       "product_name": i['product_name'],
                                       "product_link": i['product_link'],
                                       "product_brand": j[3],
                                       "site_sku": site_sku,
                                       "source": i['source'],
                                       "sellers": i['sellers'],
                                       "shippings": shippings,
                                       "trash_score": t_score
                                       }
                        if i['id_crawler'] in idcrawlers_busca:
                            list_result_final.append(result_list)

            ##################################################
            #print("tamanho : ", len(list_result_final))
            if len(list_result_final) == 0:
                return []
            if len(list_result_final) > 0:
                m = max(list_result_final, key=lambda x: x["trash_score"])

            p = list(filter(lambda x: x['trash_score'] ==
                            m['trash_score'], list_result_final))

            #print("Tamanho P antes ", len(p))
            #p = self.proc_prep.get_products_time(p)
            #print("Tamanho P depois ", len(p))

            # p = filter(lambda x: x['trash_score'] ==
            #            m['trash_score'], list_result_final)

            result_return.append({'id': j[4], 'name': j[2],
                                  'results': p})

        return result_return
