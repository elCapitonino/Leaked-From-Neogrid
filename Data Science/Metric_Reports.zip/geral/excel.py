"""
Arquivo com uma função que define o "formato" do excel gerado.
Aqui serão criadas outras tabelas que são colocadas em outras abas.

Por enquanto, temos as seguintes abas:
- Dados Brutos: os resultados comparativos de cada precificação;

- Erros de Projeção: os erros médios de preço, demanda e receita para cada
    precificação e o agregado;

- Consolidado: as análises de alterações de marge, volume, receita e lucro
    para cada precificação que adotou a IA e a agregada;
"""

import math
from datetime import date
from typing import Optional

import pandas as pd
from openpyxl.styles.numbers import FORMAT_NUMBER_00, FORMAT_PERCENTAGE_00
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.worksheet import Worksheet

from report import Report, ReportStyle, get_summaries, float_columns, pct_columns, get_tb_erros

# FIXME: cores na função antiga bugadas, por enquanto
ant_opt = {"align": "center", "num_format": "#,##0.00"}  # "bg_color": "#99c2ff",
proj_opt = {"align": "center", "num_format": "#,##0.00"} # "bg_color": "#ff5c33", 
post_opt = {"align": "center", "num_format": "#,##0.00"} # "bg_color": "#4d94ff",
alt_opt = {"align": "center", "num_format": "#,##0.00"}  # "bg_color": "#66ff66",


def save_excel_reports(
    filename: str,
    reports: list[Report],
    col_mapping: dict[str, str],
    report_style: ReportStyle,
    save_summaries: bool = True,
    blocked_cols: Optional[list[str]] = None,
) -> None:
    links, rev_links, startrows = {}, {}, {}
    with pd.ExcelWriter(filename, engine="openpyxl") as writer:
        for report in reports:
            sheet_name = report.name
            startrow = 0 if report.final else 1
            startrows[sheet_name] = startrow

            if blocked_cols is not None:
                report = report.remove_columns(blocked_cols)

            links[report.id] = sheet_name
            rev_links[sheet_name] = report

            report.get_styled_report(report_style, col_mapping).to_excel(
                writer, sheet_name=sheet_name, index=False, float_format="%.4f", startrow=startrow
            )
        workbook = writer.book
        sheets = workbook.sheetnames
        for sheet in sheets:
            ws = workbook[sheet]
            # NOTE precisa ser feito antes de usar fórmulas
            _adjust_cell_width(ws)
            _adjust_cell_height(ws)

        for sheet in sheets:
            ws: Worksheet = workbook[sheet]
            startrow = startrows[sheet]
            ws.auto_filter.ref = f"A{startrow + 1}:{get_column_letter(ws.max_column)}{ws.max_row}"
            report = rev_links[sheet]
            float_cols = report.float_columns()
            pct_cols = report.pct_columns()
            _format_float_cols(ws, float_cols)
            _format_pct_cols(ws, pct_cols)

            ref_ids = report.get_ref_ids()
            if ref_ids is None:
                continue  # não há relatório para linkar
            for i, ref_id in enumerate(ref_ids):
                target_sheet = links[ref_id]
                ws.cell(
                    i + startrow + 2, 1
                ).value = f'=HYPERLINK("#\'{target_sheet}\'!A1", "{ws.cell(i + startrow + 2, 1).value}")'
                target_ws = workbook[target_sheet]
                target_ws.cell(1, 1).value = f'=HYPERLINK("#\'{sheet}\'!A1", "Voltar")'
                target_ws.cell(1, 1).style = "Hyperlink"

        if save_summaries:
            for report in reports:
                summaries = report.get_summaries()
                if summaries:
                    _save_summaries(writer, report.name, summaries)


def _format_float_cols(worksheet: Worksheet, float_cols: list[int]) -> None:
    for col_loc in float_cols:
        col_letter = get_column_letter(col_loc + 1)
        for cell in worksheet[col_letter]:
            cell.number_format = FORMAT_NUMBER_00


def _format_pct_cols(worksheet: Worksheet, float_cols: list[int]) -> None:
    for col_loc in float_cols:
        col_letter = get_column_letter(col_loc + 1)
        for cell in worksheet[col_letter]:
            cell.number_format = FORMAT_PERCENTAGE_00


def _adjust_cell_width(worksheet: Worksheet, multiplier: float = 1.15, constant: int = 2) -> None:
    dims = {}
    for row in worksheet.rows:
        for cell in row:
            if not cell.value or str(cell.value).startswith("="):  # ignorar fórmulas
                continue
            dims[cell.column_letter] = max(
                dims.get(cell.column_letter, 0),
                constant + math.ceil(multiplier * len(str(cell.value).split("\n", maxsplit=1)[0])),
            )
    for col, value in dims.items():
        worksheet.column_dimensions[col].width = value


def _adjust_cell_height(worksheet: Worksheet, constant: int = 15) -> None:
    dims = {}
    for row in worksheet.rows:
        for cell in row:
            dims[cell.row] = max(
                (dims.get(cell.row, 0), constant * (1 + str(cell.value).count("\n")))
            )

    for row, value in dims.items():
        worksheet.row_dimensions[row].height = value


def _save_summaries(writer, parent_name: str, summaries: dict[str, list[pd.DataFrame]]) -> None:
    # TODO muito acoplado com a implementação de Report!
    tb_erros, tb_erros_2, tb_erros_3, tb_erros_4 = summaries["erros"]
    cons_dfs = summaries["consolidado"]

    erros_sheet = f"{parent_name} - Erros de Projeção"
    tb_erros.to_excel(writer, sheet_name=erros_sheet, index=True, float_format="%.2f", startcol=0, startrow=1)
    tb_erros_2.to_excel(
        writer,
        sheet_name=erros_sheet,
        index=True,
        header=False,
        float_format="%.2f",
        startcol=1,
        startrow=3 + tb_erros.shape[0],
    )
    tb_erros_3.to_excel(
        writer,
        sheet_name=erros_sheet,
        index=True,
        float_format="%.2f",
        startrow=1,
        startcol=4 + tb_erros.shape[1],
    )
    tb_erros_4.to_excel(
        writer,
        sheet_name=erros_sheet,
        index=True,
        header=False,
        float_format="%.2f",
        startrow=3 + tb_erros.shape[0],
        startcol=5 + tb_erros.shape[1],
    )
    worksheet = writer.sheets[erros_sheet]
    _adjust_cell_width(worksheet)
    worksheet.cell(1, 3).value = "Erro Médio do Modelo"
    worksheet.cell(1, 7 + tb_erros.shape[1]).value = "Erro Médio do Modelo"
    worksheet.cell(1, 1).value = f'=HYPERLINK("#\'{parent_name}\'!A1", "Voltar")'
    worksheet.cell(1, 1).style = "Hyperlink"

    consolidado_sheet = f"{parent_name} - Consolidado"
    startrow = 1
    worksheet = None
    startrows = []
    headers = [
        "Resultado Consolidado das Mudanças Semanais (Apenas Registros Cujo Preço Ajustado foi Adotado)",
        "Quantidade de Registros de Preços Aprovados",
        "Quantidade de Registros por Tipo de Influência da IA - Preço Sem Regras",
        "Quantidade de Registros por Tipo de Influência da IA - Preço Ajustado",
        "Quantidade de Registros por Tipo de Influência da IA - Preços Novos - Preço Ajustado",
    ]
    for i, df in enumerate(cons_dfs):
        startcol = 0
        if i == 1:  # FIXME melhorar! tabelas diferentes são "coladas" juntas
            startcol = 1
        df.to_excel(
            writer, sheet_name=consolidado_sheet, index=True, float_format="%.2f", startcol=startcol, startrow=startrow
        )
        gap = 2 if i == 0 else 3
        if i == 1:
            startrow += gap + df.shape[0]
            continue

        startrows.append(startrow)
        startrow += gap + df.shape[0]

    worksheet = writer.sheets[consolidado_sheet]
    _adjust_cell_width(worksheet)
    for startrow, header in zip(startrows, headers):
        worksheet.cell(startrow, 2).value = header

    worksheet.cell(1, 1).value = f'=HYPERLINK("#\'{parent_name}\'!A1", "Voltar")'
    worksheet.cell(1, 1).style = "Hyperlink"

    # links parent_sheet -> summaries
    worksheet = writer.sheets[parent_name]
    worksheet.cell(1, 2).value = f'=HYPERLINK("#\'{erros_sheet}\'!A1", "Erros")'
    worksheet.cell(1, 2).style = "Hyperlink"
    worksheet.cell(1, 3).value = f'=HYPERLINK("#\'{consolidado_sheet}\'!A1", "Consolidado")'
    worksheet.cell(1, 3).style = "Hyperlink"


# TODO unificar funções para salvar Excel
def to_excel(df: pd.DataFrame, params: dict) -> None:
    """Função auxiliar para gerar um excel totalmente formatado,
    com bloco de cores, precisão de casas decimais, etc.
    """
    nome = f"Relatorio_-_{params['idcompany']}_-_{date.today().isoformat()}.xlsx"
    cols = list(df.columns)

    float_cols = float_columns(df)
    pct_cols = pct_columns(df)

    summaries = get_summaries(df)
    tb_erros, tb_erros_2, tb_erros_3, tb_erros_4 = summaries["erros"]
    tb_alts, tb_alts_2, tb_qtd_aprov, tb_qtd_ia_sem_regra, tb_qtd_ia, tb_qtd_ia_new = summaries["consolidado"]


    with pd.ExcelWriter(
        nome,
        # if_sheet_exists='new' - apenas na versao 1.3.0
        engine="openpyxl",
        date_format="YYYY-MM-DD",
        datetime_format="YYYY-MM-DD HH:MM:SS",
    ) as writer:
        workbook = writer.book

        df.to_excel(writer, sheet_name="Dados Brutos", index=False, float_format="%.2f", startrow=1)
        ws = workbook["Dados Brutos"]

        # TODO: add uma explicação para cada conjunto de colunas
        # ws.cell(
        #     1, cols.index("Preço de Custo (Semana Anterior)") +1
        # ).value = "Dados Relativos a Semana Anterior a Precificação"
        
        # ws.cell(
        #     1, cols.index("Preço de Custo (Precificação)") +1
        # ).value = "Dados Projetados para a Semana da Precificação"

        # ws.cell(
        #     1, cols.index("Preço de Custo (Semana Seguinte)") +1
        # ).value = "Dados Relativos a mesma Semana da Precificação"

        # ws.cell(1, cols.index("Lucro (Semana Seguinte)") +2).value = "Análises de Performance da Ferramenta"
        # ws.cell(1, cols.index("Alteração de Margem (Semanal) - %") +1).value = "O que Mudou entre uma Semana e Outra"

        _format_float_cols(ws, float_cols)
        _format_pct_cols(ws, pct_cols)

        tb_erros.to_excel(
            writer, sheet_name="Erros de Projeção", index=True, float_format="%.2f", startcol=0, startrow=1
        )
        tb_erros_2.to_excel(
            writer,
            sheet_name="Erros de Projeção",
            index=True,
            header=False,
            float_format="%.2f",
            startcol=1,
            startrow=3 + tb_erros.shape[0],
        )
        tb_erros_3.to_excel(
            writer,
            sheet_name="Erros de Projeção",
            index=True,
            float_format="%.2f",
            startrow=1,
            startcol=4 + tb_erros.shape[1],
        )
        tb_erros_4.to_excel(
            writer,
            sheet_name="Erros de Projeção",
            index=True,
            header=False,
            float_format="%.2f",
            startrow=3 + tb_erros.shape[0],
            startcol=5 + tb_erros.shape[1],
        )
        ws = workbook["Erros de Projeção"]
        ws.cell(1, 3).value = "Erro Médio do Modelo"
        ws.cell(1, 7 + tb_erros.shape[1]).value = "Erro Médio do Modelo"

        tb_alts.to_excel(writer, sheet_name="Consolidado", index=True, float_format="%.2f", startcol=0, startrow=1)
        tb_alts_2.to_excel(
            writer,
            sheet_name="Consolidado",
            index=True,
            header=False,
            float_format="%.2f",
            startcol=1,
            startrow=3 + tb_alts.shape[0],
        )
        tb_qtd_aprov.to_excel(
            writer,
            sheet_name="Consolidado",
            index=True,
            float_format="%.2f",
            startcol=0,
            startrow=6 + tb_alts.shape[0] + tb_alts_2.shape[0],
        )
        tb_qtd_ia_sem_regra.to_excel(
            writer,
            sheet_name="Consolidado",
            index=True,
            float_format="%.2f",
            startcol=3 + tb_qtd_aprov.shape[1],
            startrow=6 + tb_alts.shape[0] + tb_alts_2.shape[0],
        )
        tb_qtd_ia.to_excel(
            writer,
            sheet_name="Consolidado",
            index=True,
            float_format="%.2f",
            startcol=6 + tb_qtd_aprov.shape[1] + tb_qtd_ia_sem_regra.shape[1],
            startrow=6 + tb_alts.shape[0] + tb_alts_2.shape[0],
        )
        ws = workbook["Consolidado"]
        ws.cell(1, 3).value = "Resultado Consolidado das Mudanças Semanais (Apenas Registros Cujo Preço Ajustado foi Adotado)"
        ws.cell(6 + tb_alts.shape[0] + tb_alts_2.shape[0], 1).value = "Quantidade de Registros de Preços Aprovados"
        ws.cell(
            6 + tb_alts.shape[0] + tb_alts_2.shape[0],
            4 + tb_qtd_aprov.shape[1]
        ).value = "Quantidade de Registros por Tipo de Influência da IA - Preço Sem Regras"
        ws.cell(
            6 + tb_alts.shape[0] + tb_alts_2.shape[0],
            7 + tb_qtd_aprov.shape[1] + tb_qtd_ia_sem_regra.shape[1]
        ).value = "Quantidade de Registros por Tipo de Influência da IA - Preço Ajustado"

    return None
