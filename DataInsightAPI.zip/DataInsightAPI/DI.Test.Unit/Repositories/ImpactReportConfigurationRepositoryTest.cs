﻿using DI.Repository.Interfaces;

namespace DI.Test.Unit.Repositories
{
    public class ImpactReportConfigurationRepositoryTest
    {
        private readonly IUnitOfWork _unitOfWork;

        public ImpactReportConfigurationRepositoryTest(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        [Fact]
        public void TestGetById_ValidId()
        {
            var companyId = 3026;
            var getCompany = _unitOfWork.ImpactReportConfigurationRepository.GetByCompanyId(companyId);
            Assert.NotNull(getCompany);
        }

        [Fact]
        public void TestGetById_InvalidId()
        {
            long companyId = -1;
            Assert.Throws<NullReferenceException>(() =>
            {
                var idInvalid = _unitOfWork.ImpactReportConfigurationRepository.GetByCompanyId(companyId);
            });
        }

        [Fact]
        public void TestGetById_NonExistentId()
        {
            long nonExistentCompany = 00000;
            Assert.Throws<NullReferenceException>(() =>
            {
                var idNonExistentCompany = _unitOfWork.ImpactReportConfigurationRepository.GetByCompanyId(nonExistentCompany);
            });
        }

        [Fact]
        public void TestGetCompany_DetailsAsync()
        {
            long companyId = 3026;
            var getPriceProjection = _unitOfWork.ImpactReportConfigurationRepository.GetByCompanyId(companyId);

            Assert.NotNull(getPriceProjection);
            Assert.NotNull(getPriceProjection.CompanyId);
            Assert.NotNull(getPriceProjection.RawCategoryField);
            Assert.NotNull(getPriceProjection.RawSubCategoryField);
            Assert.NotNull(getPriceProjection.Goal);
            Assert.NotNull(getPriceProjection.Royalty);
        }
    }
}
