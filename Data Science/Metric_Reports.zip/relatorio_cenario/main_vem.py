"""
Gera relatórios de precificação para VEM por filial.
"""

import argparse
import json
import os
import shutil
from datetime import datetime

import pandas as pd
from unidecode import unidecode
from xlsxwriter.utility import xl_col_to_name


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--csv",
        type=str,
        required=True,
        help="CSV do relatório com dados de todas as filiais",
    )
    parser.add_argument(
        "--affiliate-info",
        type=str,
        required=True,
        help=(
            "Caminho para arquivo XLSX com informações de filiais da VEM. "
            "Arquivo salvo no blob vem (pasta tabelas_predify/affiliate_info.xlsx)"
        ),
    )
    parser.add_argument(
        "--chosen-products",
        type=str,
        default=None,
        help=(
            "Caminho para arquivo JSON com os produtos selecionados (Product) por filial (Affiliate). "
            "Gerado pelo script activity_level/vem_get_top_products.py deste repositório."
        ),
    )
    args = parser.parse_args()

    df = pd.read_csv(args.csv, sep=";", decimal=",")
    today = datetime.today().strftime("%Y-%m-%d")
    path = f"./reports_{today}"
    if os.path.exists(path):
        choice = input(
            f"WARNING: a pasta {path} já existe, APAGAR e sobrescrever os dados? [s/n] "
        )
        if choice.lower() != "s":
            return
        shutil.rmtree(path)
    os.makedirs(path)

    df_info = pd.read_excel(args.affiliate_info)

    df_info["PARALISADA"] = df_info["PARALISADA"].astype("bool")
    df_info["SUCEDIDA"] = df_info["SUCEDIDA"].astype("bool")
    df_info["FINALIZADA"] = df_info["FINALIZADA"].astype("bool")
    df_info = df_info[
        ~df_info["PARALISADA"] & ~df_info["SUCEDIDA"] & ~df_info["FINALIZADA"]
    ]

    df["Código da Filial"] = df["Código da Filial"].astype(str)
    present_affiliates = set(df["Código da Filial"].values.tolist())
    all_affiliates = set(df_info["ZBRM"].astype(str).values.tolist())

    missing_aff = all_affiliates - present_affiliates
    excess_aff = present_affiliates - all_affiliates

    if missing_aff:
        print(f"WARNING: known affiliates without data: {sorted(missing_aff)}")
    if excess_aff:
        raise ValueError(
            f"The following affiliates in the data that are not in the affiliate_info file: {sorted(excess_aff)}"
        )

    if args.chosen_products is not None:
        chosen = json.load(open(args.chosen_products, "r", encoding="utf-8"))
        chosen_structured = [
            {"Código da Filial": affiliate, "Product": product}
            for affiliate, products in chosen.items()
            for product in products
        ]
        df_chosen = pd.DataFrame(chosen_structured)

    affiliates = sorted(present_affiliates)
    for i, affiliate in enumerate(affiliates):
        if (i + 1) % 10 == 0:
            print(f"-> {i + 1}/{len(affiliates)}")
        df_aff = df[df["Código da Filial"] == affiliate].copy()
        aff_name = unidecode(df_aff["Filial"].iloc[0]).lower().replace(" ", "_")

        if args.chosen_products is not None:
            df_aff = pd.merge(
                df_aff, df_chosen, how="inner", on=["Código da Filial", "Product"]
            )

        df_aff = df_aff[abs(df_aff["Último_Preço"] - df_aff["Preço_Aprovado"]) >= 0.01]
        assert (
            df_aff.shape[0] == df_aff["Descrição"].nunique()
        ), f"{affiliate} - {df_aff.shape[0]} vs {df_aff['Descrição'].nunique()}"

        var_lucro = df_aff["Variação_de_Lucro"].sum()
        if var_lucro < 0:
            print(f"WARNING: filial {affiliate}: variação de lucro = R${var_lucro:.2f}")

        df_aff = df_aff.sort_values("Variação_de_Lucro", ascending=False)
        df_aff = df_aff.drop(columns=["Product"])

        if df_aff.empty:
            print(f"WARNING: no prices left after filters for affiliate {affiliate}")

        with pd.ExcelWriter(
            f"{path}/{affiliate}_{aff_name}.xlsx", engine="xlsxwriter"
        ) as writer:
            df_aff.to_excel(writer, index=False, float_format="%.2f")

            # Get the xlsxwriter workbook and worksheet objects.
            workbook = writer.book
            worksheet = writer.sheets["Sheet1"]

            float_cols = [i for i, type in enumerate(df_aff.dtypes) if type == "float"]
            format1 = workbook.add_format({"num_format": "0.00"})
            for col in float_cols:
                worksheet.set_column(
                    f"{xl_col_to_name(col)}:{xl_col_to_name(col)}", None, format1
                )
            worksheet.autofit()

    shutil.make_archive(path, "zip", path)
    print(f"dados salvos em {path}.zip")


if __name__ == "__main__":
    main()
