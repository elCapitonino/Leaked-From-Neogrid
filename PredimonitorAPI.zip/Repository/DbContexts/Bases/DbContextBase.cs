﻿using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.EntityFrameworkCore;
using Repository.Entity;
using System.Reflection;
using Repository.Attributes;

namespace Repository.DbContexts.Bases
{
    public abstract class DbContextBase : DbContext, IMultiDbContext
    {
        public abstract string DbContextName { get; }

        protected DbContextBase(DbContextOptions options) : base(options)
        {

        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            ApplyAllTypeConfigurations(modelBuilder);
        }

        private void ApplyAllTypeConfigurations(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly(),
                t => t.GetInterfaces().Any(i => i.IsGenericType && i.GetGenericTypeDefinition() == typeof(IEntityTypeConfiguration<>)) &&
                     t.GetCustomAttribute<DbContextTypeConfigurationAttribute>()?.DbContextType == GetType());
        }

        public override int SaveChanges()
        {
            var entries = ChangeTracker
                .Entries()
                .Where(e => e.Entity is BaseEntity && (e.State == EntityState.Added || e.State == EntityState.Modified));

            foreach (var entityEntry in entries)
            {
                if (entityEntry.Entity is BaseEntity)
                {
                    ((BaseEntity)entityEntry.Entity).UpdateDate = DateTime.Now;
                    if (entityEntry.State == EntityState.Added)
                    {
                        ((BaseEntity)entityEntry.Entity).CreateDate = DateTime.Now;
                    }
                }
            }
            return base.SaveChanges();
        }
    }
}
