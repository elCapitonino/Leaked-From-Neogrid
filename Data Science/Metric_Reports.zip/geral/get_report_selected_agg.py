"""
Código para gerar um excel com relatórios a partir de precificações selecionadas
e relatórios agregados a partir desses.
"""
import warnings
warnings.filterwarnings("ignore", category=UserWarning)

import json
import time
from datetime import date
from typing import Any

import yaml
from pyodbc import Connection

import config
from aggregator import aggregate
from db import query_selected_price_groups
from excel import save_excel_reports
from generator import generate_reports, get_base_parser
from report_conf import CONFIGS


def main(conn_obj: Connection, params: dict[str, Any]) -> None:
    """Função para gerar os dados da planilha excel."""
    price_groups = query_selected_price_groups(
        conn_obj,
        params["idcompany"],
        params["price_groups"],
        group_granularity=params["group_gran"],
        group_info=params["group_info"],
        days_lookback=params["lookback"],
        days_interval=params["interval"],
        days_lookforward=params["lookforward"],
    )
    reports = generate_reports(price_groups, conn_obj, params)
    if not reports:
        return
    conf = CONFIGS[params["idcompany"]]
    reports = aggregate(reports, params, conf.agg_steps)

    company_col_map = params["col_map"].get(int(params["idcompany"]), {})
    filename = f"Relatorio_-_{params['idcompany']}_-_{date.today().isoformat()}.xlsx"
    save_excel_reports(
        filename,
        reports,
        company_col_map,
        conf.style,
        save_summaries=not params["no_summary"],
        blocked_cols=params["col_blocklist"],
    )


if __name__ == "__main__":
    parser = get_base_parser()
    parser.add_argument(
        "--price-groups", type=int, nargs="+", required=True, help="grupos de precificação que entrarão no relatório"
    )
    parser.add_argument(
        "--group-lookback",
        type=int,
        default=30,
        help="número de dias retroativos nos quais serão buscadas precificações",
    )
    parser.add_argument(
        "--agg-order",
        type=str,
        nargs="+",
        required=True,
        help=(
            "hierarquia para agregar relatórios. "
            "Ordem: do mais genérico para o mais específico. "
            "Deve estar contida em --group-granularity"
        ),
    )
    parser.add_argument(
        "--no-summary", action="store_true", help="não salvar resumos (tabelas de erro e consolidado) dos relatórios"
    )
    args = parser.parse_args()

    extra_agg = sorted(set(args.agg_order) - set(args.group_granularity).union(set(args.group_info)))
    if extra_agg:
        raise ValueError(
            (
                f"Hierarquia precisa estar contida na granularidade de grupos ou group_info. "
                f"Valores sobrando: {extra_agg}"
            )
        )

    filtros = {}
    if args.filters_json is not None:
        with open(args.filters_json, "r", encoding="utf-8") as f:
            filtros = json.load(f)

    print(f"Filtros:\n{filtros = }")

    with open("company_col_map.yaml", "r", encoding="utf-8") as f:
        col_map = yaml.safe_load(f)
    print(col_map)

    col_blocklist = None
    if args.col_blocklist is not None:
        with open(args.col_blocklist, "r", encoding="utf-8") as f:
            col_blocklist = yaml.safe_load(f)
        print(col_blocklist)

    params = {
        "idcompany": args.id_company,
        "price_groups": args.price_groups,
        "gran": args.granularity,
        "group_gran": args.group_granularity,
        "filtros": filtros,
        "clean_data": args.clean_data,
        "col_map": col_map,
        "group_lookback": args.group_lookback,
        "lookback": args.lookback,
        "interval": args.interval,
        "lookforward": args.lookforward,
        "last_price_lookback": args.last_price_lookback,
        "agg_order": args.agg_order,
        "no_summary": args.no_summary,
        "keep_quantity_na": args.keep_quantity_na,
        "col_blocklist": col_blocklist,
        "only_date": args.only_date,
        "preco": args.preco,
        "product_info": args.product_info,
        "group_info": args.group_info,
    }

    t = time.time()
    with config.getDadosAWSSession(args.env) as aws:
        print("\nConexao estabelecida com sucesso.\n")
        main(aws, params)

    print(f"Levaram {(time.time() - t)/60:.2f} mins para executar tudo.")
