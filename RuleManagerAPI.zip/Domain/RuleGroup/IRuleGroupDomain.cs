﻿using Domain.Models;

namespace Domain.RuleGroup
{
    public interface IRuleGroupDomain
    {
        Task<long> GetRuleGroupIdByName(long companyId, string name);
        Task<RuleGroupResponse> GetRuleGroupById(long companyId, long id);

        IEnumerable<RuleGroupGetAllResponse> GetAllRuleGroupByCompanyId(long companyId);
    }
}