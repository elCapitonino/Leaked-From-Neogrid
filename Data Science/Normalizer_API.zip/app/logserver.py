

class LogServer:

    def log_norm_serv(self):
        try:
            with open('nohup.out', 'r') as f:
                lines = f.read().splitlines()

                return lines[len(lines)-100:len(lines)]
        except Exception as e:
            return e
