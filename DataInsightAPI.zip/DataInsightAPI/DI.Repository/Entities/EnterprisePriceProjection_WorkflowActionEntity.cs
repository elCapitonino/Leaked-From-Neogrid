﻿namespace DI.Repository.Entities
{
    public sealed class EnterprisePriceProjection_WorkflowActionEntity : BaseNoKeyEntity
    {
        public long EnterprisePriceProjection_WorkflowActionId { get; set; }

        public long PriceProjection_WorkflowId { get; set; }

        public long WorkflowActionId { get; set; }

        public bool ToSendERP { get; set; } = false;

        public int Action { get; set; }

        public int UserType { get; set; }

        public string? UserId { get; set; }
        public string ActionResult
        {
            get
            {
                if (Action == 0)
                    return "Aprovado";
                else if (Action == 1)
                    return "Reprovado";
                else if (Action == 2)
                    return "Escalado";
                else
                    return "";
            }
        }
        public bool IsDeleted { get; set; }
    }


}
