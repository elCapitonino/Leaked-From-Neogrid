﻿using Domain.Models;
using Newtonsoft.Json.Linq;

namespace Domain.Utils
{
    public static class CopilotResponseExtension
    {
        public static IEnumerable<CopilotOperationRuleGroupRuleValueFront> GenerateParameters(this JObject? obj)
        {
            if (obj == null || obj.Type == JTokenType.Array)
                yield break;

            foreach (var param in obj.Properties())
            {
                CopilotOperationRuleGroupRuleValueFront value = new CopilotOperationRuleGroupRuleValueFront(param.Name);

                switch (param.Value.Type)
                {
                    case JTokenType.String:

                        throw new NotImplementedException();

                    case JTokenType.Float:
                    case JTokenType.Integer:
                        value.DecimalValue = param.ToObject<float>();
                        yield return value;
                        break;

                    case JTokenType.Boolean:
                        value.BooleanValue = param.ToObject<bool>();
                        yield return value;
                        break;

                    case JTokenType.Array:

                        if (value.StringValue == "SELLERNAME")
                        {
                            foreach (var seller in param.Value)
                            {
                                yield return new CopilotOperationRuleGroupRuleValueFront($"SELLERNAME;{seller.Value<string>()}");
                            }
                        }
                        else if (value.StringValue == "WeekDay")
                        {
                            foreach (var seller in param.Value)
                            {
                                yield return new CopilotOperationRuleGroupRuleValueFront(seller.Value<string>()!);
                            }
                        }

                        break;
                }
            }
        }
    }
}
