# Relatório Geral

Relatório geral de adesão de preços e comparações de projeção de demanda.

## Como Usar

Há 3 scripts, todos compartilham alguns parâmetros (use -h para ajuda).

1. get_report_selected

    Uma sequência de IDs de grupos de precificação pré-selecionados são passados no parâmetro --price-groups. O relatório será gerado apenas em cima desses grupos usando a DataHoraCriacao como referência de data de precificação.

2. get_report_published

    Apenas os IDs de precificação marcados como publicados (Published = 1 na Enterprise_Price_Groups) são usados. PublishedDate é usado como referência de data de precificação.

3. get_report_published_agg

    Apenas os IDs de precificação marcados como publicados (Published = 1 na Enterprise_Price_Groups) são usados. PublishedDate é usado como referência de data de precificação. Além disso, os relatórios (um por grupo de precificação) serão agrupados e depois agregados. Os relatórios (sheets no Excel) terão links para sheets filhas e um botão 'Voltar' para voltar para a sheet mãe.

    Esse script requer que o ID da empresa esteja na constante CONF do módulo report_conf. Essa configuração define as agregações que serão aplicadas e sobre quais colunas elas serão aplicadas (ver classe AggregationStep), além do estilo do relatório, o qual pode ser aplicado por colunas, por substring de colunas e de forma geral (ver classe ReportStyle).

    **No momento, apenas esse script usa configurações dinâmicas de estilo.**

    Formatação: floats e floats porcentagem são formatados com 2 casas decimais (excel:save_excel_reports).
    - float: colunas do tipo float (pandas) são formatadas
    - float porcentagem: colunas com o símbolo definido em report.PCT_SIGN na string são formatadas


**Ver COMMANDS.md para exemplos registrados.**

## Configurando novas empresas

Há dois passos potencialmente necessários:

1. Configurar mapa para renomear colunas em company_col_map.yaml:

    Cada empresa deve ter um mapa de colunas a serem renomeadas sob chave com o seu ID company. Se não houver necessidade de renomear nenhuma coluna, não é preciso incluir nada.

2. Configurar agregação e estilo:

    _Opcional: apenas se for usar relatório agregado._

    Criar nova instância de ReportConfig em report_conf.py e colocá-la no dicionário CONFIGS sob o ID da empresa. Essas configurações devem conter as agregações a serem aplicadas sobre os relatórios bem como o estilo da planilha.
