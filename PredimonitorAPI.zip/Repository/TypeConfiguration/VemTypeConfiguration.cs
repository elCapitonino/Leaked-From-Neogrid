﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using Repository.Attributes;
using Repository.DbContexts;
using Repository.Entity;
using MongoDB.EntityFrameworkCore.Extensions;

namespace Repository.TypeConfiguration
{
    [DbContextTypeConfiguration(typeof(NielsenDbContext))]
    public class VemTypeConfiguration : TypeConfigurationBase<VemEntity>, IEntityTypeConfiguration<VemEntity>
    {
        public override void Configure(EntityTypeBuilder<VemEntity> builder)
        {
            builder.ToTable("base_vem").ToCollection("base_vem");
        }
    }
}
