﻿using Repository.DbContexts;
using Repository.Entity;
using Repository.EntityRepository.Bases;

namespace Repository.EntityRepository
{
    public class ProductMarketResultSellerRepository : GenericRepository<ProductMarketResultSellerEntity, long>, IProductMarketResultSellerRepository
    {
        public ProductMarketResultSellerRepository(ApplicationDbContext dbContext) : base(dbContext)
        {

        }
        public static string DbContextName => nameof(ApplicationDbContext);
    }
}
