﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Repository.Attributes;
using Repository.DbContexts;
using Repository.Entity;

namespace Repository.TypeConfiguration
{
    [DbContextTypeConfiguration(typeof(ApplicationDbContext))]
    public class CompanyConfigurationTypeConfiguration : TypeConfigurationBase<CompanyConfigurationEntity>, IEntityTypeConfiguration<CompanyConfigurationEntity>
    {
        public override void Configure(EntityTypeBuilder<CompanyConfigurationEntity> builder)
        {
            builder.ToTable("EmpresaConfiguracoes");
            builder.Property(x => x.Id).HasColumnName("IdConfiguracao");
            builder.Property(x => x.CompanyId).HasColumnName("IdEmpresa");
            builder.Property(x => x.IsDeleted).HasColumnName("IsDeletado");
            builder.Property(x => x.CreateDate).HasColumnName("DataHoraCriacao");
            builder.Property(x => x.UpdateDate).HasColumnName("DataHoraUltimaAlteracao");
        }
    }
}
