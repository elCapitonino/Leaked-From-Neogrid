﻿using PredifyClientAPI.Services.DataInsightAPI.Enums;

namespace PredifyClientAPI.Services.DataInsightAPI.DataImpact.Models
{
    public sealed class GranularityGroupResponse
    {
        public Guid Id { get; set; }

        public EGranularityType GranularityType { get; set; }

        public string? Description { get; set; }

        public IEnumerable<GranularityLevelResponse>? GranularityLevels { get; set; }
    }
}
