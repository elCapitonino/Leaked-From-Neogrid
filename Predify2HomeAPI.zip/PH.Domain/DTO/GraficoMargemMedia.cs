﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PH.Domain.DTO
{
    public class GraficoMargemMedia
    {
        public int Week { get; set; }    
        public int Year { get; set;}
        public decimal? Margin { get; set; }
        public string Description { get; set; }   
        public string Category { get; set; }   
        public string SubCategory { get; set; }   
    }
}
