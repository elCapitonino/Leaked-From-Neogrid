﻿namespace DI.Domain.Services.Interfaces.Reports
{
    public interface IGenerateImpactReportExcelFileService
    {
        Task<MemoryStream> Generate(ValueObjects.ImpactReport data, CancellationToken cancellation);
    }
}
