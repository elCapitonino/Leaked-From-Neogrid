"""
Adapted from https://github.com/iamsinghrajat/async-cache
"""

import datetime
from collections import OrderedDict

from pympler import asizeof

from logger import logger


def get_key(args, kwargs):
    """Obtém a chave para salvar chamada no cache. Apenas kwargs entram na chave."""
    kwargs = kwargs.copy()
    kwargs = {k: kwargs[k] for k in sorted(kwargs)}
    logger.debug("cache key: %s", kwargs)
    return f"{kwargs}"


# NOTE maxsize em bytes
class LRU(OrderedDict):
    def __init__(self, maxsize, *args, **kwargs):
        self.maxsize = maxsize
        self.sizes = {}
        super().__init__(*args, **kwargs)

    def __getitem__(self, key):
        value = super().__getitem__(key)
        self.move_to_end(key)
        return value

    def __setitem__(self, key, value):
        logger.debug("pre insert cache size: %s", len(self))
        size = asizeof.asizeof(value)
        if self.maxsize and size >= self.maxsize:
            return
        super().__setitem__(key, value)
        self.sizes[key] = size
        while self.maxsize and len(self) > self.maxsize:
            oldest = next(iter(self))
            self.remove(oldest)
        logger.debug("post insert cache size: %s", len(self))

    def __len__(self):
        return sum(self.sizes.values())

    def remove(self, key) -> None:
        try:
            del self[key]
            del self.sizes[key]
        except KeyError:
            logger.error("cache error: key not found: %s", key)


class AsyncTTL:
    class _TTL(LRU):
        def __init__(self, time_to_live, maxsize):
            super().__init__(maxsize=maxsize)

            self.time_to_live = datetime.timedelta(seconds=time_to_live) if time_to_live else None

            self.maxsize = maxsize

        def __contains__(self, key):
            if key not in self.keys():
                return False
            key_expiration = super().__getitem__(key)[1]
            if key_expiration and key_expiration < datetime.datetime.now():
                self.remove(key)
                return False
            return True

        def __getitem__(self, key):
            value = super().__getitem__(key)[0]
            return value

        def __setitem__(self, key, value):
            ttl_value = (datetime.datetime.now() + self.time_to_live) if self.time_to_live else None
            super().__setitem__(key, (value, ttl_value))

    def __init__(self, time_to_live=60, maxsize=1024, skip_args: int = 0):
        """
        :param time_to_live: Use time_to_live as None for non expiring cache
        :param maxsize: Use maxsize as None for unlimited size cache. Size in bytes.
        :param skip_args: Use `1` to skip first arg of func in determining cache key
        """
        self.ttl = self._TTL(time_to_live=time_to_live, maxsize=maxsize)
        self.skip_args = skip_args

    def __call__(self, func):
        async def wrapper(*args, use_cache=True, **kwargs):
            key = get_key(args[self.skip_args :], kwargs)
            if key in self.ttl and use_cache:
                val = self.ttl[key]
            else:
                val = await func(*args, **kwargs)
                if use_cache:
                    self.ttl[key] = val

            return val

        wrapper.__name__ += func.__name__

        return wrapper
