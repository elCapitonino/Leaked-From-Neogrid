

class ValidateProducts:
    def __init__(self):
        # self.pn = ProductsNomalized()
        # self.products_nomal = self.pn.get_products_nomal()
        # print(len(self.products_nomal))
        print(" ------ Inicio  validação ------ ")

    def validate_products(self, product):
        '''
        sem nome do produto = 0
        produto sem demais caracteristicas = 1

        '''
        # print(" ------------- Inicio validação produtos ------------- ")
        # print(" valida produrto : ", products)

        if(len(product["product"]) != 0):

            #print(product["product"], " produto valido ")

            return True, None

            # if (product["brands"] != None or product["materials"] != None or product["power"] != None or product["voltage"] != None or product["metric_units"] != None or product["dimensions"] != None or product["energy_source"] != None or product["size"] != None):
            #     # print('produto valido ------------------')

            #     return True, None

            # if(product["brands"] == None and product["materials"] == None and product["power"] == None and product["voltage"] == None and product["metric_units"] == None and product["dimensions"] == None and product["energy_source"] == None and product["size"] == None):
            #     # print('produto invalido ################### 1',)
            #     return False, 1

        if(len(product["product"]) == 0):

            # print('produto invalido ################### 2')

            return False, 0
    ''' 
    def checks_ean(self, products_normalized, ean):

        # print("ean", ean, " - ", i["ean"])
        for i in products_normalized:
            if(ean == i["ean"]):
                # print("i[ean]", i["ean"])

                return i["_id"]
    '''

    def checks_products_register(self, products_normalized, product):
        '''
            self.memory.products_normalized, products, ean, product_model
        '''
        #print("products_normalized", products_normalized)
        # ###################### EAN ################################
        ''' 
        if(product['ean'] != '' and product['ean'] != None):
            id_return = self.checks_ean(products_normalized, product['ean'])
            # print("id_return EAN", id_return, " --- ",
            #     "products --- :", products, "brands", brands, "ean", ean)

            return id_return
        '''
        # ###################### Geral ################################
        for i in products_normalized:

            if(sorted(product["product"]) == sorted(i["product"]) and product['brands'] == i["brands"] and product['power'] == i["power"] and product['voltage'] == i["voltage"] and sorted(product['metric_units']) == sorted(i["metric_units"]) and product['dimensions'] == i["dimensions"] and product['energy_source'] == i["energy_source"] and product['size'] == i["size"] and product['language'] == i["language"]):
                # print(i["_id"])
                return i["_id"]
        #print("produto novo")
        return None
