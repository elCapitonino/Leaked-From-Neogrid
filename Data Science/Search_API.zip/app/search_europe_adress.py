from async_mongo import AsyncMongoConnect
from collections import defaultdict

class Search_Store_Address():
    
    def __init__(self):
        self.dbMongo = AsyncMongoConnect()

    async def get_lidl_addresses(self):
        mongo_docs = await self.dbMongo.get_lidl_addresses()

        addresses_by_country = defaultdict(list)
        for doc in mongo_docs:
            product_local = doc.get("product_local")
            if product_local:
                country = product_local.get("country")
                if country:
                    product_local["product_link"] = doc.get("product_link")
                    addresses_by_country[country].append(product_local)

        result = []
        count_by_country = {}
        for country, addresses in addresses_by_country.items():
            result.append({"country": country, "addresses": addresses})
            count_by_country[country] = len(addresses)

        return {"addresses": result, "counts": count_by_country}