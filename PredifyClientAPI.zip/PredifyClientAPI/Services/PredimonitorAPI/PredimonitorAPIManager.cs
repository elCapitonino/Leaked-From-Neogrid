﻿using Microsoft.Extensions.Options;
using PredifyClientAPI.Services.PredimonitorAPI.DynamicFilter;
using PredifyClientAPI.Services.PredimonitorAPI.Models;

namespace PredifyClientAPI.Services.PredimonitorAPI
{
    public class PredimonitorAPIManager
    {

        public PredimonitorAPIManager(HttpClient client, IOptions<PredimonitorAPIOptions> options)
        {
            DynamicFilterService = new DynamicFilterService(client);
        }

        public IDynamicFilterService DynamicFilterService { get; }

    }
}
