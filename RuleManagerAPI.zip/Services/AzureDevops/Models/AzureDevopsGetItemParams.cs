﻿namespace Services.AzureDevops.Models
{
    public sealed class AzureDevopsGetItemParams
    {
        public string ProjectId { get; set; }
        public string RepositoryId { get; set; }
        public string Path { get; set; }
    }
}
