﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Repository.Attributes;
using Repository.DbContexts;
using Repository.Entity;

namespace Repository.TypeConfiguration
{
    [DbContextTypeConfiguration(typeof(ApplicationDbContext))]
    public class MonitoringItemResultsStatusTypeconfiguration : TypeConfigurationBase<MonitoringItemResultsStatusEntity>, IEntityTypeConfiguration<MonitoringItemResultsStatusEntity>
    {
        public override void Configure(EntityTypeBuilder<MonitoringItemResultsStatusEntity> builder)
        {
            ConfigureTableName(builder, "MonitoringItem_ResultsStatus");

            builder.Property(p => p.Id).HasColumnName("IdMonitoringItem_ResultsStatus");
            builder.Property(p => p.CompanyId).HasColumnName("IdCompany").IsRequired();
            builder.Property(p => p.CurrentStep).IsRequired();
            builder.Property(p => p.Message).HasMaxLength(256);
            builder.Property(p => p.TaskId).IsRequired();
            builder.Property(p => p.Status).IsRequired();
            builder.HasOne(p => p.Company).WithMany().HasForeignKey(p => p.CompanyId);
        }
    }
}
