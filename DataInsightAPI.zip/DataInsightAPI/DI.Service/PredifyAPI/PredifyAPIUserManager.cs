﻿using DI.Service.PredifyAPI.Access;
using DI.Service.PredifyAPI.Empresa;
using DI.Service.PredifyAPI.Models;
using Microsoft.Extensions.Options;
using System.Net.Http.Headers;

namespace DI.Service.PredifyAPI
{
    public class PredifyAPIUserManager
    {
        private readonly HttpClient client;

        public PredifyAPIUserManager(HttpClient client, IOptions<PredifyAPIOptions> options)
        {
            EmpresaService = new EmpresaService(client);
            AccessService = new AccessService(client);
            this.client = client;
        }

        public void SetAuthorization(string token) => client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
        public IEmpresaService EmpresaService { get; }
        public IAccessService AccessService { get; }
    }
}
