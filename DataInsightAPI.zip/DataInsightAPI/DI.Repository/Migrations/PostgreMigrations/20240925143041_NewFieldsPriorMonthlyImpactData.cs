﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DI.Repository.Migrations.PostgreMigrations
{
    /// <inheritdoc />
    public partial class NewFieldsPriorMonthlyImpactData : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<decimal>(
                name: "PriorCost",
                table: "MonthlyImpactData",
                type: "numeric(18,2)",
                nullable: false,
                defaultValue: 0m);

            migrationBuilder.AddColumn<decimal>(
                name: "PriorDemand",
                table: "MonthlyImpactData",
                type: "numeric(18,2)",
                nullable: false,
                defaultValue: 0m);

            migrationBuilder.AddColumn<decimal>(
                name: "PriorProfit",
                table: "MonthlyImpactData",
                type: "numeric(18,2)",
                nullable: false,
                defaultValue: 0m);

            migrationBuilder.AddColumn<decimal>(
                name: "PriorRevenue",
                table: "MonthlyImpactData",
                type: "numeric(18,2)",
                nullable: false,
                defaultValue: 0m);

            migrationBuilder.AddColumn<decimal>(
                name: "PriorRoyalty",
                table: "MonthlyImpactData",
                type: "numeric(18,2)",
                nullable: false,
                defaultValue: 0m);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "PriorCost",
                table: "MonthlyImpactData");

            migrationBuilder.DropColumn(
                name: "PriorDemand",
                table: "MonthlyImpactData");

            migrationBuilder.DropColumn(
                name: "PriorProfit",
                table: "MonthlyImpactData");

            migrationBuilder.DropColumn(
                name: "PriorRevenue",
                table: "MonthlyImpactData");

            migrationBuilder.DropColumn(
                name: "PriorRoyalty",
                table: "MonthlyImpactData");
        }
    }
}
