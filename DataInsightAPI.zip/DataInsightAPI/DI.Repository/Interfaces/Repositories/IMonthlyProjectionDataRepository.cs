﻿using DI.Repository.Entities;
using DI.Repository.Enum;

namespace DI.Repository.Interfaces.Repositories
{
    public interface IMonthlyProjectionDataRepository
    {
        IEnumerable<MonthlyProjectionDataEntity> GetAll(long CompanyId, int startYearMonth, int endYearMonth, EGranularityType eGranularityType);
    }
}