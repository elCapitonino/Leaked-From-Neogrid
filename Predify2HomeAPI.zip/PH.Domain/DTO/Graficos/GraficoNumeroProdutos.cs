﻿namespace PH.Domain.DTO.Graficos
{
    public class GraficoNumeroProdutos
    {
        public int Ano { get; set; }
        public int Mes { get; set; }
        //public int Action { get; set; }
        public double Approved { get; set; }
        public double AdoptionSuggested { get; set; }
        public double RejectionSuggested { get; set; }
    }
}
