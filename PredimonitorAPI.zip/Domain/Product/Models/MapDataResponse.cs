using System;

namespace Domain.Product.Models
{
    public class MapDataDatabricksResponse
    {
        public string? Name { get; set; }
        public string? Seller { get; set; }
        public string? Address { get; set; }
        public string? Latitude { get; set; }
        public string? Longitude { get; set; }
        public string? UF { get; set; }
        public decimal AvgPrice { get; set; }
        public int AdsQuantity { get; set; }
    }

    public class MapDataResponse
    {
        public List<MapProductSellerPoints>? Products { get; set; }
        public IEnumerable<string?>? Sellers { get; set; }
        public List<MapStateData>? States { get; set; }
    }

    public class MapStateData
    {
        public string? UF { get; set; }
        public decimal AvgPrice { get; set; }
        public int SellerQuantity { get; set; }
        public int AdsQuantity { get; set; }
    }

    public class MapProductSellerPoints
    {
        public string? Name { get; set; }
        public string? Seller { get; set; }
        public string? Type { get; set; }
        public decimal Price { get; set; }
        public string? Address { get; set; }
        public int AdsQuantity { get; set; }
        public string? Latitude { get; set; }
        public string? Longitude { get; set; }
    }
}