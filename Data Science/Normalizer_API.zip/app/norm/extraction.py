import pandas as pd
import numpy as np
import re
import datetime
import pint


class Extraction:
    def __init__(self):
        date = datetime.date.today()
        self.year_current = date.strftime("%Y")
        pass

    def normalize_products(self, texto, product_dic):
        list_products = []
        for (k_product, v_synonym) in product_dic.items():
            prod = re.search(r"(^|\s)"+k_product+'($|\s|,)', texto)
            if prod:
                prod = prod.group()
                list_products.append(prod.strip())

                # return prod.strip(), prod.strip()
            for i in v_synonym:
                prod = re.search(r"(^|\s)"+i+'($|\s)', texto)
                if prod:
                    prod = prod.group()
                    list_products.append(prod.strip())

                    # return prod.strip(), k_product

        return sorted(list_products), sorted(list_products)

        '''
        for product_dic in products_ready:
            prod = re.search(r"(^|\s)"+product_dic+'($|\s)', texto)
            if prod:
                prod = str(prod.group())
                # Sinonimos
                for(k, v) in products_synonyms.items():
                    if k in prod:
                        # print(k, " -- ", v, " -- ", products)
                        # print("V", v)
                        return prod.strip(), v
                return prod.strip(), prod.strip()
        return None, None
        '''

    def normalize_brands(self, texto, brands_ready):
        '''
        - Busca a marca no texto
        - Retorna o nome da marca
        '''
        # print("brands_ready ", brands_ready)
        for k in brands_ready:
            brand = re.search(r"(^|\s)"+k+'($|\s)', texto)
            if brand:
                brand = brand.group()
                return brand.strip()
        return None

    def normalize_categories(self, products, categories_ready):

        # print("categories_ready ", categories_ready)
        if products != None:
            for (k, v) in categories_ready.items():
                for i in v:
                    if i in products:
                        # print(k, " ----- ", i, " -- --- ", v)

                        return k
            return None

    def normalize_materials(self, texto, materials_ready):

        for (k, v) in materials_ready.items():
            for i in v:
                m = re.search(r"(^|\s)"+i+'($|\s)', texto)

                if m:
                    # print("k : ", k, " i : ", i, " m ", m.group())

                    return m.group(), k.strip()
        return None, None

    def normalize_voltage(self, texto, voltage_ready):
        result_voltagem_leftover = []
        result_voltagem = []
        for (k, v) in voltage_ready.items():
            for i in v:
                # print(i, " -- ", k, " -- ", v)
                # x = re.search(r"(^|\s)"+i+'[vV]*($|\s)' "|\s"+i, texto)
                x = re.search(r"(^|\s)"+i+'[vV]*($|\s)', texto)
                if x:
                    x = str(x.group())
                    # print("voltagem ", x, " -- ", k)
                    result_voltagem.append(k)
                    result_voltagem_leftover.append(x.strip())

        if '127' in result_voltagem and '220' in result_voltagem:
            return result_voltagem_leftover, "bivolt"
        if '220' in result_voltagem:
            return result_voltagem_leftover, "220"
        if '127' in result_voltagem:
            return result_voltagem_leftover, "127"
        if 'bivolt' in result_voltagem:
            return result_voltagem_leftover, "bivolt"
        if result_voltagem_leftover != []:
            return result_voltagem_leftover, k
        return None, None

    def normalize_metric_units(self, texto, metric_units_ready):
        list_result_mm = []
        trash = []
        for (k, v) in metric_units_ready.items():
            for i in v:
                # mm = re.search(
                #     "\s[0-9]{1,}([.,][0-9]{1,})?([0-9]{1,}([.,][0-9]{1,})?)?( *)?"+i+'($|\s|,)', texto)
                mm = re.findall(
                    r'([0-9,]+\s*'+i+')(?:[^a-z]|$)', texto, re.I | re.S)
                if len(mm) != 0:
                    trash = trash + mm
                    result_mm = [metrics.replace(i, k) for metrics in mm]
                    result_mm = [re.sub(r'\s', '', metrics)
                                 for metrics in result_mm]
                    list_result_mm = list_result_mm + result_mm

        return trash, sorted(set(list_result_mm))

    def normalize_power(self, texto, power_ready):

        # print(texto)

        for (k, v) in power_ready.items():
            for i in v:
                # print(i, " -- ", k, " -- ", v)
                p = re.search(
                    r"\s[0-9]*"+i+'($|\s)' "|\s[0-9]*[,./][0-9]*"+i+'($|\s)', texto)

                if p:
                    # print(p)
                    p = p.group()
                    p_leftover = p
                    p = p.replace(i, k)
                    # print("power ", p, " -k ", k, " -i ", i)

                    if "," in p:
                        p_leftover = p_leftover.replace(",", " ")
                        # print("leftover_power : ", p_leftover)
                        return p_leftover.strip(), p.strip()
                    if "." in p:
                        p_leftover = p_leftover.replace(".", " ")
                        return p_leftover.strip(), p.strip()
                    if "/" in p:
                        p_leftover = p_leftover.replace("/", " ")
                        return p_leftover.strip(), p.strip()
                    return p_leftover.strip(), p.strip()

                # print("power teste ", leftover_power)
                # print(p)
        return None, None

    def normalize_dimensions(self, texto, dimensions_ready):

        for (k, v) in dimensions_ready.items():
            for i in v:
                d_dimensions = re.search('(^|\s)[0-9]{1,}([.,][0-9]*)?(\s*)?'+i +
                                         '((\s*)?[0-9]{1,}([.,][0-9]*)?(\s*)?('+i+'(\s*)?[0-9]*([.,][0-9]*)?)?)', texto)
                if d_dimensions is None and i == "mm":
                    d_dimensions = re.search(
                        '(\d+\.)?((?:[1-9][0-9]*|0)\/[1-9][0-9]*|[\d]+('+i+')?)(\s)?[Xx]+((\s)?(\d+\.)?((?:[1-9][0-9]*|0)\/[1-9][0-9]*|[\d]+('+i+')?))', texto)

                if d_dimensions:
                    only_dimensions = str(d_dimensions.group())
                    valorDoNegocio = []
                    if (i == "mm"):
                        d_dimensions = only_dimensions.split("x")
                        for palavra in d_dimensions:
                            valorDoNegocio.append(
                                self.unity_dimensions_calculus(palavra))
                    if (len(valorDoNegocio) > 0):
                        d_dimensions = " x ".join(valorDoNegocio)
                    else:
                        d_dimensions = str(d_dimensions.group())
                    d_dimensions_s_space = d_dimensions.replace(" ", "")
                    return only_dimensions.strip(), d_dimensions_s_space.strip()
        return None, None

    def unity_dimensions_calculus(self, str_number: str) -> str:
        calculo = 0
        fracao = 0
        numeroInteiro = 0
        only_number = re.sub("[a-zA-Z]", "", str_number)
        if (only_number == ''):
            return str_number
        if (only_number.startswith("0")):
            only_number = only_number[1:]

        if (str_number == "0"):
            return str_number
        if ((not re.match('(?:[1-9][0-9]*|0)\/[1-9][0-9]*', str_number) or re.match("mm", str_number))):
            return str_number
        if (eval(only_number) >= 10):
            return str_number

        if ("." in str_number):
            numeros = str_number.split(".")
            numeroInteiro = numeros[0]
            fracao = eval(numeros[1])
            calculo = int(numeroInteiro) + fracao
        elif ("/" in str_number):
            teste = str_number.split("/")
            if (int(teste[0]) > int(teste[1])):
                lista_de_numeros = [numero for numero in teste[0]]
                # Retira o ultimo pq faz parte da fração, caso exista mais de um
                if (len(lista_de_numeros) > 1):
                    lista_de_numeros.pop()
                    numeroInteiro = ''.join(lista_de_numeros)
                    if (str_number.startswith(numeroInteiro)):
                        fracao = eval(str_number[len(numeroInteiro):])
                        calculo = int(numeroInteiro) + fracao
                # Senão, é apenas uma fração
                else:
                    calculo = eval(str_number)
        ureg = pint.UnitRegistry()
        if (calculo == 0):
            calculo: int = eval(only_number)
        if (calculo > 0):
            milimiterValue = (calculo * ureg.inch).to('mm')
            return str(round(milimiterValue.magnitude, 2)) + "mm"
        return str_number
        '''
        d = re.search('(^|\s)[0-9]{1,}([.,][0-9]*)?(\s*)?'+i +
                              '((\s*)?[0-9]{1,}([.,][0-9]*)?(\s*)?('+i+'(\s*)?[0-9]*([.,][0-9]*)?)?)*($|\s)', texto)

        if d:
            if "," in d.group():
                leftover_d = d.group().replace(",", " ")
                return leftover_d, d.group().replace(" ", "")
            if "." in d.group():
                leftover_d = d.group().replace(".", " ")
                return leftover_d, d.group().replace(" ", "")

            return d.group().strip(), d.group().replace(" ", "").strip()
            # d = d.group().replace(" ", "")
            # d = d.strip("[']")
            # print(d)
            # print(d.group(), " -- ", d.group().replace(" ", ""))

        return None, None
    '''

    def normalize_energy_source(self, texto, energy_source_ready):

        for (k, v) in energy_source_ready.items():
            for i in v:
                if i in texto:
                    x = re.findall(r"\s"+i+'\s' '|^'+i+'\s' '|\s'+i+'$', texto)

                    if x:
                        x = str(x)
                        x = x.strip("[']")
                        # print("energia x ", x, " -- k ", k)
                        return x.strip(), k.strip()

        return None, None

    def normalize_size(self, texto, size_ready):

        for (k, v) in size_ready.items():
            for i in v:
                x = re.search(r"(^|\s)"+i+'($|\s)', texto)
                if x:
                    x = str(x.group())

                    return x.strip(), k.strip()

        return None, None

    def normalize_leftover_unique(self, texto, leftover_):
        """_summary_

        Args:
            texto (string): Descrição do produto
            leftover_ (string): atributo identificado pelo regex para remover da descrição

        Returns:
            string: restante da descrição do produto
        """
        if type(leftover_) == str:
            texto = texto.replace(leftover_, " ")
            # regex_text = leftover_+'(:?$|\s)'
            # texto = re.sub(regex_text, ' ', texto)
        if type(leftover_) == list:
            for leftover in leftover_:
                texto = texto.replace(leftover, " ")
                # regex_text = leftover + '(:?$|\s)'
                # texto = re.sub(regex_text, ' ', texto)

        return texto.strip()

    def normalize_state(self, state_texto, state_ready):
        """_summary_

        Args:
            state_texto (_type_): estado para normalizar
            state_ready (_type_): dicionário com estados normalizados, nomes e siglas

        Returns:
            _type_:  estado normalizado, se encontado no dicionário
        """

        for (k, v) in state_ready.items():
            for i in v:
                if i in state_texto:
                    x = re.findall(r'^'+i+'$', state_texto)

                    if x:
                        return k
        return None

    def normalize_hours(self, hours):
        """_summary_

        Args:
            hours (_type_): horas para normalizar e validar

        Returns:
            _type_: horas normalizadas e validadas
        """
        x = re.findall(r'^\d*$', str(hours))
        if x:
            return hours
        return None

    def normalize_year(self, year):
        """_summary_

        Args:
            year (_type_): ano para normalizar e validar

        Returns:
            _type_: ano normalizado e validado
        """
        if len(str(year)) <= 2:
            # print("ano 2 :", year)
            if (year < 25):
                year += 2000
            else:
                year += 1900

        x = re.findall(r'^\d{4}$', str(year))
        if (x != [] and len(x[0]) == 4):
            if (int(1900) < int(x[0]) <= int(self.year_current)):
                return x[0]
            return None
        return None

    def normalize_category_dafiti(self, category):
        list = ["feminino", "masculino", "infantil"]

        for i in list:
            if i in category:
                if i == "feminino":
                    return "feminina"
                if i == "masculino":
                    return "masculina"
                if i == "infantil":
                    return "infantil"

                return None

    # def normalize_leftover(self, texto, products, brands,
    #                        materials, voltage, metric_units, power, dimensions, energy_source_leftover, size_leftover):
    #     if products:
    #         texto = texto.replace(products, " ")
    #     if brands:
    #         texto = texto.replace(brands, " ")
    #     if materials:
    #         texto = texto.replace(materials, " ")
    #     if voltage:
    #         for i in voltage:
    #             texto = texto.replace(i, " ")
    #     if metric_units:
    #         texto = texto.replace(metric_units, " ")
    #     if power:
    #         texto = texto.replace(power, " ")
    #     if dimensions:
    #         texto = texto.replace(dimensions, " ")
    #     if energy_source_leftover:
    #         texto = texto.replace(energy_source_leftover, " ")
    #     if size_leftover:
    #         texto = texto.replace(size_leftover, " ")
    #     return texto.strip()
