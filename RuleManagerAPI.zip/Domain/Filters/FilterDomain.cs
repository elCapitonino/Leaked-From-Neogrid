﻿using AutoMapper;
using Domain.Models;
using Microsoft.EntityFrameworkCore;
using Repository.UnitOfWork;
using Services.PredifyAPI;

namespace Domain.Filters
{
    public class FilterDomain : IFilterDomain
    {
        private readonly IUnitOfWork _uow;
        private readonly IMapper _mapper;
        private readonly PredifyAPIUserManager _predifyAPIUserManager;

        public FilterDomain(PredifyAPIUserManager predifyAPIUserManager, IUnitOfWork uow, IMapper mapper)
        {
            _uow = uow;
            _mapper = mapper;
            _predifyAPIUserManager = predifyAPIUserManager;
        }

        public async Task<List<DefaultFilterResponse>> GetFiltersByCompanyId(long companyId)
        {
            if (!await _predifyAPIUserManager.AccessService.UserHasAccess(companyId))
                throw new UnauthorizedAccessException($"Acesso não autorizado a empresa {companyId}");

            var entities = _uow.DefaultFilterRepository.GetAll()
                .Where(x => x.IdCompany == companyId && x.IsDeleted == false)
                .Include(x => x.Values.Where(y => y.IsDeleted == false));

            var responses = _mapper.Map<List<DefaultFilterResponse>>(entities);

            return responses;
        }

        public async Task<List<string>> GetSellerFiltersByCompanyId(long companyId)
        {
            if (!await _predifyAPIUserManager.AccessService.UserHasAccess(companyId))
                throw new UnauthorizedAccessException($"Acesso não autorizado a empresa {companyId}");

            var sellerName = _uow.ProductMarketResultSellerRepository.GetAll()
                .Where(x => x.CompanyId == companyId).Select(x => x.SellerName);

            return await sellerName.ToListAsync();
        }
    }
}
