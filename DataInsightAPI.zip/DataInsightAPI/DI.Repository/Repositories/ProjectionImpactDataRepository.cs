﻿using DI.Repository.Attributes;
using DI.Repository.Contexts;
using DI.Repository.Entities;
using DI.Repository.Interfaces.Repositories;
using DI.Repository.Repositories.Base;

namespace DI.Repository.Repositories
{
    [UsePostgreContext]
    public sealed class ProjectionImpactDataRepository : PostgreGenericNoModifyRepository<ProjectionImpactDataEntity>, IProjectionImpactDataRepository
    {
        public ProjectionImpactDataRepository(PostgreContext dbContext) : base(dbContext)
        {
        }

        public IEnumerable<ProjectionImpactDataEntity> GetAllByPriceGroupId(long priceGroupId)
        {
            return _dbContext
                .Set<ProjectionImpactDataEntity>()
                .Where(x => x.PriceGroupId == priceGroupId);
        }

        public IEnumerable<ProjectionImpactDataEntity> GetAllByPriceGroupId(List<long> priceGroupId)
        {
            return _dbContext
                .Set<ProjectionImpactDataEntity>()
                .Where(x => priceGroupId.Contains(x.PriceGroupId));
        }
    }
}
