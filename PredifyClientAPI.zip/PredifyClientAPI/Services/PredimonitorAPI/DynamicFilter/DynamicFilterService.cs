﻿using Newtonsoft.Json;
using PredifyClientAPI.Services.PredimonitorAPI.DynamicFilter.Models;
using System.Text;

namespace PredifyClientAPI.Services.PredimonitorAPI.DynamicFilter
{
    public class DynamicFilterService : IDynamicFilterService
    {
        private readonly HttpClient _client;

        public DynamicFilterService(HttpClient client)
        {
            _client = client;
        }

        public async Task<DynamicFilterResponse> GetFilter(long companyId, DynamicFilterRequest request)
        {
            string jsonPayload = JsonConvert.SerializeObject(request);

            StringContent payload = new StringContent(jsonPayload, Encoding.UTF8, "application/json");

            var response = await _client.PostAsync($"/api/DynamicFilter/GetFilter?companyId={companyId}", payload);
            var content = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
                return JsonConvert.DeserializeObject<DynamicFilterResponse>(content);
            else if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                throw new UnauthorizedAccessException();

            throw new Exception(content);
        }

        public async Task<List<SeeResultResponse>> GetResult(ResultFilterRequest request)
        {
            string jsonPayload = JsonConvert.SerializeObject(request);

            StringContent payload = new StringContent(jsonPayload, Encoding.UTF8, "application/json");

            var response = await _client.PostAsync($"/api/DynamicFilter/GetResult", payload);
            var content = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
                return JsonConvert.DeserializeObject<List<SeeResultResponse>>(content);
            else if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                throw new UnauthorizedAccessException();

            throw new Exception(content);
        }
    }
}
