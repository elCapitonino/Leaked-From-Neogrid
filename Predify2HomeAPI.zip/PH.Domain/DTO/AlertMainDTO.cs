﻿namespace PH.Domain.DTO
{
    public class AlertMainDTO
    {
        public AlertDTO MarginCard { get; set; }
        public AlertDTO ProfitVariation { get; set; }
        //public AlertDTO PsicologyPriceCard { get; set; }
        public AlertDTO CompetitorPriceCard { get; set; }
    }

    public class AlertDTO
    {
        public AlertDTO(string cardType)
        {
            CardType = cardType;
            Products = new List<AlertProductDTO>();
        }
        public string CardType { get; set; }
        public int CardValue { get; set; }
        public List<AlertProductDTO> Products { get; set; }
    }

    public class AlertProductDTO
    {
        public string ProductName { get; set; }
        public decimal Data { get; set; }
        public long IdEnterprisePricesProjection { get; set; }
        public long IdEnterprisePriceGroup { get; set; }
    }
}
