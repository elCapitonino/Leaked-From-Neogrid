﻿using Microsoft.Extensions.Options;
using PredifyClientAPI.Services.PredifyAPI.Access;
using PredifyClientAPI.Services.PredifyAPI.Empresa;
using PredifyClientAPI.Services.PredifyAPI.Models;

namespace PredifyClientAPI.Services.PredifyAPI
{
    public class PredifyAPISystemManager
    {

        public PredifyAPISystemManager(HttpClient client, IOptions<PredifyAPIOptions> options)
        {
            EmpresaService = new EmpresaService(client);
            AccessService = new AccessService(client);
        }

        public IEmpresaService EmpresaService { get; }

        public IAccessService AccessService { get; }

    }
}
