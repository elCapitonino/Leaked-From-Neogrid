﻿namespace DI.Repository.Entities
{
    public sealed class MonthlyProjectionDataEntity : BaseEntity
    {
        public required long CompanyId { get; set; }
        public Guid GranularityGroupId { get; set; }
        public GranularityGroupEntity? GranularityGroup { get; set; }
        public string? ProductId { get; set; }
        public required int YearMonth { get; set; }
        public string? MajorGranularity { get; set; }
        public string? ConsolidateGroupBy { get; set; }

        public int AdoptionCount { get; set; }
        public int NotAdoptionCount { get; set; }
        public int PricingCount { get; set; }
        public int ApprovedCount { get; set; }
        public decimal Demand { get; set; }
        public decimal Revenue { get; set; }
        public decimal Profit { get; set; }
        public decimal DemandNotProjected { get; set; }
        public decimal RevenueNotProjected { get; set; }
        public decimal ProfitNotProjected { get; set; }
    }
}
