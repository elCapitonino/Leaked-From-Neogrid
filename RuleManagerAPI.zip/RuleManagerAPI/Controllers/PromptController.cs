﻿using Domain.Copilot;
using Domain.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace RuleManagerAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class PromptController : ControllerBase
    {
        private readonly ILogger<PromptController> _logger;
        private readonly ICopilotDomain _domain;
        public PromptController(ICopilotDomain domain, ILogger<PromptController> logger)
        {
            _logger = logger;
            _domain = domain;
        }

        [HttpGet]
        [Route("GetAvailable")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(long))]
        [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status401Unauthorized, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
        public async Task<IActionResult> GetAvailablePrompts()
        {
            try
            {
                return Ok(await _domain.GetAvailablePrompts());
            }
            catch (NotFoundException ex)
            {
                _logger.LogError(ex, "{Message}", ex.Message);
                return NotFound(ex.Message);
            }
            catch (UnauthorizedAccessException ex)
            {
                _logger.LogError(ex, "{Message}", ex.Message);
                return Unauthorized(ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "{Message}", ex.Message);
                return BadRequest(ex.Message);
            }
        }
    }
}
