﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using PH.Domain.Domain;
using PH.Domain.DTO;
using PH.Domain.Interfaces.Repositories;
using PH.Domain.Interfaces.Services;
using Spire.Xls;
using System.Globalization;
using System.Text.RegularExpressions;

namespace PH.Service.Services
{
    public class AcaoPromocionalServices : IAcaoPromocionalServices
    {
        private readonly ILogger<AcaoPromocionalServices> _logger;
        private readonly IAcaoPromocionalRepository _acaoPromocionalRepository;
        private readonly IMemoryCache _memoryCache;
        private readonly IMapper _mapper;
        private readonly ICacheControlService _cacheControlService;

        public AcaoPromocionalServices(ILogger<AcaoPromocionalServices> logger,
                               IAcaoPromocionalRepository AcaoPromocionalRepository,
                               IMemoryCache memoryCache,
                               IMapper mapper,
                               ICacheControlService cacheControlService)
        {
            _logger = logger;
            _acaoPromocionalRepository = AcaoPromocionalRepository;
            _memoryCache = memoryCache;
            _mapper = mapper;
            _cacheControlService = cacheControlService;
        }

        public async Task Add(AcaoPromocional acaoPromocional)
        {
            _logger.LogInformation("Service: adicionando AcaoPromocional");

            try
            {
                await _acaoPromocionalRepository.Add(acaoPromocional);
                _memoryCache.Remove("AcaoPromocional");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Service: erro ao adicionar AcaoPromocional. {ex.Message}");
                throw;
            }
        }

        public async Task<AcaoPromocionalMainResponseDTO> GetAll(long idCompany)
        {
            _logger.LogInformation("Service: buscando todos os AcaoPromocional");

            try
            {
                AcaoPromocionalMainResponseDTO response = (AcaoPromocionalMainResponseDTO)_memoryCache.Get("AcaoPromocional");

                //if (response == null)
                //{
                response = new AcaoPromocionalMainResponseDTO();
                var acoesPromocionais = await _acaoPromocionalRepository.GetAll();
                var currentActions = acoesPromocionais.Where(c => DateTime.Now >= c.StartDate && DateTime.Now <= c.EndDate && c.IdCompany == idCompany).ToList();
                var nextActions = acoesPromocionais.Where(c => c.StartDate >= DateTime.Now && c.EndDate >= DateTime.Now && c.IdCompany == idCompany).ToList();

                response.CurrentActions = _mapper.Map<List<AcaoPromocionalResponseDTO>>(currentActions);
                response.NextActions = _mapper.Map<List<AcaoPromocionalResponseDTO>>(nextActions);

                _cacheControlService.SettingTimeAndCache(response, "AcaoPromocional");
                // }

                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Service: erro ao buscar todos os AcaoPromocional. {ex.Message}");
                throw;
            }
        }

        public async Task<AcaoPromocional> GetById(string acaoPromocionalId)
        {
            _logger.LogInformation("Service: buscando AcaoPromocional");

            try
            {
                var acaoPromocional = await _acaoPromocionalRepository.GetById(acaoPromocionalId);
                return acaoPromocional;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Service: erro ao buscar AcaoPromocional. {ex.Message}");
                throw;
            }
        }

        public async Task Remove(string acaoPromocionalId)
        {
            _logger.LogInformation("Service: removendo AcaoPromocional");

            try
            {
                await _acaoPromocionalRepository.RemoveById(acaoPromocionalId);
                _memoryCache.Remove("AcaoPromocional");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Service: erro ao remover AcaoPromocional. {ex.Message}");
                throw;
            }
        }

        public async Task Update(string acaoPromocionalId, AcaoPromocional newAcaoPromocional)
        {
            _logger.LogInformation("Service: atualizando AcaoPromocional");

            try
            {
                if (await GetById(acaoPromocionalId) != null)
                {
                    newAcaoPromocional.SetId(acaoPromocionalId);
                    await _acaoPromocionalRepository.Update(acaoPromocionalId, newAcaoPromocional);
                    _memoryCache.Remove("AcaoPromocional");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Service: erro ao atualizar AcaoPromocional. {ex.Message}");
                throw;
            }
        }

        public async Task<ImportProdutoAcaoPromocional> ImportAcao(IFormFile file, long idCompany)
        {
            _logger.LogInformation("Inserindo arquivo de Produtos Promocionais");

            var response = InitializeResponse();

            if (!IsValidFile(file, response))
                return response;

            _logger.LogInformation($"Transformando excel para dados no arquivo {file.Name}");

            try
            {
                var workbook = LoadWorkbook(file);
                var sheet = workbook.ActiveSheet;

                response.Errors = await ValidateImporteTagFileHeader(sheet);
                ExtractFromExcel(sheet, response, workbook.CultureInfo);

                if (!response.Success)
                    return response;

                var acaoPromocional = CreateAcaoPromocional(response, idCompany);

                await Add(acaoPromocional);

                return response;
            }
            catch (Exception ex)
            {
                LogImportError(ex);
                throw;
            }
        }

        private ImportProdutoAcaoPromocional InitializeResponse()
        {
            return new ImportProdutoAcaoPromocional
            {
                Success = true,
                Errors = new List<ProdutoAcaoPromocionalErrorModel>(),
                Items = new List<ProdutoAcaoPromocional>()
            };
        }

        private bool IsValidFile(IFormFile file, ImportProdutoAcaoPromocional response)
        {
            if (file.Length <= 0)
            {
                AddError(response, "TXT_NO_SELECTED_FILE");
                return false;
            }

            if (file.ContentType != "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" && file.FileName.Split('.').Last() != "xlsx")
            {
                AddError(response, "TXT_ONLY_XLSX");
                return false;
            }

            return true;
        }

        private Workbook LoadWorkbook(IFormFile file)
        {
            Workbook workbook = new Workbook();
            workbook.LoadFromStream(file.OpenReadStream());
            return workbook;
        }

        private AcaoPromocional CreateAcaoPromocional(ImportProdutoAcaoPromocional response, long idCompany)
        {
            return new AcaoPromocional
            {
                NomeAcao = "TXT_ACTION_PROMOTIONAL",
                StartDate = response.Items.OrderBy(x => x.StartDate).Select(x => x.StartDate).FirstOrDefault(),
                EndDate = response.Items.OrderByDescending(x => x.EndDate).Select(x => x.EndDate).FirstOrDefault(),
                IdCompany = idCompany,
                Produtos = response.Items
            };
        }

        private void AddError(ImportProdutoAcaoPromocional response, string textToken)
        {
            response.Success = false;
            response.Errors.Add(new ProdutoAcaoPromocionalErrorModel
            {
                TextToken = textToken
            });
        }

        private void LogImportError(Exception ex)
        {
            _logger.LogError(ex, $"Erro ao inserir arquivo de Produtos Promocionais {ex.Message}");
        }


        private void ExtractFromExcel(Worksheet sheet, ImportProdutoAcaoPromocional response, CultureInfo cultureInfo)
        {
            foreach (var row in sheet.Rows)
            {
                if (row.Row <= 1)
                    continue;

                try
                {
                    ProdutoAcaoPromocional acaoPromocional = new ProdutoAcaoPromocional();

                    acaoPromocional.TipoPromo = row.CellList[0]?.DisplayedText.Trim();
                    acaoPromocional.NomeProduto = ValidatePromotionalName(row.CellList[1]?.DisplayedText.Trim(), row.Row, response);
                    acaoPromocional.EAN = ValidateEAN(row.CellList[2]?.DisplayedText.Trim(), row.Row, response);
                    acaoPromocional.PrecoAcao = ValidatePrice(row.CellList[3]?.DisplayedText, row.Row, response);
                    acaoPromocional.Combo = ValidateCombo(row.CellList[4]?.DisplayedText, row.Row, response);
                    acaoPromocional.StartDate = ValidateDate(row.CellList[5]?.DisplayedText, row.Row, "TXT_PROMOTIONAL_STARTDATE_ERROR", response, "6", cultureInfo);
                    acaoPromocional.EndDate = ValidateEndDate(row.CellList[6]?.DisplayedText, row.Row, response, cultureInfo);

                    ValidateDates(acaoPromocional.StartDate, acaoPromocional.EndDate, row.Row, response);

                    if (response.Errors.Count == 0)
                        response.Items.Add(acaoPromocional);

                    if (response.Errors.Count >= 10)
                    {
                        _logger.LogWarning("Número máximo de 10 erros atingido. Processamento interrompido.");
                        break;
                    }
                }
                catch (Exception ex)
                {
                    LogUnexpectedError(row.Row, ex.Message, response);
                    if (response.Errors.Count >= 10)
                        break;
                }
            }

            response.Success = response.Errors.Count == 0;
        }

        private void ValidateDates(DateTime startDate, DateTime endDate, int row, ImportProdutoAcaoPromocional response)
        {
            if(endDate < startDate)
            {
                AddError(response, "TXT_END_DATE_LOWER_START_DATE", row, "7", string.Empty);
            }
        }

        private string ValidateEAN(string ean, int row, ImportProdutoAcaoPromocional response)
        {
            if (!string.IsNullOrEmpty(ean) && !Regex.IsMatch(ean.Replace(" ", "").Replace("\"", ""), @"^[\d;]+$"))
            {
                AddError(response, "TXT_EAN_CONTAINS_ONLY_NUMBERS", row, "2", ean);
                return null;
            }
            return ean;
        }

        private string ValidatePromotionalName(string name, int row, ImportProdutoAcaoPromocional response)
        {
            if (string.IsNullOrEmpty(name))
            {
                AddError(response, "TXT_PROMOTIONAL_NAME_ERROR", row, "3", name);
                return null;
            }
            return name;
        }

        private double ValidatePrice(string priceText, int row, ImportProdutoAcaoPromocional response)
        {
            if (!double.TryParse(priceText, out double price))
            {
                AddError(response, "TXT_PROMOTIONAL_PRICE_ERROR", row, "4", priceText);
            }
            return price;
        }

        private bool ValidateCombo(string comboText, int row, ImportProdutoAcaoPromocional response)
        {
            if (comboText.Equals("verdadeiro", StringComparison.InvariantCultureIgnoreCase))
                comboText = "TRUE";

            if (comboText.Equals("falso", StringComparison.InvariantCultureIgnoreCase))
                comboText = "FALSE";

            if (!bool.TryParse(comboText, out bool combo))
            {
                AddError(response, "TXT_PROMOTIONAL_COMBO_ERROR", row, "5", comboText);
            }
            return combo;
        }

        private DateTime ValidateDate(string dateText, int row, string errorToken, ImportProdutoAcaoPromocional response, string collumn, CultureInfo cultureInfo)
        {
            if (!DateTime.TryParse(dateText, cultureInfo, System.Globalization.DateTimeStyles.None, out DateTime date))
            {
                AddError(response, errorToken, row, collumn, dateText);
            }
            return DateTime.SpecifyKind(date, DateTimeKind.Utc);
        }

        private DateTime ValidateEndDate(string dateText, int row, ImportProdutoAcaoPromocional response, CultureInfo cultureInfo)
        {
            var endDate = ValidateDate(dateText, row, "TXT_PROMOTIONAL_ENDDATE_ERROR", response, "7", cultureInfo);
            var adjustedEndDate = endDate.AddHours(23).AddMinutes(59);
            return DateTime.SpecifyKind(adjustedEndDate, DateTimeKind.Utc);
        }

        private void AddError(ImportProdutoAcaoPromocional response, string textToken, int row, string column, string dateText)
        {
            response.Errors.Add(new ProdutoAcaoPromocionalErrorModel
            {
                TextToken = textToken,
                Line = row,
                Column = column,
                Found = dateText
            });
        }

        private void LogUnexpectedError(int row, string message, ImportProdutoAcaoPromocional response)
        {
            _logger.LogWarning($"Erro inesperado na linha {row}: {message}");
            if (response.Errors.Count >= 10)
            {
                _logger.LogWarning("Número máximo de 10 erros atingido. Processamento interrompido.");
            }
        }

        private async Task<List<ProdutoAcaoPromocionalErrorModel>> ValidateImporteTagFileHeader(Worksheet worksheet)
        {
            var errorList = new List<ProdutoAcaoPromocionalErrorModel>();

            var expectedHeaders = new string[]
            {
                "Nome da promoção", "Nome do produto", "EAN do produto", "Preço", "Combo", "Data de início da promoção", "Data de fim da promoção"
            };

            var headerRow = worksheet.Rows.FirstOrDefault(row => row.Row == 1);

            if (headerRow == null)
            {
                errorList.Add(new ProdutoAcaoPromocionalErrorModel
                {
                    TextToken = "TXT_HEADER_ROW_MISSING",
                    Line = 1
                });
                return errorList;
            }

            for (int col = 1; col <= expectedHeaders.Length; col++)
            {
                var cellValue = headerRow.Cells[col - 1]?.Value?.ToString();
                var expectedHeader = expectedHeaders[col - 1];

                if (!string.Equals(cellValue, expectedHeader, StringComparison.OrdinalIgnoreCase))
                {
                    errorList.Add(new ProdutoAcaoPromocionalErrorModel
                    {
                        TextToken = "TXT_HEADER_MISMATCH_ERROR",
                        Expected = expectedHeader,
                        Line = 1,
                        Column = col.ToString(),
                        Found = cellValue
                    });
                }
            }

            return errorList;
        }

    }
}
