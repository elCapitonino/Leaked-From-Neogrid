<template>
    <span>
        <v-row>
            <v-dialog v-model="dialog" persistent width="100%" max-width="590">
                <template v-slot:activator="{ on, attrs }">
                    <v-btn color="#3C5CA7" class="mr-4 pa-4 white--text" v-bind="attrs" v-on="on">
                        {{title}}
                    </v-btn>
                </template>
                <v-card>
                    <v-card-title class="text-h5" v-if="!savedSelectedFilter">
                        {{cardTitle}}
                    </v-card-title>
                    <v-card-title v-if="!!savedSelectedFilter">
                        {{cardEdit}}
                    </v-card-title>
                    <div class="modal" v-if="!!savedSelectedFilter">
                        <v-card-text style="font-weight: bold">
                            {{ $t( "TXT_EDITED_SAVED_FILTER__FILTERNAME__WHAT_TO_DO_NOW",
                            { FILTER_NAME: "Filtro Salvo 1" })
                            }}
                        </v-card-text>
                        <v-radio-group row  v-model="filterGroup" class="mx-4" hide-details>
                            <v-radio :label="$t('TXT_OVERRIDE_FILTER')" value="sobrescrever"></v-radio>
                            <v-radio :label="$t('TXT_SAVE_AS_NEW_FILTER')" value="salvar"></v-radio>
                        </v-radio-group>
                        <p class="text" v-if="filterGroup == 'sobrescrever'" style="
                          font-weight: bold;
                          color: #ec4c37;
                          margin-top: 16px;
                        " v-t="
                          'TXT_SELECTED_VALUES_WILL_BE_OVERRITEN_ACTION_CANNOT_BE_UNDONE'
                        "></p>
                    </div>
                    <div class="modal" v-if="filterGroup == 'salvar'">
                        <v-card-text> {{cardText}}</v-card-text>
                        <v-text-field :label="label" class="text-model" @input="onInput" dense outlined hide-details
                            required>
                        </v-text-field>
                    </div>
                    <v-card-actions>
                        <v-spacer></v-spacer>
                        <v-btn color="#3C5CA7" class="mr-4 pa-4 white--text" @click="saveDialogButtom">
                            Salvar
                        </v-btn>
                        <v-btn color="#3C5CA7" outlined @click="dialog = false">
                            Cancelar
                        </v-btn>
                    </v-card-actions>
                </v-card>
            </v-dialog>
        </v-row>
    </span>
</template>

<script>
export default {
    data() {
        return {
            dialog: false,
            savedSelectedFilter: null,
            showEditFilter: false,
            filterGroup: "salvar",
        }
    },
    props: {
        cardTitle: {
            type: String,
            require: true
        },
        cardText: {
            type: String,
            require: true
        },
        title: {
            type: String,
            require: true
        },
        cardEdit: {
            type: String,
            require: true
        },
        editFilter: {
            type: String
        },
        label: {
            type: String
        }
    },
    methods: {
        saveDialogButtom() {
            this.$emit('save-dialog', this.dialog = false)
        },
        onInput(values) {
            this.$emit('input', values)
        }
    }
}
</script>

<style>
.v-card__actions{
    justify-content: end;
}
</style>