﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DI.Repository.Migrations.PostgreMigrations
{
    /// <inheritdoc />
    public partial class RenamingCollunmsConfigurations : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "GrossSubCategoryField",
                table: "ImpactReportConfiguration",
                newName: "RawSubCategoryField");

            migrationBuilder.RenameColumn(
                name: "GrossReportRoyalty",
                table: "ImpactReportConfiguration",
                newName: "HasRawReportRoyalty");

            migrationBuilder.RenameColumn(
                name: "GrossCategoryField",
                table: "ImpactReportConfiguration",
                newName: "RawCategoryField");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "RawSubCategoryField",
                table: "ImpactReportConfiguration",
                newName: "GrossSubCategoryField");

            migrationBuilder.RenameColumn(
                name: "RawCategoryField",
                table: "ImpactReportConfiguration",
                newName: "GrossCategoryField");

            migrationBuilder.RenameColumn(
                name: "HasRawReportRoyalty",
                table: "ImpactReportConfiguration",
                newName: "GrossReportRoyalty");
        }
    }
}
