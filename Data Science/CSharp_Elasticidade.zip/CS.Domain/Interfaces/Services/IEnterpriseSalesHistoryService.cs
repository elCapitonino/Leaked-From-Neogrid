﻿using CS.Domain.Domain;
using CS.Domain.DTO;

namespace CS.Domain.Interfaces.Services
{
    public interface IEnterpriseSalesHistoryService
    {
        Task<List<EnterpriseElasticit>> SimpleElasticSearch(SimpleSearchDTO searchFilter);
    }
}
