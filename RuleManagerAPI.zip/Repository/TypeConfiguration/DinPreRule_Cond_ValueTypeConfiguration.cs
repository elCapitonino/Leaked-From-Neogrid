﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Repository.Entity;

namespace Repository.TypeConfiguration
{
    public sealed class DinPreRule_Cond_ValueTypeConfiguration : TypeConfigurationBase<DinPreRule_Cond_ValueEntity>, IEntityTypeConfiguration<DinPreRule_Cond_ValueEntity>
    {
        public override void Configure(EntityTypeBuilder<DinPreRule_Cond_ValueEntity> builder)
        {
            ConfigureTableName(builder, "DinPreRule_Cond_Value");
            builder.ToTable("DinPreRule_Cond_Value", table => table.ExcludeFromMigrations());
            builder.Ignore(x => x.Id);
            builder.HasKey(x => x.ConditionValueId);
            builder.Property(x => x.StringValue).HasMaxLength(58);
            builder.Property(x => x.ConditionValueId).HasColumnName("IdConditionValue");
            builder.Property(x => x.CreatedDate).HasColumnName("DataHoraCriacao");
            builder.Property(x => x.UpdatedDate).HasColumnName("DataHoraUltimaAlteracao");

            builder.HasOne(x => x.RuleCondition).WithMany(x => x.Values).HasForeignKey(x => x.IdRuleCondition);
        }
    }
}
