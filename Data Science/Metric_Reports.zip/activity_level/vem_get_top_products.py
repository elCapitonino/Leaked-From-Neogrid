import argparse
import json
from datetime import date, datetime
from typing import Optional, Set

import pandas as pd
import requests

from geral.config import getDadosAWSSession

ID_COMPANY = 3026

# EANs dos KVIs de 2023-11-28
KVI = {
    "78936683",
    "7891991014762",
    "7891149108718",
    "7891991015462",
    "7896045523412",
    "7891991294942",
    "7891991297479",
    "7891149011001",
    "7891149200504",
    "7891991015493",
    "7891149010509",
    "7896045504831",
    "7891991297424",
    "78905498",
    "7891149103102",
    "7896045506040",
    "7896045506248",
    "7896045505340",
    "7891149201006",
    "7897395020217",
    "7893218000473",
    "5000267013602",
    "5000291020706",
    "7893218003603",
    "7891991301138",
    "7891991301114",
    "7891149105564",
    "7891083611138",
    "7804320116846",
    "7896037913146",
    "7804320116921",
    "7894900530001",
    "7894900531008",
    "7894900530032",
    "7896065880069",
    "7896445490086",
    "7896445490116",
    "7896065880106",
    "7894900530025",
    "7896065870497",
    "7891098040893",
    "7891098040848",
    "7891098040688",
    "611269991000",
    "70847022015",
    "9002490214166",
    "9002490209346",
    "611269101713",
    "70847033301",
    "70847022206",
    "70847022305",
    "9002490229160",
    "9002490243678",
    "7898923217031",
    "7896326100219",
    "7898923217017",
    "7892840808174",
    "7892840808037",
    "7892840808051",
    "7892840808020",
    "7892840808044",
    "7898953148701",
    "7894900660333",
    "7898953148169",
    "7894900593709",
    "7894900660319",
    "7894900550054",
    "7894900027013",
    "7894900010015",
    "7894900011609",
    "7894900700015",
    "7894900701517",
    "7894900701609",
    "7891991001342",
    "7892840812850",
    "7894900010398",
    "7892840812423",
}


def get_tabelados(affiliate: int, uf: str) -> Set[str]:
    response = requests.get(
        f"https://predifyhom20.azurewebsites.net/api/ProdutosTabelados?idCompany=3026&state={uf}&affiliate={affiliate}",
        timeout=60,
    )
    if response.status_code != 200:
        raise ValueError(
            f"AcaoPromocional request has failed with status {response.status_code}: {response.content}"
        )

    out = response.json()

    out_eans = set()
    for x in out:
        ean = x.get("ean")
        if isinstance(ean, str):
            out_eans.add(ean)

    out_eans = {ean for ean in out_eans if ean}
    return out_eans


def check_date_range(
    name: str, ref_date: date, initial_date: Optional[str], final_date: Optional[str]
) -> None:
    if initial_date is None or final_date is None:
        print(f"WARNING: action {name} has no initial_date or final_date")
        return

    try:
        initial_date = datetime.strptime(initial_date, "%d/%m/%Y").date()
        final_date = datetime.strptime(final_date, "%d/%m/%Y").date()

        if ref_date < initial_date or ref_date > final_date:
            print(
                f"WARNING: current date {ref_date.isoformat()} is out of bounds "
                f"({initial_date.isoformat()} - {final_date.isoformat()}) for action {name}"
            )

    except Exception as exc:
        print(f"ERROR: failed to parse date range for action {name}: {exc}")


def get_promotional_eans(
    id_company: int, ref_date: date, action_type: Optional[str] = None
) -> Set[str]:
    response = requests.get(
        f"https://predifyhom20.azurewebsites.net/api/AcaoPromocional?idCompany={id_company}",
        timeout=60,
    )
    if response.status_code != 200:
        raise ValueError(
            f"AcaoPromocional request has failed with status {response.status_code}: {response.content}"
        )

    out = response.json()
    out_eans = set()
    actions = out.get("currentActions") or []

    for action in actions:
        name = action.get("actionName") or "<NO NAME>"
        initial_date = action.get("initialDate")
        final_date = action.get("finalDate")

        check_date_range(name, ref_date, initial_date, final_date)

        products = action.get("products") or []
        for product in products:
            if product.get("isCombo"):
                continue
            if (
                action_type is not None
                and action_type.lower() not in (product.get("actionType") or "").lower()
            ):
                continue
            ean_string = product.get("ean") or ""
            eans = ean_string.split(";")
            out_eans.update(eans)

    out_eans = {ean for ean in out_eans if ean}
    return out_eans


def products_with_monitoring(conn, affiliate: int) -> Set[str]:
    query = """
    SELECT TOP 1 pg.IdEnterprisePriceGroups FROM Enterprise_Price_Groups AS pg
    JOIN Enterprise_Price_Groups_Filter F
    ON pg.IdEnterprisePriceGroups = F.IdEnterprisePriceGroups
    JOIN EnterprisePriceGroups_DefaultFilter DF
    ON F.IdEnterprisePriceGroups_DefaultFilter = DF.IdEnterprisePriceGroups_DefaultFilter
    WHERE pg.IdCompany = 3026
    AND [Automatic] = 1
    AND F.IsDeleted = 0
    AND DF.dbField = 7 -- Affiliate
    AND F.Value = ?
    ORDER BY IdEnterprisePriceGroups DESC
    """

    price_id = conn.execute(query, affiliate).fetchone()[0]

    query_pp = """
    SELECT DISTINCT Product
    FROM Enterprise_Prices_Projection
    WHERE IdEnterprisePriceGroups = ?
    AND idProductMarketResult IS NOT NULL
    """
    return {x[0] for x in conn.execute(query_pp, price_id)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--affiliate-info",
        type=str,
        required=True,
        help=(
            "Caminho para arquivo XLSX com informações de filiais da VEM. "
            "Arquivo salvo no blob vem (pasta tabelas_predify/affiliate_info.xlsx)"
        ),
    )
    parser.add_argument(
        "--n-products",
        type=int,
        default=200,
        help="Número de produtos a serem selecionados por filial.",
    )
    args = parser.parse_args()

    df_info = pd.read_excel(args.affiliate_info)
    df_info["UF"] = df_info["UF"].str.strip().str.upper()
    df_info["ZBRM"] = df_info["ZBRM"].astype(str)
    df_info["PARALISADA"] = df_info["PARALISADA"].astype("bool")
    df_info["SUCEDIDA"] = df_info["SUCEDIDA"].astype("bool")
    df_info["FINALIZADA"] = df_info["FINALIZADA"].astype("bool")
    df_info = df_info[
        ~df_info["PARALISADA"] & ~df_info["SUCEDIDA"] & ~df_info["FINALIZADA"]
    ]

    conn = getDadosAWSSession("producao")
    data = pd.read_sql_query(
        """
        SELECT * FROM EnterpriseActivityLevel
        WHERE IdCompany = ? AND IsDeleted = 0
        AND CreateDate = (
            SELECT MAX(CreateDate)
            FROM EnterpriseActivityLevel
            WHERE IdCompany = ? AND IsDeleted = 0
        )
        """,
        conn,
        params=[3026, 3026],
    )

    try:
        desc_ean = pd.read_parquet("desc_ean.parquet")
        print(
            "\n\n",
            "-> WARNING: using local description-EAN table.",
            "Delete desc_ean.parquet to fetch a new version\n",
        )
    except Exception:
        desc_ean = pd.read_sql_query(
            """
            SELECT Product, Description, PackageDescription
            FROM Enterprise_Sales_History WHERE IdCompany = 3026 AND IsDeletado = 0
            GROUP BY Product, Description, PackageDescription
            """,
            conn,
        )
        desc_ean.to_parquet("desc_ean.parquet", index=False)

    prod_id_map = {row["Description"]: row["Product"] for _, row in desc_ean.iterrows()}

    today = date.today()
    data = data.rename(columns={"Granularity1": "Description"})
    data = pd.merge(data, desc_ean, how="left")

    products = {}
    counts = {}
    for _, row in df_info.iterrows():
        aff = row["ZBRM"]
        uf = row["UF"]
        print(f"-> processing {aff}")
        tabelados = get_tabelados(aff, uf)
        with_monitoring = products_with_monitoring(conn, aff)
        promotional = get_promotional_eans(ID_COMPANY, today, "big 5")
        df_aff = data[data["Granularity2"] == aff]
        df_aff = df_aff[~df_aff["PackageDescription"].isin(tabelados)]
        df_aff = df_aff[~df_aff["PackageDescription"].isin(promotional)]
        df_aff = df_aff[df_aff["Product"].isin(with_monitoring)]
        df_aff = df_aff.sort_values("Frequency1", ascending=False)

        counts[aff] = df_aff["Description"].nunique()

        if df_aff.empty:
            print(f"--> WARNING: No products for affiliate {aff}\n\n\n")
            continue

        # FIXME necessário agrupar por descrição pois uma descrição pode ter mais de 1 EAN
        df_kvi = df_aff[df_aff["PackageDescription"].isin(KVI)]
        df_kvi = (
            df_kvi.groupby("Description")["Frequency1"]
            .first()
            .reset_index()
            .sort_values("Frequency1", ascending=False)
        )
        present_kvi = set(df_kvi.iloc[: args.n_products]["Description"].values.tolist())

        df_aff.sort_values("Description").to_excel("foo.xlsx")
        n_eans = args.n_products - len(present_kvi)

        df_others = df_aff[~df_aff["Description"].isin(present_kvi)]
        df_others = (
            df_others.groupby("Description")["Frequency1"]
            .first()
            .reset_index()
            .sort_values("Frequency1", ascending=False)
        )

        chosen_desc = set(df_others.iloc[:n_eans]["Description"].values.tolist())
        products[aff] = sorted(present_kvi | chosen_desc)
        print(f"number KVIs = {len(present_kvi)} | number others =  {len(chosen_desc)}")

    products_ids = {
        aff: [prod_id_map.get(x) for x in prods] for aff, prods in products.items()
    }

    for aff, prod_descs in products.items():
        if len(set(prod_descs)) != min(counts[aff], args.n_products):
            raise ValueError(
                f"Description count: expected {min(counts[aff], args.n_products)}, got {len(set(prod_descs))}"
            )
        if len(set(products[aff])) != min(counts[aff], args.n_products):
            raise ValueError(
                f"Product count: expected {min(counts[aff], args.n_products)}, got {len(set(products[aff]))}"
            )
        if len(products[aff]) < args.n_products:
            print(
                f"-> WARNING: affiliate {aff} has {len(products[aff])} instead of {args.n_products} products"
            )

    prod_path = f"./activity_level/chosen_products_{today.isoformat()}.json"
    with open(prod_path, "w", encoding="utf-8") as f:
        json.dump(products, f, indent=2, ensure_ascii=False)

    prod_id_path = f"./activity_level/chosen_products_ids_{today.isoformat()}.json"
    with open(prod_id_path, "w", encoding="utf-8") as f:
        json.dump(products_ids, f, indent=2, ensure_ascii=False)

    print(f"saved {prod_path} and {prod_id_path}")
    return products_ids


if __name__ == "__main__":
    products = main()
