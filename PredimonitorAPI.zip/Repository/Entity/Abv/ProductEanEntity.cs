﻿using MongoDB.Bson.Serialization.Attributes;

namespace Repository.Entity.Abv
{
    public class ProductEanEntity
    {
        [BsonElement("EAN")]
        public string? Ean { get; set; }
    }

}
