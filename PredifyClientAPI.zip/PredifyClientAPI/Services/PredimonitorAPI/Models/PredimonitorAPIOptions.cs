﻿namespace PredifyClientAPI.Services.PredimonitorAPI.Models
{
    public class PredimonitorAPIOptions
    {
        public Uri BaseAddress { get; set; }
        public double TimeoutMinutes { get; set; }
    }
}
