﻿using Microsoft.EntityFrameworkCore;
using MongoDB.Driver;
using Repository.DbContexts.Bases;

namespace Repository.DbContexts
{
    public class NielsenDbContext : MongoDbContextBase
    {
        public NielsenDbContext(DbContextOptions<NielsenDbContext> options, IMongoClient mongoClient) : base(options, mongoClient)
        {
        }

        public override string DbContextName => nameof(NielsenDbContext);
    }

}
