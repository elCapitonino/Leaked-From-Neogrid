﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DI.Repository.Migrations.PostgreMigrations
{
    /// <inheritdoc />
    public partial class AddCollunmsConfiguration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_ImpactReportConfiguration",
                table: "ImpactReportConfiguration");

            migrationBuilder.DropColumn(
                name: "Id",
                table: "ImpactReportConfiguration");

            migrationBuilder.RenameColumn(
                name: "ConcolidateGroupField",
                table: "ImpactReportConfiguration",
                newName: "PriceVariableToCalc");

            migrationBuilder.AddColumn<long>(
                name: "CompanyId",
                table: "ImpactReportConfiguration",
                type: "bigint",
                nullable: false,
                defaultValue: 0L);

            migrationBuilder.AddColumn<string>(
                name: "ConsolidateFieldGroupBy",
                table: "ImpactReportConfiguration",
                type: "character varying(64)",
                maxLength: 64,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "ConsolidateGroupField",
                table: "ImpactReportConfiguration",
                type: "character varying(64)",
                maxLength: 64,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "GrossCategoryField",
                table: "ImpactReportConfiguration",
                type: "character varying(64)",
                maxLength: 64,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "GrossSubCategoryField",
                table: "ImpactReportConfiguration",
                type: "character varying(64)",
                maxLength: 64,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddPrimaryKey(
                name: "PK_ImpactReportConfiguration",
                table: "ImpactReportConfiguration",
                column: "CompanyId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_ImpactReportConfiguration",
                table: "ImpactReportConfiguration");

            migrationBuilder.DropColumn(
                name: "CompanyId",
                table: "ImpactReportConfiguration");

            migrationBuilder.DropColumn(
                name: "ConsolidateFieldGroupBy",
                table: "ImpactReportConfiguration");

            migrationBuilder.DropColumn(
                name: "ConsolidateGroupField",
                table: "ImpactReportConfiguration");

            migrationBuilder.DropColumn(
                name: "GrossCategoryField",
                table: "ImpactReportConfiguration");

            migrationBuilder.DropColumn(
                name: "GrossSubCategoryField",
                table: "ImpactReportConfiguration");

            migrationBuilder.RenameColumn(
                name: "PriceVariableToCalc",
                table: "ImpactReportConfiguration",
                newName: "ConcolidateGroupField");

            migrationBuilder.AddColumn<Guid>(
                name: "Id",
                table: "ImpactReportConfiguration",
                type: "uuid",
                nullable: false,
                defaultValueSql: "uuid_generate_v4()");

            migrationBuilder.AddPrimaryKey(
                name: "PK_ImpactReportConfiguration",
                table: "ImpactReportConfiguration",
                column: "Id");
        }
    }
}
