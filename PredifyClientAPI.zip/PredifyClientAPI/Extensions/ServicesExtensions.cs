﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using PredifyClientAPI.Models;
using PredifyClientAPI.Services.DataInsightAPI;
using PredifyClientAPI.Services.DataInsightAPI.Models;
using PredifyClientAPI.Services.PredifyAPI;
using PredifyClientAPI.Services.PredifyAPI.Models;
using PredifyClientAPI.Services.PredimonitorAPI;
using PredifyClientAPI.Services.PredimonitorAPI.Models;
using System.Net.Http.Headers;

namespace PredifyClientAPI.Extensions
{
    public static class ServicesExtensions
    {
        public static void AddServices(this IServiceCollection services)
        {
            services.AddHttpClient<PredifyAPISystemManager>((service, client) =>
            {
                var options = service.GetService<IOptions<PredifyAPIOptions>>();
                client.BaseAddress = options.Value.BaseAddress;
                client.Timeout = TimeSpan.FromMinutes(options.Value.TimeoutMinutes);

                if (client.DefaultRequestHeaders.Authorization == null)
                {
                    var formLogin = new FormUrlEncodedContent(new Dictionary<string, string>()
                                                                {
                                                                    { "client_id", options.Value.ClientId },
                                                                    { "grant_type", options.Value.GrantType },
                                                                    { "password", options.Value.Password },
                                                                    { "username", options.Value.Username }
                                                                });

                    var result = client.PostAsync("token", formLogin).Result;
                    var content = result.Content.ReadAsStringAsync().Result;
                    var token = JsonConvert.DeserializeAnonymousType(content, new { access_token = "" });

                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token.access_token);
                }
            });

            services.AddHttpClient<PredifyAPIUserManager>((service, client) =>
            {

                var options = service.GetService<IOptions<PredifyAPIOptions>>();
                var currentUser = service.GetService<ICurrentUser>();
                var logger = service.GetService<ILogger<PredifyAPIUserManager>>();
                client.BaseAddress = options.Value.BaseAddress;
                client.Timeout = TimeSpan.FromMinutes(options.Value.TimeoutMinutes);
                if (currentUser?.Identity != null)
                {
                    if (!currentUser.IsAuthenticated)
                        throw new Exception("Usuário não autenticado!");
                    if (string.IsNullOrEmpty(currentUser.AccessToken))
                        throw new Exception("Token de acesso não encontrado!");

                    if (client.DefaultRequestHeaders.Authorization == null)
                    {
                        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", currentUser.AccessToken);
                    }
                }
                else
                {
                    throw new UnauthorizedAccessException();
                }
            });

            services.AddHttpClient<PredimonitorAPIManager>((service, client) =>
            {
                var options = service.GetService<IOptions<PredimonitorAPIOptions>>();
                var currentUser = service.GetService<ICurrentUser>();
                var logger = service.GetService<ILogger<PredimonitorAPIManager>>();
                client.BaseAddress = options.Value.BaseAddress;
                client.Timeout = TimeSpan.FromMinutes(options.Value.TimeoutMinutes);
                if (currentUser?.Identity == null) 
                    throw new UnauthorizedAccessException();

                if (!currentUser.IsAuthenticated)
                    throw new Exception("Usuário não autenticado!");

                if (string.IsNullOrEmpty(currentUser.AccessToken))
                    throw new Exception("Token de acesso não encontrado!");

                if (client.DefaultRequestHeaders.Authorization == null)
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", currentUser.AccessToken);
                 }
            });

            services.AddHttpClient<DataInsightAPIManager>((service, client) =>
            {
                var options = service.GetService<IOptions<DataInsightAPIOptions>>();
                var currentUser = service.GetService<ICurrentUser>();
                var logger = service.GetService<ILogger<DataInsightAPIManager>>();
                client.BaseAddress = options.Value.BaseAddress;
                client.Timeout = TimeSpan.FromMinutes(options.Value.TimeoutMinutes);

                if (currentUser?.Identity == null)
                    throw new UnauthorizedAccessException();

                if (!currentUser.IsAuthenticated)
                    throw new Exception("Usuário não autenticado!");

                if (string.IsNullOrEmpty(currentUser.AccessToken))
                    throw new Exception("Token de acesso não encontrado!");

                if (client.DefaultRequestHeaders.Authorization == null)
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", currentUser.AccessToken);
                }
            });
        }
    }
}
