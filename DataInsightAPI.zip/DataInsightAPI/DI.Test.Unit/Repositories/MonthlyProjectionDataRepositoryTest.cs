﻿using DI.Repository.Enum;
using DI.Repository.Interfaces;

namespace DI.Test.Unit.Repositories
{
    public class MonthlyProjectionDataRepositoryTest
    {
        private readonly IUnitOfWork _unitOfWork;

        public MonthlyProjectionDataRepositoryTest(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        [Fact]
        public void TestGetAll_ReturnsData()
        {
            long companyId = 3026;
            int startYearMonth = 202401;
            int endYearMonth = 202404;
            EGranularityType granularityType = EGranularityType.None;

            var result = _unitOfWork.MonthlyProjectionDataRepository.GetAll(companyId, startYearMonth, endYearMonth, granularityType);

            Assert.NotNull(result);
            Assert.NotEmpty(result);
            Assert.All(result, item => Assert.Equal(companyId, item.CompanyId));
            Assert.All(result, item => Assert.InRange(item.YearMonth, startYearMonth, endYearMonth));
        }

        [Fact]
        public void TestGetAll_NoDataReturned()
        {
            long companyId = 00000;
            int startYearMonth = 202301;
            int endYearMonth = 202312;
            EGranularityType granularityType = EGranularityType.None;

            var result = _unitOfWork.MonthlyProjectionDataRepository.GetAll(companyId, startYearMonth, endYearMonth, granularityType);

            Assert.NotNull(result);
            Assert.Empty(result);
        }

        [Fact]
        public void TestGetAll_FilterByYearMonth()
        {
            long companyId = 1;
            int startYearMonth = 202301;
            int endYearMonth = 202306;
            EGranularityType granularityType = EGranularityType.None;

            var result = _unitOfWork.MonthlyProjectionDataRepository.GetAll(companyId, startYearMonth, endYearMonth, granularityType);

            Assert.NotNull(result);
            Assert.All(result, item => Assert.InRange(item.YearMonth, startYearMonth, endYearMonth));
        }

        [Fact]
        public void TestGetAll_FilterByGranularityType()
        {
            long companyId = 3026;
            int startYearMonth = 202401;
            int endYearMonth = 202404;
            EGranularityType granularityType = EGranularityType.Elasticity;

            var result = _unitOfWork.MonthlyProjectionDataRepository.GetAll(companyId, startYearMonth, endYearMonth, granularityType);

            Assert.NotNull(result);
            Assert.All(result, item => Assert.Equal(granularityType, item.GranularityGroup.GranularityType));
        }
    }
}