using Repository.DbContexts;
using Repository.Entity.Databricks;
using Repository.EntityRepository.Bases;
using System;

namespace Repository.EntityRepository;

public class IgnoredPriceRepository : GenericDatabricksRepository<IgnoredPriceEntity>, IIgnoredPriceRepository
{
    public IgnoredPriceRepository(DatabricsDbContext dbContext) : base(dbContext, "ignored_prices")
    {
    }
}