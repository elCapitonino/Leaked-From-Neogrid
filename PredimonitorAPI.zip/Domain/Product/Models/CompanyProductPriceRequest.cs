namespace Domain.Product.Models;

public class CompanyProductPriceRequest
{
    public int CompanyId { get; set; }
    public List<string>? ProductIds { get; set; }
    public decimal Price { get; set; }
}