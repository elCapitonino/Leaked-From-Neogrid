using Repository.Models.Databricks;
using System;

namespace Repository.EntityRepository.Bases;

public interface IGenericDatabricksRepository<T> where T : class
{
    Task<List<T>> Get(List<QueryFilter>? filters = null, int limit = 100);
    Task<List<TResult>> GetWithJoin<TResult>(QueryParameters parameters) where TResult : class, new();
    Task<int> GetCount(QueryParameters parameters);
    void Insert(T item);
    void Insert(List<T> items);
    void Remove(IEnumerable<string> ids);
    void ExecuteSQL(string sql);
    string GetSchema();
}