﻿using AutoMapper;
using DI.Domain;

namespace DI.API.IoC
{
    public static class AutoMapperExtensions
    {
        public static void AddAutoMapper(this IServiceCollection services)
        {
            var mappingConfig = new MapperConfiguration(mc =>
            {
                var profiles = typeof(DomainProfile).Assembly.GetTypes()
                    .Where(x => typeof(Profile).IsAssignableFrom(x))
                    .Select(Activator.CreateInstance)
                    .Cast<Profile>()
                    .ToList();

                mc.AddProfiles(profiles);
            });

            mappingConfig.CompileMappings();

            IMapper mapper = mappingConfig.CreateMapper();
            services.AddSingleton(mapper);
        }
    }
}
