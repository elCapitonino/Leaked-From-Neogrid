﻿using Repository.DbContexts;
using Repository.Entity;
using Repository.EntityRepository.Bases;

namespace Repository.EntityRepository
{
    public class MonitoringItemConfigRepository : GenericRepository<MonitoringItemConfigEntity, long>, IMonitoringItemConfigRepository
    {
        public MonitoringItemConfigRepository(ApplicationDbContext dbContext) : base(dbContext)
        {
        }
        public static string DbContextName => nameof(ApplicationDbContext);
    }
}
