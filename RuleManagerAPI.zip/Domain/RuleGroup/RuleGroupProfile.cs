﻿using AutoMapper;
using Domain.Models;
using Repository.Entity;

namespace Domain.Rule
{
    public class RuleGroupProfile : Profile
    {
        public RuleGroupProfile()
        {
            CreateMap<DinPreRuleEntity, RuleGroupResponse>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.RuleId))
                .ForMember(dest => dest.Name, opt => opt.MapFrom(src => src.Description))
                .ForMember(dest => dest.CompanyId, opt => opt.MapFrom(src => src.IdEmpresa))
                .ForMember(dest => dest.Elasticity, opt => opt.MapFrom(src => src.Enterprise_ElasticityStatus))
                .ForMember(dest => dest.Rules, opt => opt.MapFrom(src => src.Conditions))
                .ForMember(dest => dest.Filters, opt => opt.MapFrom(src => src.Filters));

            CreateMap<DinPreRule_DefaultFilter_ValueEntity, RuleGroupFilterResponse>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.IdEnterprisePriceGroups_DefaultFilter))
                .ForMember(dest => dest.Value, opt => opt.MapFrom(src => src.Value));
        }
    }
}
