﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Services.PredifyAPI.Models;
using Services.PredifyAPI;
using System.Net.Http.Headers;
using Domain.Models;
using Services.SearchAPI;
using Services.SearchAPI.Models;

namespace PredimonitorAPI.Extensions
{
    public static class ServicesExtensions
    {
        public static void AddServices(this IServiceCollection services)
        {
            services.AddHttpClient<PredifyAPISystemManager>((service, client) =>
            {
                var options = service.GetService<IOptions<PredifyAPIOptions>>();
                client.BaseAddress = options.Value.BaseAddress;

                if (client.DefaultRequestHeaders.Authorization == null)
                {

                    var formLogin = new FormUrlEncodedContent(new Dictionary<string, string>()
                                                                {
                                                                    { "client_id", options.Value.ClientId },
                                                                    { "grant_type", options.Value.GrantType },
                                                                    { "password", options.Value.Password },
                                                                    { "username", options.Value.Username }
                                                                });
                    var result = client.PostAsync("token", formLogin).Result;
                    var content = result.Content.ReadAsStringAsync().Result;
                    var token = JsonConvert.DeserializeAnonymousType(content, new { access_token = "" });

                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token.access_token);
                }
            });

            services.AddHttpClient<PredifyAPIUserManager>((service, client) =>
            {

                var options = service.GetService<IOptions<PredifyAPIOptions>>();
                var currentUser = service.GetService<ICurrentUser>();
                var logger = service.GetService<ILogger<PredifyAPIUserManager>>();
                client.BaseAddress = options.Value.BaseAddress;
                if (currentUser?.Identity != null)
                {
                    if (!currentUser.IsAuthenticated)
                        throw new Exception("Usuário não autenticado!");
                    if (string.IsNullOrEmpty(currentUser.AccessToken))
                        throw new Exception("Token de acesso não encontrado!");

                    if (client.DefaultRequestHeaders.Authorization == null)
                    {
                        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", currentUser.AccessToken);
                    }
                }
                else
                {
                    logger.LogDebug("usando socket, usuário será autenticado no Hub");
                }
            });

            services.AddHttpClient<ISearchAPIService, SearchAPIService>((service, client) =>
            {
                var options = service.GetService<IOptions<SearchAPIOptions>>();
                client.BaseAddress = options.Value.UrlBase;
                client.Timeout = TimeSpan.FromDays(1);
            });
        }
    }
}
