﻿namespace DI.Domain.ValueObjects
{
    /// <summary>
    /// Esta classe contém os dados usados para UM worksheet de um arquivo excel
    /// </summary>
    public class ImpactReportWorksheet
    {
        public decimal TotalSkus { get; set; }
        public decimal TotalSkusPrecification { get; set; }
        public decimal ApprovedSkus { get; set; }
        public decimal AdoptedSkus { get; set; }
        public decimal PercentageApprovedSkus { get; set; }
        public decimal PercentageAdoptedSkus { get; set; }
        public string? WorkSheetName { get; set; }
        public string? GroupName { get; set; }
        public string? PeriodConsidered { get; set; }
        public int? AffiliatesCount { get; set; }
        public int? GroupsCount { get; set; }
        public string? MajorGranularity { get; set; }
        public IEnumerable<ImpactReportTable>? Tables { get; set; }
    }
}
