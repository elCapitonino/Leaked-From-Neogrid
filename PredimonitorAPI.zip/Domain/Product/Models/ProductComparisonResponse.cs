﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Product.Models
{
    public class ProductComparisonResponse
    {
        public string Description { get; set; } = string.Empty;
        public decimal Min { get; set; }
        public decimal Q1 { get; set; }
        public decimal Median { get; set; }
        public decimal Q3 { get; set; }
        public decimal Max { get; set; }
        public decimal Avg { get; set; }
        public decimal MostFrequently { get; set; }
        public IEnumerable<decimal>? Outliers { get; set; }
        public decimal Low { get; set; }
        public decimal High { get; set; }
    }

    public class ProductComparisonPricesResponse
    {
        public string? Name { get; set; }
        public decimal Price { get; set; }
    }
}
