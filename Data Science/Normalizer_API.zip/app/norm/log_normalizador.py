from norm.conect_mongo import MongoConnect
from datetime import datetime


class LogNormalizador:
    def __init__(self):
        self.dbMongo = MongoConnect()

    def log_normalization(self, id_price, ListNorm, product_norm, product_name, id_crawler, tipo_norm):
        # normalizador = 0
        # price = 1
        # falha = 2
        log = {"product_name": product_name, "product_norm": product_norm, "id_normalized": ListNorm, "id_price": id_price,
               "norm_date": datetime.now(), "id_crawler": id_crawler, "norm_type": tipo_norm}

        self.dbMongo.insert_log_normalizer(log)

    def flush(self):
        self.dbMongo.flush()