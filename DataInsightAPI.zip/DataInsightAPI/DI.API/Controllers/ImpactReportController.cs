﻿using DI.API.Utils.Cache;
using DI.Domain.ImpactReport;
using DI.Domain.Models.ImpactReport;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Swashbuckle.AspNetCore.Annotations;
using System.Security.Claims;

namespace DI.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]

    public class ImpactReportController : ControllerBase
    {
        private readonly ILogger<ImpactReportController> _logger;
        private readonly IImpactReportDomain _domainImpactReport;
        private readonly ICacheService _cacheService;

        public ImpactReportController(ILogger<ImpactReportController> logger, IImpactReportDomain domainImpactReport, ICacheService cacheService)
        {
            _logger = logger;
            _domainImpactReport = domainImpactReport;
            _cacheService = cacheService;
        }

        [HttpPost]
        [Route("DownloadRawReport")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [SwaggerOperation(Summary = "Downloads a raw impact Excel report with styling", Description = "Generates and downloads a raw impact Excel report")]
        public async Task<IActionResult> DownloadRawReport([FromBody] ImpactRawRequestModel request)
        {
            try
            {
                var cacheKey = request.GenerateCacheKey();

                var cachedBytes = _cacheService.Get<byte[]>(cacheKey);
                if (cachedBytes == null)
                {
                    var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
                    using (var memoryStream = _domainImpactReport.GenerateRawImpactReport(request.CompanyId, request.PriceGroupIds, userId))
                    {
                        var payload = memoryStream.ToArray();
                        var cacheOptions = new MemoryCacheEntryOptions()
                            .SetSlidingExpiration(TimeSpan.FromMinutes(10))
                            .SetAbsoluteExpiration(TimeSpan.FromHours(1))
                            .SetPriority(CacheItemPriority.Normal);
                        _cacheService.Set(cacheKey, payload, cacheOptions);
                        return File(new MemoryStream(payload), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "RelatorioImpactoBruto.xlsx");
                    }
                }
                else
                {
                    return File(new MemoryStream(cachedBytes), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "RelatorioImpactoBruto.xlsx");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error generating Excel report");
                return BadRequest("An error occurred while generating the report.");
            }
        }

        [HttpPost]
        [Route("DownloadConsolidatedReport")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [SwaggerOperation(Summary = "Downloads a consolidated impact Excel report with styling", Description = "Generates and downloads a consolidated impact Excel report")]
        public async Task<IActionResult> DownloadConsolidatedReport([FromBody] ImpactConsolidatedRequestModel request, CancellationToken cancellationToken)
        {
            try
            {
                var cacheKey = request.GenerateCacheKey();

                var cachedBytes = _cacheService.Get<byte[]>(cacheKey);
                if (cachedBytes == null)
                {
                    var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
                    using (var memoryStream = await _domainImpactReport.GenerateConsolidatedReport(request, cancellationToken, userId))
                    {
                        var payload = memoryStream.ToArray();
                        var cacheOptions = new MemoryCacheEntryOptions()
                            .SetSlidingExpiration(TimeSpan.FromMinutes(10))
                            .SetAbsoluteExpiration(TimeSpan.FromHours(1))
                            .SetPriority(CacheItemPriority.Normal);
                        _cacheService.Set(cacheKey, payload, cacheOptions);
                        return File(new MemoryStream(payload), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "RelatorioImpactoConsolidado.xlsx");
                    }
                }
                else
                {
                    return File(new MemoryStream(cachedBytes), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "RelatorioImpactoConsolidado.xlsx");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error generating Excel report");
                return BadRequest(ex.Message);
            }
        }
    }
}
