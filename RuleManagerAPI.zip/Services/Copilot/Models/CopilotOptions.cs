﻿namespace Services.Copilot.Models
{
    public class CopilotOptions
    {
        public string Host { get; set; }
    }
}
