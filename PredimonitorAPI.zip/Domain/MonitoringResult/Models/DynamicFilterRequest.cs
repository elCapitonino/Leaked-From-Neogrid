﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.MonitoringResult.Models
{
    public class DynamicFilterRequest
    {
        public List<string?> ProductNames { get; set; }
        public List<long?> MonitoringItemIds { get; set; }
        public List<string?> Categories { get; set; }
        public List<string?> Sellers { get; set; }
        public List<string?> Brands { get; set; }
        public List<string?> Origins { get; set; }
        public List<string?> States { get; set; }
        public List<string?> Years { get; set; }
        public List<string?>? Models { get; set; }
        public bool IsCost { get; set; }
    }

}
