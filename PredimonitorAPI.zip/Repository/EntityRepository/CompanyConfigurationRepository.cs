﻿using Repository.DbContexts;
using Repository.Entity;
using Repository.EntityRepository.Bases;

namespace Repository.EntityRepository
{
    public class CompanyConfigurationRepository : GenericRepository<CompanyConfigurationEntity, long>, ICompanyConfigurationRepository
    {
        public CompanyConfigurationRepository(ApplicationDbContext dbContext) : base(dbContext)
        {
        }
        public static string DbContextName => nameof(ApplicationDbContext);
    }
}
