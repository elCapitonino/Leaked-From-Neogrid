using Domain.Product.Models;

namespace Domain.Product;

public interface IProductDomain
{
    Task<ProductResponse> GetGroupedProducts(FiltersRequest request);
    void SaveCompanyProductPrice(CompanyProductPriceRequest request);
    Task<MapDataResponse> GetMapData(FiltersRequest request);
    Task<IEnumerable<ProductComparisonResponse>> GetProductComparisonData(FiltersRequest request);
    Task<CompetitivenessIndexResponse> GetCompetitivenessIndexData(FiltersRequest request);
}