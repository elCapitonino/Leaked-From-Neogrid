﻿using Repository.Entity;

namespace Repository.EntityRepository
{
    public sealed class RuleRepository : GenericRepository<DinPreRule_ConditionEntity>, IRuleRepository
    {
        public new static string DbContextName => nameof(ApplicationDbContext);
        public RuleRepository(ApplicationDbContext dbContext) : base(dbContext)
        {
        }
    }
}
