﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Repository.Attributes;
using Repository.DbContexts;
using Repository.Entity;

namespace Repository.TypeConfiguration
{
    [DbContextTypeConfiguration(typeof(ApplicationDbContext))]
    public class ProductMarketResultSellerTypeConfiguration : TypeConfigurationBase<ProductMarketResultSellerEntity>, IEntityTypeConfiguration<ProductMarketResultSellerEntity>
    {
        public override void Configure(EntityTypeBuilder<ProductMarketResultSellerEntity> builder)
        {
            builder.ToTable("ProductMarketResultSeller");
            builder.Property(x => x.Id).HasColumnName("IdProductMarketResultSeller");
            builder.Property(x => x.CompanyId).HasColumnName("IdCompany");
            builder.Property(x => x.SellerName).HasMaxLength(256);
        }
    }
}
