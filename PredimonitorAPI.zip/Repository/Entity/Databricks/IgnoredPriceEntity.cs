namespace Repository.Entity.Databricks;

public class IgnoredPriceEntity
{
    public string? Id { get; set; }
    public int CompanyId { get; set; }
    public string? ProductPriceId { get; set; }
}