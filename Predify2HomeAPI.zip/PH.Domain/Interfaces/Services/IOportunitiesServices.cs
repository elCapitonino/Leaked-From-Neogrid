﻿using PH.Domain.DTO;

namespace PH.Domain.Interfaces.Services
{
    public interface IOportunitiesServices
    {
        Task<OportunitiesMainDTO> Get(long idCompany, long idPriceGroup);
    }
}
