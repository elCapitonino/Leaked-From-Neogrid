﻿using Domain.CompanyMonitoringCrawler;
using Domain.MonitoringResult;
using Domain.MonitoringResult.Models;
using DomainTests.DynamicFilter.Seed;
using DomainTests.Extensions;
using MathNet.Numerics;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.DependencyInjection;
using MongoDB.Driver;
using Moq;
using Repository.DbContexts;
using Repository.Entity;
using Repository.Enums;
using Repository.UnitOfWork;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainTests.MonitoringResult
{
    [TestClass]
    public class MonitoringResultFilteredDataTests
    {
        private IServiceCollection _services;
        private ServiceProvider _serviceProvider;

        [TestInitialize]
        public void Initialize()
        {
            _services = new ServiceCollection();
            var mongo = new Mock<MongoClient>().Object;

            _services.AddDbContext<ApplicationDbContext>(options => options.UseSqlite("Filename=:memory:").ConfigureWarnings(opt => opt.Ignore(RelationalEventId.AmbientTransactionWarning)));

            _services.AddTransient<IMongoClient>(provider => mongo);
            _services.AddScoped<IMonitoringResultDomain, MonitoringResultDomain>();
            _services.AddScoped<ICompanyMonitoringCrawlerDomain, CompanyMonitoringCrawlerDomain>();
            _services.AddScoped<IUnitOfWork, UnitOfWork>();
            _services.AddMemoryCache();
            _services.AddLogging();

            _services.AddDbContext<HorusDbContext>(options => options.UseMongoDB(mongo, "Horus").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            _services.AddDbContext<InfoPriceSaoJoaoDbContext>(options => options.UseMongoDB(mongo, "InfroPriceSaoJoao").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            _services.AddDbContext<NormalizerDbContext>(options => options.UseMongoDB(mongo, "Normalizer").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            _services.AddDbContext<LinxDbContext>(options => options.UseMongoDB(mongo, "Linx").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            _services.AddDbContext<NeogridDbContext>(options => options.UseMongoDB(mongo, "Neogrid").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            _services.AddDbContext<NielsenDbContext>(options => options.UseMongoDB(mongo, "Nielsen").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            _services.AddDbContext<SmarketCompetitorDbContext>(options => options.UseMongoDB(mongo, "SmarketCompetitor").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            _services.AddDbContext<OfflineDbContext>(options => options.UseMongoDB(mongo, "Offline").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            _services.AddDbContext<ScantechSupermaxiDbContext>(options => options.UseMongoDB(mongo, "Scantech").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);

            _services.AddTransient(provider => new DatabricsDbContext("", ""));

            _services.SetAutoMapper();

            _serviceProvider = _services.BuildServiceProvider();

            var context = _serviceProvider.GetRequiredService<ApplicationDbContext>();
            context.Database.OpenConnection();
            context.Database.EnsureCreated();
        }

        [TestMethod]
        public void ShouldApplyFiltersCorrectly()
        {
            var uow = _serviceProvider.GetService<IUnitOfWork>()!;
            var domain = _serviceProvider.GetService<IMonitoringResultDomain>();

                        uow.Company.AddRange(CompanySeed.GetTestData(), autosave: true);
            uow.MonitoringCrawler.AddRange(MonitoringCrawlerSeed.GetTestData(), autosave: true);
            uow.MonitoringItem.AddRange(MonitoringItemSeed.GetTestData(), autosave: true);
            uow.MonitoringItemResults.AddRange(MonitoringItemResultsSeed.GetTestData(), autosave: true);

            
            var request = new DynamicFilterRequest
            {
                Categories = new List<string?> { "Electronics" },
                Brands = new List<string?> { "BrandA", "BrandB" },
                States = new List<string?> { "CA", "TX" },
                Years = new List<string?> { "2022" }
            };

            
            var result = domain.GetMonitoringResultFilteredData(1, request).Result;

            // Assertions to verify the filters were applied correctly
            Assert.IsTrue(result.Categories.All(c => c == "Electronics"), "Todas as categorias devem ser 'Electronics'");
            Assert.IsTrue(result.Brands.All(b => b == "BrandA" || b == "BrandB"), "Todas as marcas devem ser 'BrandA' ou 'BrandB'");
            Assert.IsTrue(result.States.All(s => s == "CA" || s == "TX"), "Todos os estados devem ser 'CA' ou 'TX'");
            Assert.IsTrue(result.Years.All(y => y == "2022"), "Todos os anos devem ser '2022'");

            // Additional assertions to ensure uniqueness and correct filtering
            Assert.AreEqual(result.Categories.Distinct().Count(), result.Categories.Count(), "As categorias devem ser únicas");
            Assert.AreEqual(result.Brands.Distinct().Count(), result.Brands.Count(), "As marcas devem ser únicas");
            Assert.AreEqual(result.States.Distinct().Count(), result.States.Count(), "Os estados devem ser únicos");
            Assert.AreEqual(result.Years.Distinct().Count(), result.Years.Count(), "Os anos devem ser únicos");
        }

        [TestMethod]
        public void ShouldReturnAllResultsWhenNoFiltersAreApplied()
        {
            // Arrange
            var uow = _serviceProvider.GetService<IUnitOfWork>()!;
            var domain = _serviceProvider.GetService<IMonitoringResultDomain>();

            var company = new CompanyEntity
            {
                Id = 1,
                Company = "Company1",
                Cnpj = "00.000.000/0001-01"
            };
            uow.Company.Create(company, autosave: true);

            var crawlers = new List<MonitoringCrawlerEntity>
            {
                new MonitoringCrawlerEntity { Id = 101, Description = "Linx" },
                new MonitoringCrawlerEntity { Id = 102, Description = "Nielsen" },
                new MonitoringCrawlerEntity { Id = 103, Description = "Smarket" },
                new MonitoringCrawlerEntity { Id = 104, Description = "Neogrid" },
                new MonitoringCrawlerEntity { Id = 105, Description = "InfoPrice" },
                new MonitoringCrawlerEntity { Id = 106, Description = "Horus" },
                new MonitoringCrawlerEntity { Id = 107, Description = "Normalizer" },
                new MonitoringCrawlerEntity { Id = 108, Description = "Predify" },
                new MonitoringCrawlerEntity { Id = 109, Description = "Indireta" },
                new MonitoringCrawlerEntity { Id = 110, Description = "Vem" }
            };
            uow.MonitoringCrawler.AddRange(crawlers, autosave: true);

            var companyMonitoringCrawlers = new List<CompanyMonitoringCrawlerEntity>
            {
                new CompanyMonitoringCrawlerEntity
                {
                    CompanyId = company.Id,
                    MonitoringCrawlerId = 101,
                    Source = PreSegmentoSource.Linx,
                    CrawlerType = CrawlersTypes.Search,
                    Store = "Linx Store",
                    StoreType = "Online",
                    City = "São Paulo",
                    State = "SP",
                    Networks = "Linx Network",
                    Cnpj = "00.000.000/0001-01",
                    ExactVector = true,
                    UseInPricing = true,
                    IsSale = true,
                    IsCost = false,
                    IsDeleted = false
                },
                new CompanyMonitoringCrawlerEntity
                {
                    CompanyId = company.Id,
                    MonitoringCrawlerId = 102,
                    Source = PreSegmentoSource.Nielsen,
                    CrawlerType = CrawlersTypes.Paginate,
                    Store = "Nielsen Store",
                    StoreType = "Physical",
                    City = "Rio de Janeiro",
                    State = "RJ",
                    Networks = "Nielsen Network",
                    Cnpj = "00.000.000/0002-02",
                    ExactVector = false,
                    UseInPricing = false,
                    IsSale = true,
                    IsCost = false,
                    IsDeleted = false
                }
            };
            uow.CompanyMonitoringCrawler.AddRange(companyMonitoringCrawlers, autosave: true);

            var monitoringItems = new List<MonitoringItemEntity>
            {
                new MonitoringItemEntity { Id = 201, CompanyId = company.Id, Description = "Product A" },
                new MonitoringItemEntity { Id = 202, CompanyId = company.Id, Description = "Product B" },
            };
            uow.MonitoringItem.AddRange(monitoringItems, autosave: true);

            var monitoringItemResults = new List<MonitoringItemResultsEntity>
            {
                new MonitoringItemResultsEntity
                {
                    CompanyId = company.Id,
                    MonitoringItemId = 201,
                    CrawlerId = 101,
                    Category = "Electronics",
                    Seller = "Seller A",
                    Brand = "Brand A",
                    State = "SP",
                    Year = "2022",
                    Hash = "hash1"
                },
                new MonitoringItemResultsEntity
                {
                    CompanyId = company.Id,
                    MonitoringItemId = 202,
                    CrawlerId = 102,
                    Category = "Groceries",
                    Seller = "Seller B",
                    Brand = "Brand B",
                    State = "RJ",
                    Year = "2023",
                    Hash = "hash2"
                }
            };
            uow.MonitoringItemResults.AddRange(monitoringItemResults, autosave: true);

            // Act
            var request = new DynamicFilterRequest();

            var result = domain.GetMonitoringResultFilteredData(company.Id, request).Result;

            // Assert
            Assert.AreEqual(2, result.Products.Count(), "O número de produtos retornados deve ser igual ao total de resultados sem filtros.");
            Assert.AreEqual(2, result.Categories.Count(), "O número de categorias distintas deve ser igual ao número total de categorias sem filtros.");
            Assert.AreEqual(2, result.Sellers.Count(), "O número de vendedores distintos deve ser igual ao número total de vendedores sem filtros.");
            Assert.AreEqual(2, result.Brands.Count(), "O número de marcas distintas deve ser igual ao número total de marcas sem filtros.");
            Assert.AreEqual(2, result.States.Count(), "O número de estados distintos deve ser igual ao número total de estados sem filtros.");
            Assert.AreEqual(2, result.Years.Count(), "O número de anos distintos deve ser igual ao número total de anos sem filtros.");
        }
        [TestMethod]
        public void ShouldFilterByProductAndReturnCorrectRelatedData()
        {
            // Arrange
            var uow = _serviceProvider.GetService<IUnitOfWork>()!;
            var domain = _serviceProvider.GetService<IMonitoringResultDomain>();

            
            var company = new CompanyEntity
            {
                Id = 1,
                Company = "Company1",
                Cnpj = "00.000.000/0001-01"
            };
            uow.Company.Create(company, autosave: true);

            
            var crawlers = new List<MonitoringCrawlerEntity>
    {
        new MonitoringCrawlerEntity { Id = 101, Description = "Linx" },
        new MonitoringCrawlerEntity { Id = 102, Description = "Nielsen" },
    };
            uow.MonitoringCrawler.AddRange(crawlers, autosave: true);

            var companyMonitoringCrawlers = new List<CompanyMonitoringCrawlerEntity>
            {
                new CompanyMonitoringCrawlerEntity
                {
                    CompanyId = company.Id,
                    MonitoringCrawlerId = 101,
                    Source = PreSegmentoSource.Linx,
                    CrawlerType = CrawlersTypes.Search,
                    Store = "Linx Store",
                    StoreType = "Online",
                    City = "São Paulo",
                    State = "SP",
                    Networks = "Linx Network",
                    Cnpj = "00.000.000/0001-01",
                    ExactVector = true,
                    UseInPricing = true,
                    IsSale = true,
                    IsCost = false,
                    IsDeleted = false
                },
                new CompanyMonitoringCrawlerEntity
                {
                    CompanyId = company.Id,
                    MonitoringCrawlerId = 102,
                    Source = PreSegmentoSource.Nielsen,
                    CrawlerType = CrawlersTypes.Paginate,
                    Store = "Nielsen Store",
                    StoreType = "Physical",
                    City = "Rio de Janeiro",
                    State = "RJ",
                    Networks = "Nielsen Network",
                    Cnpj = "00.000.000/0002-02",
                    ExactVector = false,
                    UseInPricing = false,
                    IsSale = true,
                    IsCost = false,
                    IsDeleted = false
                }
            };
            uow.CompanyMonitoringCrawler.AddRange(companyMonitoringCrawlers, autosave: true);

            
            var monitoringItems = new List<MonitoringItemEntity>
    {
        new MonitoringItemEntity { Id = 201, CompanyId = company.Id, Description = "Product A" },
        new MonitoringItemEntity { Id = 202, CompanyId = company.Id, Description = "Product B" },
    };
            uow.MonitoringItem.AddRange(monitoringItems, autosave: true);

            
            var monitoringItemResults = new List<MonitoringItemResultsEntity>
    {
        new MonitoringItemResultsEntity
        {
            CompanyId = company.Id,
            MonitoringItemId = 201,
            MonitoringItem = monitoringItems[0],  
            CrawlerId = 101,
            MonitoringCrawler = crawlers[0],     
            Category = "Electronics",
            Seller = "Seller A",
            Brand = "Brand A",
            State = "SP",
            Year = "2022",
            Hash = "hash1"
        },
        new MonitoringItemResultsEntity
        {
            CompanyId = company.Id,
            MonitoringItemId = 202,
            MonitoringItem = monitoringItems[1],  
            CrawlerId = 102,
            MonitoringCrawler = crawlers[1],      
            Category = "Groceries",
            Seller = "Seller B",
            Brand = "Brand B",
            State = "RJ",
            Year = "2023",
            Hash = "hash2"
        },
    };
            uow.MonitoringItemResults.AddRange(monitoringItemResults, autosave: true);

            // Act
            var request = new DynamicFilterRequest
            {
                ProductNames = new List<string?> { "Product A" }
            };
            var result = domain.GetMonitoringResultFilteredData(company.Id, request).Result;

            // Assert
            Assert.AreEqual(2, result.Products.Count(), "O número de produtos retornados deve ser igual a 2.");
            Assert.AreEqual("Product A", result.Products.First().ProductName, "O produto retornado deve ser 'Product A'.");
            Assert.AreEqual("Product B", result.Products.Last().ProductName, "O produto retornado deve ser 'Product B'.");

            Assert.AreEqual(1, result.Categories.Count(), "O número de categorias distintas deve ser igual a 1.");
            Assert.AreEqual("Electronics", result.Categories.First(), "A categoria retornada deve ser 'Electronics'.");

            Assert.AreEqual(1, result.Sellers.Count(), "O número de vendedores distintos deve ser igual a 1.");
            Assert.AreEqual("Seller A", result.Sellers.First(), "O vendedor retornado deve ser 'Seller A'.");

            Assert.AreEqual(1, result.Brands.Count(), "O número de marcas distintas deve ser igual a 1.");
            Assert.AreEqual("Brand A", result.Brands.First(), "A marca retornada deve ser 'Brand A'.");

            Assert.AreEqual(1, result.States.Count(), "O número de estados distintos deve ser igual a 1.");
            Assert.AreEqual("SP", result.States.First(), "O estado retornado deve ser 'SP'.");

            Assert.AreEqual(1, result.Years.Count(), "O número de anos distintos deve ser igual a 1.");
            Assert.AreEqual("2022", result.Years.First(), "O ano retornado deve ser '2022'.");

            Assert.AreEqual(1, result.Origins.Count(), "O número de origens distintas deve ser igual a 1.");
            Assert.AreEqual("Linx", result.Origins.First(), "A origem retornada deve ser 'Linx'.");
        }

        [TestMethod]
        public void ShouldFilterByMultipleProductsAndReturnCombinedRelatedData()
        {
            // Arrange
            var uow = _serviceProvider.GetService<IUnitOfWork>()!;
            var domain = _serviceProvider.GetService<IMonitoringResultDomain>();

            
            var company = new CompanyEntity
            {
                Id = 1,
                Company = "Company1",
                Cnpj = "00.000.000/0001-01"
            };
            uow.Company.Create(company, autosave: true);

            

            
            var crawlers = new List<MonitoringCrawlerEntity>
    {
        new MonitoringCrawlerEntity { Id = 101, Description = "Linx" },
        new MonitoringCrawlerEntity { Id = 102, Description = "Nielsen" },
    };
            uow.MonitoringCrawler.AddRange(crawlers, autosave: true);

            
            var monitoringItems = new List<MonitoringItemEntity>
    {
        new MonitoringItemEntity { Id = 201, CompanyId = company.Id, Description = "Product A" },
        new MonitoringItemEntity { Id = 202, CompanyId = company.Id, Description = "Product B" },
    };
            uow.MonitoringItem.AddRange(monitoringItems, autosave: true);

            
            var monitoringItemResults = new List<MonitoringItemResultsEntity>
    {
        new MonitoringItemResultsEntity
        {
            CompanyId = company.Id,
            MonitoringItemId = 201,
            MonitoringItem = monitoringItems[0],  
            CrawlerId = 101,
            MonitoringCrawler = crawlers[0],     
            Category = "Electronics",
            Seller = "Seller A",
            Brand = "Brand A",
            State = "SP",
            Year = "2022",
            Hash = "hash1"
        },
        new MonitoringItemResultsEntity
        {
            CompanyId = company.Id,
            MonitoringItemId = 202,
            MonitoringItem = monitoringItems[1],  
            CrawlerId = 102,
            MonitoringCrawler = crawlers[1],      
            Category = "Groceries",
            Seller = "Seller B",
            Brand = "Brand B",
            State = "RJ",
            Year = "2023",
            Hash = "hash2"
        },
        
        new MonitoringItemResultsEntity
        {
            CompanyId = company.Id,
            MonitoringItemId = 202,
            MonitoringItem = monitoringItems[1],  
            CrawlerId = 101,
            MonitoringCrawler = crawlers[0],     
            Category = "Groceries",
            Seller = "Seller A",
            Brand = "Brand A",
            State = "SP",
            Year = "2022",
            Hash = "hash3"
        }
    };
            uow.MonitoringItemResults.AddRange(monitoringItemResults, autosave: true);


            var companyMonitoringCrawlers = new List<CompanyMonitoringCrawlerEntity>
            {
                new CompanyMonitoringCrawlerEntity
                {
                    CompanyId = company.Id,
                    MonitoringCrawlerId = 101,
                    Source = PreSegmentoSource.Linx,
                    CrawlerType = CrawlersTypes.Search,
                    Store = "Linx Store",
                    StoreType = "Online",
                    City = "São Paulo",
                    State = "SP",
                    Networks = "Linx Network",
                    Cnpj = "00.000.000/0001-01",
                    ExactVector = true,
                    UseInPricing = true,
                    IsSale = true,
                    IsCost = false,
                    IsDeleted = false
                },
                new CompanyMonitoringCrawlerEntity
                {
                    CompanyId = company.Id,
                    MonitoringCrawlerId = 102,
                    Source = PreSegmentoSource.Nielsen,
                    CrawlerType = CrawlersTypes.Paginate,
                    Store = "Nielsen Store",
                    StoreType = "Physical",
                    City = "Rio de Janeiro",
                    State = "RJ",
                    Networks = "Nielsen Network",
                    Cnpj = "00.000.000/0002-02",
                    ExactVector = false,
                    UseInPricing = false,
                    IsSale = true,
                    IsCost = false,
                    IsDeleted = false
                }
            };
            uow.CompanyMonitoringCrawler.AddRange(companyMonitoringCrawlers, autosave: true);


            // Act
            var request = new DynamicFilterRequest
            {
                ProductNames = new List<string?> { "Product A", "Product B" }
            };
            var result = domain.GetMonitoringResultFilteredData(company.Id, request).Result;

            // Assert
            Assert.AreEqual(2, result.Products.Count(), "O número de produtos retornados deve ser igual a 2.");
            Assert.IsTrue(result.Products.Any(p => p.ProductName == "Product A"), "O produto retornado deve incluir 'Product A'.");
            Assert.IsTrue(result.Products.Any(p => p.ProductName == "Product B"), "O produto retornado deve incluir 'Product B'.");

            Assert.AreEqual(2, result.Categories.Count(), "O número de categorias distintas deve ser igual a 2.");
            Assert.IsTrue(result.Categories.Contains("Electronics"), "A categoria retornada deve incluir 'Electronics'.");
            Assert.IsTrue(result.Categories.Contains("Groceries"), "A categoria retornada deve incluir 'Groceries'.");

            Assert.AreEqual(2, result.Sellers.Count(), "O número de vendedores distintos deve ser igual a 2.");
            Assert.IsTrue(result.Sellers.Contains("Seller A"), "O vendedor retornado deve incluir 'Seller A'.");
            Assert.IsTrue(result.Sellers.Contains("Seller B"), "O vendedor retornado deve incluir 'Seller B'.");

            Assert.AreEqual(2, result.Brands.Count(), "O número de marcas distintas deve ser igual a 2.");
            Assert.IsTrue(result.Brands.Contains("Brand A"), "A marca retornada deve incluir 'Brand A'.");
            Assert.IsTrue(result.Brands.Contains("Brand B"), "A marca retornada deve incluir 'Brand B'.");

            Assert.AreEqual(2, result.States.Count(), "O número de estados distintos deve ser igual a 2.");
            Assert.IsTrue(result.States.Contains("SP"), "O estado retornado deve incluir 'SP'.");
            Assert.IsTrue(result.States.Contains("RJ"), "O estado retornado deve incluir 'RJ'.");

            Assert.AreEqual(2, result.Years.Count(), "O número de anos distintos deve ser igual a 2.");
            Assert.IsTrue(result.Years.Contains("2022"), "O ano retornado deve incluir '2022'.");
            Assert.IsTrue(result.Years.Contains("2023"), "O ano retornado deve incluir '2023'.");

            Assert.AreEqual(2, result.Origins.Count(), "O número de origens distintas deve ser igual a 2.");
            Assert.IsTrue(result.Origins.Contains("Linx"), "A origem retornada deve incluir 'Linx'.");
            Assert.IsTrue(result.Origins.Contains("Nielsen"), "A origem retornada deve incluir 'Nielsen'.");
        }

        [TestMethod]
        public void ShouldFilterByMultipleProductsAndReturnCombinedRelatedDataWithMultipleMonitoringItems()
        {
            // Arrange
            var uow = _serviceProvider.GetService<IUnitOfWork>()!;
            var domain = _serviceProvider.GetService<IMonitoringResultDomain>();

            
            var company = new CompanyEntity
            {
                Id = 1,
                Company = "Company1",
                Cnpj = "00.000.000/0001-01"
            };
            uow.Company.Create(company, autosave: true);

            
            var crawlers = new List<MonitoringCrawlerEntity>
    {
        new MonitoringCrawlerEntity { Id = 101, Description = "Linx" },
        new MonitoringCrawlerEntity { Id = 102, Description = "Nielsen" },
    };
            uow.MonitoringCrawler.AddRange(crawlers, autosave: true);

            
            var monitoringItems = new List<MonitoringItemEntity>
    {
        new MonitoringItemEntity { Id = 201, CompanyId = company.Id, Description = "Product A" },
        new MonitoringItemEntity { Id = 202, CompanyId = company.Id, Description = "Product B" },
        new MonitoringItemEntity { Id = 203, CompanyId = company.Id, Description = "Product C" },
    };
            uow.MonitoringItem.AddRange(monitoringItems, autosave: true);

            
            var monitoringItemResults = new List<MonitoringItemResultsEntity>
    {
        new MonitoringItemResultsEntity
        {
            CompanyId = company.Id,
            MonitoringItemId = 201,
            MonitoringItem = monitoringItems[0],  
            CrawlerId = 101,
            MonitoringCrawler = crawlers[0],     
            Category = "Electronics",
            Seller = "Seller A",
            Brand = "Brand A",
            State = "SP",
            Year = "2022",
            Hash = "hash1"
        },
        new MonitoringItemResultsEntity
        {
            CompanyId = company.Id,
            MonitoringItemId = 202,
            MonitoringItem = monitoringItems[1],  
            CrawlerId = 102,
            MonitoringCrawler = crawlers[1],      
            Category = "Groceries",
            Seller = "Seller B",
            Brand = "Brand B",
            State = "RJ",
            Year = "2023",
            Hash = "hash2"
        },
        
        new MonitoringItemResultsEntity
        {
            CompanyId = company.Id,
            MonitoringItemId = 202,
            MonitoringItem = monitoringItems[1],  
            CrawlerId = 101,
            MonitoringCrawler = crawlers[0],     
            Category = "Groceries",
            Seller = "Seller A",
            Brand = "Brand A",
            State = "SP",
            Year = "2022",
            Hash = "hash3"
        },
        new MonitoringItemResultsEntity
        {
            CompanyId = company.Id,
            MonitoringItemId = 203,
            MonitoringItem = monitoringItems[2],  
            CrawlerId = 101,
            MonitoringCrawler = crawlers[0],     
            Category = "Clothing",
            Seller = "Seller C",
            Brand = "Brand C",
            State = "MG",
            Year = "2022",
            Hash = "hash4"
        },
        new MonitoringItemResultsEntity
        {
            CompanyId = company.Id,
            MonitoringItemId = 203,
            MonitoringItem = monitoringItems[2],  
            CrawlerId = 102,
            MonitoringCrawler = crawlers[1],     
            Category = "Clothing",
            Seller = "Seller C",
            Brand = "Brand C",
            State = "RJ",
            Year = "2023",
            Hash = "hash5"
        }
    };
            uow.MonitoringItemResults.AddRange(monitoringItemResults, autosave: true);

            var companyMonitoringCrawlers = new List<CompanyMonitoringCrawlerEntity>
            {
                new CompanyMonitoringCrawlerEntity
                {
                    CompanyId = company.Id,
                    MonitoringCrawlerId = 101,
                    Source = PreSegmentoSource.Linx,
                    CrawlerType = CrawlersTypes.Search,
                    Store = "Linx Store",
                    StoreType = "Online",
                    City = "São Paulo",
                    State = "SP",
                    Networks = "Linx Network",
                    Cnpj = "00.000.000/0001-01",
                    ExactVector = true,
                    UseInPricing = true,
                    IsSale = true,
                    IsCost = false,
                    IsDeleted = false
                },
                new CompanyMonitoringCrawlerEntity
                {
                    CompanyId = company.Id,
                    MonitoringCrawlerId = 102,
                    Source = PreSegmentoSource.Nielsen,
                    CrawlerType = CrawlersTypes.Paginate,
                    Store = "Nielsen Store",
                    StoreType = "Physical",
                    City = "Rio de Janeiro",
                    State = "RJ",
                    Networks = "Nielsen Network",
                    Cnpj = "00.000.000/0002-02",
                    ExactVector = false,
                    UseInPricing = false,
                    IsSale = true,
                    IsCost = false,
                    IsDeleted = false
                }
            };
            uow.CompanyMonitoringCrawler.AddRange(companyMonitoringCrawlers, autosave: true);

            // Act
            var request = new DynamicFilterRequest
            {
                ProductNames = new List<string?> { "Product A", "Product B" }
            };
            var result = domain.GetMonitoringResultFilteredData(company.Id, request).Result;

            // Assert
            Assert.AreEqual(3, result.Products.Count(), "O número de produtos retornados deve ser igual a 3.");
            Assert.IsTrue(result.Products.Any(p => p.ProductName == "Product A"), "O produto retornado deve incluir 'Product A'.");
            Assert.IsTrue(result.Products.Any(p => p.ProductName == "Product B"), "O produto retornado deve incluir 'Product B'.");
            Assert.IsTrue(result.Products.Any(p => p.ProductName == "Product C"), "O produto retornado deve incluir 'Product C'.");

            Assert.AreEqual(2, result.Categories.Count(), "O número de categorias distintas deve ser igual a 2.");
            Assert.IsTrue(result.Categories.Contains("Electronics"), "A categoria retornada deve incluir 'Electronics'.");
            Assert.IsTrue(result.Categories.Contains("Groceries"), "A categoria retornada deve incluir 'Groceries'.");

            Assert.AreEqual(2, result.Sellers.Count(), "O número de vendedores distintos deve ser igual a 2.");
            Assert.IsTrue(result.Sellers.Contains("Seller A"), "O vendedor retornado deve incluir 'Seller A'.");
            Assert.IsTrue(result.Sellers.Contains("Seller B"), "O vendedor retornado deve incluir 'Seller B'.");

            Assert.AreEqual(2, result.Brands.Count(), "O número de marcas distintas deve ser igual a 2.");
            Assert.IsTrue(result.Brands.Contains("Brand A"), "A marca retornada deve incluir 'Brand A'.");
            Assert.IsTrue(result.Brands.Contains("Brand B"), "A marca retornada deve incluir 'Brand B'.");

            Assert.AreEqual(2, result.States.Count(), "O número de estados distintos deve ser igual a 2.");
            Assert.IsTrue(result.States.Contains("SP"), "O estado retornado deve incluir 'SP'.");
            Assert.IsTrue(result.States.Contains("RJ"), "O estado retornado deve incluir 'RJ'.");

            Assert.AreEqual(2, result.Years.Count(), "O número de anos distintos deve ser igual a 2.");
            Assert.IsTrue(result.Years.Contains("2022"), "O ano retornado deve incluir '2022'.");
            Assert.IsTrue(result.Years.Contains("2023"), "O ano retornado deve incluir '2023'.");

            Assert.AreEqual(2, result.Origins.Count(), "O número de origens distintas deve ser igual a 2.");
            Assert.IsTrue(result.Origins.Contains("Linx"), "A origem retornada deve incluir 'Linx'.");
            Assert.IsTrue(result.Origins.Contains("Nielsen"), "A origem retornada deve incluir 'Nielsen'.");
        }

        [TestMethod]
        public void ShouldFilterBySellerAndReturnCorrectRelatedData()
        {
            // Arrange
            var uow = _serviceProvider.GetService<IUnitOfWork>()!;
            var domain = _serviceProvider.GetService<IMonitoringResultDomain>();

            
            var company = new CompanyEntity
            {
                Id = 1,
                Company = "Company1",
                Cnpj = "00.000.000/0001-01"
            };
            uow.Company.Create(company, autosave: true);

            
            var crawlers = new List<MonitoringCrawlerEntity>
    {
        new MonitoringCrawlerEntity { Id = 101, Description = "Linx" },
        new MonitoringCrawlerEntity { Id = 102, Description = "Nielsen" },
    };
            uow.MonitoringCrawler.AddRange(crawlers, autosave: true);

            
            var monitoringItems = new List<MonitoringItemEntity>
    {
        new MonitoringItemEntity { Id = 201, CompanyId = company.Id, Description = "Product A" },
        new MonitoringItemEntity { Id = 202, CompanyId = company.Id, Description = "Product B" },
        new MonitoringItemEntity { Id = 203, CompanyId = company.Id, Description = "Product C" },
    };
            uow.MonitoringItem.AddRange(monitoringItems, autosave: true);

            
            var monitoringItemResults = new List<MonitoringItemResultsEntity>
    {
        new MonitoringItemResultsEntity
        {
            CompanyId = company.Id,
            MonitoringItemId = 201,
            MonitoringItem = monitoringItems[0],  
            CrawlerId = 101,
            MonitoringCrawler = crawlers[0],     
            Category = "Electronics",
            Seller = "Seller A",
            Brand = "Brand A",
            State = "SP",
            Year = "2022",
            Hash = "hash1"
        },
        new MonitoringItemResultsEntity
        {
            CompanyId = company.Id,
            MonitoringItemId = 202,
            MonitoringItem = monitoringItems[1],  
            CrawlerId = 102,
            MonitoringCrawler = crawlers[1],      
            Category = "Groceries",
            Seller = "Seller B",
            Brand = "Brand B",
            State = "RJ",
            Year = "2023",
            Hash = "hash2"
        },
        
        new MonitoringItemResultsEntity
        {
            CompanyId = company.Id,
            MonitoringItemId = 203,
            MonitoringItem = monitoringItems[2],  
            CrawlerId = 101,
            MonitoringCrawler = crawlers[0],     
            Category = "Clothing",
            Seller = "Seller A",
            Brand = "Brand C",
            State = "MG",
            Year = "2022",
            Hash = "hash3"
        },
        new MonitoringItemResultsEntity
        {
            CompanyId = company.Id,
            MonitoringItemId = 203,
            MonitoringItem = monitoringItems[2],  
            CrawlerId = 102,
            MonitoringCrawler = crawlers[1],     
            Category = "Clothing",
            Seller = "Seller B",
            Brand = "Brand C",
            State = "RJ",
            Year = "2023",
            Hash = "hash4"
        }
    };
            uow.MonitoringItemResults.AddRange(monitoringItemResults, autosave: true);

            var companyMonitoringCrawlers = new List<CompanyMonitoringCrawlerEntity>
            {
                new CompanyMonitoringCrawlerEntity
                {
                    CompanyId = company.Id,
                    MonitoringCrawlerId = 101,
                    Source = PreSegmentoSource.Linx,
                    CrawlerType = CrawlersTypes.Search,
                    Store = "Linx Store",
                    StoreType = "Online",
                    City = "São Paulo",
                    State = "SP",
                    Networks = "Linx Network",
                    Cnpj = "00.000.000/0001-01",
                    ExactVector = true,
                    UseInPricing = true,
                    IsSale = true,
                    IsCost = false,
                    IsDeleted = false
                },
                new CompanyMonitoringCrawlerEntity
                {
                    CompanyId = company.Id,
                    MonitoringCrawlerId = 102,
                    Source = PreSegmentoSource.Nielsen,
                    CrawlerType = CrawlersTypes.Paginate,
                    Store = "Nielsen Store",
                    StoreType = "Physical",
                    City = "Rio de Janeiro",
                    State = "RJ",
                    Networks = "Nielsen Network",
                    Cnpj = "00.000.000/0002-02",
                    ExactVector = false,
                    UseInPricing = false,
                    IsSale = true,
                    IsCost = false,
                    IsDeleted = false
                }
            };
            uow.CompanyMonitoringCrawler.AddRange(companyMonitoringCrawlers, autosave: true);

            // Act
            var request = new DynamicFilterRequest
            {
                Sellers = new List<string?> { "Seller A" }
            };
            var result = domain.GetMonitoringResultFilteredData(company.Id, request).Result;

            // Assert
            Assert.AreEqual(2, result.Products.Count(), "O número de produtos retornados deve ser igual a 2.");
            Assert.IsTrue(result.Products.Any(p => p.ProductName == "Product A"), "O produto retornado deve incluir 'Product A'.");
            Assert.IsTrue(result.Products.Any(p => p.ProductName == "Product C"), "O produto retornado deve incluir 'Product C'.");

            Assert.AreEqual(2, result.Categories.Count(), "O número de categorias distintas deve ser igual a 2.");
            Assert.IsTrue(result.Categories.Contains("Electronics"), "A categoria retornada deve incluir 'Electronics'.");
            Assert.IsTrue(result.Categories.Contains("Clothing"), "A categoria retornada deve incluir 'Clothing'.");

            Assert.AreEqual(2, result.Sellers.Count(), "O número de vendedores distintos deve ser igual a 2.");
            Assert.AreEqual("Seller A", result.Sellers.First(), "O vendedor retornado deve ser 'Seller A'.");

            Assert.AreEqual(2, result.Brands.Count(), "O número de marcas distintas deve ser igual a 2.");
            Assert.IsTrue(result.Brands.Contains("Brand A"), "A marca retornada deve incluir 'Brand A'.");
            Assert.IsTrue(result.Brands.Contains("Brand C"), "A marca retornada deve incluir 'Brand C'.");

            Assert.AreEqual(2, result.States.Count(), "O número de estados distintos deve ser igual a 2.");
            Assert.IsTrue(result.States.Contains("SP"), "O estado retornado deve incluir 'SP'.");
            Assert.IsTrue(result.States.Contains("MG"), "O estado retornado deve incluir 'MG'.");

            Assert.AreEqual(1, result.Years.Count(), "O número de anos distintos deve ser igual a 1.");
            Assert.AreEqual("2022", result.Years.First(), "O ano retornado deve ser '2022'.");

            Assert.AreEqual(1, result.Origins.Count(), "O número de origens distintas deve ser igual a 1.");
            Assert.AreEqual("Linx", result.Origins.First(), "A origem retornada deve ser 'Linx'.");
        }
        [TestMethod]
        public void ShouldFilterByOriginAndReturnCorrectRelatedData()
        {
            // Arrange
            var uow = _serviceProvider.GetService<IUnitOfWork>()!;
            var domain = _serviceProvider.GetService<IMonitoringResultDomain>();

            
            var company = new CompanyEntity
            {
                Id = 1,
                Company = "Company1",
                Cnpj = "00.000.000/0001-01"
            };
            uow.Company.Create(company, autosave: true);

            
            var crawlers = new List<MonitoringCrawlerEntity>
    {
        new MonitoringCrawlerEntity { Id = 101, Description = "Linx" },
        new MonitoringCrawlerEntity { Id = 102, Description = "Nielsen" },
        new MonitoringCrawlerEntity { Id = 103, Description = "Smarket" }
    };
            uow.MonitoringCrawler.AddRange(crawlers, autosave: true);

            
            var monitoringItems = new List<MonitoringItemEntity>
    {
        new MonitoringItemEntity { Id = 201, CompanyId = company.Id, Description = "Product A" },
        new MonitoringItemEntity { Id = 202, CompanyId = company.Id, Description = "Product B" },
        new MonitoringItemEntity { Id = 203, CompanyId = company.Id, Description = "Product C" }
    };
            uow.MonitoringItem.AddRange(monitoringItems, autosave: true);

            
            var monitoringItemResults = new List<MonitoringItemResultsEntity>
    {
        new MonitoringItemResultsEntity
        {
            CompanyId = company.Id,
            MonitoringItemId = 201,
            MonitoringItem = monitoringItems[0],  
            CrawlerId = 101,
            MonitoringCrawler = crawlers[0],     
            Category = "Electronics",
            Seller = "Seller A",
            Brand = "Brand A",
            State = "SP",
            Year = "2022",
            Hash = "hash1"
        },
        new MonitoringItemResultsEntity
        {
            CompanyId = company.Id,
            MonitoringItemId = 202,
            MonitoringItem = monitoringItems[1],  
            CrawlerId = 102,
            MonitoringCrawler = crawlers[1],      
            Category = "Groceries",
            Seller = "Seller B",
            Brand = "Brand B",
            State = "RJ",
            Year = "2023",
            Hash = "hash2"
        },
        new MonitoringItemResultsEntity
        {
            CompanyId = company.Id,
            MonitoringItemId = 203,
            MonitoringItem = monitoringItems[2],  
            CrawlerId = 103,
            MonitoringCrawler = crawlers[2],     
            Category = "Clothing",
            Seller = "Seller C",
            Brand = "Brand C",
            State = "MG",
            Year = "2022",
            Hash = "hash3"
        },
        new MonitoringItemResultsEntity
        {
            CompanyId = company.Id,
            MonitoringItemId = 203,
            MonitoringItem = monitoringItems[2],  
            CrawlerId = 101,
            MonitoringCrawler = crawlers[0],     
            Category = "Clothing",
            Seller = "Seller D",
            Brand = "Brand D",
            State = "SP",
            Year = "2023",
            Hash = "hash4"
        }
    };
            uow.MonitoringItemResults.AddRange(monitoringItemResults, autosave: true);
            var companyMonitoringCrawlers = new List<CompanyMonitoringCrawlerEntity>
            {
                new CompanyMonitoringCrawlerEntity
                {
                    CompanyId = company.Id,
                    MonitoringCrawlerId = 101,
                    Source = PreSegmentoSource.Linx,
                    CrawlerType = CrawlersTypes.Search,
                    Store = "Linx Store",
                    StoreType = "Online",
                    City = "São Paulo",
                    State = "SP",
                    Networks = "Linx Network",
                    Cnpj = "00.000.000/0001-01",
                    ExactVector = true,
                    UseInPricing = true,
                    IsSale = true,
                    IsCost = false,
                    IsDeleted = false
                },
                new CompanyMonitoringCrawlerEntity
                {
                    CompanyId = company.Id,
                    MonitoringCrawlerId = 102,
                    Source = PreSegmentoSource.Nielsen,
                    CrawlerType = CrawlersTypes.Paginate,
                    Store = "Nielsen Store",
                    StoreType = "Physical",
                    City = "Rio de Janeiro",
                    State = "RJ",
                    Networks = "Nielsen Network",
                    Cnpj = "00.000.000/0002-02",
                    ExactVector = false,
                    UseInPricing = false,
                    IsSale = true,
                    IsCost = false,
                    IsDeleted = false
                }
            };
            uow.CompanyMonitoringCrawler.AddRange(companyMonitoringCrawlers, autosave: true);
            // Act
            var request = new DynamicFilterRequest
            {
                Origins = new List<string?> { "Linx" }
            };
            var result = domain.GetMonitoringResultFilteredData(company.Id, request).Result;

            // Assert
            Assert.AreEqual(2, result.Products.Count(), "O número de produtos retornados deve ser igual a 2.");
            Assert.IsTrue(result.Products.Any(p => p.ProductName == "Product A"), "O produto retornado deve incluir 'Product A'.");
            Assert.IsTrue(result.Products.Any(p => p.ProductName == "Product C"), "O produto retornado deve incluir 'Product C'.");

            Assert.AreEqual(2, result.Categories.Count(), "O número de categorias distintas deve ser igual a 2.");
            Assert.IsTrue(result.Categories.Contains("Electronics"), "A categoria retornada deve incluir 'Electronics'.");
            Assert.IsTrue(result.Categories.Contains("Clothing"), "A categoria retornada deve incluir 'Clothing'.");

            Assert.AreEqual(2, result.Sellers.Count(), "O número de vendedores distintos deve ser igual a 2.");
            Assert.IsTrue(result.Sellers.Contains("Seller A"), "O vendedor retornado deve incluir 'Seller A'.");
            Assert.IsTrue(result.Sellers.Contains("Seller D"), "O vendedor retornado deve incluir 'Seller D'.");

            Assert.AreEqual(2, result.Brands.Count(), "O número de marcas distintas deve ser igual a 2.");
            Assert.IsTrue(result.Brands.Contains("Brand A"), "A marca retornada deve incluir 'Brand A'.");
            Assert.IsTrue(result.Brands.Contains("Brand D"), "A marca retornada deve incluir 'Brand D'.");

            Assert.AreEqual(1, result.States.Count(), "O número de estados distintos deve ser igual a 1.");
            Assert.AreEqual("SP", result.States.First(), "O estado retornado deve ser 'SP'.");

            Assert.AreEqual(2, result.Years.Count(), "O número de anos distintos deve ser igual a 2.");
            Assert.IsTrue(result.Years.Contains("2022"), "O ano retornado deve incluir '2022'.");
            Assert.IsTrue(result.Years.Contains("2023"), "O ano retornado deve incluir '2023'.");

            Assert.AreEqual(2, result.Origins.Count(), "O número de origens distintas deve ser igual a 2.");
            Assert.AreEqual("Linx", result.Origins.First(), "A origem retornada deve ser 'Linx'.");
        }

        [TestMethod]
        public void ShouldReturnNAWhenMonitoringItemDescriptionIsNull()
        {
            // Arrange
            var uow = _serviceProvider.GetService<IUnitOfWork>()!;
            var domain = _serviceProvider.GetService<IMonitoringResultDomain>();

            
            var company = new CompanyEntity
            {
                Id = 1,
                Company = "Company1",
                Cnpj = "00.000.000/0001-01"
            };
            uow.Company.Create(company, autosave: true);

            
            var crawlers = new List<MonitoringCrawlerEntity>
            {
                new MonitoringCrawlerEntity { Id = 101, Description = "Linx" },
            };
                    uow.MonitoringCrawler.AddRange(crawlers, autosave: true);

                    
                    var monitoringItems = new List<MonitoringItemEntity>
            {
                new MonitoringItemEntity { Id = 201, CompanyId = company.Id, Description = null }, 
                new MonitoringItemEntity { Id = 202, CompanyId = company.Id, Description = "Valid Description" }
            };
                    uow.MonitoringItem.AddRange(monitoringItems, autosave: true);

                    
                    var monitoringItemResults = new List<MonitoringItemResultsEntity>
            {
                new MonitoringItemResultsEntity
                {
                    CompanyId = company.Id,
                    MonitoringItemId = 201,
                    MonitoringItem = monitoringItems[0],  
                    CrawlerId = 101,
                    MonitoringCrawler = crawlers[0],     
                    Category = "Electronics",
                    Seller = "Seller A",
                    Brand = "Brand A",
                    State = "SP",
                    Year = "2022",
                    Hash = "hash1"
                },
                new MonitoringItemResultsEntity
                {
                    CompanyId = company.Id,
                    MonitoringItemId = 202,
                    CrawlerId = 101,
                    MonitoringCrawler = crawlers[0],     
                    Category = "Clothing",
                    Seller = "Seller B",
                    Brand = "Brand B",
                    State = "RJ",
                    Year = "2023",
                    Hash = "hash2"
                }
            };
            uow.MonitoringItemResults.AddRange(monitoringItemResults, autosave: true);

            var companyMonitoringCrawlers = new List<CompanyMonitoringCrawlerEntity>
            {
                new CompanyMonitoringCrawlerEntity
                {
                    CompanyId = company.Id,
                    MonitoringCrawlerId = 101,
                    Source = PreSegmentoSource.Linx,
                    CrawlerType = CrawlersTypes.Search,
                    Store = "Linx Store",
                    StoreType = "Online",
                    City = "São Paulo",
                    State = "SP",
                    Networks = "Linx Network",
                    Cnpj = "00.000.000/0001-01",
                    ExactVector = true,
                    UseInPricing = true,
                    IsSale = true,
                    IsCost = false,
                    IsDeleted = false
                },
                new CompanyMonitoringCrawlerEntity
                {
                    CompanyId = company.Id,
                    MonitoringCrawlerId = 101,
                    Source = PreSegmentoSource.Linx,
                    CrawlerType = CrawlersTypes.Paginate,
                    Store = "Nielsen Store",
                    StoreType = "Physical",
                    City = "Rio de Janeiro",
                    State = "RJ",
                    Networks = "Nielsen Network",
                    Cnpj = "00.000.000/0002-02",
                    ExactVector = false,
                    UseInPricing = false,
                    IsSale = true,
                    IsCost = false,
                    IsDeleted = false
                }
            };
            uow.CompanyMonitoringCrawler.AddRange(companyMonitoringCrawlers, autosave: true);

            // Act
            var request = new DynamicFilterRequest
            {
                Origins = new List<string?> { "Linx" }
            };
            var result = domain.GetMonitoringResultFilteredData(company.Id, request).Result;

            // Assert
            Assert.AreEqual(2, result.Products.Count(), "O número de produtos retornados deve ser igual a 2.");

            var productWithNullDescription = result.Products.FirstOrDefault(p => p.IdMonitoringItem == 201);
            Assert.IsNotNull(productWithNullDescription, "Deve haver um produto com ID de MonitoringItem 201.");
            Assert.AreEqual("N/A", productWithNullDescription.ProductName, "O nome do produto deve ser 'N/A' quando a descrição for nula.");

        }


    }
}

