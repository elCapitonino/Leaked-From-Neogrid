﻿using System.ComponentModel;

namespace PH.Domain.DTO
{
    public class GraficoDTO
    {
        public GraficoDTO()
        {
            Data = new List<GraficoDataDTO>();
        }
        [Description("Nome do gráfico")]
        public string YAxisTitle { get; set; }
        public List<GraficoDataDTO> Data { get; set; }
    }

    public class GraficoDataDTO
    {
        public GraficoDataDTO()
        {
            Data = new List<double>();
        }
        public string Type { get; set; } = "column";
        public string Name { get; set; }
        public List<double> Data { get; set; }
        public string Color { get; set; }
    }
}
