﻿using MongoDB.Driver;
using Serilog;
using UpdateHash.Models;
using UpdateHashHorus;

namespace UpdateHash.Handlers
{
    public class InfoPriceHandler
    {
        private readonly MongoClient _client;

        public InfoPriceHandler(MongoClient client)
        {
            _client = client;
        }

        public async Task ExecuteAsync(string baseName, string collectionName, DateTime startDate, DateTime endDate, int batchSize, bool dryRun = false)
        {
            var database = _client.GetDatabase(baseName);
            var collection = database.GetCollection<InfoPriceProducts>(collectionName);

            var filter = Builders<InfoPriceProducts>.Filter.And(
                Builders<InfoPriceProducts>.Filter.Gte(doc => doc.data_preco, startDate),
                Builders<InfoPriceProducts>.Filter.Lte(doc => doc.data_preco, endDate)
            );

            var projection = Builders<InfoPriceProducts>.Projection
                .Include(doc => doc.descricao)
                .Include(doc => doc.gtin_formated)
                .Include(doc => doc.loja);

            int take = batchSize;
            int skip = 0;

            while (true)
            {
                Log.Information("Buscando Produtos");

                var documents = await collection.Find(filter)
                                                 .Sort(Builders<InfoPriceProducts>.Sort.Descending(doc => doc.data_preco))
                                                 .Skip(skip)
                                                 .Limit(take)
                                                 .Project<InfoPriceProducts>(projection)
                                                 .ToListAsync();

                if (documents.Count == 0)
                {
                    break;
                }

                Log.Information("Atualizando Produtos");

                var updates = new List<WriteModel<InfoPriceProducts>>();

                foreach (var doc in documents)
                {
                    var ean = doc.gtin_formated;
                    var store = doc.loja;

                    var concatenatedString = $"{ean}|{store}";

                    var hashValue = Utils.CalculateSHA256(concatenatedString);

                    var filterDoc = Builders<InfoPriceProducts>.Filter.Eq("_id", doc._id);
                    var update = Builders<InfoPriceProducts>.Update.Set("hash", hashValue);
                    updates.Add(new UpdateOneModel<InfoPriceProducts>(filterDoc, update));
                }

                if (!dryRun)
                    await collection.BulkWriteAsync(updates);

                Log.Information($"Atualizados {skip + take} documentos");

                skip += take;
            }
        }
    }
}
