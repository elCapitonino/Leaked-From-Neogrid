﻿using AutoMapper;
using Domain.MonitoringResult.Models;
using Repository.Entity;
using Repository.Enums;

namespace Domain.MonitoringResult.Converters
{
    public class InfoPriceTorreToResultFilterResponseConverter : ITypeConverter<InfoPriceTorreEntity, ResultFilterResponse>
    {
        public ResultFilterResponse Convert(InfoPriceTorreEntity source, ResultFilterResponse destination, ResolutionContext context)
        {
            var dest = new ResultFilterResponse()
            {
                ProductName = source.Descricao,
                ProductLink = source.Hash,
                ProductBrand = source.Marca,
                SellerName = source.IdentificadorLoja,
                Marketplace = (string)context.Items["CrawlerName"],
                Price = (decimal)(source.PrecoPago ?? 0),
                PaymentType = "-",
                Price_unit_type = PriceUnitType.UNITARIO,
                CrawlerDate = source.DataPreco,
                Disregarded = false,
                IdCrawler = (int)context.Items["CrawlerId"],
                City = source.Cidade,
                On_request = false,
                State = source.UF,
                Format_market = source.TipoLoja,
                Coordinates = source.Coordinates == null ? null : new PrediMonitorProduct_CoordinatesModel()
                {
                    Longitude = (decimal)source.Coordinates.Coordinates[0],
                    Latitude = (decimal)source.Coordinates.Coordinates[1],
                },
            };

            return dest;
        }
    }
}
