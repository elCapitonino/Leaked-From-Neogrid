﻿using Domain.Models;

namespace Domain.Rule
{
    public interface IRuleDomain
    {
        Task<List<RuleResponse>> GetByGroupId(long ruleGroupId);
    }
}