namespace Domain.ProductPrice.Models
{
    public class ProductPriceResponse
    {
    }

    public class IgnoredProductPriceResponse
    {
        public string? ProductId { get; set; }
        public string? ProductSellerId { get; set; }
        public string? Name { get; set; }
        public string? ProductLink { get; set; }
        public string? Brand { get; set; }
        public int Origin { get; set; }
        public string? CrawlerName { get; set; }
        public decimal Price { get; set; }
        public DateTime Date { get; set; }
    }
}