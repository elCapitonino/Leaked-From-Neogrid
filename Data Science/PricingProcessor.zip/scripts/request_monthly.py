"""
Script para (re)calcular todos os dados de impacto mensais para uma empresa.
"""

import argparse
import time

import requests
from sqlalchemy import Table, func, select

from scripts.request_retroactive import (
    LOCAL_URL,
    _get_date_task_status,
    _get_price_group_task_status,
)
from src.db import create_postgresql_engine


def get_date_range(conn, metadata, id_company: int):
    table = Table("MonthlySaleHistoryImportStatus", metadata, autoload_with=conn)
    stmt = select(func.min(table.c.MinIssuance), func.max(table.c.MaxIssuance)).where(
        table.c.CompanyId == id_company
    )
    return conn.execute(stmt).fetchone()


def calculate(id_company: int, min_date, max_date, api_url: str) -> None:
    print(
        f"-> requesting id_company {id_company} with dates between {min_date} and {max_date}"
    )
    res = requests.post(
        api_url + f"/calculate_projection_metrics/{id_company}/date_range",
        params={
            "id_company": id_company,
            "initial_date": min_date,
            "final_date": max_date,
        },
        timeout=15,
    )
    if res.status_code != 200:
        raise RuntimeError(f"error when requesting: {res.text}")

    res_json = res.json()
    print(res_json)
    date_task_id = res_json["date_task_id"]
    pg_task_ids = res_json["pg_task_ids"]

    while True:
        time.sleep(10)
        date_status = _get_date_task_status(date_task_id, api_url)
        pg_status = [
            _get_price_group_task_status(uuid, api_url) for uuid in pg_task_ids
        ]
        if date_status == "success" and all(s == "success" for s in pg_status):
            print(f"-> id_company {id_company} finished successfully")
            break

        if date_status not in ("running", "success"):
            raise RuntimeError(f"date task failed for id_company {id_company}")

        if any(s not in ("running", "success") for s in pg_status):
            raise RuntimeError(
                f"at least one pg task failed for id_company {id_company}"
            )

        print("continue...")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--id-company", type=int, required=True)
    parser.add_argument("--api-url", type=str, default=LOCAL_URL)
    args = parser.parse_args()

    engine, metadata = create_postgresql_engine()
    with engine.connect() as conn:
        min_date, max_date = get_date_range(conn, metadata, args.id_company)

    calculate(args.id_company, min_date, max_date, args.api_url)


if __name__ == "__main__":
    main()
