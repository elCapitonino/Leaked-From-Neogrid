﻿namespace DI.Repository.Entities
{
    public sealed class EnterpriseValueOverrideEntity : BaseNoKeyEntity
    {
        public long EnterpriseValuesOverridesId { get; set; }

        public long EnterprisePriceGroupsId { get; set; }

        public EnterprisePriceGroupEntity? PriceGroups { get; set; }

        public string? ProjectionsReference { get; set; }

        public decimal? Price { get; set; }

        public decimal? Price_Margin { get; set; }

        public decimal? Price_Demand { get; set; }

        public decimal? Manual_Price { get; set; }

        public decimal? Manual_Price_Margin { get; set; }

        public decimal? Manual_Price_Demand { get; set; }

        public bool IsManual { get; set; } = true;

        public long? RuleId { get; set; }

        public bool IsBlocked { get; set; }

        public int Semaphore { get; set; }
    }
}
