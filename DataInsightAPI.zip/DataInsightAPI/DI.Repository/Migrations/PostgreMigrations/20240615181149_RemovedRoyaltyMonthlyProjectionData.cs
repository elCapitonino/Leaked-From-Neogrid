﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DI.Repository.Migrations.PostgreMigrations
{
    /// <inheritdoc />
    public partial class RemovedRoyaltyMonthlyProjectionData : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "RoyaltyPercentage",
                table: "MonthlyProjectionData");

            migrationBuilder.DropColumn(
                name: "RoyaltyReal",
                table: "MonthlyProjectionData");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<decimal>(
                name: "RoyaltyPercentage",
                table: "MonthlyProjectionData",
                type: "numeric",
                nullable: false,
                defaultValue: 0m);

            migrationBuilder.AddColumn<decimal>(
                name: "RoyaltyReal",
                table: "MonthlyProjectionData",
                type: "numeric",
                nullable: false,
                defaultValue: 0m);
        }
    }
}
