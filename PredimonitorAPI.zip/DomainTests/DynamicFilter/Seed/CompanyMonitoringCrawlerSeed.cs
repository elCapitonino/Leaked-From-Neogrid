﻿using Repository.Entity;
using Repository.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainTests.DynamicFilter.Seed
{

    public static class CompanyMonitoringCrawlerSeed
    {
        public static List<CompanyMonitoringCrawlerEntity> GetTestData()
        {
            return new List<CompanyMonitoringCrawlerEntity>
            {
                new CompanyMonitoringCrawlerEntity
                {
                    CompanyId = 1,
                    MonitoringCrawlerId = 101,
                    Source = PreSegmentoSource.Linx,
                    CrawlerType = CrawlersTypes.Search,
                    Store = "Linx Store",
                    StoreType = "Online",
                    City = "São Paulo",
                    State = "SP",
                    Networks = "Linx Network",
                    Cnpj = "00.000.000/0001-01",
                    ExactVector = true,
                    UseInPricing = true,
                    IsSale = true,
                    IsCost = false,
                    IsDeleted = false
                },
                new CompanyMonitoringCrawlerEntity
                {
                    CompanyId = 1,
                    MonitoringCrawlerId = 102,
                    Source = PreSegmentoSource.Nielsen,
                    CrawlerType = CrawlersTypes.Paginate,
                    Store = "Nielsen Store",
                    StoreType = "Physical",
                    City = "Rio de Janeiro",
                    State = "RJ",
                    Networks = "Nielsen Network",
                    Cnpj = "00.000.000/0002-02",
                    ExactVector = false,
                    UseInPricing = false,
                    IsSale = true,
                    IsCost = false,
                    IsDeleted = false
                },
                new CompanyMonitoringCrawlerEntity
                {
                    CompanyId = 1,
                    MonitoringCrawlerId = 103,
                    Source = PreSegmentoSource.Smarket,
                    CrawlerType = CrawlersTypes.Driver,
                    Store = "Smarket Store",
                    StoreType = "Hybrid",
                    City = "Belo Horizonte",
                    State = "MG",
                    Networks = "Smarket Network",
                    Cnpj = "00.000.000/0003-03",
                    ExactVector = true,
                    UseInPricing = true,
                    IsSale = true,
                    IsCost = false,
                    IsDeleted = false
                },
                new CompanyMonitoringCrawlerEntity
                {
                    CompanyId = 1,
                    MonitoringCrawlerId = 104,
                    Source = PreSegmentoSource.Neogrid,
                    CrawlerType = CrawlersTypes.Search,
                    Store = "Neogrid Store",
                    StoreType = "Online",
                    City = "Curitiba",
                    State = "PR",
                    Networks = "Neogrid Network",
                    Cnpj = "00.000.000/0004-04",
                    ExactVector = false,
                    UseInPricing = true,
                    IsSale = true,
                    IsCost = false,
                    IsDeleted = false
                },
                new CompanyMonitoringCrawlerEntity
                {
                    CompanyId = 1,
                    MonitoringCrawlerId = 105,
                    Source = PreSegmentoSource.Sao_Joao_InfoPrice,
                    CrawlerType = CrawlersTypes.Paginate,
                    Store = "InfoPrice Store",
                    StoreType = "Physical",
                    City = "Porto Alegre",
                    State = "RS",
                    Networks = "InfoPrice Network",
                    Cnpj = "00.000.000/0005-05",
                    ExactVector = true,
                    UseInPricing = false,
                    IsSale = false,
                    IsCost = true,
                    IsDeleted = false
                },
                new CompanyMonitoringCrawlerEntity
                {
                    CompanyId = 1,
                    MonitoringCrawlerId = 106,
                    Source = PreSegmentoSource.Horus_Search,
                    CrawlerType = CrawlersTypes.Driver,
                    Store = "Horus Store",
                    StoreType = "Hybrid",
                    City = "Florianópolis",
                    State = "SC",
                    Networks = "Horus Network",
                    Cnpj = "00.000.000/0006-06",
                    ExactVector = true,
                    UseInPricing = true,
                    IsSale = true,
                    IsCost = true,
                    IsDeleted = false
                },
                new CompanyMonitoringCrawlerEntity
                {
                    CompanyId = 1,
                    MonitoringCrawlerId = 107,
                    Source = PreSegmentoSource.Predify,
                    CrawlerType = CrawlersTypes.Search,
                    Store = "Normalizer Store",
                    StoreType = "Online",
                    City = "Salvador",
                    State = "BA",
                    Networks = "Normalizer Network",
                    Cnpj = "00.000.000/0007-07",
                    ExactVector = true,
                    UseInPricing = false,
                    IsSale = true,
                    IsCost = false,
                    IsDeleted = false
                },
                new CompanyMonitoringCrawlerEntity
                {
                    CompanyId = 1,
                    MonitoringCrawlerId = 108,
                    Source = PreSegmentoSource.Predify,
                    CrawlerType = CrawlersTypes.Paginate,
                    Store = "Predify Store",
                    StoreType = "Physical",
                    City = "Brasília",
                    State = "DF",
                    Networks = "Predify Network",
                    Cnpj = "00.000.000/0008-08",
                    ExactVector = false,
                    UseInPricing = true,
                    IsSale = false,
                    IsCost = true,
                    IsDeleted = false
                },
                new CompanyMonitoringCrawlerEntity
                {
                    CompanyId = 1,
                    MonitoringCrawlerId = 109,
                    Source = PreSegmentoSource.Smarket,
                    CrawlerType = CrawlersTypes.Driver,
                    Store = "Indireta Store",
                    StoreType = "Hybrid",
                    City = "Recife",
                    State = "PE",
                    Networks = "Indireta Network",
                    Cnpj = "00.000.000/0009-09",
                    ExactVector = true,
                    UseInPricing = false,
                    IsSale = true,
                    IsCost = true,
                    IsDeleted = false
                },
                new CompanyMonitoringCrawlerEntity
                {
                    CompanyId = 1,
                    MonitoringCrawlerId = 110,
                    Source = PreSegmentoSource.Linx_Vem,
                    CrawlerType = CrawlersTypes.Search,
                    Store = "Vem Store",
                    StoreType = "Online",
                    City = "Fortaleza",
                    State = "CE",
                    Networks = "Vem Network",
                    Cnpj = "00.000.000/0010-10",
                    ExactVector = false,
                    UseInPricing = true,
                    IsSale = true,
                    IsCost = false,
                    IsDeleted = false
                }
            };
        }
    }

}
