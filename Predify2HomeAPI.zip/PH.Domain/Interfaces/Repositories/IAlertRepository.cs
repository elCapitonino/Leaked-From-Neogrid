﻿using PH.Domain.DTO;

namespace PH.Domain.Interfaces.Repositories
{
    public interface IAlertRepository
    {
        Task<AlertMainDTO> Get(long idCompany, long idPriceGroup);
    }
}
