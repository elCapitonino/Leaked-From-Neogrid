﻿namespace Domain.Models
{
    public sealed class DefaultFilterResponse
    {
        public long Id { get; set; }
        public long? ParentId { get; set; }
        public string? Description {  get; set; }
        public List<DefaultFilterValueResponse>? Values { get; set; }
    }

    public sealed class DefaultFilterValueResponse
    {
        public long Id { get; set; }
        public long? ParentId { get; set; }
        public string? Description { get; set; }
        public string? Value { get; set; }
    }
}
