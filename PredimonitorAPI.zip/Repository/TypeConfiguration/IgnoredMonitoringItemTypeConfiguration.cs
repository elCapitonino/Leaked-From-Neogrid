﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Repository.Attributes;
using Repository.DbContexts;
using Repository.Entity;

namespace Repository.TypeConfiguration
{
    [DbContextTypeConfiguration(typeof(ApplicationDbContext))]
    public class IgnoredMonitoringItemTypeConfiguration : TypeConfigurationBase<IgnoredMonitoringItemEntity>, IEntityTypeConfiguration<IgnoredMonitoringItemEntity>
    {
        public override void Configure(EntityTypeBuilder<IgnoredMonitoringItemEntity> builder)
        {
            ConfigureTableName(builder, "IgnoredMonitoringItem");

            builder.Property(p => p.Id).IsRequired().HasColumnName("IdIgnoredMonitoringItem");
            builder.Property(p => p.MonitoringItemId).IsRequired().HasColumnName("IdMonitoringItem");

            builder.HasOne(p => p.MonitoringItem).WithMany().HasForeignKey(p => p.MonitoringItemId);
        }
    }
}
