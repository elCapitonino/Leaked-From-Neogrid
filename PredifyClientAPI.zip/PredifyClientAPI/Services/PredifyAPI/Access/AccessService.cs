﻿using Newtonsoft.Json;
using PredifyClientAPI.Services.PredifyAPI.Access.Models;

namespace PredifyClientAPI.Services.PredifyAPI.Access
{
    public class AccessService : IAccessService
    {
        private readonly HttpClient client;

        public AccessService(HttpClient client)
        {
            this.client = client;
        }

        public async Task<AccessTokenResponse> Login(LoginRequest requestModel)
        {
            var request = new HttpRequestMessage(HttpMethod.Get, "/token");
            var collection = new List<KeyValuePair<string, string>>
            {
                new("grant_type", "password"),
                new("username", requestModel.Username),
                new("password", requestModel.Password),
                new("client_id", "multiverso-emp-angularjs-app")
            };

            var content = new FormUrlEncodedContent(collection);
            request.Content = content;

            var response = await client.SendAsync(request);
            var contentResponse = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
                return JsonConvert.DeserializeObject<AccessTokenResponse>(contentResponse);
            else if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                throw new UnauthorizedAccessException();
            else
                throw new UnauthorizedAccessException(contentResponse);
        }

        public async Task<bool> UserHasAccess(long companyId)
        {
            var response = await client.GetAsync($"/api/V2/Access/Validation/ValidateCompany?idCompany={companyId}");
            var content = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
                return true;
            else if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                return false;

            throw new Exception(content);
        }
    }
}
