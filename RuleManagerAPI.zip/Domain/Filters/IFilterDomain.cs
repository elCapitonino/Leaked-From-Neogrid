﻿using Domain.Models;

namespace Domain.Filters
{
    public interface IFilterDomain
    {
        Task<List<DefaultFilterResponse>> GetFiltersByCompanyId(long companyId);
        Task<List<string>> GetSellerFiltersByCompanyId(long companyId);
    }
}