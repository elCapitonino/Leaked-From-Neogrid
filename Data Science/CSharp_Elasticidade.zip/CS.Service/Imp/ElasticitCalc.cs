﻿using MathNet.Numerics.Statistics;
using CS.Domain.DTO;
using CS.Domain.Domain;
using MathNet.Numerics.LinearRegression;

namespace CS.Service.Imp
{
    public class ElasticitCalc
    {
        public EnterpriseElasticit Calculate(List<EnterpriseSalesHistoryElasticSimpleCalculator> listOFESH, string time, string product, string affiliate)
        {
            List<EnterpriseSalesHistoryElasticSimpleCalculator> listOFESHAux = GroupList(listOFESH, affiliate);
            listOFESH = listOFESHAux;

            double[] listSalePrice = listOFESH.Where(c => c.SalePrice != null && c.Product == product && c.Affiliate == affiliate)
                                              .Select(c => Convert.ToDouble(c.SalePrice.Value)).ToArray();
            double[] listQuantity = listOFESH.Where(c => c.Quantity != null && c.Product == product && c.Affiliate == affiliate)
                                            .Select(c => Convert.ToDouble(c.Quantity.Value)).ToArray();
            double slope = 0;

            var linearReggresion = Accord.Statistics.Models.Regression.Linear.SimpleLinearRegression.FromData(listSalePrice, listQuantity);
            
            float sloapFloat = (float)linearReggresion.Slope;
            double medianPrice = listSalePrice.Median();
            double medianQuantity = listQuantity.Median();



            double elasticityPrice = (slope) * (medianPrice / medianQuantity);

            if (true)
            {
                var lastDate = Convert.ToDateTime(listOFESH.OrderByDescending(c => c.Issuance).FirstOrDefault().Issuance);
                var result = listOFESH.Where(c => Convert.ToDateTime(c.Issuance) >= lastDate.AddMonths(-1));

                double[] salePriceLastMonth = result.Where(c => c.SalePrice != null)
                                              .Select(c => Convert.ToDouble(c.SalePrice)).ToArray();

                double[] quantityLastMonth = result.Where(c => c.Quantity != null)
                                            .Select(c => Convert.ToDouble(c.Quantity.Value)).ToArray();

                double lastMonthMedianPrice = salePriceLastMonth.Median();
                double lastMonthMedianQuantity = quantityLastMonth.Median();

                double lastQuantity = Convert.ToDouble(result.Where(c => c.Quantity != null)
                                             .OrderByDescending(c => c.Issuance)
                                             .FirstOrDefault().Quantity.Value);

                double lastPrice = Convert.ToDouble(result.Where(c => c.SalePrice != null)
                                          .OrderByDescending(c => c.Issuance)
                                          .FirstOrDefault().SalePrice.Value);

                var enterpriseElasticit = new EnterpriseElasticit(time,
                                                                                  product,
                                                                                  elasticityPrice,
                                                                                  lastMonthMedianQuantity,
                                                                                  lastMonthMedianPrice,
                                                                                  lastQuantity,
                                                                                  lastPrice,
                                                                                  affiliate);

                return enterpriseElasticit;
            }
        }

        private static List<EnterpriseSalesHistoryElasticSimpleCalculator> GroupList(List<EnterpriseSalesHistoryElasticSimpleCalculator> listOFESH, string affiliate)
        {
            var result = listOFESH.GroupBy(c => new { c.Issuance, c.Product });
            List<EnterpriseSalesHistoryElasticSimpleCalculator> listOFESHAux = new List<EnterpriseSalesHistoryElasticSimpleCalculator>();

            foreach (var group in result)
            {
                var listGroupAndProduct = listOFESH.Where(c => c.Issuance == group.Key.Issuance && c.Product == group.Key.Product);
                var totalQuantity = listGroupAndProduct.Select(c => c.Quantity).Sum();
                var averagePrice = listGroupAndProduct.Select(c => c.SalePrice).Average();

                listOFESHAux.Add(new EnterpriseSalesHistoryElasticSimpleCalculator()
                {
                    Affiliate = affiliate,
                    Issuance = group.Key.Issuance,
                    Product = group.Key.Product,
                    Quantity = totalQuantity,
                    SalePrice = averagePrice
                });
            }

            return listOFESHAux;
        }

        private static void LinearRegression(double[] xVals,
                                            double[] yVals,
                                            out double rSquared,
                                            out double yIntercept,
                                            out double slope)
        {
            if (xVals.Length != yVals.Length)
            {
                throw new Exception("Input values should be with the same length.");
            }

            double sumOfX = 0;
            double sumOfY = 0;
            double sumOfXSq = 0;
            double sumOfYSq = 0;
            double sumCodeviates = 0;

            for (var i = 0; i < xVals.Length; i++)
            {
                var x = xVals[i];
                var y = yVals[i];
                sumCodeviates += x * y;
                sumOfX += x;
                sumOfY += y;
                sumOfXSq += x * x;
                sumOfYSq += y * y;
            }

            var count = xVals.Length;
            var ssX = sumOfXSq - ((sumOfX * sumOfX) / count);
            var ssY = sumOfYSq - ((sumOfY * sumOfY) / count);

            var rNumerator = (count * sumCodeviates) - (sumOfX * sumOfY);
            var rDenom = (count * sumOfXSq - (sumOfX * sumOfX)) * (count * sumOfYSq - (sumOfY * sumOfY));
            var sCo = sumCodeviates - ((sumOfX * sumOfY) / count);

            var meanX = sumOfX / count;
            var meanY = sumOfY / count;
            var dblR = rNumerator / Math.Sqrt(rDenom);

            rSquared = dblR * dblR;
            yIntercept = meanY - ((sCo / ssX) * meanX);
            slope = sCo / ssX;
        }
    }
}
