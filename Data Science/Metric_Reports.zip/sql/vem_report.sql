WITH tb_groups AS (
    SELECT
        DataHoraCriacao,
        IdEnterprisePriceGroups
    FROM Enterprise_Price_Groups AS t1
    WHERE DataHoraCriacao >= DATEADD(DAY, -45, GETDATE())  -- apenas últimos 45 dias!
    AND IdCompany = 3026
    AND IsDeletado = 0
    AND CalcDate IS NOT NULL
),
tb_filters AS (
    SELECT F.IdEnterprisePriceGroups, DF.dbField, F.Value
    FROM Enterprise_Price_Groups_Filter F
    JOIN EnterprisePriceGroups_DefaultFilter DF
    ON F.IdEnterprisePriceGroups_DefaultFilter = DF.IdEnterprisePriceGroups_DefaultFilter
    WHERE DF.IdCompany = 3026
    AND F.IsDeleted = 0
    AND DF.dbField = 7 -- Affiliate
),
tb_affiliate AS (
    SELECT
        t1.*,
        t2.[Value] AS Affiliate,
        -- FIXME números arbitrários só pra ter dados, Paulo quer 7 e 7
        DATEADD(day, -60, t1.DataHoraCriacao) AS InitialDate,
        DATEADD(
            day,
            7,
            coalesce(
                lead(t1.DataHoraCriacao) OVER (PARTITION BY t2.[Value] ORDER BY t1.DataHoraCriacao),
                GETDATE()
            )
        ) AS EndDate
    FROM tb_groups AS t1
    JOIN tb_filters AS t2
    ON t1.IdEnterprisePriceGroups = t2.IdEnterprisePriceGroups
),
tb_sales_history AS (
    SELECT
        t1.[Description],
        t1.Affiliate,
        t1.Quantity,
        t2.IdEnterprisePriceGroups,
        t2.DataHoraCriacao,
        t2.InitialDate,
        t2.EndDate,
        t1.Issuance,
        t1.AffiliateName,
        t1.SalePrice,
        t1.PbCost
    FROM Enterprise_Sales_History AS t1
    JOIN tb_affiliate AS t2
    ON t1.Affiliate = t2.Affiliate
    WHERE t1.IdCompany = 3026
    AND t1.IsDeletado = 0
    AND t1.Issuance >= t2.InitialDate
    -- AND t1.Issuance < t2.EndDate  -- XXX se adiciona esse filtro, não acaba nunca!
),
tb_filter_issuance AS (
    SELECT
        IdEnterprisePriceGroups,
        Affiliate,
        [Description],
        MAX(DataHoraCriacao) AS DataHoraCriacao,
        avg(SalePrice) AS AvgPrice,
        avg(100 * (SalePrice - PbCost) / SalePrice) AS AvgMargin,
        sum(Quantity) AS Demand, --- XXX transformar em por dia!
        sum(SalePrice * Quantity) AS Revenue -- XXX como tirar média?
    FROM tb_sales_history
    GROUP BY IdEnterprisePriceGroups, Affiliate, [Description]
),
tb_avg AS (
    SELECT
        t1.DataHoraCriacao,
        t1.Description,
        t1.Affiliate,
        pp.AffiliateName,
        pp.Category3 AS Category,
        -- XXX margem do preço da IA ou do preço final??
        pp.SalePrice_Margin AS Margin,
        pp.SalePrice_Demand_CurveABC AS ABC,
        CASE WHEN ppwa.[Action] = 0 THEN 'Aprovado' WHEN ppwa.[Action] = 1 THEN 'Reprovado' ELSE 'Escalado' END AS Aproval,
        -- XXX todos do preço praticado após precificação!
        t1.Demand,
        t1.Revenue,
        t1.AvgPrice,
        t1.AvgMargin,
        CASE
            WHEN vo.identerprisevaluesoverrides IS NOT NULL THEN vo.price
            ELSE pp.saleprice
        END AS SuggestedPrice,
        CASE
            WHEN vo.IdEnterpriseValuesOverrides IS NOT NULL THEN vo.Price_Demand * vo.price
            ELSE pp.SalePrice * pp.SalePrice_Demand
        END AS SuggestedRevenue,
        CASE
            WHEN vo.IdEnterpriseValuesOverrides IS NOT NULL THEN vo.Price_Margin
            ELSE pp.SalePrice_Margin
        END AS SuggestedMargin,
        pp.SalePrice AS IAPrice,
        pp.LastSalePrice AS LastSalePrice,
        pp.LastSalePrice_Margin AS LastSalePriceMargin
    FROM tb_filter_issuance AS t1
    JOIN Enterprise_Prices_Projection AS pp
    ON t1.IdEnterprisePriceGroups = pp.IdEnterprisePriceGroups
    AND t1.[Description] = pp.ProductName
    AND t1.Affiliate = pp.Affiliate
    LEFT JOIN enterprise_values_overrides vo
    ON vo.projectionsreference = pp.projectionsreference
    JOIN enterprisepriceprojection_workflow ppw
    ON ppw.identerprisepriceprojection = pp.IdEnterprisePricesProjection
    JOIN enterprisepriceprojection_workflowaction ppwa
    ON ppwa.idpriceprojection_workflow = ppw.IdEnterprisePriceProjection_Workflow
    -- ON ppwa.idpriceprojection_workflow = ppw.IdLastAction
)
SELECT
    *,
    CASE WHEN ABS(AvgPrice - IAPrice) <= 0.01 THEN 'Sim' ELSE 'Não' END AS AdoptionIA,
    CASE WHEN ABS(LastSalePrice - IAPrice) >= 0.01 THEN 'Sim' ELSE 'Não' END AS NewPriceIA,
    CASE WHEN ABS(AvgPrice - SuggestedPrice) <= 0.01 THEN 'Sim' ELSE 'Não' END AS AdoptionSuggested,
    CASE WHEN ABS(LastSalePrice - SuggestedPrice) >= 0.01 THEN 'Sim' ELSE 'Não' END AS NewPriceSuggested
FROM tb_avg;