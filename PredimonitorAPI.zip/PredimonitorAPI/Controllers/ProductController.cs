using Domain.Product;
using Domain.Product.Models;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;

namespace PredimonitorAPI.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ProductController : ControllerBase
{
    private readonly ILogger<ProductController> _logger;
    private readonly IProductDomain _domain;

    public ProductController(ILogger<ProductController> logger, IProductDomain domain)
    {
        _logger = logger;
        _domain = domain;
    }

    [HttpPost]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<ProductResponse>))]
    [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(string))]
    [ProducesResponseType(StatusCodes.Status401Unauthorized, Type = typeof(string))]
    [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
    [SwaggerOperation(Summary = "Retrieves data accordingly to filters for the predimonitor screen", Description = "Get results from database accordingly to filters for the predimonitor screen")]

    public async Task<IActionResult> Search(FiltersRequest request)
    {
        if (request == null)
        {
            _logger.LogDebug("Null request received.");
            return BadRequest("Request cannot be null.");
        }

        if (!ModelState.IsValid)
        {
            _logger.LogDebug("Invalid request received.");
            return BadRequest("Invalid request data.");
        }

        try
        {
            var response = await _domain.GetGroupedProducts(request);

            if (response.Products == null || !response.Products.Any())
            {
                _logger.LogDebug("No data found");
                return NoContent();
            }

            return Ok(response);
        }
        catch (UnauthorizedAccessException ex)
        {
            _logger.LogError(ex, "Unauthorized access");
            return Unauthorized("Unauthorized access.");
        }
        catch (ArgumentException ex)
        {
            _logger.LogError(ex, "Bad request");
            return BadRequest("Invalid argument: " + ex.Message);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error executing the request");
            return StatusCode(StatusCodes.Status500InternalServerError, "An unexpected error occurred.");
        }
    }

    [HttpPost("SaveCompanyProductPrice")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(string))]
    [ProducesResponseType(StatusCodes.Status401Unauthorized, Type = typeof(string))]
    [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
    [SwaggerOperation(Summary = "Save the current company price for the product", Description = "Save the current company price for the product")]

    public async Task<IActionResult> SaveCompanyProductPrice(CompanyProductPriceRequest request)
    {
        if (request == null)
        {
            _logger.LogDebug("Null request received.");
            return BadRequest("Request cannot be null.");
        }

        if (!ModelState.IsValid)
        {
            _logger.LogDebug("Invalid request received.");
            return BadRequest("Invalid request data.");
        }

        try
        {
            _domain.SaveCompanyProductPrice(request);

            return Ok();
        }
        catch (UnauthorizedAccessException ex)
        {
            _logger.LogError(ex, "Unauthorized access");
            return Unauthorized("Unauthorized access.");
        }
        catch (ArgumentException ex)
        {
            _logger.LogError(ex, "Bad request");
            return BadRequest("Invalid argument: " + ex.Message);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error executing the request");
            return StatusCode(StatusCodes.Status500InternalServerError, "An unexpected error occurred.");
        }
    }

    [HttpPost("SearchMapData")]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(MapDataResponse))]
    [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(string))]
    [ProducesResponseType(StatusCodes.Status401Unauthorized, Type = typeof(string))]
    [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
    [SwaggerOperation(Summary = "Retrieves product and price data accordingly to filters for map", Description = "Retrieves product and price data accordingly to filters for map")]

    public async Task<IActionResult> SearchMapData(FiltersRequest request)
    {
        if (request == null)
        {
            _logger.LogDebug("Null request received.");
            return BadRequest("Request cannot be null.");
        }

        if (!ModelState.IsValid)
        {
            _logger.LogDebug("Invalid request received.");
            return BadRequest("Invalid request data.");
        }

        try
        {
            var response = await _domain.GetMapData(request);

            if (response is null)
            {
                _logger.LogDebug("No data found");
                return NoContent();
            }

            return Ok(response);
        }
        catch (UnauthorizedAccessException ex)
        {
            _logger.LogError(ex, "Unauthorized access");
            return Unauthorized("Unauthorized access.");
        }
        catch (ArgumentException ex)
        {
            _logger.LogError(ex, "Bad request");
            return BadRequest("Invalid argument: " + ex.Message);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error executing the request");
            return StatusCode(StatusCodes.Status500InternalServerError, "An unexpected error occurred.");
        }
    }

    [HttpPost("SearchProductComparisonData")]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(ProductComparisonResponse))]
    [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(string))]
    [ProducesResponseType(StatusCodes.Status401Unauthorized, Type = typeof(string))]
    [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
    [SwaggerOperation(Summary = "Retrieves product comparison data accordingly to filters", Description = "Retrieves product comparison data accordingly to filters")]

    public async Task<IActionResult> SearchProductComparisonData(FiltersRequest request)
    {
        if (request == null)
        {
            _logger.LogDebug("Null request received.");
            return BadRequest("Request cannot be null.");
        }

        if (!ModelState.IsValid)
        {
            _logger.LogDebug("Invalid request received.");
            return BadRequest("Invalid request data.");
        }

        try
        {
            var response = await _domain.GetProductComparisonData(request);

            if (response is null || !response.Any())
            {
                _logger.LogDebug("No data found");
                return NoContent();
            }

            return Ok(response);
        }
        catch (UnauthorizedAccessException ex)
        {
            _logger.LogError(ex, "Unauthorized access");
            return Unauthorized("Unauthorized access.");
        }
        catch (ArgumentException ex)
        {
            _logger.LogError(ex, "Bad request");
            return BadRequest("Invalid argument: " + ex.Message);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error executing the request");
            return StatusCode(StatusCodes.Status500InternalServerError, "An unexpected error occurred.");
        }
    }

    [HttpPost("SearchCompetitivenessIndexData")]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(CompetitivenessIndexResponse))]
    [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(string))]
    [ProducesResponseType(StatusCodes.Status401Unauthorized, Type = typeof(string))]
    [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
    [SwaggerOperation(Summary = "Retrieves product competitiveness index data accordingly to filters", Description = "Retrieves product competitiveness index data accordingly to filters")]

    public async Task<IActionResult> SearchCompetitivenessIndexData(FiltersRequest request)
    {
        if (request == null)
        {
            _logger.LogDebug("Null request received.");
            return BadRequest("Request cannot be null.");
        }

        if (!ModelState.IsValid)
        {
            _logger.LogDebug("Invalid request received.");
            return BadRequest("Invalid request data.");
        }

        try
        {
            var response = await _domain.GetCompetitivenessIndexData(request);

            if (response is null)
            {
                _logger.LogDebug("No data found");
                return NoContent();
            }

            return Ok(response);
        }
        catch (UnauthorizedAccessException ex)
        {
            _logger.LogError(ex, "Unauthorized access");
            return Unauthorized("Unauthorized access.");
        }
        catch (ArgumentException ex)
        {
            _logger.LogError(ex, "Bad request");
            return BadRequest("Invalid argument: " + ex.Message);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error executing the request");
            return StatusCode(StatusCodes.Status500InternalServerError, "An unexpected error occurred.");
        }
    }
}