﻿namespace Repository.Entity
{
    public class MonitoringItemResultsEntity : BaseEntity
    {
        public long CompanyId { get; set; }

        public long MonitoringItemId { get; set; }

        public int CrawlerId { get; set; }

        public string Hash { get; set; }

        public string? Category { get; set; }

        public string? Seller { get; set; }

        public string? Brand { get; set; }

        public string? State { get; set; }

        public string? Year { get; set; }

        public string? Model { get; set; }

        public CompanyEntity Company { get; set; }
        public MonitoringItemEntity MonitoringItem { get; set; }
        public MonitoringCrawlerEntity MonitoringCrawler { get; set; }
    }
}
