namespace Domain.Product.Models
{

    public class FiltersRequest
    {
        public int CompanyId { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public List<string?>? ProductIds { get; set; }
        public List<string?>? ProductNames { get; set; }
        public List<string?>? Categories { get; set; }
        public List<string?>? Sellers { get; set; }
        public List<string?>? Segments { get; set; }
        public List<string?>? Brands { get; set; }
        public List<string?>? Origins { get; set; }
        public List<string?>? Regions { get; set; }
        public List<string?>? States { get; set; }
        public List<string?>? Years { get; set; }
        public List<string?>? Models { get; set; }
        public FilterRequestRange? Kilometers { get; set; }
        public bool IsCost { get; set; }
        public int Page { get; set; }
        public int Take { get; set; }
        public string? OrderBy { get; set; }
    }

    public class FilterRequestRange
    {
        public int? Min { get; set; }
        public int? Max { get; set; }
    }
}