﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PH.Domain.DTO
{
    public class GraficoReceitaDTO
    {
        public DateTime Date { get; set; }

        public int Value { get; set; }
    }
}
