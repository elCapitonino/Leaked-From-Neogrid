﻿using Domain.Models;
using Services.AzureDevops.Models;
using Services.Copilot.Models;
using Services.PredifyAPI.Models;

namespace RuleManagerAPI.Extensions
{
    public static class OptionsExtensions
    {
        public static IServiceCollection AddCustomOptions(this IServiceCollection services, IConfiguration configuration)
        {
            services.Configure<AppsettingsOptions>(configuration);
            services.Configure<CopilotOptions>(configuration.GetSection("Services").GetSection("Copilot"));
            services.Configure<PredifyAPIOptions>(configuration.GetSection("Services").GetSection("PredifyAPI"));
            services.Configure<AzureDevopsOptions>(configuration.GetSection("Services").GetSection("AzureDevops"));
            return services;
        }
    }
}
