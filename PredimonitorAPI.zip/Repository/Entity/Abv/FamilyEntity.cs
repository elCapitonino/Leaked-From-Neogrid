﻿using MongoDB.Bson.Serialization.Attributes;

namespace Repository.Entity.Abv
{
    public class FamilyEntity
    {
        [BsonElement("SEQFAMILIA")]
        public long? SeqFamilia { get; set; }

        [BsonElement("FAMILIA")]
        public string? Familia { get; set; }
    }

}
