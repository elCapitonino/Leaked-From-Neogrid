﻿using Microsoft.EntityFrameworkCore;
using MongoDB.Driver;
using Repository.DbContexts.Bases;

namespace Repository.DbContexts
{
    public class LinxDbContext : MongoDbContextBase
    {
        public LinxDbContext(DbContextOptions<LinxDbContext> options, IMongoClient mongoClient) : base(options, mongoClient)
        {

        }
        public override string DbContextName => nameof(LinxDbContext);

    }
}
