﻿using Repository.DbContexts;
using Repository.Entity;
using Repository.EntityRepository.Bases;

namespace Repository.EntityRepository
{
    public class OfflineSupermarketTorreRepository : GenericMongoRepository<OfflineSupermarketTorreEntity>, IOfflineSupermarketTorreRepository
    {

        public OfflineSupermarketTorreRepository(OfflineDbContext dbContext) : base(dbContext)
        {
        }
        public static string DbContextName => nameof(OfflineDbContext);


    }
}
