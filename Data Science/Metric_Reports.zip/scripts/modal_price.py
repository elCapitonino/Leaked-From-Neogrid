"""
Script mínimo para gerar XLSX comparando moda do preço de um produto entre BR MANIA,
outras conveniências e small supermarket, a partir da base da Nielsen.
"""

import pandas as pd
from pymongo import MongoClient

MONGO_URI = "xxxx"
EAN = "78936683"
client = MongoClient(MONGO_URI)

coll = client["nielsen"]["base_vem"]

cur = coll.aggregate(
    [
        {"$match": {"STORE_NAME": "BR MANIA", "EAN": EAN}},
        {"$group": {"_id": {"price": "$WEEKLY_PRICE", "uf": "$STATE_UF"}, "count": {"$sum": 1}}},
        {"$sort": {"count": -1}},
        {
            "$group": {
                "_id": "$_id.uf",
                "data": {"$push": {"price": "$_id.price", "count": "$count"}},
                "max_count": {"$max": "$count"},
            }
        },
        {
            "$project": {
                "items": {
                    "$filter": {"input": "$data", "as": "single", "cond": {"$eq": ["$$single.count", "$max_count"]}}
                }
            }
        },
        {"$unwind": "$items"},
        {"$group": {"_id": "$_id", "modal_price": {"$avg": "$items.price"}}},
    ]
)
br_mania_prices = list(cur)

cur = coll.aggregate(
    [
        {"$match": {"FORMAT_MARKET": "GAS STATION", "STORE_NAME": {"$ne": "BR MANIA"}, "EAN": EAN}},
        {"$group": {"_id": {"price": "$WEEKLY_PRICE", "uf": "$STATE_UF"}, "count": {"$sum": 1}}},
        {"$sort": {"count": -1}},
        {
            "$group": {
                "_id": "$_id.uf",
                "data": {"$push": {"price": "$_id.price", "count": "$count"}},
                "max_count": {"$max": "$count"},
            }
        },
        {
            "$project": {
                "items": {
                    "$filter": {"input": "$data", "as": "single", "cond": {"$eq": ["$$single.count", "$max_count"]}}
                }
            }
        },
        {"$unwind": "$items"},
        {"$group": {"_id": "$_id", "modal_price": {"$avg": "$items.price"}}},
    ]
)
conv_prices = list(cur)

cur = coll.aggregate(
    [
        {"$match": {"FORMAT_MARKET": "SMALL SUPERMARKET", "EAN": EAN}},
        {"$group": {"_id": {"price": "$WEEKLY_PRICE", "uf": "$STATE_UF"}, "count": {"$sum": 1}}},
        {"$sort": {"count": -1}},
        {
            "$group": {
                "_id": "$_id.uf",
                "data": {"$push": {"price": "$_id.price", "count": "$count"}},
                "max_count": {"$max": "$count"},
            }
        },
        {
            "$project": {
                "items": {
                    "$filter": {"input": "$data", "as": "single", "cond": {"$eq": ["$$single.count", "$max_count"]}}
                }
            }
        },
        {"$unwind": "$items"},
        {"$group": {"_id": "$_id", "modal_price": {"$avg": "$items.price"}}},
    ]
)
small_prices = list(cur)


cur = coll.aggregate(
    [
        {"$match": {"FORMAT_MARKET": "SUPERETTE", "EAN": EAN}},
        {"$group": {"_id": {"price": "$WEEKLY_PRICE", "uf": "$STATE_UF"}, "count": {"$sum": 1}}},
        {"$sort": {"count": -1}},
        {
            "$group": {
                "_id": "$_id.uf",
                "data": {"$push": {"price": "$_id.price", "count": "$count"}},
                "max_count": {"$max": "$count"},
            }
        },
        {
            "$project": {
                "items": {
                    "$filter": {"input": "$data", "as": "single", "cond": {"$eq": ["$$single.count", "$max_count"]}}
                }
            }
        },
        {"$unwind": "$items"},
        {"$group": {"_id": "$_id", "modal_price": {"$avg": "$items.price"}}},
    ]
)
superette_prices = list(cur)

df_br = pd.DataFrame(br_mania_prices)
df_conv = pd.DataFrame(conv_prices)
df_small = pd.DataFrame(small_prices)
df_merge = pd.merge(
    df_br,
    df_conv[["_id", "modal_price"]].rename(columns={"modal_price": "modal_price_convenience"}),
    how="left",
    on="_id",
)
df_merge = pd.merge(
    df_merge,
    df_small[["_id", "modal_price"]].rename(columns={"modal_price": "modal_price_small_smkt"}),
    how="left",
    on="_id",
)
df_merge.rename(columns={"_id": "uf"}, inplace=True)
# df_merge.drop(columns=["count", "max_count"], inplace=True)
df_merge.to_excel("./vem_heineken_moda.xlsx", index=False)


# cidade
cur = coll.aggregate(
    [
        {"$match": {"STORE_NAME": "BR MANIA", "EAN": EAN}},
        {"$group": {"_id": {"price": "$WEEKLY_PRICE", "uf": "$CITY"}, "count": {"$sum": 1}}},
        {"$sort": {"count": -1}},
        {
            "$group": {
                "_id": "$_id.uf",
                "data": {"$push": {"price": "$_id.price", "count": "$count"}},
                "max_count": {"$max": "$count"},
            }
        },
        {
            "$project": {
                "items": {
                    "$filter": {"input": "$data", "as": "single", "cond": {"$eq": ["$$single.count", "$max_count"]}}
                }
            }
        },
        {"$unwind": "$items"},
        {"$group": {"_id": "$_id", "modal_price": {"$avg": "$items.price"}}},
    ]
)
br_mania_prices = list(cur)

cur = coll.aggregate(
    [
        {"$match": {"FORMAT_MARKET": "GAS STATION", "STORE_NAME": {"$ne": "BR MANIA"}, "EAN": EAN}},
        {"$group": {"_id": {"price": "$WEEKLY_PRICE", "uf": "$CITY"}, "count": {"$sum": 1}}},
        {"$sort": {"count": -1}},
        {
            "$group": {
                "_id": "$_id.uf",
                "data": {"$push": {"price": "$_id.price", "count": "$count"}},
                "max_count": {"$max": "$count"},
            }
        },
        {
            "$project": {
                "items": {
                    "$filter": {"input": "$data", "as": "single", "cond": {"$eq": ["$$single.count", "$max_count"]}}
                }
            }
        },
        {"$unwind": "$items"},
        {"$group": {"_id": "$_id", "modal_price": {"$avg": "$items.price"}}},
    ]
)
conv_prices = list(cur)

cur = coll.aggregate(
    [
        {"$match": {"FORMAT_MARKET": "SMALL SUPERMARKET", "EAN": EAN}},
        {"$group": {"_id": {"price": "$WEEKLY_PRICE", "uf": "$CITY"}, "count": {"$sum": 1}}},
        {"$sort": {"count": -1}},
        {
            "$group": {
                "_id": "$_id.uf",
                "data": {"$push": {"price": "$_id.price", "count": "$count"}},
                "max_count": {"$max": "$count"},
            }
        },
        {
            "$project": {
                "items": {
                    "$filter": {"input": "$data", "as": "single", "cond": {"$eq": ["$$single.count", "$max_count"]}}
                }
            }
        },
        {"$unwind": "$items"},
        {"$group": {"_id": "$_id", "modal_price": {"$avg": "$items.price"}}},
    ]
)
small_prices = list(cur)


cur = coll.aggregate(
    [
        {"$match": {"FORMAT_MARKET": "SUPERETTE", "EAN": EAN}},
        {"$group": {"_id": {"price": "$WEEKLY_PRICE", "uf": "$CITY"}, "count": {"$sum": 1}}},
        {"$sort": {"count": -1}},
        {
            "$group": {
                "_id": "$_id.uf",
                "data": {"$push": {"price": "$_id.price", "count": "$count"}},
                "max_count": {"$max": "$count"},
            }
        },
        {
            "$project": {
                "items": {
                    "$filter": {"input": "$data", "as": "single", "cond": {"$eq": ["$$single.count", "$max_count"]}}
                }
            }
        },
        {"$unwind": "$items"},
        {"$group": {"_id": "$_id", "modal_price": {"$avg": "$items.price"}}},
    ]
)
superette_prices = list(cur)

df_br = pd.DataFrame(br_mania_prices)
df_conv = pd.DataFrame(conv_prices)
df_small = pd.DataFrame(small_prices)
df_merge = pd.merge(
    df_br,
    df_conv[["_id", "modal_price"]].rename(columns={"modal_price": "modal_price_convenience"}),
    how="left",
    on="_id",
)
df_merge = pd.merge(
    df_merge,
    df_small[["_id", "modal_price"]].rename(columns={"modal_price": "modal_price_small_smkt"}),
    how="left",
    on="_id",
)
df_merge.rename(columns={"_id": "city"}, inplace=True)
# df_merge.drop(columns=["count", "max_count"], inplace=True)
df_merge.to_excel("./vem_heineken_moda_cidade.xlsx", index=False)
