"""
Cria uma planilha XLSX a partir das informações de nível de atividade da VEM.
Especialmente para as filiais escolhidas como case.
Requer um JSON com a descrição dos produtos escolhidos gerado pelo script vem_get_top_products
"""

import argparse
import json
import warnings
from datetime import datetime

import pandas as pd

from geral.config import getDadosAWSSession
from utils import (
    activity_level_pivot,
    activity_level_sheet,
    save_excel,
    remove_missing_granularity,
    reorder_pivot_columns,
)


ID_COMPANY = 3026
PROD_ID = "Description"
GRANULARITY = ["Affiliate"]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--env", required=True, choices=["producao", "preproducao"])
    parser.add_argument(
        "--day-lookback",
        type=int,
        default=90,
        help="período retroativo a ser considerado",
    )
    parser.add_argument(
        "--allowed-json",
        type=str,
        required=True,
        help="JSON with allowed descriptions per affiliate",
    )
    args = parser.parse_args()

    warnings.simplefilter(action="ignore", category=UserWarning)
    conn = getDadosAWSSession(args.env)

    allowed_json = json.load(open(args.allowed_json, "r", encoding="utf-8"))
    affiliates = list(allowed_json)
    allowed = pd.DataFrame(
        [
            {"Affiliate": affiliate, "Description": desc}
            for affiliate, descriptions in allowed_json.items()
            for desc in descriptions
        ]
    )
    print(allowed.head())

    print("getting activity level data")
    al_sheet = activity_level_sheet(conn, ID_COMPANY, [PROD_ID, *GRANULARITY])

    al_sheet = al_sheet[al_sheet["Affiliate"].isin(affiliates)]

    print("getting daily sales data")
    pivot_sheet = activity_level_pivot(
        conn, ID_COMPANY, args.day_lookback, PROD_ID, GRANULARITY
    )

    pivot_sheet = remove_missing_granularity(pivot_sheet, al_sheet, GRANULARITY)

    print(al_sheet.shape)
    print(f"limitando por {args.allowed_json}")
    al_sheet = pd.merge(al_sheet, allowed, on=["Description", "Affiliate"], how="inner")
    pivot_sheet = pd.merge(
        pivot_sheet, allowed, on=["Description", "Affiliate"], how="inner"
    )

    print(al_sheet.shape)

    pivot_sheet = reorder_pivot_columns(pivot_sheet, GRANULARITY)

    fname = f"activity_level_{ID_COMPANY}_{datetime.now().strftime('%Y-%m-%d')}.xlsx"
    print(f"saving to {fname}")
    save_excel(fname, al_sheet, pivot_sheet)


if __name__ == "__main__":
    main()
