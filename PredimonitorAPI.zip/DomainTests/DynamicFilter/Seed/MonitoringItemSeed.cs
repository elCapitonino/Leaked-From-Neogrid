﻿using Repository.Entity;

namespace DomainTests.DynamicFilter.Seed
{
    public class MonitoringItemSeed
    {

        public static List<MonitoringItemEntity> GetTestData()
        {
            return new List<MonitoringItemEntity>
            {
                new MonitoringItemEntity { Id = 1, Description = "Banana" },
                new MonitoringItemEntity { Id = 2, Description = "Maca" },
                new MonitoringItemEntity { Id = 3, Description = "Laranja" },
                new MonitoringItemEntity { Id = 4, Description = "Uva" },
                new MonitoringItemEntity { Id = 5, Description = "Abacaxi" },
                new MonitoringItemEntity { Id = 6, Description = "Manga" },
                new MonitoringItemEntity { Id = 7, Description = "Morango" },
                new MonitoringItemEntity { Id = 8, Description = "Pera" },
                new MonitoringItemEntity { Id = 9, Description = "Melancia" },
                new MonitoringItemEntity { Id = 10, Description = "Melao" },
                new MonitoringItemEntity { Id = 11, Description = "Coco" },
                new MonitoringItemEntity { Id = 12, Description = "Mamao" },
                new MonitoringItemEntity { Id = 13, Description = "Kiwi" },
                new MonitoringItemEntity { Id = 14, Description = "Abacate" },
                new MonitoringItemEntity { Id = 15, Description = "Limao" },
                new MonitoringItemEntity { Id = 16, Description = "Goiaba" },
                new MonitoringItemEntity { Id = 17, Description = "Caqui" },
                new MonitoringItemEntity { Id = 18, Description = "Acerola" },
                new MonitoringItemEntity { Id = 19, Description = "Caju" },
                new MonitoringItemEntity { Id = 20, Description = "Framboesa" },
                new MonitoringItemEntity { Id = 21, Description = "Alface" },
                new MonitoringItemEntity { Id = 22, Description = "Cenoura" },
                new MonitoringItemEntity { Id = 23, Description = "Tomate" },
                new MonitoringItemEntity { Id = 24, Description = "Batata" },
                new MonitoringItemEntity { Id = 25, Description = "Beterraba" },
                new MonitoringItemEntity { Id = 26, Description = "Pimentao" },
                new MonitoringItemEntity { Id = 27, Description = "Pepino" },
                new MonitoringItemEntity { Id = 28, Description = "Berinjela" },
                new MonitoringItemEntity { Id = 29, Description = "Brocolis" },
                new MonitoringItemEntity { Id = 30, Description = "Celular" },
                new MonitoringItemEntity { Id = 31, Description = "Televisao" },
                new MonitoringItemEntity { Id = 32, Description = "Notebook" },
                new MonitoringItemEntity { Id = 33, Description = "Tablet" },
                new MonitoringItemEntity { Id = 34, Description = "Camera" },
                new MonitoringItemEntity { Id = 35, Description = "Fone de ouvido" },
                new MonitoringItemEntity { Id = 36, Description = "Radio" },
                new MonitoringItemEntity { Id = 37, Description = "Quadro pintado a mao" },
                new MonitoringItemEntity { Id = 38, Description = "Vaso de ceramica" },
                new MonitoringItemEntity { Id = 39, Description = "Cesta de palha" },
                new MonitoringItemEntity { Id = 40, Description = "Escultura de madeira" }
            };
        }
    }
}

