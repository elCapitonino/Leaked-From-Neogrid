﻿using PredifyClientAPI.Services.PredifyAPI.Models;

namespace PredifyClientAPI.Services.PredifyAPI.SaleHistory.Models
{
    public class EnterpriseSalesHistoryAddRequest : AccessBase
    {
        /// <summary>
        /// Vendas efetuadas, limite de 1000 registros por chamada.
        /// </summary>
        public List<EnterpriseSalesHistoryModel> sales { get; set; }

        /// <summary>
        /// Efetua os cálculos e atualiza lista de produtos globais.
        /// </summary>
        public bool calculateValues { get; set; } = true;
    }
}
