﻿using Repository.DbContexts;
using Repository.Entity;
using Repository.EntityRepository.Bases;

namespace Repository.EntityRepository
{
    public class InfoPricePeraltaRepository : GenericMongoRepository<InfoPricePeraltaEntity>, IInfoPricePeraltaRepository
    {
        public InfoPricePeraltaRepository(InfoPriceSaoJoaoDbContext dbContext) : base(dbContext)
        {
        }
        public static string DbContextName => nameof(InfoPriceSaoJoaoDbContext);
    }
}
