﻿using Repository.Enums;

namespace Repository.Entity
{
    public class MonitoringItemResultsStatusEntity : BaseEntity
    {

        public long CompanyId { get; set; }
        public virtual CompanyEntity Company { get; set; }

        public string? Message { get; set; }
        public Guid TaskId { get; set; }
        public long CurrentStep { get; set; }

        public MonitoringItemResultsStatusType Status { get; set; }
    }
}
