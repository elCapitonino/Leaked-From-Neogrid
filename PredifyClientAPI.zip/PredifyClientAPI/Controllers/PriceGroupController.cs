﻿using Asp.Versioning;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PredifyClientAPI.Services.PredifyAPI;
using PredifyClientAPI.Services.PredifyAPI.Models;
using PredifyClientAPI.Services.PredifyAPI.PriceGroup.Models;

namespace PredifyClientAPI.Controllers
{
    [ApiController]
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiVersion("1.0")]
    [Authorize]
    public class PriceGroupController : ControllerBase
    {
        private readonly ILogger<PriceGroupController> _logger;
        private readonly PredifyAPIUserManager _predifyAPIUserManager;

        public PriceGroupController(ILogger<PriceGroupController> logger, PredifyAPIUserManager predifyAPIUserManager)
        {
            _logger = logger;
            _predifyAPIUserManager = predifyAPIUserManager;
        }

        [HttpPost("List")]
        [MapToApiVersion("1.0")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(GeneralResponse<EnterpriseListGroupsResponse>))]
        [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status401Unauthorized, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
        public async Task<IActionResult> List([FromBody] EnterpriseListGroupsRequest request)
        {
            try
            {
                var response = await _predifyAPIUserManager.PriceGroupService.List(request);

                return Ok(response);
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized(ex.Message);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
