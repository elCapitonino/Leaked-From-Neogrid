from google.cloud import bigquery
from google.oauth2 import service_account
import pandas as pd
import numpy as np
from pymongo import MongoClient
from pymongo import MongoClient
import uuid
import geoApiService

class linxIntegration:
    def __init__(self, google_bigquery_credencial, mongo_conection_string):
        credentials = service_account.Credentials.from_service_account_file(google_bigquery_credencial)
        self.client = bigquery.Client(credentials=credentials, project=credentials.project_id)
        
        client = MongoClient(mongo_conection_string)
        mongo_db = client['linx']
        self.col_fact_ticket_control = mongo_db['fact_ticket_control']
        self.col_fact_ticket = mongo_db['fact_ticket']
        
    def get_control_to_import(self):
        #limitado atualmente para olhar de abril para frente por questão de teste e não estar efetivamente funcionando da maneira correta
        query_control = f"""
            SELECT year_invoice, week_invoice, week_fist_day_invoice, week_last_day_invoice, year_ingestion, week_ingestion, date_ingestion, sequence_ingestion, cnae, amount_invoice
            FROM shared-data-platform-prd.linx.fact_ticket_control
            WHERE week_fist_day_invoice >= '2024-04-01';
        """
        query_job = self.client.query(query_control)
        results = query_job.result()
        #coleta o controle atual 
        ticket_controls = results.to_dataframe().to_dict(orient='records')

        control_local = self.col_fact_ticket_control.find()
        # Propriedades a serem comparadas
        propriedades = ["year_invoice", "week_invoice", "week_fist_day_invoice", "week_last_day_invoice", "cnae", "sequence_ingestion"]

        return self.comparar_listas(ticket_controls, control_local, propriedades)

    def item_presente(self, item, lista, propriedades):
        for item_lista in lista:
            if all(item[prop] == item_lista[prop] for prop in propriedades):
                return True
        return False

    def comparar_listas(self, lista1, lista2, propriedades):
        nao_inclusos = [item for item in lista1 if not self.item_presente(item, lista2, propriedades)]
        return nao_inclusos

    def fact_ticket_to_mongo(self, ticket_control):

        query_ticket = f"""
            SELECT id_time, cd_location, cd_ticket, cd_supplier, cd_ean, nm_item, vl_quantity_sold, vl_item_price, vl_item_discount, vl_item_total_value, vl_sales_total_value, cd_ncm, cd_currency, cd_cnae, cd_state, cd_postalcode, cd_item, ds_item, cd_unit_measure, dh_created, dh_updated, vl_item_addition, ds_billing_range, id_week_invoice, id_week_ingestion, id_year_invoice, id_year_ingestion, id_sequence_ingestion
            FROM `shared-data-platform-prd`.linx.fact_ticket
            WHERE id_week_invoice = {ticket_control['week_invoice']} and id_year_invoice = {ticket_control['year_invoice']} and cd_cnae  = '{ticket_control['cnae']}' and id_time >= '{ticket_control['week_fist_day_invoice']}' and id_time <= '{ticket_control['week_last_day_invoice']}' and id_sequence_ingestion = {ticket_control['sequence_ingestion']};
        """

        query_job = self.client.query(query_ticket)

        # Obtém os resultados da query
        df = query_job.result().to_dataframe()

        # # Lista das colunas e os tipos para os quais você deseja converter
        # column_types = {
        #     'col1': float,
        #     'col2': float
        #     # Adicione outras colunas e seus tipos desejados aqui
        # }

        # # Converte as colunas específicas para os tipos desejados
        # df = df.astype(column_types)

        print('eliminando espaço livre')
        df = df.applymap(lambda x: x.strip() if isinstance(x, str) else x)

        print('trantando Nan')
        df = df.replace({np.nan: None})

        print('Gerando id import')
        id_import = str(uuid.uuid4())
        ticket_control['id_import'] = id_import
        df['id_import'] = id_import

        print('criando dicionário')
        data = df.to_dict(orient='records')

        #=====================================================================================
        print('Analisando endereços')
        geoService = geoApiService.geoApiService()

        props_to_check = ['cd_state', 'cd_postalcode']

        # Obtendo a lista distinct
        distinct_adress = self.distinct_dicts(data, props_to_check)
        print('Endereços distintos encontrados:', len(distinct_adress))

        address_founded = {}
        for da in distinct_adress:
            address_info = {
                "base": "linx",
                "id_consulta": f"BR, {da['cd_state']}, {da['cd_postalcode']}-000",
                "address":"",
                "neighborhood": "",
                "city": "",
                "state": da['cd_state'] if da['cd_state'] is not None else "",
                "country": ""
            }
            address = geoService.get_address(address_info)
            address_founded[f"{da['cd_state']}, {da['cd_postalcode']}"] = address

        print('coordenadas encontradas:', len(address_founded))

        for d in data:
            id_address = f"{d['cd_state']}, {d['cd_postalcode']}"
            if id_address in address_founded:
                d['coordinates'] = address_founded[id_address]['coordinates']

        print('coordenadas inseridas:', len(address_founded))

        print('inserindo no mongo')
        self.col_fact_ticket.insert_many(data)
        ticket_control['predify_count_imported'] = len(data)
        
        self.col_fact_ticket_control.insert_one(ticket_control)

        print('dados inseridos:', len(data))

    # faz um distinct de acordo com as propriedades passadas da lista de dicionário
    def distinct_dicts(self, dict_list, props):
        seen = set()
        result = []
        
        for d in dict_list:
            key = tuple(d[prop] for prop in props)
            if key not in seen:
                seen.add(key)
                result.append(d)
        
        return result





