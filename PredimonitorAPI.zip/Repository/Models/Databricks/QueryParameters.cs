namespace Repository.Models.Databricks;

public class QueryParameters
{
    public List<QuerySelect> Select { get; set; } = [];
    public List<QueryFilter> Filters { get; set; } = [];
    public List<QuerySQL> SqlFilters { get; set; } = [];
    public List<QueryJoin> Joins { get; set; } = [];
    public List<QueryGroupBy> GroupBy { get; set; } = [];
    public List<QueryOrderBy> OrderBy { get; set; } = [];
    public int Skip { get; set; }
    public int Take { get; set; }
    public bool TakeAll { get; set; }
}

public class QuerySelect
{
    public string? Column { get; set; }
    public bool IsFromMainTable { get; set; }
}

public class QueryJoin
{
    public string? JoinTable { get; set; }
    public string? JoinType { get; set; }
    public string? JoinCondition { get; set; }
    public bool JoinWithMainTable { get; set; }
    public string? JoinSQL { get; set; }
}

public class QueryFilter
{
    public string? Column { get; set; }
    public string? Operator { get; set; }
    public object? Value { get; set; }
}

public class QueryGroupBy
{
    public string? Column { get; set; }
}

public class QueryOrderBy
{
    public string? Column { get; set; }
}

public class QuerySQL
{
    public string? SQL { get; set; }
}

public enum QueryIgnore
{
    DonotIgnore = 0,
    Name = 1,
    Category = 2,
    Seller = 3,
    Brand = 4,
    Crawler = 5,
    UF = 6,
    Year = 7,
    Region = 8,
    Segment = 9
}
