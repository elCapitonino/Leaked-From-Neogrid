import re
from time import time
from predimonitor_type import id_company_config


from async_mongo import AsyncMongoConnect
from config import *
from processing import Processing
from algorithms import Algorithm
from processing_product import Processing_product
from restriction_list import RestrictionList
from restriction_search_company import RestrictionSearchCompany

# temporário
import numpy as np
import pandas as pd


# Restriction_List = RestrictionList()


class Search_products:
    def __init__(self):
        try:
            # print(" ------ Search iniciado  ------")
            self.dbMongo = AsyncMongoConnect()
            self.prep = Processing()
            self.prep_product = Processing_product()
            # self.Restriction_list = RestrictionList()
            self.Restriction_search_company = RestrictionSearchCompany()
            self.calc = Algorithm()
        except Exception as ex:
            # print(" ------ Search não iniciado  ------")
            print(ex)

    async def get_all_products(self, id_crawler_list, start_date, end_date):
        return await self.dbMongo.get_all_products( id_crawler_list, start_date, end_date)

    async def get_all_products_netshoes(self, id_crawler_list, start_date, end_date):
        return await self.dbMongo.get_all_products_netshoes( id_crawler_list, start_date, end_date)

    async def get_products(self, data_resp, start_date, end_date, idcrawlers_busca, language, id_company, list_restrict, name_product, mandatory_tag_model):
        # print(data_resp)
        list_result_final = []
        result_return = []
        sc = []
        mandatory_tag_list = mandatory_tag_model.split(";")
        if (data_resp['products_list'][0] != []):
            trash = data_resp['products_list'][0][0][5]
            if (trash != None):
                # se o termo esta na restricao, atualiza a lista
                if (trash in list_restrict):
                    sc.append({"txt": trash, "score": 1})
                    # print("Removido: ", s)
                    list_restrict.remove(trash)
                if (trash.upper() in list_restrict):
                    sc.append({"txt":trash.upper(), "score":1})
                    list_restrict.remove(trash.upper())
                
                for s in trash.split(' '):
                    if ((s != '') or (s != ' ') or (s != None)):
                        x = re.search("(\A)[a-zA-Z]*\d($(\Z))", s)
                        if x:
                            sc.append({"txt": s, "score": 2})
                            y = re.search("(\A)[a-zA-Z]*", x.group())
                            sc.append({"txt": y.group(), "score": 1})
                            sc.append(
                                {"txt": s.replace(y.group(), ""), "score": 1})
                        if s in list_restrict:
                            sc.append({"txt": s, "score": 1})
                            # print("Removido: ", s)
                            list_restrict.remove(s)
                        else:
                            sc.append({"txt": s, "score": 1})
            for search_word in name_product.split(" "):
                if search_word in list_restrict:
                    list_restrict.remove(search_word)             
            for mandatory_tag in mandatory_tag_list:
                for mandatory_tag_model_word in mandatory_tag.split(" "):
                    if mandatory_tag_model_word.lower() in list_restrict:
                        list_restrict.remove(mandatory_tag_model_word)
                    elif mandatory_tag_model_word.upper() in list_restrict:
                        list_restrict.remove(mandatory_tag_model_word)
                    elif mandatory_tag_model_word in list_restrict:
                        list_restrict.remove(mandatory_tag_model_word)

            for r in list_restrict:
                sc.append({"txt": r, "score": -3})

            for item in data_resp['products_list'][0]:
                ##################################
                result = await self.dbMongo.get_products_general(
                    item[0], start_date, end_date, idcrawlers_busca)
                ##################################
                # result = list(result)
                # print("result: ", len(result))
                for i in result:
                    if 'product_link' not in i:
                        continue
                    if 'sellers' not in i:
                        continue

                    if (i["id_product_normalized"] == "6336bc78638a4c4ea897f48f"):
                        print()

                    product_model = ''
                    busca_name = ''
                    busca_name = str(i["product_name"])
                    if "product_model" in i:
                        product_model = str(i["product_model"])
                        if product_model.lower() not in busca_name.lower():
                            busca_name = busca_name + " " + product_model   
                        if(product_model == '' or product_model == ' '):
                            continue

                    product_name = self.prep.run(busca_name, language)
                    site_sku: str = None
                    shippings = None
                    if 'site_sku' in i:
                        site_sku = i['site_sku']
                    if 'shippings' in i:
                        shippings = i['shippings']
                    
                    if product_name.lower().__contains__("mf 250x"):
                        print()

                    ##################################
                    t_score = 0
                    for mandatory_tag_model in mandatory_tag_list:
                        if mandatory_tag_model != "" and mandatory_tag_model.lower() == product_model.lower():
                            t_score = 3
                            break
                        elif mandatory_tag_model != "" and not(re.search(mandatory_tag_model.lower(), product_model.lower())):
                            t_score += -3
                            # number_model_split = re.findall('[0-9]+', mandatory_tag_model)
                            # if len(number_model_split) > 0 and number_model_split[0] in  product_model:
                            #     t_score += 6

                    # eliminar produtos vendidos por atacado com numero no inicio da descricao
                    x_num = re.search("^(\d{1,2}\s)", product_name)
                    if x_num:
                        t_score += -1

                    for s in sc:
                        if (s['txt'] in product_name):
                            t_score += s['score']

                    if (((t_score > 0) and (item[5] != None) or ((t_score == 0)) and (item[5] == None))):

                        '''
                        Somente produtos com score maior ou igual a 0 serao adicionados a lista de resultados
                        score maior que 0 e trash diferente de none
                        score igual a 0 e trash igual a none
                        '''
                        i.update({"trash_score": t_score})
                        i['id'] = str(i['_id'])
                        i.pop('_id')
                        list_result_final.append(i)

            ##################################################
            if len(list_result_final) == 0:
                return []
            if len(list_result_final) > 0:
                m = max(list_result_final, key=lambda x: x["trash_score"])

            p = list(filter(lambda x: x['trash_score'] ==
                            m['trash_score'], list_result_final))

            p = self.prep_product.get_products_time(p)

            # name_search = '_'.join(item[2])
            # name_search = str(name_search)

            # result_return.append({'id': item[4], 'name': name_search,
            #                       'results': p})
        return p
        # return result_return

    async def get_products_pred_monitor(self, data_resp, start_date, end_date, idcrawlers_busca, local_states, manufacture_year, used_hours, language, id_company, list_restrict, mandatoryTagModel, exactVector, category, manufacturer_name):
        if used_hours == None:
            used_hours_min = None
            used_hours_max = None
        if used_hours != None:
            used_hours_min = used_hours.min
            used_hours_max = used_hours.max

        sc = []
        mandatory_tag_list = mandatoryTagModel.split(";")
        if (data_resp['products_list'] != []):
            trash = data_resp['products_list'][0][0][4]
            product_brand = data_resp['products_list'][0][0][3]
            if (product_brand != None):
                for s in product_brand.split(' '):
                    if ((s != '') or (s != ' ') or (s != None)):
                        x = re.search("(\A)[a-zA-Z]*\d($(\Z))", s)
                        if x:
                            sc.append({"txt": s, "score": 2})
                            y = re.search("(\A)[a-zA-Z]*", x.group())
                            sc.append({"txt": y.group(), "score": 1})
                            sc.append(
                                {"txt": s.replace(y.group(), ""), "score": 1})
                        if s in list_restrict:
                            sc.append({"txt": s, "score": 1})
                            # print("Removido: ", s)
                            list_restrict.remove(s)
                        else:
                            sc.append({"txt": s, "score": 1})

            if (trash != None):
                for s in trash.split(' '):
                    if ((s != '') or (s != ' ') or (s != None)):
                        x = re.search("(\A)[a-zA-Z]*\d($(\Z))", s)
                        if x:
                            sc.append({"txt": s, "score": 2})
                            y = re.search("(\A)[a-zA-Z]*", x.group())
                            sc.append({"txt": y.group(), "score": 1})
                            sc.append(
                                {"txt": s.replace(y.group(), ""), "score": 1})
                        if s in list_restrict:
                            sc.append({"txt": s, "score": 1})
                            # print("Removido: ", s)
                            list_restrict.remove(s)
                        else:
                            sc.append({"txt": s, "score": 1})
            for mandatory_tag in mandatory_tag_list:
                for mandatory_tag_model_word in mandatory_tag.split(" "):
                    if mandatory_tag_model_word.lower() in list_restrict:
                        list_restrict.remove(mandatory_tag_model_word)
                    elif mandatory_tag_model_word.upper() in list_restrict:
                        list_restrict.remove(mandatory_tag_model_word)
                    elif mandatory_tag_model_word in list_restrict:
                        list_restrict.remove(mandatory_tag_model_word)
            for r in list_restrict:
                sc.append({"txt": r, "score": -3})
            list_result_final_pred = []

            idList = []

            for item in data_resp['products_list'][0]:
                idList.append(item[0])
                if (len(idList) == 200):
                    break

            mongo_result = await self.dbMongo.get_products_pred_monitor(
                idList, start_date, end_date, idcrawlers_busca)

            mongo_result = list(mongo_result)

            for item in data_resp['products_list'][0]:
                # print("item: ", item)
                #################################################
                # result = await self.dbMongo.get_products_pred_monitor(
                #     item[0], start_date, end_date, idcrawlers_busca)
                ################################################

                result = filter(lambda e: e['id_product_normalized'] == item[0], mongo_result)

                for i in result:

                    product_model = ''
                    busca_name = ''
                    busca_name = str(i["product_name"])
                    if "product_model" in i:
                        product_model = str(i["product_model"])
                        if product_model not in busca_name:
                            busca_name = busca_name + " " + product_model

                    states_year_hours = True
                    product_name = self.prep.run(busca_name, language)
                    site_sku = None

                    if 'site_sku' in i:
                        site_sku = i['site_sku']

                    if 'product_local' not in i or i['product_local'] == None:
                        i["product_local"] = {}
                    if 'state' not in i['product_local']:
                        i['product_local']['state'] = None

                    if 'product_used_hours' not in i:
                        i["product_used_hours"] = None
                    if 'product_manufacture_year' not in i:
                        i["product_manufacture_year"] = None

                    if 'sellers' not in i:
                        continue

                    # if 'sellers' not in i:
                    #     continue
                    ##################################
                    t_score = 0
                    for mandatory_tag_model in mandatory_tag_list:
                        if mandatory_tag_model != "" and mandatory_tag_model.lower() == product_model.lower():
                            t_score = 3
                            break
                        elif mandatory_tag_model != "" and not(re.search(mandatory_tag_model.lower(), product_model.lower())):
                            t_score += -3
                    # eliminar produtos vendidos por atacado com numero no inicio da descricao
                    x_num = re.search("^(\d{1,2}\s)", product_name)
                    if x_num:
                        t_score += -1
                    # print("-------------------------------------")

                    for s in sc:

                        if s['txt'] in product_name:
                            t_score += s['score']

                    if ((t_score > 0 and item[4] != None) or (t_score == 0 and item[4] == None) or (t_score > 0 and exactVector == False)):

                        '''
                        Somente produtos com score maior ou igual a 0 serao adicionados a lista de resultados
                        '''
                        if ("product_link" not in i):
                            i["product_link"] = ""
                            
                        result_list = {'id': str(i['_id']),
                                       'id_crawler': i['id_crawler'],
                                       "product_name": i['product_name'],
                                       "product_link": i['product_link'],
                                       "site_sku": site_sku,
                                       "source": i['source'],
                                       "language": i['language'],
                                       "product_brand": item[3],
                                       "id_product_normalized": i["id_product_normalized"],
                                       "trash_score": 0,
                                       "crawler_date": i["crawler_date"],
                                       "seller_name": i["sellers"][0]["seller_name"],
                                       "prices": i["sellers"][0]["prices"],
                                       "product_local": i["product_local"],
                                       "product_manufacture_year": i["product_manufacture_year"],
                                       "product_used_hours": i["product_used_hours"],
                                       }
                        result_list.update({"trash_score": t_score})

                        if (local_states != None and (len(local_states) > 0)):
                            if (str(i["product_local"]["state"]).lower() not in local_states):
                                states_year_hours = False

                        if (manufacture_year != None) and (len(manufacture_year) > 0):
                            if (i["product_manufacture_year"] not in manufacture_year):
                                states_year_hours = False

                        if ((used_hours_min != None) and (used_hours_max != None)):
                            if (i["product_used_hours"] == None):
                                states_year_hours = False
                            if (i["product_used_hours"] != None and int(used_hours_max) != 0):
                                if ((int(used_hours_min) > int(i["product_used_hours"])) or (int(i["product_used_hours"]) > int(used_hours_max))):
                                    states_year_hours = False
                        
                        # Condição que verifica se o cliente é Addiante, caso seja True ela confere se os fabricantes selecionados estão relacionados nos produtos
                        if (manufacturer_name != None and len(manufacturer_name ) > 0 and (i["id_company"] != None) and id_company == id_company_config.addiante.value):
                            if(i["product_brand"] != None and len(manufacturer_name) > 0):
                               if not any(re.match(i["product_brand"], brand) for brand in manufacturer_name):
                                    states_year_hours = False

                        # Condição que verifica se o cliente é Addiante, caso seja True ela confere se as categorias selecionadas estão relacionadas nos produtos
                        if (category != None and len(category) > 0 and (i["id_company"] != None) and id_company == id_company_config.addiante.value):
                            if(i["product_name"] != None and len(category) > 0):
                                for c in category:
                                    if not (re.search(c, str(i["product_name"]).lower())):
                                        states_year_hours = False

                        if (states_year_hours == True):
                            list_result_final_pred.append(result_list)

            if len(list_result_final_pred) == 0:
                return []
            if len(list_result_final_pred) > 0:
                m = max(list_result_final_pred,
                        key=lambda x: x["trash_score"])
                
            result_pred = list(filter(lambda x: x['trash_score'] >=
                                      m['trash_score'], list_result_final_pred))

            return result_pred 

    async def get_products_pred_monitor_restricted(self, data_resp, start_date, end_date, idcrawlers_busca, local_states, manufacture_year, used_hours, language, id_company, list_restrict):

        if used_hours == None:
            used_hours_min = None
            used_hours_max = None
        if used_hours != None:
            used_hours_min = used_hours.min
            used_hours_max = used_hours.max

        sc = []
        if (data_resp['products_list'] != []):
            trash = data_resp['products_list'][0][0][4]
            if (trash != None):
                for s in trash.split(' '):
                    if ((s != '') or (s != ' ') or (s != None)):
                        x = re.search("(\A)[a-zA-Z]*\d($(\Z))", s)
                        if x:
                            sc.append({"txt": s, "score": 2})
                            y = re.search("(\A)[a-zA-Z]*", x.group())
                            sc.append({"txt": y.group(), "score": 1})
                            sc.append(
                                {"txt": s.replace(y.group(), ""), "score": 1})
                        if s in list_restrict:
                            sc.append({"txt": s, "score": 1})
                            # print("Removido: ", s)
                            list_restrict.remove(s)
                        else:
                            sc.append({"txt": s, "score": 1})

            for r in list_restrict:
                sc.append({"txt": r, "score": -3})
            list_result_final_pred = []
            for item in data_resp['products_list'][0]:
                # print("item: ", item)
                #################################################
                result = await self.dbMongo.get_products_pred_monitor(
                    item[0], start_date, end_date, idcrawlers_busca)
                #################################################
                for i in result:

                    product_model = ''
                    busca_name = ''
                    busca_name = str(i["product_name"])
                    if "product_model" in i:
                        product_model = str(i["product_model"])
                        if busca_name not in product_model:
                            busca_name = busca_name + " " + product_model

                    states_year_hours = True
                    product_name = self.prep.run(busca_name, language)
                    site_sku = None

                    if 'site_sku' in i:
                        site_sku = i['site_sku']

                    if 'product_local' not in i:
                        i["product_local"] = {}
                    if 'state' not in i['product_local']:
                        i['product_local']['state'] = None

                    if 'product_used_hours' not in i:
                        i["product_used_hours"] = None
                    if 'product_manufacture_year' not in i:
                        i["product_manufacture_year"] = None

                    if 'sellers' not in i:
                        continue

                    if 'sellers' not in i:
                        continue
                    ##################################
                    t_score = 0
                    # eliminar produtos vendidos por atacado com numero no inicio da descricao
                    x_num = re.search("^(\d{1,2}\s)", product_name)
                    if x_num:
                        t_score += -1
                    # print("-------------------------------------")

                    for s in sc:
                        for name in product_name.split(' '):
                            if (s['txt'] == name):
                                t_score += s['score']

                    if (((t_score > 0) and (item[4] != None) or ((t_score == 0)) and (item[4] == None))):

                        '''
                        Somente produtos com score maior ou igual a 0 serao adicionados a lista de resultados
                        '''

                        result_list = {'id': str(i['_id']),
                                       'id_crawler': i['id_crawler'],
                                       "product_name": i['product_name'],
                                       "product_link": i['product_link'],
                                       "site_sku": site_sku,
                                       "product_model": product_model,
                                       "source": i['source'],
                                       "language": "pt-br",
                                       "product_brand": item[3],
                                       "id_product_normalized": i["id_product_normalized"],
                                       "trash_score": 0,
                                       "crawler_date": i["crawler_date"],
                                       "seller_name": i["sellers"][0]["seller_name"],
                                       "prices": i["sellers"][0]["prices"],
                                       "product_local": i["product_local"],
                                       "product_manufacture_year": i["product_manufacture_year"],
                                       "product_used_hours": i["product_used_hours"],
                                       }
                        result_list.update({"trash_score": t_score})

                        if (local_states != None and (len(local_states) > 0)):
                            if (i["product_local"]["state"] not in local_states):
                                states_year_hours = False

                        if (manufacture_year != None) and (len(manufacture_year) > 0):
                            if (i["product_manufacture_year"] not in manufacture_year):
                                states_year_hours = False

                        if ((used_hours_min != None) and (used_hours_max != None)):
                            if (i["product_used_hours"] == None):
                                states_year_hours = False
                            if (i["product_used_hours"] != None):
                                if ((int(used_hours_min) > int(i["product_used_hours"])) or (int(i["product_used_hours"]) > int(used_hours_max))):
                                    states_year_hours = False

                        if (states_year_hours == True):
                            list_result_final_pred.append(result_list)

            if len(list_result_final_pred) == 0:
                return []
            if len(list_result_final_pred) > 0:
                m = max(list_result_final_pred,
                        key=lambda x: x["trash_score"])

            result_pred = list(filter(lambda x: x['trash_score'] ==
                                      m['trash_score'], list_result_final_pred))
            return result_pred
