﻿using Dapper;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using PH.Domain.DTO;
using PH.Domain.Interfaces.Repositories;
using System.Data;
using System.Data.SqlClient;

namespace PH.Data.Repositories
{
    public class AlertRepository : IAlertRepository
    {
        private string _sQLConnectionString;
        private readonly IConfiguration _configuration;

        public AlertRepository(IConfiguration configuration)
        {
            _configuration = configuration;
            _sQLConnectionString = _configuration.GetConnectionString("SQLConnectionString");
        }

        public async Task<AlertMainDTO> Get(long idCompany, long idPriceGroup)
        {
            AlertMainDTO mainDTO = new AlertMainDTO();
            mainDTO.MarginCard = await GerarAlertaPorcentagem("Margem", "VEM_Alerta_Margem", idCompany, idPriceGroup);
            mainDTO.ProfitVariation = await GerarAlertaPorcentagem("Variação de Lucro", "VEM_Alerta_Variação_De_Lucro", idCompany, idPriceGroup);
            //mainDTO.PsicologyPriceCard = new AlertDTO("Preço psicológico");
            mainDTO.CompetitorPriceCard = await GerarAlertaPorcentagem("Preço concorrente", "VEM_Alerta_Preco_Concorrente", idCompany, idPriceGroup);

            return mainDTO;
        }

        private async Task<AlertDTO> GerarAlertaPorcentagem(string nome, string storedProcedure, long idCompany , long idPriceGroup)
        {
            AlertDTO alert = new AlertDTO(nome);

            try
            {
                IDbConnection connection = CreateSqlConnection();
                var parametros = new { IDCOMPANY = idCompany , IDPRICEGROUP = idPriceGroup };
                var result = connection.Query<AlertProductDTO>(storedProcedure, parametros, commandType: CommandType.StoredProcedure, commandTimeout: 6000);

                if (result != null && result.Any())
                {
                    alert.CardValue = result.Count();
                    alert.Products = result.ToList();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return alert;
        }

        private IDbConnection CreateSqlConnection() => new SqlConnection(_sQLConnectionString);
    }
}