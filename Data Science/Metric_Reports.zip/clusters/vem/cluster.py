"""
Script para gerar clusters de filiais da VEM (2024-03-13)
a partir de dados gerados pelo script prepare_data.
Registrado para arquivamento.
"""
# %%

# pylint: disable=W0106

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from plotnine import *
from scipy.stats import boxcox
from sklearn.cluster import KMeans
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from yellowbrick.cluster import KElbowVisualizer

# %%

df_affiliates = pd.read_parquet("./affiliate_data.parquet")

# %%

col_mapping = {
    "quantity": "Demanda",
    "revenue": "Receita",
    "total_cost": "Custo Total",
    "margin": "Margem Bruta",
    "profit": "Lucro Bruto",
    "adj_margin": "Margem Bruta Ajustada",
}

# %%

df_vem = pd.read_excel("BR_MANIA_ATIVAS_BASE_FEV24.xlsx")
df_vem_clusters = df_vem[["ZBRM", "CLUSTER"]].copy()
df_vem_clusters["CLUSTER"] = (
    df_vem_clusters["CLUSTER"].astype(str).apply(lambda x: x.split(".")[0])
)
df_vem_clusters = df_vem_clusters[df_vem_clusters["CLUSTER"] != "nan"]
df_vem_clusters = df_vem_clusters.rename(
    columns={"ZBRM": "zbrm", "CLUSTER": "vem_cluster"}
)
df_vem_clusters["zbrm"] = df_vem_clusters["zbrm"].astype(str)
df_vem_clusters.head()
# %%

df_affiliates["case"] = df_affiliates["zbrm"].isin(
    {
        "303645",
        "303341",
        "308058",
        "300173",
        "300596",
    }
)

# %%

(
    ggplot(df_affiliates, aes(x="quantity", y="profit"))
    + geom_point()
    + facet_wrap("case")
)

# %%

(
    ggplot(df_affiliates, aes(x="quantity", y="revenue"))
    + geom_point()
    + facet_wrap("case")
)

# %%

(
    ggplot(df_affiliates, aes(x="quantity", y="revenue"))
    + geom_point()
    + facet_wrap("case")
)

# %%

(
    ggplot(df_affiliates, aes(x="revenue", y="profit"))
    + geom_point()
    + facet_wrap("case")
)

# %%

(
    ggplot(df_affiliates, aes(x="TABACO", y="PADARIA"))
    + geom_point()
    + facet_wrap("case")
)

# %%

(
    ggplot(df_affiliates, aes(x="revenue", y="quantity"))
    + geom_point(aes(colour="margin"))
    + facet_wrap("case")
)

# %%

(
    ggplot(df_affiliates, aes(x="revenue", y="quantity"))
    + geom_point(aes(colour="profit"))
    + facet_wrap("case")
)

# %%


def create_model(n_clusters: int, random_state: int = 42) -> Pipeline:
    return Pipeline(
        [
            ("scaler", StandardScaler()),
            ("cluster", KMeans(n_clusters=n_clusters, random_state=random_state)),
        ]
    )


# %%


def elbow_method(df, target, create_model_fn):
    inertia_score = []

    for i in range(1, 11):
        pipeline = create_model_fn(i)
        pipeline.fit(df[[i for i in target]])
        inertia_score.append(pipeline[-1].inertia_)

    # Plot the elbow curve using silhouette scores
    plt.plot(range(1, 11), inertia_score)
    plt.title("Elbow Curve for K-Means Clustering")
    plt.xlabel("Number of Clusters")
    plt.ylabel("Inertia Score")
    plt.show()


# %%

df_prepared = df_affiliates[
    [
        "quantity",
        "revenue",
        "total_cost",
        "profit",
        "zbrm",
        "adj_margin",
        "pbcost_pct",
        "margin",
        "case",
        "pbcost_count",
        "FILTROS",
        "OLEOS",
        "MERCEARIA",
        "BEBIDAS ALCOOLICAS",
        "TABACO",
        "BEBIDAS NAO ALCOOLICAS",
        "BOMBONIERE",
        "FLUIDOS",
        "BAZAR AUTOMOTIVO",
        "BAZAR",
        "OUTROS",
        "BISCOITOS e SNACKS",
        "PADARIA",
        "CONGELADOS",
        "NÃO VINCULADO",
        "FOOD SERVICE",
        "PISTA",
        "ISENTOS",
    ]
].copy()

print(df_prepared.shape)
print(df_prepared.shape)
df_prepared.head()
df_prepared["has_cost"] = (df_prepared["pbcost_count"] != 0).astype(int)
# %%

X = df_prepared[
    [
        "quantity",
        "revenue",
        "total_cost",
        "profit",
        "adj_margin",
    ]
].copy()

sns.histplot(X, x="revenue")
plt.show()

# %%
for col in ("quantity", "revenue", "total_cost", "profit"):
    out = boxcox(1 + X[col])
    print(out[1])
    X[col] = out[0]
# %%

sns.histplot(X, x="revenue")
plt.show()

# %%

model = create_model(2)
# %%

X_scaled = model[0].fit_transform(X)
X_scaled = model[1].fit_transform(X)
# %%
visualizar = KElbowVisualizer(model[-1], k=range(1, 10))
visualizar.fit(X_scaled)
visualizar.show()
# %%
model = create_model(4)

model = model.fit(X[X["adj_margin"] < 1])  # XXX
df_prepared["cluster"] = (1 + model.predict(X)).astype(str)

df_prepared["case_zbrm"] = df_prepared["zbrm"].copy()
df_prepared.loc[~df_prepared["case"], "case_zbrm"] = ""

df_prepared["is_case"] = "Geral"
df_prepared.loc[df_prepared["case"], "is_case"] = "Case"
# %%

df_prepared[df_prepared["case"]]
# %%


def plot_clusters(df: pd.DataFrame, x: str, y: str, log_x=False, log_y=False):
    plot = (
        ggplot(df, aes(x=x, y=y))
        + geom_point(aes(fill="cluster"))
        + geom_text(
            mapping=aes(label="case_zbrm"),
            size=10,
            nudge_x=0.1,
            nudge_y=0.1,
            adjust_text={
                "time_lim": 1,
                "force_text": (0.5, 0.5),
                "expand": (5, 5),
                "lw": 0.5,
                "arrowprops": {"arrowstyle": "->", "color": "black"},
            },
        )
        + facet_wrap("is_case")
        + theme(figure_size=(9, 5))
        + ylab(col_mapping.get(y, y))
        + xlab(col_mapping.get(x, x))
    )
    if log_x:
        plot += scale_x_log10()
    if log_y:
        plot += scale_y_log10()
    return plot


# %%
plot = plot_clusters(df_prepared, "revenue", "quantity")
plot.draw()

# %%

plot = plot_clusters(df_prepared, "revenue", "profit")
plot.draw()

# %%

plot = plot_clusters(df_prepared, "revenue", "adj_margin", log_x=True)
plot.draw()

# %%

plot = plot_clusters(df_prepared, "revenue", "margin", log_x=True)
plot.draw()

# %%

plot = plot_clusters(df_prepared, "profit", "adj_margin", log_x=True)
plot.draw()

# %%

print(df_prepared.shape)
df_compare_cluster = pd.merge(df_prepared, df_vem_clusters, on="zbrm", how="inner")
print(df_compare_cluster.shape)
# %%

df_cluster_count = (
    df_compare_cluster.groupby("cluster")["quantity"]
    .count()
    .reset_index()
    .rename(columns={"quantity": "cluster_count"})
)
df_vem_cluster_count = (
    df_compare_cluster.groupby(["cluster", "vem_cluster"])["quantity"]
    .count()
    .reset_index()
    .rename(columns={"quantity": "vem_cluster_count"})
)
df_cluster_prop = pd.merge(df_cluster_count, df_vem_cluster_count, on="cluster")
df_cluster_prop.head()
df_cluster_prop["prop"] = (
    df_cluster_prop["vem_cluster_count"] / df_cluster_prop["cluster_count"]
)
df_cluster_prop.head()
# %%

(
    ggplot(df_cluster_prop, aes(x="cluster", y="prop", fill="vem_cluster"))
    + geom_bar(stat="identity", colour="black")
    + ylab("Proporção")
    + xlab("Cluster")
    + scale_fill_discrete(name="Cluster VEM")
)

# %%
df_cluster_count = (
    df_compare_cluster.groupby("vem_cluster")["quantity"]
    .count()
    .reset_index()
    .rename(columns={"quantity": "vem_cluster_count"})
)
df_vem_cluster_count = (
    df_compare_cluster.groupby(["cluster", "vem_cluster"])["quantity"]
    .count()
    .reset_index()
    .rename(columns={"quantity": "cluster_count"})
)
df_cluster_prop = pd.merge(df_cluster_count, df_vem_cluster_count, on="vem_cluster")
df_cluster_prop.head()
df_cluster_prop["prop"] = (
    df_cluster_prop["cluster_count"] / df_cluster_prop["vem_cluster_count"]
)
df_cluster_prop.head()
# %%

(
    ggplot(df_cluster_prop, aes(x="vem_cluster", y="prop", fill="cluster"))
    + geom_bar(stat="identity", colour="black")
    + ylab("Proporção")
    + xlab("Cluster VEM")
    + scale_fill_discrete(name="Cluster")
)
# %%

df_compare_cluster[df_compare_cluster["case"]]
# %%

df_agg = (
    df_prepared.groupby("cluster")[
        [
            "revenue",
            "quantity",
            "total_cost",
            "profit",
        ]
    ]
    .agg(["min", "max", "mean", "median"])
    .reset_index()
)
# %%

df_agg.to_excel("agg.xlsx")
df_agg.head()
# %%

df_agg = (
    df_prepared[df_prepared["has_cost"] == 1]
    .groupby("cluster")[
        [
            "margin",
            "adj_margin",
        ]
    ]
    .agg(["min", "max", "mean", "median"])
    .reset_index()
)
# %%

df_agg.to_excel("agg_margin.xlsx")
df_agg.head()
# %%

df_prepared.groupby("cluster")[
    ["revenue", "quantity", "total_cost", "margin", "adj_margin"]
].quantile(0.75).to_excel("q3.xlsx")

# %%

df_prepared.groupby("cluster")[
    ["revenue", "quantity", "total_cost", "margin", "adj_margin"]
].quantile(0.25).to_excel("q1.xlsx")

# %%

# %%


def plot_cluster_limits(df: pd.DataFrame, col: str):
    df_lims = df.groupby("cluster")[col].agg(["min", "mean", "max"]).reset_index()

    return (
        ggplot(df_lims, aes(x="cluster", y="mean"))
        + geom_violin(df, aes(x="cluster", y=col, fill="cluster"), alpha=0.1)
        + geom_pointrange(mapping=aes(ymin="min", ymax="max", fill="cluster"))
        + ylab(col_mapping.get(col, col))
        + xlab("Cluster")
        + theme_bw()
    )


# %%
plot_cluster_limits(df_prepared, "quantity")
# %%
plot_cluster_limits(df_prepared, "adj_margin")
# %%
plot_cluster_limits(df_prepared, "margin")
# %%
plot_cluster_limits(df_prepared, "total_cost")
# %%
plot_cluster_limits(df_prepared, "revenue")
# %%
plot_cluster_limits(df_prepared, "profit")
# %%
df_prepared_with_cost = df_prepared[df_prepared["has_cost"] == 1]
# %%
plot_cluster_limits(df_prepared_with_cost, "quantity")
# %%
plot_cluster_limits(df_prepared_with_cost, "adj_margin")
# %%
plot_cluster_limits(df_prepared_with_cost, "margin")
# %%
plot_cluster_limits(df_prepared_with_cost, "total_cost")
# %%
plot_cluster_limits(df_prepared_with_cost, "revenue")
# %%
plot_cluster_limits(df_prepared_with_cost, "profit")
# %%

df_out = pd.merge(df_prepared, df_vem_clusters, on="zbrm", how="outer")
df_out.head()

# %%
df_out.to_excel("clusters.xlsx", float_format="%.2f", index=False)
# %%
