from typing import Optional

import pandas as pd
from sqlalchemy import MetaData, Table, select

from src.db import PostgreSQLConnection
from src.logger import logger

DEFAULT_SALE_PRICE_COLUMN = "SalePrice"


def get_sale_price_column(
    pg_conn: PostgreSQLConnection, metadata: MetaData, id_company: int
) -> str:
    logger.debug("getting sale_price column name for id_company %d", id_company)
    table_config = Table("ImpactReportConfiguration", metadata, autoload_with=pg_conn)
    stmt = select(table_config.c.PriceVariableToCalc).where(
        table_config.c.CompanyId == id_company
    )
    result = pg_conn.execute(stmt).fetchone()
    if not result:
        logger.warning("no configuration found for id_company %d", id_company)
        return DEFAULT_SALE_PRICE_COLUMN

    column = result[0]
    logger.debug(
        "found sale_price column name %s for id_company %d", column, id_company
    )
    column = DEFAULT_SALE_PRICE_COLUMN if not column else column
    return column


def build_product_id(df: pd.DataFrame, granularity: list[str]) -> Optional[pd.Series]:
    if not granularity:
        return None

    if df.empty:
        return None

    product_id = df[granularity].fillna("").agg("||".join, axis=1)
    return product_id


def get_royalty(
    pg_conn: PostgreSQLConnection, metadata: MetaData, id_company: int
) -> Optional[float]:
    logger.debug("getting royalty for id_company %d", id_company)
    table_config = Table("ImpactReportConfiguration", metadata, autoload_with=pg_conn)
    stmt = select(table_config.c.Royalty).where(table_config.c.CompanyId == id_company)
    result = pg_conn.execute(stmt).fetchone()
    if not result:
        logger.warning("no configuration found for id_company %d", id_company)
        return None

    royalty = float(result[0])
    logger.debug("found royalty %s for id_company %d", royalty, id_company)
    return royalty
