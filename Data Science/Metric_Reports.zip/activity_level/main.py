"""
Cria uma planilha XLSX a partir das informações de nível de atividade de uma empresa
com dados de venda agregados por dia.
"""

import argparse
import warnings
from datetime import datetime

from geral.config import getDadosAWSSession
from utils import (
    activity_level_pivot,
    activity_level_sheet,
    save_excel,
    remove_missing_granularity,
    reorder_pivot_columns,
)


def main():
    parser = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    parser.add_argument("--env", required=True, choices=["producao", "preproducao"])
    parser.add_argument("--id-company", type=int, required=True)
    parser.add_argument(
        "--day-lookback",
        type=int,
        default=30,
        help="período retroativo a ser considerado",
    )
    parser.add_argument(
        "--prod-id", type=str, required=True, help="coluna identificadora de um produto"
    )
    parser.add_argument(
        "--granularity",
        type=str,
        nargs="+",
        required=True,
        help=(
            "colunas da granularidade sem a coluna --prod-id, "
            "na mesma ordem usada para calcular o nível de atividade ao salvar no banco"
        ),
    )
    args = parser.parse_args()

    warnings.simplefilter(action="ignore", category=UserWarning)
    conn = getDadosAWSSession(args.env)

    print("getting activity level data")
    al_sheet = activity_level_sheet(
        conn, args.id_company, [args.prod_id, *args.granularity]
    )

    print("getting daily sales data")
    pivot_sheet = activity_level_pivot(
        conn, args.id_company, args.day_lookback, args.prod_id, args.granularity
    )

    pivot_sheet = remove_missing_granularity(pivot_sheet, al_sheet, args.granularity)

    pivot_sheet = reorder_pivot_columns(pivot_sheet, args.granularity)

    fname = (
        f"activity_level_{args.id_company}_{datetime.now().strftime('%Y-%m-%d')}.xlsx"
    )
    print(f"saving to {fname}")
    save_excel(fname, al_sheet, pivot_sheet)


if __name__ == "__main__":
    main()
