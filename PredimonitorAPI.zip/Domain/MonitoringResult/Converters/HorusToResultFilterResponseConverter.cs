﻿using AutoMapper;
using Domain.MonitoringResult.Models;
using Repository.Entity;
using Repository.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.MonitoringResult.Converters
{
    public class HorusToResultFilterResponseConverter : ITypeConverter<HorusProductsEntity, ResultFilterResponse>
    {
        public ResultFilterResponse Convert(HorusProductsEntity source, ResultFilterResponse destination, ResolutionContext context)
        {
            var dest = new ResultFilterResponse()
            {
                ProductName = source.Description,
                ProductLink = source.Hash,
                ProductBrand = source.ProductBrand,
                SellerName = source.Brand,
                Marketplace = (string)context.Items["CrawlerName"],
                Price = source.Price,
                PaymentType = "-",
                Price_unit_type = PriceUnitType.UNITARIO,
                CrawlerDate = source.Date,
                Disregarded = false,               
                IdCrawler = (int)context.Items["CrawlerId"],
                Format_market = source.FormatMarket,
                City = source.City,               
                On_request = false,              
                State = source.Uf,
                Coordinates = source.Coordinates == null ? null : new PrediMonitorProduct_CoordinatesModel()
                {
                    Longitude = (decimal)source.Coordinates.Coordinates[0],
                    Latitude = (decimal)source.Coordinates.Coordinates[1],
                },
            };

            return dest;
        }
    }
}
