﻿using DI.Repository.Attributes;
using DI.Repository.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DI.Repository.TypeConfiguration
{
    [UseSQLContext]
    public class EnterpriseElasticityNewTypeConfiguration : TypeConfigurationBase<EnterpriseElasticityNewEntity>, IEntityTypeConfiguration<EnterpriseElasticityNewEntity>
    {
        public override void Configure(EntityTypeBuilder<EnterpriseElasticityNewEntity> builder)
        {
            ConfigureTableName(builder, "Enterprise_ElasticityNew");
            builder.ToTable("Enterprise_ElasticityNew", table => table.ExcludeFromMigrations());
            builder.HasKey(x => x.Enterprise_ElasticityNewId);
            builder.Ignore(x => x.Id);
            builder.Ignore(x => x.UpdatedDate);
            builder.Ignore(x => x.CreatedDate);
            builder.Property(x => x.Enterprise_ElasticityNewId).HasColumnName("IdEnterprise_ElasticityNew");
            builder.Property(x => x.CompanyId).HasColumnName("IdCompany");
            builder.Property(x => x.EnterpriseAIConfigurationId).HasColumnName("IdEnterpriseAIConfiguration");
        }
    }
}
