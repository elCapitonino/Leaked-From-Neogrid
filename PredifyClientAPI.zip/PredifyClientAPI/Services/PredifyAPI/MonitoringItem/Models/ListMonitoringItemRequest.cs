﻿using PredifyClientAPI.Services.PredifyAPI.Models;
using System.ComponentModel;

namespace PredifyClientAPI.Services.PredifyAPI.MonitoringItem.Models
{
    /// <summary>
    /// Modelo de requisição para listagem de items de monitoramento de uma empresa
    /// </summary>
    public class ListMonitoringItemRequest : AccessBase
    {
        public long? IdMonitoringGroup { get; set; } = null;

        /// <summary>
        /// Será incluido no resultado informações de lead atrelado ao item de monitoramento caso exista
        /// </summary>
        [DefaultValue(false)]
        public bool IncludeLeadInfo { get; set; } = false;

        /// <summary>
        /// Será incluido no resultado informações de Config atrelado ao item de monitoramento caso exista
        /// </summary>
        [DefaultValue(true)]
        public bool IncludeConfigInfo { get; set; } = true;

        /// <summary>
        /// data de restrição para itens adicionados iniciandos em um periodo
        /// </summary>
        public DateTime? MonitoringItemCreateStartDate { get; set; } = null;

        /// <summary>
        /// uma data de restrição para itens adicionados limitados a um periodo
        /// </summary>
        public DateTime? MonitoringItemCreateEndDate { get; set; } = null;

        /// <summary>
        /// caso true será retornado apenas os items de monitoramento e configurações
        /// para serem consultados pelos crawlers em sua proxima consulta
        /// </summary>
        [DefaultValue(false)]
        public bool OnlyForSearch { get; set; } = false;

        /// <summary>
        /// Irá retornar apenas aqueles que possuem lead atrelado
        /// </summary>
        [DefaultValue(false)]
        public bool OnlyWithLead { get; set; } = false;

        /// <summary>
        /// Ira incluir os grupo do item de monitoramento
        /// </summary>
        [DefaultValue(false)]
        public bool IncludeGroupsInfo { get; set; } = false;

        /// <summary>
        /// Retorna apenas os itens de monitoramento que possuem configuração
        /// </summary>
        [DefaultValue(false)]
        public long? IdMonitoringBatch { get; set; } = null;
    }
}
