﻿using PH.Domain.DTO;

namespace PH.Domain.Interfaces.Services
{
    public interface IGraficoServices
    {
        Task<List<GraficoDTO>> Get(string? loja, string? curva, string? categoria);
        Task<List<GraficoReceitaDTO>> GetGraficoReceita(long idCompany, string? loja);
    }
}
