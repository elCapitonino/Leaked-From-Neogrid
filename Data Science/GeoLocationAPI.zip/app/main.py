import time

from fastapi import BackgroundTasks, FastAPI, Request
from fastapi.exceptions import HTTPException

from models.request import DiscoverRequest, GeosearchRequest
from models.response import DiscoverResult, GeosearchResult
from src.discover import Discover, discover_search
from src.external_search import here
from src.logger import logger
from src.mongo import (
    create_unique_address_index,
    get_async_mongo_connection,
    upsert_address_info,
    upsert_discover_info,
)
from src.search import GeoSearcher, search

app = FastAPI()


@app.on_event("startup")
def startup():
    logger.debug("starting up")
    try:
        app.state.mongo_conn = get_async_mongo_connection()
        app.state.here_searcher = GeoSearcher(
            mongo_conn=app.state.mongo_conn,
            remote_searcher=here.search_address,
            mock=False,
        )
        app.state.discover = Discover(
            mongo_conn=app.state.mongo_conn,
            remote_searcher=here.discover_place,
            mock=False,
        )
        app.state.mock_here_searcher = GeoSearcher(
            mongo_conn=app.state.mongo_conn,
            remote_searcher=here.mock_search_address,
            mock=True,
        )
    except Exception as exc:
        raise RuntimeError("startup failed") from exc


@app.get("/health")
async def health():
    return "OK"


@app.post("/geosearch")
async def geosearch(
    request: Request,
    bg_tasks: BackgroundTasks,
    body: GeosearchRequest,
) -> GeosearchResult:
    return await _geosearch(
        request, bg_tasks, body, searcher=request.app.state.here_searcher
    )


@app.post("/discover")
async def discover(request: Request, body: DiscoverRequest) -> DiscoverResult:
    return await _discover(request, body, searcher=request.app.state.discover)


@app.post("/mock_geosearch")
async def mock_geosearch(
    request: Request,
    bg_tasks: BackgroundTasks,
    body: GeosearchRequest,
) -> GeosearchResult:
    return await _geosearch(
        request, bg_tasks, body, searcher=request.app.state.mock_here_searcher
    )


@app.post("/create_unique_index")
async def create_unique_index(request: Request):
    await create_unique_address_index(request.app.state.mongo_conn)


async def _geosearch(
    request: Request,
    bg_tasks: BackgroundTasks,
    body: GeosearchRequest,
    searcher: GeoSearcher,
) -> GeosearchResult:
    init = time.perf_counter()
    try:
        out, address_info_coord = await search(
            searcher=searcher,
            input_address_info=body.address_info,
            use_cache=body.use_cache,
        )
        if address_info_coord is not None:
            bg_tasks.add_task(
                upsert_address_info, request.app.state.mongo_conn, address_info_coord
            )

    except HTTPException as exc:
        raise exc
    except Exception as exc:
        msg = f"unexpected error of type {type(exc).__name__}: {exc}"
        logger.error(msg, exc_info=True)
        raise HTTPException(status_code=500, detail=msg) from exc
    logger.debug("request took %.2f ms", 1000 * (time.perf_counter() - init))
    return out


async def _discover(
    request: Request,
    body: DiscoverRequest,
    searcher: Discover,
) -> DiscoverResult:
    init = time.perf_counter()
    try:
        out = await discover_search(
            searcher=searcher,
            params=body,
            use_cache=body.use_cache,
        )
    except HTTPException as exc:
        raise exc
    except Exception as exc:
        msg = f"unexpected error of type {type(exc).__name__}: {exc}"
        logger.error(msg, exc_info=True)
        raise HTTPException(status_code=500, detail=msg) from exc
    logger.debug("request took %.2f ms", 1000 * (time.perf_counter() - init))
    return out
