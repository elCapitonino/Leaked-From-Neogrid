﻿using Microsoft.AspNetCore.Mvc;
using PH.Domain.Interfaces.Services;

namespace PH.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FiltersController : ControllerBase
    {
        private readonly ILogger<FiltersController> _logger;
        private readonly IFiltersServices _service;

        public FiltersController(ILogger<FiltersController> logger,
                                IFiltersServices service)
        {
            _logger = logger;
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            _logger.LogInformation("Controller: Buscando todos os Filterss");

            try
            {
                var recipes = await _service.Get();
                return Ok(recipes);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Controller: Erro ao buscar todos os Filterss. {ex.Message}");
                return StatusCode(500, "Erro ao buscar todos os Filterss");
            }
        }

    }
}
