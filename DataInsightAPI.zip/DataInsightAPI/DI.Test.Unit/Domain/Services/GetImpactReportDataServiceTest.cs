﻿using DI.Domain.Models.ImpactReport;
using DI.Domain.Services.Reports;
using DI.Domain.Utils;
using DI.Domain.ValueObjects;
using DI.Repository.Entities;
using DI.Repository.Enum;
using DI.Repository.Interfaces;
using DocumentFormat.OpenXml.Spreadsheet;
using Moq;

namespace DI.Test.Unit.Domain.Services
{
    public class GetImpactReportDataServiceTests
    {
        private readonly Mock<IUnitOfWork> _unitOfWork;


        private readonly GetImpactReportDataService _service;

        public GetImpactReportDataServiceTests()
        {
            _unitOfWork = new Mock<IUnitOfWork>();
            _service = new GetImpactReportDataService(_unitOfWork.Object);
        }

        [Fact]
        public async Task GenerateImpactReportData_ShouldReturnCorrectImpactReport()
        {
            // Arrange
            var model = new ImpactConsolidatedRequestModel
            {
                Affiliates = new List<Affiliates> { new Affiliates { Description = "Affiliate1", Value = "A1" } },
                PriceGroups = new List<DataPriceGroups> { new DataPriceGroups { Year = 2024, Month = 8, PriceGroupIds = new List<long> { 1, 2 } } },
                CompanyId = 123
            };

            var expectedImpactReportWorksheet = new ImpactReportWorksheet();

            var impactReportConfig = new ImpactReportConfigurationEntity { Goal = 1000, Royalty = 0.1m };

            _unitOfWork.Setup(uow => uow.ImpactReportConfigurationRepository.GetByCompanyId(It.IsAny<long>()))
                .Returns(impactReportConfig);

            _unitOfWork.Setup(uow => uow.MonthlyImpactDataRepository.GetAll(It.IsAny<long>(), It.IsAny<int>(), It.IsAny<MonthlyImpactDataType>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(new List<MonthlyImpactDataEntity>());

            _unitOfWork.Setup(uow => uow.EnterprisePriceGroupRepository.GetAllById(It.IsAny<IEnumerable<long>>()))
                .ReturnsAsync(new List<EnterprisePriceGroupEntity> { new EnterprisePriceGroupEntity { Name = "Group1" } });

            _unitOfWork.Setup(uow => uow.EnterprisePriceGroupRepository.GetByYearMonth(It.IsAny<DateTime>()))
                .ReturnsAsync(new List<EnterprisePriceGroupEntity> { new EnterprisePriceGroupEntity { Name = "Group2" } });

            _unitOfWork.Setup(uow => uow.GrupoRecursosRepository.GetHierarchyUserById(It.IsAny<long>(), It.IsAny<string>()))
                .Returns("Gerente");

            _unitOfWork.Setup(x => x.MonthlySaleHistoryDataRepository.GetCountSkus(It.IsAny<long>(),
                It.IsAny<EGranularityType>(),
                It.IsAny<IEnumerable<string>>(),
                It.IsAny<CancellationToken>()))
                .ReturnsAsync(10);

            // Act
            var result = await _service.GenerateImpactReportData(model, CancellationToken.None, String.Empty);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(1, result.ImpactPreDataConsolidateds.Count(x => x.WorkSheetName == "Impacto agosto"));
            Assert.Equal(1, result.ImpactPreDataConsolidateds.Count(x => x.WorkSheetName == "Impacto Geral agosto"));
            Assert.Equal(1, result.ImpactPreDataConsolidateds.Count(x => x.WorkSheetName == "Impacto Adotados agosto"));
            Assert.Equal(1, result.ImpactPreDataConsolidateds.Count(x => x.WorkSheetName == "Impacto Aprovados agosto"));
            Assert.Equal(1, result.ImpactPreDataConsolidateds.Count(x => x.WorkSheetName == "Impacto Precificados agosto"));
            Assert.Equal(1, result.ImpactPreDataConsolidateds.Count(x => x.GroupName == "Group2"));
            Assert.Equal(4, result.ImpactPreDataConsolidateds.Count(x => x.GroupName == "Group1"));
        }

        [Fact]
        public void GetAddicionalRoyalty_ShouldCalculateRoyaltyDifferenceCorrectly()
        {
            // Arrange
            var yearMonth = new YearMonth(2024, 8);
            var companyId = 123;
            var mockSalesData = new List<MonthlySaleHistoryDataEntity>
            {
                new MonthlySaleHistoryDataEntity() { CompanyId = 3026, YearMonth = yearMonth.Value, RoyaltyReal = 100 },
                new MonthlySaleHistoryDataEntity() { CompanyId = 3026, YearMonth = yearMonth.AddMonths(-1).Value, RoyaltyReal = 50 }
            };

            _unitOfWork.Setup(uow => uow.MonthlySaleHistoryDataRepository.GetAll(companyId, yearMonth.AddMonths(-1).Value, yearMonth.Value, EGranularityType.ImpactConsolidateReport))
                .Returns(mockSalesData.AsQueryable());

            // Act
            var result = _service.GetAddicionalRoyalty(yearMonth, companyId, EGranularityType.ImpactConsolidateReport);

            // Assert
            Assert.Equal(50, result);
        }


        [Fact]
        public void GenerateRevenueDataTable_ShouldReturnCorrectImpactReportTable()
        {
            // Arrange
            var impactData = new List<ImpactPreDataConsolidatedData>
            {
                new ImpactPreDataConsolidatedData
                {
                    Value = "Category1",
                    RevenueBefore = 100,
                    RevenueProjection = 120,
                    RevenueAfter = 110
                }
            };

            // Act
            var result = _service.GenerateRevenueDataTable(impactData);

            // Assert
            Assert.NotNull(result);
            Assert.Equal("RECEITA", result.Header);
            Assert.Equal(2, result.Lines.Count());
            Assert.Equal("Total", result.Lines.Last().Value);
            Assert.Equal("Category1", result.Lines.First().Value);
        }

        [Fact]
        public void GenerateDemandDataTable_ShouldReturnCorrectImpactReportTable()
        {
            // Arrange
            var impactData = new List<ImpactPreDataConsolidatedData>
            {
                new ImpactPreDataConsolidatedData
                {
                    Value = "Category1",
                    DemandBefore = 100,
                    DemandProjection = 120,
                    DemandAfter = 110
                }
            };

            // Act
            var result = GetImpactReportDataService.GenerateDemandDataTable(impactData);

            // Assert
            Assert.NotNull(result);
            Assert.Equal("DEMANDA", result.Header);
            Assert.Equal(2, result.Lines.Count());
            Assert.Equal("Total", result.Lines.Last().Value);
            Assert.Equal("Category1", result.Lines.First().Value);
        }

        [Fact]
        public void GenerateProfitDataTable_ShouldReturnCorrectImpactReportTable()
        {
            // Arrange
            var impactData = new List<ImpactPreDataConsolidatedData>
            {
                new ImpactPreDataConsolidatedData
                {
                    Value = "Category1",
                    ProfitBefore = 50,
                    ProfitProjection = 60,
                    ProfitAfter = 55
                }
            };

            // Act
            var result = _service.GenerateProfitDataTable(impactData);

            // Assert
            Assert.NotNull(result);
            Assert.Equal("LUCRO BRUTO", result.Header);
            Assert.Equal(2, result.Lines.Count());
            Assert.Equal("Total", result.Lines.Last().Value);
            Assert.Equal("Category1", result.Lines.First().Value);
        }

        [Fact]
        public void GenerateMarginDataTable_ShouldReturnCorrectImpactReportTable()
        {
            // Arrange
            var impactData = new List<ImpactPreDataConsolidatedData>
            {
                new ImpactPreDataConsolidatedData
                {
                    Value = "Category1",
                    RevenueBefore = 100,
                    ProfitBefore = 50,
                    RevenueProjection = 120,
                    ProfitProjection = 60,
                    RevenueAfter = 110,
                    ProfitAfter = 55
                }
            };

            // Act
            var result = GetImpactReportDataService.GenerateMarginDataTable(impactData);

            // Assert
            Assert.NotNull(result);
            Assert.Equal("MARGEM BRUTA", result.Header);
            Assert.Equal(2, result.Lines.Count());
            Assert.Equal("Total", result.Lines.Last().Value);
            Assert.Equal("Category1", result.Lines.First().Value);
        }


        [Fact]
        public void GenerateRoyaltyDataTable_ShouldReturnCorrectImpactReportTable()
        {
            // Arrange
            var impactData = new List<ImpactPreDataConsolidatedData>
            {
                new ImpactPreDataConsolidatedData
                {
                    Value = "Category1",
                    RevenueBefore = 100,
                    RevenueAfter = 110
                }
            };

            var impactReportConfig = new ImpactReportConfigurationEntity { Goal = 1000, Royalty = 0.1m };

            _unitOfWork.Setup(x => x.MonthlySaleHistoryDataRepository.GetAll(It.IsAny<long>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<EGranularityType>()))
                .Returns(new List<MonthlySaleHistoryDataEntity>());

            // Act
            var result = _service.GenerateRoyaltyDataTable(impactData, new List<Affiliates>(), new YearMonth(2024, 8), impactReportConfig, 0);

            // Assert
            Assert.NotNull(result);
            Assert.Equal("ROYALTY", result.Header);
            Assert.Equal(2, result.Lines.Count());
            Assert.Equal("Total", result.Lines.Last().Value);
            Assert.Equal("Category1", result.Lines.First().Value);
        }


    }
}
