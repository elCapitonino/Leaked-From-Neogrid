using AutoMapper;
using Domain.CompanyMonitoringCrawler;
using Domain.MonitoringResult.Models;
using Domain.Utils;
using MathNet.Numerics.Statistics;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using MongoDB.Driver;
using Repository.Entity;
using Repository.Enums;
using Repository.UnitOfWork;
using Services.PredifyAPI;
using Services.SearchAPI.Models;
using System.Collections.Concurrent;
using System.Data;
using System.Diagnostics;

namespace Domain.MonitoringResult
{
    public class MonitoringResultDomain : IMonitoringResultDomain
    {
        private readonly ILogger<MonitoringResultDomain> _logger;
        private readonly IUnitOfWork _uow;
        private readonly IMapper _mapper;
        private readonly IMemoryCache _cache;
        private readonly ICompanyMonitoringCrawlerDomain _companyMonitoringCrawlerDomain;
        private readonly PredifyAPISystemManager _predify;
        private const int _pageSize = 2000;

        public MonitoringResultDomain(ILogger<MonitoringResultDomain> logger, IUnitOfWork uow, IMapper mapper, IMemoryCache cache, ICompanyMonitoringCrawlerDomain companyMonitoringCrawlerDomain)
        {
            _logger = logger;
            _uow = uow;
            _mapper = mapper;
            _cache = cache;
            _companyMonitoringCrawlerDomain = companyMonitoringCrawlerDomain;
        }

        public async Task<DynamicFilterResponse> GetMonitoringResultFilteredData(long companyId, DynamicFilterRequest request)
        {
            //TODO: Analisar e remover se não for necessário
            //if (_cache.TryGetValue(GetDynamicFilterCacheKey(request, companyId), out DynamicFilterResponse? result) && result != null && result.Products.Count() > 0)
            //{
            //    return result;
            //}

            DynamicFilterResponse? result = null;

            if (!_cache.TryGetValue($"companyCrawler_{companyId}_{request.IsCost}", out Dictionary<int, string> crawlers))
            {
                crawlers = await _uow.CompanyMonitoringCrawler.GetAll()
                                         .Where(x => x.CompanyId == companyId && !x.IsDeleted && (request.IsCost ? x.IsCost : x.IsSale))
                                         .Select(x => new { x.MonitoringCrawlerId, x.MonitoringCrawler.Description })
                                         .Distinct()
                                         .ToDictionaryAsync(k => k.MonitoringCrawlerId, v => v.Description);


                _cache.Set($"companyCrawler_{companyId}_{request.IsCost}", crawlers, new MemoryCacheEntryOptions() { AbsoluteExpiration = DateTimeOffset.Now.AddHours(2), SlidingExpiration = TimeSpan.FromMinutes(30) });
            }

            FixNamingReverso(request);

            var companyCrawlersIds = crawlers.Keys.Distinct().ToHashSet();

            result = new DynamicFilterResponse
            {
                Products = (await _uow.MonitoringItemResults.GetAll()
                   .ApplyFilters(request, companyId, RequestFilterType.Product)
                   .Where(x => companyCrawlersIds.Contains(x.CrawlerId))
                   .GroupBy(x => x.MonitoringItemId)
                   .Select(x => new { ProductName = x.First().MonitoringItem.Description, MonitoringItemId = x.Key })
                   .ToListAsync())
                   .OrderBy(x => x.ProductName)
                   .Select(r => new ProductData
                   {
                       ProductName = r.ProductName ?? "N/A",
                       IdMonitoringItem = r.MonitoringItemId,
                       Selected = (request.MonitoringItemIds != null && request.MonitoringItemIds.Contains(r.MonitoringItemId)) ||
                                    (request.ProductNames != null && request.ProductNames.Any(y => y.Equals(r.ProductName, StringComparison.InvariantCultureIgnoreCase)))
                   }),

                Categories = (await _uow.MonitoringItemResults.GetAll()
                   .ApplyFilters(request, companyId, RequestFilterType.Category)
                   .Where(x => companyCrawlersIds.Contains(x.CrawlerId))
                   .Select(r => r.Category)
                   .Distinct()
                   .ToListAsync()).Order().Where(r => !string.IsNullOrEmpty(r)),

                Sellers = (await _uow.MonitoringItemResults.GetAll()
                   .ApplyFilters(request, companyId, RequestFilterType.Seller)
                   .Where(x => companyCrawlersIds.Contains(x.CrawlerId))
                   .Select(r => r.Seller)
                   .Distinct()
                   .ToListAsync()).Order().Where(r => !string.IsNullOrEmpty(r)),

                Brands = (await _uow.MonitoringItemResults.GetAll()
                   .ApplyFilters(request, companyId, RequestFilterType.Brand)
                   .Where(x => companyCrawlersIds.Contains(x.CrawlerId))
                   .Select(r => r.Brand)
                   .Distinct()
                  .ToListAsync()).Order().Where(r => !string.IsNullOrEmpty(r)),

                States = (await _uow.MonitoringItemResults.GetAll()
                   .ApplyFilters(request, companyId, RequestFilterType.State)
                   .Where(x => companyCrawlersIds.Contains(x.CrawlerId))
                   .Select(r => r.State)
                   .Distinct()
                   .ToListAsync()).Order().Where(r => !string.IsNullOrEmpty(r)),

                Years = (await _uow.MonitoringItemResults.GetAll()
                   .ApplyFilters(request, companyId, RequestFilterType.Year)
                   .Where(x => companyCrawlersIds.Contains(x.CrawlerId))
                   .Select(r => r.Year)
                   .Distinct()
                   .ToListAsync()).Order().Where(r => !string.IsNullOrEmpty(r)),

                Models = (await _uow.MonitoringItemResults.GetAll()
                   .ApplyFilters(request, companyId, RequestFilterType.Model)
                   .Where(x => companyCrawlersIds.Contains(x.CrawlerId))
                   .Select(r => r.Model)
                   .Distinct()
                   .ToListAsync()).Order().Where(r => !string.IsNullOrEmpty(r)),

                Origins = (await _uow.MonitoringItemResults.GetAll()
                    .ApplyFilters(request, companyId, RequestFilterType.Origin)
                    .Where(x => companyCrawlersIds.Contains(x.CrawlerId))
                    .Select(r => r.CrawlerId)
                    .Distinct()
                    .ToListAsync()).Order().Select(x => crawlers[x])
            };


            FixNaming(result);

            _cache.Set(GetDynamicFilterCacheKey(request, companyId), result, new MemoryCacheEntryOptions() { AbsoluteExpiration = DateTimeOffset.Now.AddMinutes(30), SlidingExpiration = TimeSpan.FromMinutes(10) });
            return result;

        }

        [Obsolete("Solução temporária permanente que irá ser removido em um futuro distante quando corrigir a base")]
        public void FixNaming(DynamicFilterResponse result)
        {
            //Categories
            if (result.Categories != null)
            {
                var categories = result.Categories.ToList();
                for (int i = 0; i < categories.Count; i++)
                {
                    if (NameFixDictionary.Categories.ContainsKey(categories[i]))
                        categories[i] = NameFixDictionary.Categories[categories[i]];
                }

                result.Categories = categories.Distinct().Order();
            }

            //Sellers
            if (result.Categories != null)
            {
                var sellers = result.Sellers.ToList();
                for (int i = 0; i < sellers.Count; i++)
                {
                    if (NameFixDictionary.Sellers.ContainsKey(sellers[i]))
                        sellers[i] = NameFixDictionary.Sellers[sellers[i]];
                }

                result.Sellers = sellers.Distinct().Order();
            }

            //Brands
            if (result.Categories != null)
            {
                var brands = result.Brands.ToList();
                for (int i = 0; i < brands.Count; i++)
                {
                    if (NameFixDictionary.Brands.ContainsKey(brands[i]))
                        brands[i] = NameFixDictionary.Brands[brands[i]];
                }

                result.Brands = brands.Distinct().Order();
            }
        }

        [Obsolete("Solução temporária permanente que irá ser removido em um futuro distante quando corrigir a base")]
        public void FixNamingReverso(DynamicFilterRequest request)
        {
            if (request.Categories != null)
            {
                var categories = request.Categories.ToList();
                for (int i = 0; i < categories.Count; i++)
                {
                    var cats = NameFixDictionary.Categories.Where(x => x.Value.Equals(categories[i])).Select(x => x.Key);

                    if (cats.Any())
                        request.Categories.AddRange(cats);
                }
            }

            if (request.Sellers != null)
            {
                var sellers = request.Sellers.ToList();
                for (int i = 0; i < sellers.Count; i++)
                {
                    var sel = NameFixDictionary.Sellers.Where(x => x.Value.Equals(sellers[i])).Select(x => x.Key);

                    if (sel.Any())
                        request.Sellers.AddRange(sel);
                }
            }

            if (request.Brands != null)
            {
                var brands = request.Brands.ToList();
                for (int i = 0; i < brands.Count; i++)
                {
                    var bras = NameFixDictionary.Brands.Where(x => x.Value.Equals(brands[i])).Select(x => x.Key);

                    if (bras.Any())
                        request.Brands.AddRange(bras);
                }
            }
        }

        [Obsolete("Solução temporária permanente que irá ser removido em um futuro distante quando corrigir a base")]
        public void FixNamingReverso(ResultFilterRequest request)
        {
            var categories = request.Categories.ToList();
            for (int i = 0; i < categories.Count; i++)
            {
                var cats = NameFixDictionary.Categories.Where(x => x.Value.Equals(categories[i])).Select(x => x.Key);

                if (cats.Any())
                    request.Categories.AddRange(cats);
            }

            var sellers = request.Sellers.ToList();
            for (int i = 0; i < sellers.Count; i++)
            {
                var sel = NameFixDictionary.Sellers.Where(x => x.Value.Equals(sellers[i])).Select(x => x.Key);

                if (sel.Any())
                    request.Sellers.AddRange(sel);
            }

            var brands = request.Brands.ToList();
            for (int i = 0; i < brands.Count; i++)
            {
                var bras = NameFixDictionary.Brands.Where(x => x.Value.Equals(brands[i])).Select(x => x.Key);

                if (bras.Any())
                    request.Brands.AddRange(bras);
            }
        }

        public async Task<IEnumerable<SeeResultResponse>> GetMonitoringItemResult(ResultFilterRequest request)
        {
            var companyCrawlers = await _companyMonitoringCrawlerDomain.GetCompanyMonitoringCrawler(request.CompanyId, request.IsCost);
            if (companyCrawlers == null || companyCrawlers.Count == 0)
            {
                throw new ArgumentException($"No crawlers found for company {request.CompanyId}");
            }

            var monitoringItems = _uow.MonitoringItem.GetAll()
                .Where(x => x.CompanyId == request.CompanyId && !x.IsDeleted);

            FixNamingReverso(request);

            var monitoringItemResultGroups = await GetMonitoringItemResult(request, companyCrawlers);

            var listResults = await GetDatas(monitoringItemResultGroups, request, monitoringItems, companyCrawlers);

            _logger.LogInformation($"Found {listResults.Count()} results for company {request.CompanyId}.");
            return GenerateSeeResultResponses(listResults, monitoringItems);
        }

        public async Task GenerateProductMarketResult(long companyId, DateTime? startDate = null, DateTime? endDate = null, DateTime? refDate = null, int skip = 0, bool? removeOlds = null, bool? removeOutliers = null)
        {
            try
            {
                _logger.LogInformation($"Iniciante generate cache for company {companyId}.");
                var config = await GetCompanyConfiguration(companyId);

                (startDate, endDate) = CalculateDateRange(startDate, endDate, config);

                refDate = GetReferenceDate(refDate);
                SwapDatesIfNeeded(ref startDate, ref endDate);

                if (config?.DisableCalculateMarketResult == true)
                {
                    _logger.LogInformation($"Market result calculation is disabled for company {companyId}.");
                    return;
                }

                removeOutliers = GetRemoveOutliersFlag(removeOutliers, config);
                removeOlds = GetRemoveOldsFlag(removeOlds, config);

                var companyCrawlers = await _companyMonitoringCrawlerDomain.GetCompanyMonitoringCrawler(companyId, false);

                if (companyCrawlers == null || !companyCrawlers.Any())
                {
                    throw new ArgumentException($"No crawlers found for company {companyId}");
                }

                var monitoringItems = _uow.MonitoringItem.GetAll()
                                         .Where(x => x.CompanyId == companyId && !x.IsDeleted);

                var monitoringItemIds = monitoringItems.Select(x => (long?)x.Id).ToList();

                if (removeOlds.Value)
                    await DeleteOlds(companyId);

                for (int i = 0; i < monitoringItemIds.Count; i += _pageSize)
                {
                    var monitoringItemIdsBatch = monitoringItemIds
                                                .Skip(i)
                                                .Take(_pageSize)
                                                .ToList();

                    var dynamicFilterRequest = new ResultFilterRequest
                    {
                        StartDate = startDate.Value,
                        EndDate = endDate.Value,
                        Sellers = new List<string?>(),
                        MonitoringItemIds = monitoringItemIdsBatch,
                        HourMeter = new ResultFilterHourmeterRangeRequest { Max = 0, Min = 0 }
                    };

                    var queryMonitoringResultItem = GetBaseQuery(companyId).ApplyFilters(dynamicFilterRequest, companyId);

                    var monitoringItemResultGroups = GroupMonitoringItemResults(queryMonitoringResultItem, companyCrawlers);

                    await ProcessMonitoringItemResults(monitoringItemResultGroups, monitoringItems, companyCrawlers, companyId, refDate, removeOutliers.Value, skip, dynamicFilterRequest);

                    _logger.LogInformation($"Generate cache for company {companyId} Total = {monitoringItemIds.Count} / Executed {i + _pageSize}.");
                }

                _logger.LogInformation($"Finilazing generate cache for company {companyId}.");

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"An error occurred while generating the product market result for company {companyId}.");
                throw;
            }
        }

        private (DateTime? startDate, DateTime? endDate) CalculateDateRange(DateTime? startDate, DateTime? endDate, CompanyConfigurationEntity? config)
        {
            if (config?.RangeDateMarketResult != null)
            {
                endDate = DateTime.Now;
                startDate = endDate.Value.AddDays((double)config?.RangeDateMarketResult).Date;
            }
            else
            {
                startDate = GetStartDate(startDate);
                endDate = GetEndDate(startDate, endDate);
            }

            return (startDate, endDate);
        }

        public static List<MonitoringProductMarketResultItemEntity> RemoveOutliers(List<MonitoringProductMarketResultItemEntity> list, double threshold = 1.5)
        {
            var arrayDouble = list.Where(x => x.OnRequest == false).Select(x => (double)x.Price).OrderBy(x => x).ToArray();

            double pct_25 = SortedArrayStatistics.LowerQuartile(arrayDouble);
            double pct_75 = SortedArrayStatistics.UpperQuartile(arrayDouble);
            var iqr = pct_75 - pct_25;

            decimal upperLimit = (decimal)(pct_75 + threshold * iqr);
            decimal lowerLimit = (decimal)(pct_25 - threshold * iqr);

            for (int i = 0; i < list.Count; i++)
            {
                if (list[i].OnRequest)
                    continue;

                if (list[i].Price > upperLimit || list[i].Price < lowerLimit)
                {
                    list.RemoveAt(i);
                    i--;
                }
            }

            return list;
        }

        private string GetDynamicFilterCacheKey(DynamicFilterRequest request, long companyId)
        {
            string JoinList(List<string?> list) =>
                    list != null && list.Any() ? string.Join(",", list.Where(item => !string.IsNullOrEmpty(item))) : "null";

            string JoinLongList(List<long?> list) =>
                list != null && list.Any() ? string.Join(",", list.Where(item => item.HasValue).Select(item => item.Value.ToString())) : "null";

            return $"DynamicFilter_{companyId}_" +
                   $"{JoinList(request.ProductNames)}_" +
                   $"{JoinList(request.States)}_" +
                   $"{JoinList(request.Brands)}_" +
                   $"{JoinList(request.Origins)}_" +
                   $"{JoinList(request.Categories)}_" +
                   $"{JoinLongList(request.MonitoringItemIds)}_" +
                   $"{JoinList(request.Sellers)}_" +
                   $"{request.IsCost}";
        }

        private IQueryable<MonitoringItemResultsEntity> GetBaseQuery(long companyId)
        {
            return _uow.MonitoringItemResults.GetAll()
                .Include(x => x.MonitoringItem)
                .Include(y => y.MonitoringCrawler)
                .Where(m => m.CompanyId == companyId);
        }

        private DynamicFilterResponse BuildResponse(IEnumerable<MonitoringItemResultsEntity> results)
        {
            var response = new DynamicFilterResponse
            {
                Products = results
                    .Select(r => new ProductData
                    {
                        ProductName = r.MonitoringItem?.Description ?? "N/A",
                        IdMonitoringItem = r.MonitoringItemId
                    })
                    .GroupBy(p => new { p.ProductName, p.IdMonitoringItem })
                    .Select(g => g.First())
                    .OrderBy(x => x.ProductName)
                    .ToList(),

                Categories = results
                    .Where(r => !string.IsNullOrEmpty(r.Category))
                    .Select(r => r.Category)
                    .Distinct()
                    .Order()
                    .ToList(),

                Sellers = results
                    .Where(r => !string.IsNullOrEmpty(r.Seller))
                    .Select(r => r.Seller)
                    .Distinct()
                    .Order()
                    .ToList(),

                Brands = results
                    .Where(r => !string.IsNullOrEmpty(r.Brand))
                    .Select(r => r.Brand)
                    .Distinct()
                    .Order()
                    .ToList(),

                States = results
                    .Where(r => !string.IsNullOrEmpty(r.State))
                    .Select(r => r.State)
                    .Distinct()
                    .Order()
                    .ToList(),

                Years = results
                    .Where(r => !string.IsNullOrEmpty(r.Year))
                    .Select(r => r.Year)
                    .Distinct()
                    .Order()
                    .ToList(),

                Origins = results
                    .Where(r => !string.IsNullOrEmpty(r.MonitoringCrawler?.Description))
                    .Select(r => r.MonitoringCrawler?.Description)
                    .Distinct()
                    .Order()
                    .ToList()
            };

            return response;
        }

        private async Task<IEnumerable<MonitoringItemResultModel>> GetMonitoringItemResult(ResultFilterRequest request, IEnumerable<CompanyMonitoringCrawlerEntity> companyCrawlers)
        {
            _logger.LogInformation("Getting monitoring item results for company {CompanyId}.", request.CompanyId);
            var queryMonitoringResultItem = GetBaseQuery(request.CompanyId)
                    .ApplyFilters(request, request.CompanyId);

            var companyCrawlersHashSet = companyCrawlers.Select(cc => cc.MonitoringCrawlerId).ToHashSet();
            return queryMonitoringResultItem
                .Where(x => companyCrawlersHashSet.Contains(x.CrawlerId))
                .Select(x => new { x.MonitoringItemId, x.MonitoringItem.Description, x.Hash, x.CrawlerId, Source = x.MonitoringCrawler.Source, CrawlerName = x.MonitoringCrawler.Description })
                .GroupBy(x => x.MonitoringItemId)
                .AsEnumerable()
                .SelectMany(g => g.Select(x => new MonitoringItemResultModel
                {
                    MonitoringItemId = x.MonitoringItemId,
                    Description = x.Description,
                    Hash = x.Hash,
                    CrawlerId = x.CrawlerId,
                    Source = x.Source,
                    CrawlerName = x.CrawlerName,
                }));
        }

        private IEnumerable<SeeResultResponse> GenerateSeeResultResponses(IEnumerable<ResultFilterResponse> listResults, IEnumerable<MonitoringItemEntity> monitoringItems)
        {
            if (listResults == null || !listResults.Any())
            {
                return Enumerable.Empty<SeeResultResponse>();
            }

            var monitoringItemDictionary = monitoringItems.ToDictionary(mi => mi.Id, mi => mi.Description);

            return listResults
                .GroupBy(x => x.MonitoringItemId)
                .Select(g => new SeeResultResponse
                {
                    ProductName = monitoringItemDictionary.TryGetValue(g.Key, out var productName) ? productName : "N/A",
                    ProductLink = null,
                    Ean = null,
                    Category = null,
                    Section = null,
                    AvgInfo_DateTime = g.Max(x => x.CrawlerDate),
                    MaxPrice = g.Max(x => x.Price),
                    AvgPrice = g.Average(x => x.Price),
                    MinPrice = g.Min(x => x.Price),
                    PriceCurrency = null,
                    IdMonitoringItem = g.Key,
                    PriceResults = g.ToList(),
                }).Where(x => x.ProductName != "N/A");
        }
        private async Task<IEnumerable<ResultFilterResponse>> GetDatas(IEnumerable<MonitoringItemResultModel> monitoringItemResults, ResultFilterRequest request, IEnumerable<MonitoringItemEntity> monitoringItems, IEnumerable<CompanyMonitoringCrawlerEntity> companyCrawlers)
        {
            var filteredResults = await GetFilteredResultsBySource(monitoringItemResults, request, companyCrawlers);
            filteredResults = FilterByKilometerRange(filteredResults, request.Kilometers);
            filteredResults = AppliedFilterHours(filteredResults, request.HourMeter);
            var resultsWithMonitoringItemId = MapMonitoringItemId(filteredResults, request.CompanyId);
            var resultsWithinPriceRange = FilterByPriceRange(resultsWithMonitoringItemId, monitoringItems);
            var finalResults = ApplyIgnoredItemsFilter(resultsWithinPriceRange, monitoringItemResults);

            return finalResults;
        }
        private async Task<IEnumerable<ResultFilterResponse>> GetFilteredResultsBySource(IEnumerable<MonitoringItemResultModel> monitoringItemResults, ResultFilterRequest request, IEnumerable<CompanyMonitoringCrawlerEntity> companyCrawlers)
        {
            var results = new ConcurrentBag<ResultFilterResponse>();
            var sources = monitoringItemResults
                .GroupBy(x => x.Source)
                .Select(x => new { Source = x.Key, Hashes = x.Select(x => x.Hash).Distinct(), x.First().CrawlerId, x.First().CrawlerName });

            _logger.LogInformation("Getting data from {SourceCount} sources for {MonitoringItemCount} hashes.", sources.Count(), monitoringItemResults.Count());

            Parallel.ForEach(sources, new ParallelOptions() { MaxDegreeOfParallelism = 1 }, async source =>
            {
                _logger.LogInformation($"Processing source {source.Source} with {source.Hashes.Count()} hashes.");
                var sw = Stopwatch.StartNew();
                var resultsBySource = await GetResultsBySource(source.Source, source.CrawlerId, source.CrawlerName, source.Hashes, request, companyCrawlers);
                resultsBySource.ForEach(x => results.Add(x));
                sw.Stop();
                _logger.LogInformation($"Source {source.Source} took {sw.Elapsed} to process {source.Hashes.Count()} hashes.");
            });

            return results;
        }
        private IEnumerable<ResultFilterResponse> MapMonitoringItemId(IEnumerable<ResultFilterResponse> results, long companyId)
        {
            _logger.LogInformation("Mapping monitoring item id to results.");
            var productLinks = results.Select(x => x.ProductLink).Distinct().ToHashSet();
            var hashes = _uow.MonitoringItemResults.GetAll()
                .Where(x => x.Hash != null && productLinks.Contains(x.Hash) && x.CompanyId == companyId)
                .Select(x => new { x.Hash, x.MonitoringItemId })
                .GroupBy(x => x.Hash)
                .Select(x => x.First())
                .ToDictionary(k => k.Hash, v => v.MonitoringItemId);

            Parallel.ForEach(results, new ParallelOptions() { MaxDegreeOfParallelism = 20 }, result =>
            {
                if (hashes.TryGetValue(result.ProductLink, out var monitoringItemId))
                {
                    result.MonitoringItemId = monitoringItemId;
                }
            });

            return results;
        }
        private IEnumerable<ResultFilterResponse> FilterByPriceRange(IEnumerable<ResultFilterResponse> results, IEnumerable<MonitoringItemEntity> monitoringItems)
        {
            _logger.LogInformation("Filtering results by price range.");
            var monitoringItemsDict = monitoringItems.Select(x => new { x.Id, x.UsePriceRange, x.LowerPriceRange, x.UpperPriceRange }).DistinctBy(x => x.Id).ToDictionary(k => k.Id, v => v);
            return results.Where(result =>
            {
                if (monitoringItemsDict.TryGetValue(result.MonitoringItemId, out var monitoringItem))
                {
                    if (!monitoringItem.UsePriceRange.GetValueOrDefault()) return true;

                    var isAboveLowerRange = monitoringItem.LowerPriceRange == null || result.Price >= monitoringItem.LowerPriceRange;
                    var isBelowUpperRange = monitoringItem.UpperPriceRange == null || result.Price <= monitoringItem.UpperPriceRange;

                    return isAboveLowerRange && isBelowUpperRange;
                }
                else return true;
            }).ToList();
        }

        private IEnumerable<ResultFilterResponse> ApplyIgnoredItemsFilter(IEnumerable<ResultFilterResponse> results, IEnumerable<MonitoringItemResultModel> monitoringItemResults)
        {
            _logger.LogInformation("Applying ignored items filter.");
            var monitoringItemIds = monitoringItemResults.Select(x => x.MonitoringItemId).Distinct().ToHashSet();

            var ignoredItems = _uow.IgnoredMonitoringItemRepository.GetAll()
                .Where(x => monitoringItemIds.Contains(x.MonitoringItemId) && !x.IsDeleted)
                .ToList();

            foreach (var result in results)
            {
                if (ignoredItems.Any(ignored =>
                    ignored.ProductLink == result.ProductLink &&
                    ignored.ProductSeller.Equals(result.SellerName, StringComparison.OrdinalIgnoreCase)))
                {
                    result.Disregarded = true;
                }
            }

            return results;
        }

        private async Task<List<ResultFilterResponse>> GetResultsBySource(CrawlerSourceType sourceType, int crawlerId, string crawlerName, IEnumerable<string> hashes, ResultFilterRequest request, IEnumerable<CompanyMonitoringCrawlerEntity> companyCrawlers)
        {
            List<ResultFilterResponse> listResults = new List<ResultFilterResponse>();

            if (!hashes.Any()) return listResults;

            switch (sourceType)
            {
                case CrawlerSourceType.Horus:
                    listResults.AddRange(await GetDataHorusFromHash(hashes, request.StartDate, request.EndDate, crawlerId, crawlerName));
                    break;

                case CrawlerSourceType.HorusAtacado:
                    listResults.AddRange(await GetDataHorusAtacadoFromHash(hashes, request.StartDate, request.EndDate, crawlerId, crawlerName));
                    break;

                case CrawlerSourceType.InfoPriceSaoJoao:
                    listResults.AddRange(await GetDataInfoPriceSaoJoaoFromHash(hashes, request.StartDate, request.EndDate, crawlerId, crawlerName));
                    break;

                case CrawlerSourceType.Indireta:
                    listResults.AddRange(await GetDataIndiretaFromHash(hashes, request.StartDate, request.EndDate, crawlerId, crawlerName));
                    break;

                case CrawlerSourceType.SmarketABV:
                    listResults.AddRange(await GetSmarketABVFromHash(hashes, request.StartDate, request.EndDate, crawlerId, crawlerName));
                    break;

                case CrawlerSourceType.NielsenPeralta:
                    listResults.AddRange(await GetNielsenPeraltaFromHash(hashes, request.StartDate, request.EndDate, crawlerId, crawlerName));
                    break;

                case CrawlerSourceType.NielsenVem:
                    listResults.AddRange(await GetNielsenVemFromHash(hashes, request.StartDate, request.EndDate, crawlerId, crawlerName));
                    break;

                case CrawlerSourceType.Predify:
                    listResults.AddRange(await GetPredifyFromHash(hashes, request.StartDate, request.EndDate, companyCrawlers, request.Sellers));
                    break;

                case CrawlerSourceType.InfoPricePeralta:
                    listResults.AddRange(await GetDataInfoPricePeraltaFromHash(hashes, request.StartDate, request.EndDate, crawlerId, crawlerName));
                    break;

                case CrawlerSourceType.OfflineSupermarketTorre:
                    listResults.AddRange(await GetDataOfflineSupermarketTorreFromHash(hashes, request.StartDate, request.EndDate, crawlerId, crawlerName));
                    break;

                case CrawlerSourceType.InfoPriceTorre:
                    listResults.AddRange(await GetDataInfoPriceTorreFromHash(hashes, request.StartDate, request.EndDate, crawlerId, crawlerName));
                    break;
                case CrawlerSourceType.ScantechSupermaxi:
                    listResults.AddRange(await GetDataScantechSupermaxiFromHash(hashes, request.StartDate, request.EndDate, crawlerId, crawlerName));
                    break;
            }

            return listResults;
        }

        private async Task<List<ResultFilterResponse>> GetDataInfoPricePeraltaFromHash(IEnumerable<string?> hashs, DateTime startDate, DateTime endDate, int crawlerId, string crawlerName)
        {
            var data = await _uow.InfoPricePeraltaRepository.GetAll()
                .Where(x => hashs.Contains(x.Hash) && x.DataPreco >= startDate && x.DataPreco <= endDate)
                .ToListAsync();

            var results = _mapper.Map<List<ResultFilterResponse>>(data, opts =>
            {
                opts.Items["CrawlerId"] = crawlerId;
                opts.Items["CrawlerName"] = crawlerName;
            });

            return results;
        }

        private async Task<List<ResultFilterResponse>> GetDataHorusFromHash(IEnumerable<string?> hashs, DateTime startDate, DateTime endDate, int crawlerId, string crawlerName)
        {
            var data = await _uow.HorusProducts.GetAll()
                .Where(x => hashs.Contains(x.Hash) && x.Date >= startDate && x.Date <= endDate)
                .ToListAsync();

            var results = _mapper.Map<List<ResultFilterResponse>>(data, opts =>
            {
                opts.Items["CrawlerId"] = crawlerId;
                opts.Items["CrawlerName"] = crawlerName;
            });

            return results;
        }

        private async Task<List<ResultFilterResponse>> GetDataHorusAtacadoFromHash(IEnumerable<string?> hashs, DateTime startDate, DateTime endDate, int crawlerId, string crawlerName)
        {
            var data = await _uow.HorusProducts.GetAll()
                .Where(x => hashs.Contains(x.Hash) && x.Date >= startDate && x.Date <= endDate && x.FormatMarket == "Atacadista")
                .ToListAsync();

            var results = _mapper.Map<List<ResultFilterResponse>>(data, opts =>
            {
                opts.Items["CrawlerId"] = crawlerId;
                opts.Items["CrawlerName"] = crawlerName;
            });

            return results;
        }

        private async Task<List<ResultFilterResponse>> GetDataInfoPriceSaoJoaoFromHash(IEnumerable<string?> hashs, DateTime startDate, DateTime endDate, int crawlerId, string crawlerName)
        {
            var data = await _uow.InfoPriceSaoJoao.GetAll()
                .Where(x => hashs.Contains(x.Hash) && x.DataPreco >= startDate && x.DataPreco <= endDate)
                .ToListAsync();

            var results = _mapper.Map<List<ResultFilterResponse>>(data, opts =>
            {
                opts.Items["CrawlerId"] = crawlerId;
                opts.Items["CrawlerName"] = crawlerName;
            });

            return results;
        }

        private async Task<List<ResultFilterResponse>> GetDataIndiretaFromHash(IEnumerable<string?> hashs, DateTime startDate, DateTime endDate, int crawlerId, string crawlerName)
        {
            var data = await _uow.IndiretaRepository.GetAll()
                .Where(x => hashs.Contains(x.Hash) && x.LastSale >= startDate && x.LastSale <= endDate)
                .ToListAsync();

            var results = _mapper.Map<List<ResultFilterResponse>>(data, opts =>
            {
                opts.Items["CrawlerId"] = crawlerId;
                opts.Items["CrawlerName"] = crawlerName;
            });

            return results;
        }

        private async Task<List<ResultFilterResponse>> GetSmarketABVFromHash(IEnumerable<string?> hashs, DateTime startDate, DateTime endDate, int crawlerId, string crawlerName)
        {
            var data = await _uow.AbvRepository.GetAll()
                .Where(x => hashs.Contains(x.Hash) && x.PesquisaProduto.DtPesquisa >= startDate && x.PesquisaProduto.DtPesquisa <= endDate)
                .ToListAsync();

            var results = _mapper.Map<List<ResultFilterResponse>>(data, opts =>
            {
                opts.Items["CrawlerId"] = crawlerId;
                opts.Items["CrawlerName"] = crawlerName;
            });

            return results;
        }

        private async Task<List<ResultFilterResponse>> GetNielsenPeraltaFromHash(IEnumerable<string?> hashs, DateTime startDate, DateTime endDate, int crawlerId, string crawlerName)
        {
            var data = await _uow.PeraltaRepository.GetAll()
                .Where(x => hashs.Contains(x.Hash) && x.Date >= startDate && x.Date <= endDate)
                .ToListAsync();

            var results = _mapper.Map<List<ResultFilterResponse>>(data, opts =>
            {
                opts.Items["CrawlerId"] = crawlerId;
                opts.Items["CrawlerName"] = crawlerName;
            });

            return results;
        }

        private async Task<List<ResultFilterResponse>> GetNielsenVemFromHash(IEnumerable<string?> hashs, DateTime startDate, DateTime endDate, int crawlerId, string crawlerName)
        {
            var data = await _uow.VemRepository.GetAll()
                .Where(x => hashs.Contains(x.Hash) && x.Date >= startDate && x.Date <= endDate)
                .ToListAsync();

            var results = _mapper.Map<List<ResultFilterResponse>>(data, opts =>
            {
                opts.Items["CrawlerId"] = crawlerId;
                opts.Items["CrawlerName"] = crawlerName;
            });

            return results;
        }

        private async Task<List<ResultFilterResponse>> GetPredifyFromHash(IEnumerable<string?> hashs, DateTime startDate, DateTime endDate, IEnumerable<CompanyMonitoringCrawlerEntity> companyCrawlers, List<string> sellers)
        {
            var links = hashs.Where(x => x != null && x.StartsWith("http")).ToList();
            var datas = await _uow.ProductPrices.GetAll()
                .Where(x => links.Contains(x.ProductLink) && x.CrawlerDate >= startDate && x.CrawlerDate <= endDate)
                .ToListAsync();
            var productPricesMapping = new ProductPricesMappings();
            var results = await productPricesMapping.MappingsProductPricesToResultResponse(datas, companyCrawlers);

            if (sellers != null && sellers.Any())
            {
                results = results.Where(x => sellers.Contains(x.SellerName)).ToList();
            }

            return results;
        }
        private async Task<List<ResultFilterResponse>> GetDataOfflineSupermarketTorreFromHash(IEnumerable<string?> hashs, DateTime startDate, DateTime endDate, int crawlerId, string crawlerName)
        {
            var data = await _uow.OfflineSupermarketTorres.GetAll()
                .Where(x => hashs.Contains(x.Hash) && x.Date >= startDate && x.Date <= endDate)
                .ToListAsync();

            var results = _mapper.Map<List<ResultFilterResponse>>(data, opts =>
            {
                opts.Items["CrawlerId"] = crawlerId;
                opts.Items["CrawlerName"] = crawlerName;
            });

            return results;
        }

        private async Task<List<ResultFilterResponse>> GetDataInfoPriceTorreFromHash(IEnumerable<string?> hashs, DateTime startDate, DateTime endDate, int crawlerId, string crawlerName)
        {
            var data = await _uow.InfoPriceTorreRepository.GetAll()
                .Where(x => hashs.Contains(x.Hash) && x.DataPreco >= startDate && x.DataPreco <= endDate)
                .ToListAsync();

            var results = _mapper.Map<List<ResultFilterResponse>>(data, opts =>
            {
                opts.Items["CrawlerId"] = crawlerId;
                opts.Items["CrawlerName"] = crawlerName;
            });

            return results;
        }

        private async Task<List<ResultFilterResponse>> GetDataScantechSupermaxiFromHash(IEnumerable<string?> hashs, DateTime startDate, DateTime endDate, int crawlerId, string crawlerName)
        {
            //Conforme comentado na PBI 11745: o filtro de preço é necessário pois o cliente importa preços zerados mas não quer ve-los no predimonitor
            var data = await _uow.ScantechSupermaxiRepository.GetAll()
                .Where(x => hashs.Contains(x.Hash) && x.DataPreco >= startDate && x.DataPreco <= endDate && x.PrecoMedioMercado > 0)
                .ToListAsync();

            var results = _mapper.Map<List<ResultFilterResponse>>(data, opts =>
            {
                opts.Items["CrawlerId"] = crawlerId;
                opts.Items["CrawlerName"] = crawlerName;
            });

            return results;
        }


        private static IEnumerable<ResultFilterResponse> AppliedFilterHours(IEnumerable<ResultFilterResponse> resultFilters, ResultFilterHourmeterRangeRequest hourMeter)
        {
            if (hourMeter is not null)
            {
                if (hourMeter.Min is not null && hourMeter.Min > 0)
                    resultFilters = resultFilters.Where(x => x.ProductUsedHours >= hourMeter.Min);

                if (hourMeter.Max is not null && hourMeter.Max > 0)
                    resultFilters = resultFilters.Where(x => x.ProductUsedHours <= hourMeter.Max);
            }

            return resultFilters;
        }

        private static IEnumerable<ResultFilterResponse> FilterByKilometerRange(IEnumerable<ResultFilterResponse> resultFilters, ResultFilterKilometerRangeRequest kmFilter)
        {
            if (kmFilter is not null)
            {
                if (kmFilter.Min is not null)
                    resultFilters = resultFilters.Where(x => x.ProductMileage >= kmFilter.Min);

                if (kmFilter.Max is not null)
                    resultFilters = resultFilters.Where(x => x.ProductMileage <= kmFilter.Max);
            }

            return resultFilters;
        }

        private List<MonitoringItemResultGroupModel> GroupMonitoringItemResults(IQueryable<MonitoringItemResultsEntity> queryMonitoringResultItem, IEnumerable<CompanyMonitoringCrawlerEntity> companyCrawlers)
        {
            var crawlerIdHashset = companyCrawlers.Select(c => c.MonitoringCrawlerId).ToHashSet();
            return queryMonitoringResultItem
                .Where(x => crawlerIdHashset.Contains(x.CrawlerId))
                .Select(x => new MonitoringItemResultModel
                {
                    MonitoringItemId = x.MonitoringItemId,
                    Description = x.MonitoringItem.Description,
                    Hash = x.Hash,
                    CrawlerId = x.CrawlerId,
                    Source = x.MonitoringCrawler.Source,
                    CrawlerName = x.MonitoringCrawler.Description,
                })
                .GroupBy(x => x.MonitoringItemId)
                .Select(x => new MonitoringItemResultGroupModel
                {
                    MonitoringItemId = x.Key,
                    MonitoringItemResultModel = x.Select(v => v).ToList()
                })
                .ToList();
        }

        private List<MonitoringItemResultGroupModel> GroupMonitoringItemResultsTeste(IQueryable<MonitoringItemResultsEntity> queryMonitoringResultItem, IEnumerable<CompanyMonitoringCrawlerEntity> companyCrawlers)
        {
            var crawlerIdHashset = companyCrawlers.Select(c => c.MonitoringCrawlerId).ToHashSet();

            var monitoringItems = queryMonitoringResultItem
                .Where(x => crawlerIdHashset.Contains(x.CrawlerId))
                .Select(x => new
                {
                    x.MonitoringItemId,
                    x.MonitoringItem.Description,
                    x.Hash,
                    x.CrawlerId,
                    x.MonitoringCrawler.Source,
                    CrawlerName = x.MonitoringCrawler.Description
                })
                .ToList();

            return monitoringItems
                .GroupBy(x => x.MonitoringItemId)
                .Select(x => new MonitoringItemResultGroupModel
                {
                    MonitoringItemId = x.Key,
                    MonitoringItemResultModel = x.Select(v => new MonitoringItemResultModel
                    {
                        MonitoringItemId = v.MonitoringItemId,
                        Description = v.Description,
                        Hash = v.Hash,
                        CrawlerId = v.CrawlerId,
                        Source = v.Source,
                        CrawlerName = v.CrawlerName
                    }).ToList()
                })
                .ToList();
        }

        private async Task ProcessMonitoringItemResults(IEnumerable<MonitoringItemResultGroupModel> monitoringItemResultGroups,
            IEnumerable<MonitoringItemEntity> monitoringItems, IEnumerable<CompanyMonitoringCrawlerEntity> companyCrawlers, long companyId,
            DateTime? refDate, bool removeOutliers, int skip, ResultFilterRequest dynamicFilterRequest)
        {
            int count = skip;
            int errorCount = 0;
            List<string> listSellers = new List<string>();

            foreach (var monitoringItemResultGroup in monitoringItemResultGroups)
            {
                try
                {
                    var listMonitoringMarketResultItem = await ProcessSingleMonitoringItemResult(monitoringItemResultGroup.MonitoringItemId, monitoringItemResultGroup.MonitoringItemResultModel, monitoringItems, companyCrawlers, companyId, refDate, removeOutliers, dynamicFilterRequest);

                    if (listMonitoringMarketResultItem != null)
                        listSellers.AddRange(listMonitoringMarketResultItem.Select(x => x.SellerName).Distinct().ToList());
                }
                catch (Exception ex)
                {
                    errorCount++;
                    _logger.LogDebug($"{errorCount} Error {GetProgress(count, monitoringItemResultGroups.Count())} - {count + 1}/{monitoringItemResultGroups.Count()} MonitoringItem - {ex.Message}");
                }
                finally
                {
                    count++;
                }
            }

            await UpdateSellers(companyId, listSellers);
        }

        private async Task<List<MonitoringProductMarketResultItemEntity>> ProcessSingleMonitoringItemResult(long monitoringItemId, IEnumerable<MonitoringItemResultModel> monitoringItemResultGroup,
            IEnumerable<MonitoringItemEntity> monitoringItems, IEnumerable<CompanyMonitoringCrawlerEntity> companyCrawlers,
            long companyId, DateTime? refDate, bool removeOutliers, ResultFilterRequest dynamicFilterRequest)
        {
            var monitoringItem = monitoringItems.FirstOrDefault(x => x.Id == monitoringItemId);
            var listResults = await GetDatas(monitoringItemResultGroup, dynamicFilterRequest, monitoringItems, companyCrawlers);

            if (listResults == null || listResults.Count() <= 0)
                return null;

            listResults = await GetLastResult(listResults);

            var marketResult = CreateMarketResultEntity(companyId, monitoringItem, refDate.Value);
            var listMonitoringMarketResultItem = _mapper.Map<List<MonitoringProductMarketResultItemEntity>>(listResults);

            if (removeOutliers)
                listMonitoringMarketResultItem = RemoveOutliers(listMonitoringMarketResultItem);

            if (listMonitoringMarketResultItem.Count > 0)
            {
                marketResult.MonitoringProductMarketResultItem = listMonitoringMarketResultItem;
                marketResult.SetMaxAvgMin(listMonitoringMarketResultItem);
                _uow.MonitoringProductMarketResultRepository.Create(marketResult);
            }

            return listMonitoringMarketResultItem;
        }

        private async Task<List<ResultFilterResponse>> GetLastResult(IEnumerable<ResultFilterResponse> listResults)
        {
            List<ResultFilterResponse> resultFilterResponses = new List<ResultFilterResponse>();

            var groupListResults = listResults.Where(x => x.PriceInstallment == null).GroupBy(x => $"{x.ProductLink}{x.SellerName}")
                .OrderByDescending(g => g.Max(y => y.CrawlerDate))
                .ToList();

            foreach (var item in groupListResults)
            {
                resultFilterResponses.Add(item.Last());
            }

            return resultFilterResponses;
        }

        private MonitoringProductMarketResultEntity CreateMarketResultEntity(long companyId, MonitoringItemEntity monitoringItem, DateTime refDate)
        {
            return new MonitoringProductMarketResultEntity
            {
                CompanyId = companyId,
                ProductId = monitoringItem.ProductId,
                MonitoringItemId = monitoringItem.Id,
                AvgPrice = 0,
                MaxPrice = null,
                MaxPriceProductLink = null,
                MaxPriceProductName = null,
                MinPrice = null,
                MinPriceProductLink = null,
                MinPriceProductName = null,
                RefDate = refDate
            };
        }

        private string GetProgress(int count, int total)
        {
            return $"{Math.Round(((double)count / total) * 100, 2)}%";
        }

        private async Task UpdateSellers(long companyId, List<string> listSellers)
        {
            await DeleteProductMarketResultSeller(companyId);
            await InsertProductMarketResultSeller(listSellers.Distinct().ToList(), companyId);
        }

        private async Task InsertProductMarketResultSeller(List<string> listSellers, long companyId)
        {
            List<ProductMarketResultSellerEntity> listEntity = new List<ProductMarketResultSellerEntity>();

            foreach (var seller in listSellers)
            {
                if (string.IsNullOrEmpty(seller))
                    continue;

                listEntity.Add(new ProductMarketResultSellerEntity()
                {
                    CompanyId = companyId,
                    SellerName = seller,
                    IsDeleted = false,
                    CreateDate = DateTime.Now,
                    UpdateDate = DateTime.Now
                });
            }

            _uow.ProductMarketResultSellerRepository.AddRange(listEntity, true);
        }

        private async Task DeleteProductMarketResultSeller(long companyId)
        {
            var ids = await _uow.ProductMarketResultSellerRepository.GetAll()
                .Where(x => x.CompanyId == companyId && !x.IsDeleted)
                .Select(x => x.Id)
                .ToListAsync();

            _uow.ProductMarketResultSellerRepository.DeleteAll(ids);
        }

        private async Task DeleteOlds(long companyId)
        {
            var sqlUpdate = $@"
                UPDATE Monitoring_ProductMarketResult 
                SET IsDeleted = 1, UpdateDate = GETDATE() 
                WHERE IdCompany = {companyId} AND IsDeleted = 0";

            var sqlDeleteItems = $@"
                DELETE mpmri
                FROM [dbo].[Monitoring_ProductMarketResultItem] mpmri
                JOIN [dbo].[Monitoring_ProductMarketResult] mpmr
                ON mpmri.[IdMonitoring_ProductMarketResult] = mpmr.[IdMonitoring_ProductMarketResult]
                LEFT JOIN [dbo].[Enterprise_Prices_Projection] pp ON pp.idProductMarketResult = mpmr.[IdMonitoring_ProductMarketResult]
                LEFT JOIN Enterprise_Prices_Projection_MarketSimilarity ppms ON ppms.IdMonitoring_ProductMarketResult = mpmr.[IdMonitoring_ProductMarketResult]
                WHERE mpmr.[IsDeleted] = 1
                AND pp.IdEnterprisePricesProjection IS NULL
                AND ppms.IdEnterprise_Prices_Projection_MarketSimilarity IS NULL
                AND mpmr.IdCompany = {companyId}";

            var sqlDeleteResults = $@"
                DELETE mpmr
                FROM [dbo].[Monitoring_ProductMarketResult] mpmr
                LEFT JOIN [dbo].[Enterprise_Prices_Projection] pp ON pp.idProductMarketResult = mpmr.[IdMonitoring_ProductMarketResult]
                LEFT JOIN Enterprise_Prices_Projection_MarketSimilarity ppms ON ppms.IdMonitoring_ProductMarketResult = mpmr.[IdMonitoring_ProductMarketResult]
                WHERE mpmr.[IsDeleted] = 1
                AND pp.IdEnterprisePricesProjection IS NULL
                AND ppms.IdEnterprise_Prices_Projection_MarketSimilarity IS NULL
                AND mpmr.IdCompany = {companyId}";

            await _uow.MonitoringProductMarketResultRepository.ExecuteRawSQLAsync(sqlUpdate);
            await _uow.MonitoringProductMarketResultItemRepository.ExecuteRawSQLAsync(sqlDeleteItems);
            await _uow.MonitoringProductMarketResultRepository.ExecuteRawSQLAsync(sqlDeleteResults);
        }

        private DateTime GetStartDate(DateTime? startDate)
        {
            if (startDate == null)
                return new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
            return startDate.Value.Date;
        }

        private DateTime GetEndDate(DateTime? startDate, DateTime? endDate)
        {
            if (endDate == null)
            {
                var initialEndDate = new DateTime(startDate.Value.Year, startDate.Value.Month, 1);
                return initialEndDate.AddMonths(1).AddDays(-1);
            }
            return endDate.Value.Date;
        }

        private DateTime GetReferenceDate(DateTime? refDate)
        {
            if (refDate == null)
                return DateTime.Now.Date;
            return refDate.Value.Date;
        }

        private void SwapDatesIfNeeded(ref DateTime? startDate, ref DateTime? endDate)
        {
            if (startDate > endDate)
            {
                var temp = startDate;
                startDate = endDate;
                endDate = temp;
            }
        }

        private async Task<CompanyConfigurationEntity?> GetCompanyConfiguration(long companyId)
        {
            return await _uow.CompanyConfiguration.GetAll()
                .Where(x => x.CompanyId == companyId && !x.IsDeleted)
                .FirstOrDefaultAsync();
        }

        private bool GetRemoveOutliersFlag(bool? removeOutliers, CompanyConfigurationEntity config)
        {
            return removeOutliers ?? config?.RemoveOutliersOnMarketResult ?? false;
        }

        private bool GetRemoveOldsFlag(bool? removeOlds, CompanyConfigurationEntity config)
        {
            return removeOlds ?? config?.RemoveOldsMarketResult ?? false;
        }

    }
}
