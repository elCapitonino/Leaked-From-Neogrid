from pydantic import BaseModel
from typing import List
from datetime import datetime

class PredimonitorProjectionDataValue(BaseModel):
    crawlerDate: datetime
    price: float

class PredimonitorProjectionData(BaseModel):
    productName: str
    priceResults: List[PredimonitorProjectionDataValue]

class PredimonitorProjectionRequest(BaseModel):
    startDate: datetime
    endDate: datetime
    products: List[PredimonitorProjectionData]