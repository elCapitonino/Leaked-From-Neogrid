﻿namespace DI.Domain.Models.ImpactReport
{
    public class ImpactConsolidatedRequestModel
    {
        public required List<DataPriceGroups> PriceGroups { get; set; }
        public List<Affiliates> Affiliates { get; set; }
        public required long CompanyId { get; set; }

        public string GenerateCacheKey()
        {
            var priceGroupKey = string.Join("_", PriceGroups.OrderBy(x => x.Month).Select(pg => $"{pg.Year}_{pg.Month}_{string.Join(",", pg.PriceGroupIds)}_{string.Join(",", Affiliates.OrderBy(x => x.Value).Select(x => x.Value))}"));
            return $"ConsolidatedReport_{CompanyId}_{priceGroupKey}";
        }
    }

    public class DataPriceGroups
    {
        public int Year { get; set; }
        public int Month { get; set; }
        public List<long> PriceGroupIds { get; set; }
    }

    public class Affiliates
    {
        public string Description { get; set; }
        public string Value { get; set; }
    }
}
