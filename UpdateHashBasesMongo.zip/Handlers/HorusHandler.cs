﻿using MongoDB.Driver;
using Serilog;

namespace UpdateHashHorus.Handlers
{
    public class HorusHandler
    {
        private readonly MongoClient _client;
        public HorusHandler(MongoClient client)
        {
            _client = client;
        }

        public async Task ExecuteAsync (string baseName, string collectionName, DateTime startDate, DateTime endDate, int batchSize , bool dryRun = false)
        {
            var database = _client.GetDatabase(baseName);
            var collection = database.GetCollection<HorusProduct>(collectionName);

            var filter = Builders<HorusProduct>.Filter.And(
                Builders<HorusProduct>.Filter.Gte(doc => doc.date, startDate),
                Builders<HorusProduct>.Filter.Lte(doc => doc.date, endDate)
            );

            var projection = Builders<HorusProduct>.Projection
                .Include(doc => doc.description)
                .Include(doc => doc.ean)
                .Include(doc => doc.cnpj);

            int take = batchSize;
            int skip = 0;

            while (true)
            {
                Log.Information("Buscando Produtos");

                var documents = await collection.Find(filter)
                                                 .Sort(Builders<HorusProduct>.Sort.Descending(doc => doc.date))
                                                 .Skip(skip)
                                                 .Limit(take)
                                                 .Project<HorusProduct>(projection)
                                                 .ToListAsync();

                if (documents.Count == 0)
                {
                    break;
                }

                Log.Information("Atualizando Produtos");

                var updates = new List<WriteModel<HorusProduct>>();

                foreach (var doc in documents)
                {
                    var ean = doc.ean;
                    var cnpj = doc.cnpj;

                    var concatenatedString = $"{ean}|{cnpj}";

                    var hashValue = Utils.CalculateSHA256(concatenatedString);

                    var filterDoc = Builders<HorusProduct>.Filter.Eq("_id", doc._id);
                    var update = Builders<HorusProduct>.Update.Set("hash", hashValue);
                    updates.Add(new UpdateOneModel<HorusProduct>(filterDoc, update));
                }

                if(!dryRun)
                    await collection.BulkWriteAsync(updates);

                Log.Information($"Atualizados {skip + take} documentos");

                skip += take;
            }
        }
    }
}
