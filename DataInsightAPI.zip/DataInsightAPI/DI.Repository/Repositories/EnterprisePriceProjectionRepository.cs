﻿using DI.Repository.Attributes;
using DI.Repository.Contexts;
using DI.Repository.Entities;
using DI.Repository.Interfaces.Repositories;
using DI.Repository.Repositories.Base;
using Microsoft.EntityFrameworkCore;

namespace DI.Repository.Repositories
{
    [UseSQLContext]
    public sealed class EnterprisePriceProjectionRepository : SqlGenericNoModifyRepository<EnterprisePriceProjectionEntity>, IEnterprisePriceProjectionRepository
    {
        public EnterprisePriceProjectionRepository(SqlContext dbContext) : base(dbContext)
        {

        }

        public IEnumerable<EnterprisePriceProjectionEntity> GetByIdPriceGroup(long priceGroupId)
        {
            return _dbContext
                .Set<EnterprisePriceProjectionEntity>()
                .Where(x => x.EnterprisePriceGroupsId == priceGroupId)
                .Include(x => x.Elasticity)
                .Include(x => x.PriceGroup)
                .Include(x => x.Workflows.Where(x => x.IsDeleted == false))
                .ThenInclude(w => w.LastAction);
        }

        public IEnumerable<EnterprisePriceProjectionEntity> GetByIdPriceGroup(List<long> priceGroupId)
        {
            return _dbContext
                .Set<EnterprisePriceProjectionEntity>()
                .Where(x => priceGroupId.Contains(x.EnterprisePriceGroupsId.Value))
                .Include(x => x.Elasticity)
                .Include(x => x.PriceGroup)
                .Include(x => x.Workflows.Where(x => x.IsDeleted == false))
                .ThenInclude(w => w.LastAction);
        }
    }
}
