﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace PH.Domain.Domain
{
    public class AcaoPromocional
    {
        public AcaoPromocional()
        {
            CreationDate = DateTime.Now;
            Produtos = new List<ProdutoAcaoPromocional>();
        }

        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string? Id { get; private set; }
        public string NomeAcao { get; set; }
        public long IdCompany { get; set; }
        public DateTime? CreationDate { get; private set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public List<ProdutoAcaoPromocional> Produtos { get; set; }

        public void SetId(string id)
        {
            Id = id;
        }
    }

    public class ImportProdutoAcaoPromocional
    {
        public bool Success { get; set; } = true;
        public List<ProdutoAcaoPromocional> Items { get; set; }
        public List<ProdutoAcaoPromocionalErrorModel> Errors { get; set; }
    }

    public class ProdutoAcaoPromocional
    {
        public int Id { get; set; }
        public string NomeProduto { get; set; }
        public double PrecoAtual { get; set; }
        public double PrecoAcao { get; set; }
        public string? EAN { get; set; }
        public bool Combo { get; set; }
        public string? TipoPromo { get; set;}
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }

    public class ProdutoAcaoPromocionalErrorModel
    {
        public string TextToken { get; set; }
        public int Line { get; set; }
        public string Column { get; set; }
        public string Expected { get; set; }
        public string Found { get; set; }
    }
}
