from collections import defaultdict
from contextlib import asynccontextmanager
from datetime import date, timedelta
from threading import Semaphore
from uuid import UUID

import pandas as pd
from fastapi import BackgroundTasks, FastAPI, HTTPException, Request

from src.db import create_postgresql_engine, create_sql_server_engine
from src.granularity import GranularityType, load_granularity
from src.logger import logger
from src.monthly_projection import (
    MonthlyTask,
    get_monthly_tasks,
    get_price_group_monthly_task,
    import_monthly_projections,
)
from src.projections import (
    get_previous_published_pricegroups,
    get_price_group_info,
    insert_projections_into_later_period,
    read_price_groups,
    update_later_period,
)
from src.report_pipeline import run_report_pipeline
from src.status import (
    get_date_range_task_status,
    get_price_group_task_status,
    insert_date_range_import,
    insert_price_group_import,
    status_manager,
)


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.pg_engine, app.state.pg_metadata = create_postgresql_engine()
    app.state.sql_engine, app.state.sql_metadata = create_sql_server_engine()
    app.state.monthly_client_semaphores = defaultdict(lambda: Semaphore(1))
    app.state.report_client_semaphores = defaultdict(lambda: Semaphore(1))
    yield
    app.state.pg_engine.dispose()
    app.state.sql_engine.dispose()


app = FastAPI(lifespan=lifespan, title="PricingProcessor")


@app.get("/health")
async def health():
    """Check health of the application."""
    return "OK"


@app.post("/calculate_projection_metrics/{id_company}/date_range")
def calc_date_range(
    id_company: int,
    initial_date: date,
    final_date: date,
    request: Request,
    bg_tasks: BackgroundTasks,
):
    """
    Calcula métricas de projeção para todas as projeções entre as datas.
    """
    try:
        logger.info(
            "new date range request for id_company %s between dates %s and %s",
            id_company,
            initial_date,
            final_date,
        )
        tasks = get_monthly_tasks(
            id_company=id_company,
            initial_date=initial_date,
            final_date=final_date,
        )
        date_task_id = None
        if tasks:
            with request.app.state.pg_engine.begin() as pg_conn:
                date_task_id = insert_date_range_import(
                    pg_conn,
                    request.app.state.pg_metadata,
                    id_company,
                    initial_date,
                    final_date,
                )

            bg_tasks.add_task(
                _run_monthly_import, id_company, tasks, request, date_task_id
            )

        pg_task_ids = _calc_date_range_impact(
            id_company, initial_date, final_date, request, bg_tasks
        )

    except HTTPException as exc:
        raise exc
    except Exception as exc:
        msg = f"unexpected error of type {type(exc).__name__}: {exc}"
        logger.error(msg, exc_info=True)
        raise HTTPException(status_code=500, detail=msg) from exc

    return {
        "id_company": id_company,
        "date_task_id": date_task_id,
        "pg_task_ids": pg_task_ids,
    }


def _run_monthly_import(
    id_company: int, tasks: list[MonthlyTask], request: Request, task_id: UUID
):
    logger.debug("waiting until semaphore for id_company %d is available", id_company)
    with request.app.state.monthly_client_semaphores[id_company]:
        logger.debug("semaphore for id_company %d is available", id_company)
        with status_manager(
            request.app.state.pg_engine, request.app.state.pg_metadata, task_id
        ):
            num_tasks = len(tasks)
            logger.info(
                "found %d pending monthly tasks for id_company %d",
                num_tasks,
                id_company,
            )
            for i, task in enumerate(tasks):
                logger.info(
                    "-> %d/%d: running monthly data task %s", i, num_tasks, task
                )
                import_monthly_projections(
                    pg_engine=request.app.state.pg_engine,
                    pg_metadata=request.app.state.pg_metadata,
                    sql_engine=request.app.state.sql_engine,
                    sql_metadata=request.app.state.sql_metadata,
                    id_company=id_company,
                    initial_date=task.initial_date,
                    final_date=task.final_date,
                )


def _run_impact_update(
    price_group: int,
    previous_price_groups: list[int],
    id_company: int,
    request: Request,
    task_id: UUID,
):
    logger.debug("waiting until semaphore for id_company %d is available", id_company)
    with request.app.state.report_client_semaphores[id_company]:
        logger.debug("semaphore for id_company %d is available", id_company)
        with status_manager(
            request.app.state.pg_engine,
            request.app.state.pg_metadata,
            task_id,
        ):
            with request.app.state.pg_engine.begin() as pg_conn:
                logger.info(
                    "-> running price_group %s task with ID %s", price_group, task_id
                )
                run_report_pipeline(
                    pg_conn=pg_conn,
                    pg_metadata=request.app.state.pg_metadata,
                    sql_engine=request.app.state.sql_engine,
                    sql_metadata=request.app.state.sql_metadata,
                    id_company=id_company,
                    price_group=price_group,
                )

                for pg in previous_price_groups:
                    run_report_pipeline(
                        pg_conn=pg_conn,
                        pg_metadata=request.app.state.pg_metadata,
                        sql_engine=request.app.state.sql_engine,
                        sql_metadata=request.app.state.sql_metadata,
                        id_company=id_company,
                        price_group=pg,
                    )


def _run_impact_import(
    price_group: int,
    df_pg_info: pd.DataFrame,
    id_company: int,
    request: Request,
    task_id: UUID,
) -> None:
    logger.debug("waiting until semaphore for id_company %d is available", id_company)
    with request.app.state.report_client_semaphores[id_company]:
        logger.debug("semaphore for id_company %d is available", id_company)
        with status_manager(
            request.app.state.pg_engine,
            request.app.state.pg_metadata,
            task_id,
        ):
            with request.app.state.pg_engine.begin() as pg_conn:
                logger.info(
                    "-> running price_group %s task with ID %s", price_group, task_id
                )
                df_previous_pg = get_previous_published_pricegroups(
                    pg_conn=pg_conn,
                    pg_metadata=request.app.state.pg_metadata,
                    df_price_group_info=df_pg_info,
                    id_company=id_company,
                )
                price_group = int(price_group)
                previous_price_groups = df_previous_pg["PriceGroupId"].unique().tolist()
                insert_projections_into_later_period(
                    pg_conn=pg_conn,
                    pg_metadata=request.app.state.pg_metadata,
                    df_price_group_info=df_pg_info,
                )
                run_report_pipeline(
                    pg_conn=pg_conn,
                    pg_metadata=request.app.state.pg_metadata,
                    sql_engine=request.app.state.sql_engine,
                    sql_metadata=request.app.state.sql_metadata,
                    id_company=id_company,
                    price_group=price_group,
                )

                for pg in previous_price_groups:
                    df_pg = df_previous_pg.loc[df_previous_pg["PriceGroupId"] == pg, :]
                    update_later_period(
                        pg_conn=pg_conn,
                        pg_metadata=request.app.state.pg_metadata,
                        df_price_group_map=df_pg,
                    )
                    run_report_pipeline(
                        pg_conn=pg_conn,
                        pg_metadata=request.app.state.pg_metadata,
                        sql_engine=request.app.state.sql_engine,
                        sql_metadata=request.app.state.sql_metadata,
                        id_company=id_company,
                        price_group=pg,
                    )


def _calc_date_range_impact(
    id_company: int,
    initial_date: date,
    final_date: date,
    request: Request,
    bg_tasks: BackgroundTasks,
) -> list[UUID]:
    # NOTE busca por precificacao não inclui última data
    final_date = final_date + timedelta(days=1)
    with request.app.state.sql_engine.connect() as sql_conn:
        df_groups = read_price_groups(
            conn=sql_conn,
            metadata=request.app.state.sql_metadata,
            id_company=id_company,
            initial_date=initial_date,
            final_date=final_date,
        )

        price_groups = df_groups["IdEnterprisePriceGroups"].values.tolist()
        with request.app.state.pg_engine.connect() as pg_conn:
            proj_granularity = load_granularity(
                pg_conn=pg_conn,
                metadata=request.app.state.pg_metadata,
                id_company=id_company,
                granularity_type=GranularityType.PROJECTION,
            )
            previous_pg_map = {}
            for price_group in price_groups:
                df_pg_info = get_price_group_info(
                    conn=sql_conn,
                    metadata=request.app.state.sql_metadata,
                    granularity=proj_granularity.to_columns(),
                    id_company=id_company,
                    id_price_group=price_group,
                )
                if df_pg_info is None:
                    logger.info("skipping price_group %d with no data", price_group)
                    continue

                df_previous_pg = get_previous_published_pricegroups(
                    pg_conn=pg_conn,
                    pg_metadata=request.app.state.pg_metadata,
                    df_price_group_info=df_pg_info,
                    id_company=id_company,
                )
                previous_pg_map[price_group] = (
                    df_previous_pg["PriceGroupId"].unique().tolist()
                )

    task_ids = []
    logger.info(
        "found %d pending price_group tasks for id_company %d",
        len(price_groups),
        id_company,
    )
    with request.app.state.pg_engine.begin() as pg_conn:
        for price_group, previous_pgs in previous_pg_map.items():
            task_id = insert_price_group_import(
                pg_conn, request.app.state.pg_metadata, id_company, price_group
            )
            task_ids.append(task_id)
            bg_tasks.add_task(
                _run_impact_update,
                price_group,
                previous_pgs,
                id_company,
                request,
                task_id,
            )

    return task_ids


@app.post("/calculate_projection_metrics/{id_company}/price_group")
def calc_price_group(
    id_company: int, id_price_group: int, request: Request, bg_tasks: BackgroundTasks
):
    """Calcula métricas de projeção para a precificação especificada e para a anterior."""
    try:
        logger.info(
            "new price group request for id_company %s and id_price_group %s",
            id_company,
            id_price_group,
        )
        with request.app.state.pg_engine.connect() as pg_conn:
            proj_granularity = load_granularity(
                pg_conn=pg_conn,
                metadata=request.app.state.pg_metadata,
                id_company=id_company,
                granularity_type=GranularityType.PROJECTION,
            )

        with request.app.state.sql_engine.connect() as sql_conn:
            monthly_task = get_price_group_monthly_task(
                sql_conn, request.app.state.sql_metadata, id_company, id_price_group
            )
            # TODO mover para async?
            df_pg_info = get_price_group_info(
                conn=sql_conn,
                metadata=request.app.state.sql_metadata,
                granularity=proj_granularity.to_columns(),
                id_company=id_company,
                id_price_group=id_price_group,
            )

        if df_pg_info is None:
            raise HTTPException(
                status_code=400,
                detail=f"no projections found in price_group {id_price_group}",
            )

        logger.error(df_pg_info["PublishedDate"].unique())
        if df_pg_info["PublishedDate"].isna().any():
            raise HTTPException(
                status_code=400,
                detail=f"no PublishedDate found for price_group {id_price_group}, request cannot continue",
            )

        date_task_id = None
        if monthly_task is not None:
            with request.app.state.pg_engine.begin() as pg_conn:
                date_task_id = insert_date_range_import(
                    pg_conn,
                    request.app.state.pg_metadata,
                    id_company,
                    monthly_task.initial_date,
                    monthly_task.final_date,
                )

            bg_tasks.add_task(
                _run_monthly_import, id_company, [monthly_task], request, date_task_id
            )

        with request.app.state.pg_engine.begin() as pg_conn:
            pg_task_id = insert_price_group_import(
                pg_conn, request.app.state.pg_metadata, id_company, id_price_group
            )

        bg_tasks.add_task(
            _run_impact_import,
            id_price_group,
            df_pg_info,
            id_company,
            request,
            pg_task_id,
        )

    except HTTPException as exc:
        raise exc
    except Exception as exc:
        msg = f"unexpected error of type {type(exc).__name__}: {exc}"
        logger.error(msg, exc_info=True)
        raise HTTPException(status_code=500, detail=msg) from exc

    return {
        "id_company": id_company,
        "date_task_id": date_task_id,
        "pg_task_ids": [pg_task_id],
    }


@app.get("/get_price_group_task_status")
def get_task_status_endpoint(import_id: UUID, request: Request):
    """Get status of a price_group import ID."""
    with request.app.state.pg_engine.connect() as pg_conn:
        out = get_price_group_task_status(
            pg_conn, request.app.state.pg_metadata, import_id
        )
    if out is None:
        raise HTTPException(status_code=404, detail=f"import id {import_id} not found")
    return out


@app.get("/get_date_range_task_status")
def get_date_range_status_endpoint(import_id: UUID, request: Request):
    """Get status of a date range import ID."""
    with request.app.state.pg_engine.connect() as pg_conn:
        out = get_date_range_task_status(
            pg_conn, request.app.state.pg_metadata, import_id
        )
    if out is None:
        raise HTTPException(status_code=404, detail=f"import id {import_id} not found")
    return out
