﻿namespace DI.Repository.Entities
{
    public sealed class GranularityLevelEntity : BaseEntity
    {
        public Guid GranularityGroupId { get; set; }

        public GranularityGroupEntity? GranularityGroup { get; set; }

        public Guid? ParentId { get; set; }

        public string? Description { get; set; }

        public required string FieldKey { get; set; }

        public string? FieldValue { get; set; }
    }
}
