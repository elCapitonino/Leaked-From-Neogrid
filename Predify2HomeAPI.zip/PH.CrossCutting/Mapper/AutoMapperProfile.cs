﻿using AutoMapper;
using PH.Domain.Domain;
using PH.Domain.DTO;

namespace PH.CrossCutting.Mapper
{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            CreateMap<AcaoPromocional, AcaoPromocionalResponseDTO>()
                .ForMember(dto => dto.Id, o => o.MapFrom(c => c.Id))
                .ForMember(dto => dto.ActionName, o => o.MapFrom(c => c.NomeAcao))
                .ForMember(dto => dto.TooltipText, o => o.MapFrom(c => c.NomeAcao))
                .ForMember(dto => dto.InitialDate, o => o.MapFrom(c => c.StartDate.ToString("dd/MM/yyyy")))
                .ForMember(dto => dto.FinalDate, o => o.MapFrom(c => c.EndDate.ToString("dd/MM/yyyy")))
                .ForMember(dto => dto.Products, o => o.MapFrom(c => c.Produtos))
                .ReverseMap();

            CreateMap<ProdutoAcaoPromocional, ProductAcaoPromocionalResponseDTO>()
                .ForMember(dto => dto.Id, o => o.MapFrom(c => c.Id))
                .ForMember(dto => dto.ProductName, o => o.MapFrom(c => c.NomeProduto))
                .ForMember(dto => dto.Price, o => o.MapFrom(c => c.PrecoAcao))
                .ForMember(dto => dto.EAN, o => o.MapFrom(c => c.EAN))
                .ForMember(dto => dto.IsCombo, o => o.MapFrom(c => c.Combo))
                .ForMember(dto => dto.ActionType, o => o.MapFrom(c => c.TipoPromo))
                .ForMember(dto => dto.StartDate, o => o.MapFrom(c => c.StartDate.ToString("dd/MM/yyyy")))
                .ForMember(dto => dto.EndDate, o => o.MapFrom(c => c.EndDate.ToString("dd/MM/yyyy")))
                .ReverseMap();

        }
    }
}
