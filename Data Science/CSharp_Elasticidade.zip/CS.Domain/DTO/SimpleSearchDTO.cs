﻿namespace CS.Domain.DTO
{
    public class SimpleSearchDTO
    {
        public int idCompany { get; set; }
        public int pricegroup { get; set; }
        public string referenceStartDate { get; set; }
        public string referenceEndDate { get; set; }
    }
}
