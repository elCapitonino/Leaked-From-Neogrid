﻿using MongoDB.Driver;
using Serilog;
using UpdateHash.Models;
using UpdateHashHorus;

namespace UpdateHash.Handlers
{
    public class SmarketHandler
    {
        private readonly MongoClient _client;

        public SmarketHandler(MongoClient client)
        {
            _client = client;
        }

        public async Task ExecuteAsync(string baseName, string collectionName, DateTime startDate, DateTime endDate, int batchSize, bool dryRun = false)
        {
            var database = _client.GetDatabase(baseName);
            var collection = database.GetCollection<SmarketProducts>(collectionName);

            var filter = Builders<SmarketProducts>.Filter.And(
                Builders<SmarketProducts>.Filter.Gte(doc => doc.ImportDate, startDate),
                Builders<SmarketProducts>.Filter.Lte(doc => doc.ImportDate, endDate)
            );

            var projection = Builders<SmarketProducts>.Projection
                .Include(doc => doc.ProdutoDescricao.DESCRICAO)
                .Include(doc => doc.ProdutoEan.EAN)
                .Include(doc => doc.Concorrente.SEQCONCORRENTE);

            int take = batchSize;
            int skip = 0;

            while (true)
            {
                Log.Information("Buscando Produtos");

                var documents = await collection.Find(filter)
                                                 .Sort(Builders<SmarketProducts>.Sort.Descending(doc => doc.ImportDate))
                                                 .Skip(skip)
                                                 .Limit(take)
                                                 .Project<SmarketProducts>(projection)
                                                 .ToListAsync();

                if (documents.Count == 0)
                {
                    break;
                }

                Log.Information("Atualizando Produtos");

                var updates = new List<WriteModel<SmarketProducts>>();

                foreach (var doc in documents)
                {
                    var ean = doc.ProdutoEan.EAN;
                    var seqConcorrente = doc.Concorrente.SEQCONCORRENTE;

                    var concatenatedString = $"{ean}|{seqConcorrente}";

                    var hashValue = Utils.CalculateSHA256(concatenatedString);

                    var filterDoc = Builders<SmarketProducts>.Filter.Eq("_id", doc._id);
                    var update = Builders<SmarketProducts>.Update.Set("HASH", hashValue);
                    updates.Add(new UpdateOneModel<SmarketProducts>(filterDoc, update));
                }

                if (!dryRun)
                    await collection.BulkWriteAsync(updates);

                Log.Information($"Atualizados {skip + take} documentos");

                skip += take;
            }
        }
    }
}
