﻿using DI.API.Utils.Cache;
using DI.Domain.Models;
using System.Diagnostics.CodeAnalysis;

namespace DI.API.IoC
{
    [ExcludeFromCodeCoverage]
    public static class DependencyResolver
    {
        public static void AddDependencyResolver(this IServiceCollection services)
        {
            services.AddAutoMapper();
            services.AddDomain();
            services.AddRepository();
            services.AddTransient<ICurrentUser, CurrentUser>();
            services.AddSingleton<ICacheService, CacheService>();
            services.AddServices();
        }
    }
}
