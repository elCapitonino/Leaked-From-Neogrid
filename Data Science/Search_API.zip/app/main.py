"""
Entrypoint da API.

Para rodar sem uma imagem docker:
python -m uvicorn main:app_search --host 0.0.0.0 --port 8081 --reload
"""

import traceback
from datetime import datetime
from typing import List, Optional

import requests
from fastapi import FastAPI, HTTPException, Request
from fastapi.concurrency import run_in_threadpool
from fastapi.encoders import jsonable_encoder
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from search_history import Search_History
# from search_linx_vem import Search_linx_Vem
from search_nielsen import Search_nielsen

import predimonitor_router
from async_mongo import AsyncMongoConnect, reset_mongo_connection
from config import *
from logger import logger
from mean_larger_smaller import Mean_larger_smaller
from models.getAllDataModelRequest import getAllDataModelRequest
from models.search_v3_models import SearchHistoryV1, SearchProductsPredmonitorBM25, SearchProductsBM25
from predimonitor_type import *
from search_neogrid import Search_neogrid
from search_horus import Search_horus
from search_abv import Search_abv
from restriction_list import RestrictionList
from restriction_search_company import RestrictionSearchCompany
from search_general import Search_general
from search_internal import Search_internal
# from search_linx import Search_linx
from search_predify import Search_predify
from search_v3 import SearchV3
from search_europe_adress import Search_Store_Address
from search_mercantil_nova_era import Search_mercantil_nova_era
from search_infoPrice import Search_infoPrice
from search_linxV2 import SearchLinxV2
from routers import search_v4



# NOTE não apagar, são usadas na função startup
Restriction_list = None
Restriction_search_company = None

app_search = FastAPI(
    title='Search Api',
    version='1.0.0',
    description='funcionando novo deploy')

app_search.include_router(predimonitor_router.router)
app_search.include_router(search_v4.router, tags=["V4"], prefix="/v4")


class List_products(BaseModel):
    id: str
    code: Optional[str] = None
    name: str
    ean: Optional[str] = None
    ncm: Optional[str] = None
    model: Optional[str] = None
    mandatoryTagModel: Optional[str] = None
    brand: Optional[str] = None
    language: Optional[str] = None


class Search_Products(BaseModel):
    start_date: datetime = None
    end_date: datetime = None
    id_company: Optional[int] = None
    idcrawlers_offline: Optional[List[crawlers_offline]] = None
    data_source: Optional[search_source_type] = search_source_type.predify
    products: Optional[List[List_products]] = None
    idcrawlers: Optional[list] = None
    language: Optional[str] = None


class Search_restriction(BaseModel):
    id_company: Optional[int] = None
    list_restriction: Optional[list] = None
    update_list: Optional[bool] = None


@app_search.on_event("startup")
async def startup():
    reset_mongo_connection()  # deve ser o primeiro passo, inicia conexção com Mongo
    global Restriction_list
    global Restriction_search_company
    # NOTE iniciadas aqui após reset_mongo_connection ser chamada
    Restriction_search_company = RestrictionSearchCompany()
    Restriction_list = RestrictionList()
    await Restriction_list.load_restriction()
    await Restriction_search_company.load_company()


@app_search.post("/")
def raiz(products: List[Search_Products]):

    return {"teste"}

#####################


@app_search.get("/ean_sync")
def ean_sync():
    # search_linx = Search_linx()
    # search_linx.ean_sync()

    return "ok"

    #########################################


@app_search.get("/v2/getCategories/")
async def getCategoriesDictionaries(language: str):
    db_mongo = AsyncMongoConnect()
    return await db_mongo.get_categories(language)


@app_search.get("/v2/getBrands/")
async def getBrandsDictionaries(language: str):
    db_mongo = AsyncMongoConnect()
    return await db_mongo.get_brands(language)


@app_search.get("/v2/getProducts/")
async def getProductsV2(filter: str):
    db_mongo = AsyncMongoConnect()
    return await db_mongo.get_linx_products(filter)


@app_search.post("/v2/search/")
async def search(products: Search_products_predmonitor):
    try:
        if (products.data_source == search_source_type.predify or products.data_source == search_source_type.Horus_search):
            search_predify = Search_predify()
            newdata = await search_predify.search(products)
            return newdata
        elif (products.data_source == search_source_type.linx):
            return []
            search_linx = Search_linx()
            #Verifica se existe a pesquisa feita no cache
            cache = await search_linx.get_itens_memory_cache(products)
            if(cache != None and len(cache['product_list']) > 0):
                #Caso exista a mesma pesquisa no cache retorna os produtos 
                products_list = cache['product_list']
                return products_list
            else:
                products_linx = await run_in_threadpool(lambda: search_linx.search(products))
                if(products_linx != None and len(products_linx[0]['result']) > 0):
                    #Se a pesquisa feita não exista é enviada nesse momento
                    await search_linx.sent_memory_cache(products, products_linx)
                return products_linx
        
        elif (products.data_source == search_source_type.Nielsen):
            search_nielsen = Search_nielsen()
            return await search_nielsen.search_get_v2(products)

        # elif(products.data_source == search_source_type.Horus_search):
        #     search_predify = Search_predify()
        #     return await search_predify.search(products)

    except Exception as ex:
        return HTTPException(status_code=500, detail=str(ex))


@app_search.post("/v2/search_masked_seller/")
async def search_masked_seller(products: SearchProductsPredmonitorBM25):
    #endpoint neogrig - ecoa
    try:
        request = []
        search_neogrid = Search_neogrid()
        neogrid = await search_neogrid.search_get_v2(products)
        request.extend(neogrid)

        #search_vector = SearchV3()
        #newdata = await search_vector.search_v2(products, cache=products.cache)
        #if (newdata != None and len(newdata) > 0):
        #    resquest.extend(newdata)

        return request
    except Exception as ex:
        return HTTPException(status_code=500, detail=str(ex))

##########################################


@ app_search.post("/v1/search/")
async def search(products: Search_Products, request: Request):
    print("iniciando apliccao")
    print("logando request ")
    print(jsonable_encoder(products))

    try:
        Search_g = Search_general()
        retorno = await Search_g.search_general(products)
        # print('result:',jsonable_encoder(retorno))

        return retorno

    except Exception as ex:
        print("Error:", str(ex))
        return HTTPException(status_code=500, detail=str(ex))


@app_search.post("/v1/search_mean_larger_smaller/")
async def search_mean_larger_smaller(products: Search_Products, request: Request):

    try:
        for i in products.products:
            if i.language == None or i.language == "" or "language" not in i.language:
                i.language = products.language

        resp = requests.post(url=url_normalizer,
                             json=jsonable_encoder(products.products))

        data_resp = resp.json()
        search_mls = Mean_larger_smaller()
        result_busca = await search_mls.mean_larger_smaller(
            data_resp, products.start_date, products.end_date, products.idcrawlers)

        return result_busca

    except Exception as ex:
        print("Error:", ex)
        return HTTPException(status_code=500, detail=ex)


@app_search.post("/v1/search_internal/")
async def search_internal(products: Search_Products, request: Request):

    try:
        for i in products.products:
            if i.language == None or i.language == "" or "language" not in i.language:
                i.language = products.language

        resp = requests.post(url=url_normalizer,
                             json=jsonable_encoder(products.products))

        data_resp = resp.json()

        search_i = Search_internal()
        result_busca = await search_i.get_products_internal(
            data_resp, products.start_date, products.end_date, products.idcrawlers)

        return result_busca

    except Exception as ex:
        print("Error:", ex)
        return HTTPException(status_code=500, detail=ex)


@app_search.post("/v1/search_restriction/")
async def search_restriction(products: Search_restriction, request: Request):

    Restriction_list = RestrictionList()
    result = await Restriction_list.update_restriction(
        products.id_company, products.list_restriction, products.update_list)

    return result


@app_search.post("/v3/search/v1")
async def search_v3_v1(body: SearchProductsBM25):
    nielsen_result = []
    extra_result = []

    if body.data_source == search_source_type.Linx_Farma_Sellout:
        search_linxv2 = SearchLinxV2()
        result = await search_linxv2.search_get_v1_farma_sellout(body)
        return result

    if (body.data_source == search_source_type.Horus_search):
        search_horus = Search_horus()
        return await search_horus.search_get_V1_Peralta(body)
    
    if (body.data_source == search_source_type.Nielsen):
        body.data_source = search_source_type.predify

        search_nielsen = Search_nielsen()
        nielsen_result = await search_nielsen.search_get_V1(body)

        search_horus = Search_horus()
        horus_result = await search_horus.search_get_V1_Peralta(body)
        nielsen_result.extend(horus_result)

        return nielsen_result
    
    if (body.data_source == search_source_type.Nielsen_vem):
        body.data_source = search_source_type.predify
        search_nielsen = Search_nielsen()
        # nielsen_result =  await search_nielsen.search_get_V1(body)
        return await search_nielsen.search_get_V1_vem(body)
    
    if (body.data_source == search_source_type.Linx_Vem):
        search_linx_vem = Search_linx_Vem()
        return await search_linx_vem.search_linx_vem(body)

    if (body.data_source == search_source_type.Mercantil_Nova_Era):
        search_mercantil_nova_era = Search_mercantil_nova_era()
        return await search_mercantil_nova_era.search_get_V1_mercantil_nova_era(body)

    if (body.data_source == search_source_type.Demo_Varejo):
        body.data_source = search_source_type.predify
        search_horus = Search_horus()
        nielsen_result = await search_horus.search_get_V1_Peralta(body)

    if (body.data_source == search_source_type.ABV):
        search_abv = Search_abv()
        extra_result = await search_abv.search_get_v1(body)

    if (body.data_source == search_source_type.Sao_Joao_InfoPrice):
        search_infoPrice = Search_infoPrice()
        return await search_infoPrice.search_get_V1(body)

    if body.start_date >= body.end_date:
        raise ValueError("start_date deve ser anterior a end_date")

    # if body.data_source == search_source_type.Nielsen:
    #    body.data_source = search_source_type.predify

    predify_result = []
    if (body.data_source == search_source_type.predify):
        search_vector = SearchV3()

        # ajuste fujioka homologacao, para pegar os mesmo produtos na bm25
        if body.id_company == 2806:
            body.id_company = 2652

        if (
            body.monitoring_item_date_filter is not None
            and body.start_date.date() > body.monitoring_item_date_filter.date()
        ):
            predify_result = await search_vector.search_v1_by_monitoring_id(body, cache=body.cache)
        else:
            predify_result = await search_vector.search_v1(body, cache=body.cache)

    predify_result.extend(nielsen_result)
    predify_result.extend(extra_result)
    return predify_result


@app_search.post("/v3/search/v2")
async def search_v3_v2(body: SearchProductsPredmonitorBM25):
    nielsen_result = []
    search_vector = SearchV3(
        europe_products=body.data_source == search_source_type.Europe_products
    )

    if body.data_source == search_source_type.Linx_Farma_Sellout:
        search_linxv2 = SearchLinxV2()
        result = await search_linxv2.search_get_v2_farma_sellout(body)
        return result

    if body.data_source == search_source_type.Horus_search:
        search_horus = Search_horus()
        result = await search_horus.search_get_V2(body)
        return result

    if body.data_source == search_source_type.Nielsen_vem:
        eans = []
        id_crawlers = []
        if (body.filters.eans is not None and len(body.filters.eans) > 0):
            for i in body.filters.eans:
                if i.description in body.filters.products:
                    eans.append(i)
            for i in body.idcrawlers_offline:
                id_crawlers.append(i.idcrawlers)
        body.filters.eans = eans
        body.idcrawlers = id_crawlers

        search_nielsen = Search_nielsen()
        return await search_nielsen.search_get_v2_vem(body)

    if body.data_source == search_source_type.Nielsen:
        body.data_source = search_source_type.predify

        search_horus = Search_horus()
        result = await search_horus.search_get_V2(body)

        predify_result = await _search_v3_predify(search_vector, body)
        result.extend(predify_result)

        search_nielsen = Search_nielsen()
        nielsen_result = await search_nielsen.search_get_v2_peralta(body)
        result.extend(nielsen_result)

        return result

    if body.data_source == search_source_type.Mercantil_Nova_Era:
        search_mercantil_nova_era = Search_mercantil_nova_era()
        return await search_mercantil_nova_era.search_get_V2_mercantil_nova_era(body)

    if body.data_source == search_source_type.VEM_Distribuidores:
        result = []
        predify_result = await _search_v3_predify(search_vector, body)
        result.extend(predify_result)

        search_neogrid = Search_neogrid()
        predify_neogrid = await search_neogrid.search_get_Ecoa_v3v2(body)
        result.extend(predify_neogrid)

        result.extend(await search_neogrid.search_get_indireta_v3_v2(body))

        return result

    if body.data_source == search_source_type.Demo_Varejo:
        search_horus = Search_horus()
        result = await search_horus.search_get_V2(body)

        predify_result = await _search_v3_predify(search_vector, body)
        result.extend(predify_result)

        return result

    if (body.data_source == search_source_type.ABV):
        result = []
        search_abv = Search_abv()
        result_abv= await search_abv.search_get_v2(body)
        result.extend(result_abv)
        
        return result

    if (body.data_source == search_source_type.Sao_Joao_InfoPrice):
        result = []
        search_infoPrice = Search_infoPrice()
        result_infoPrice= await search_infoPrice.search_get_V2(body)
        result.extend(result_infoPrice)
				        
        return result

    filters = body.dict().get("filters") or {}
    product_names = filters.pop("products", None)
    if not product_names:
        raise ValueError("products precisa ser fornecido no array filters")

    if not body.idcrawlers:
        raise ValueError("idcrawlers precisa ser fornecido")

    if body.start_date >= body.end_date:
        raise ValueError("start_date deve ser anterior a end_date")

    predify_result = []
    if body.data_source in (search_source_type.predify, search_source_type.Europe_products):
        predify_result = await _search_v3_predify(search_vector, body)

    predify_result.extend(nielsen_result)

    return predify_result


@app_search.post("/v3/search/v2_cost")
async def search_v3_v2_cost(body: SearchProductsPredmonitorBM25):
    predify_result = []
    id_crawlersModel = body.idcrawlers
    try:
        if body.data_source == search_source_type.Nielsen_vem:
            search_neogrid = Search_neogrid()
            result = await search_neogrid.search_get_Ecoa_v3v2(body)
            predify_result.extend(result)

            # indireta
            result = await search_neogrid.search_get_indireta_v3_v2(body)
            predify_result.extend(result)

            # horus
            search_horus = Search_horus()
            result = await search_horus.search_get_V2_cost(body)
            predify_result.extend(result)

            body.data_source = search_source_type.predify

        if body.data_source == search_source_type.VEM_Distribuidores:
            search_neogrid = Search_neogrid()
            result = await search_neogrid.search_get_Ecoa_v3v2(body)
            predify_result.extend(result)

            # indireta
            result = await search_neogrid.search_get_indireta_v3_v2(body)
            predify_result.extend(result)

            # horus
            search_horus = Search_horus()
            result = await search_horus.search_get_V2_cost(body)
            predify_result.extend(result)

            body.data_source = search_source_type.predify

        if body.data_source == search_source_type.Demo_Varejo:
            search_horus = Search_horus()
            result = await search_horus.search_get_V2_cost(body)
            predify_result.extend(result)
            
            body.data_source = search_source_type.predify

        if body.data_source == search_source_type.Horus_search:
            search_horus = Search_horus()
            result = await search_horus.search_get_V2_cost(body)
            predify_result.extend(result)

        if body.data_source == search_source_type.Nielsen:
            search_horus = Search_horus()
            result = await search_horus.search_get_V2_cost(body)
            predify_result.extend(result)
                
            body.data_source = search_source_type.predify

        filters = body.dict().get("filters") or {}
        product_names = filters.pop("products", None)

        if product_names and body.idcrawlers and body.start_date <= body.end_date:
            search_vector = SearchV3(
                europe_products=body.data_source == search_source_type.Europe_products
            )
            if body.data_source in (search_source_type.predify, search_source_type.Europe_products):
                body.idcrawlers = id_crawlersModel
                predify_result.extend(await _search_v3_predify(search_vector, body))

        return predify_result
    
    except Exception as ex:
        traceback.print_exception(ex, limit=50)
        logger.error("search V3/V2 - Cost failed: %s", ex)
        return HTTPException(status_code=500, detail=str(ex))


async def _search_v3_predify(search_obj: SearchV3, request: SearchProductsPredmonitorBM25):
    if (
        request.monitoring_item_date_filter is not None
        and request.start_date.date() > request.monitoring_item_date_filter.date()
    ):
        return await search_obj.search_v2_by_monitoring_id(request, cache=request.cache)

    return await search_obj.search_v2(request, cache=request.cache)


@app_search.post("/v3/search/netshoes")
async def search_v3_netshoes(body: SearchProductsPredmonitorBM25):
    try:
        filters = body.dict().get("filters") or {}
        product_names = filters.pop("products", None)
        if not product_names:
            raise ValueError("products precisa ser fornecido no array filters")

        if not body.idcrawlers:
            raise ValueError("idcrawlers precisa ser fornecido")

        for field_name, field in filters.items():
            if not isinstance(field, list) or len(field) == 0:
                continue
            if len(field) != len(product_names):
                raise ValueError(
                    f"o campo {field_name} deve ter o mesmo número de elementos do campo products no array filters"
                )

        if body.start_date >= body.end_date:
            raise ValueError("start_date deve ser anterior a end_date")

        if (body.data_source == search_source_type.predify):
            search_vector = SearchV3(netshoes=True)
            return await search_vector.search_v2(body, cache=body.cache)
        raise ValueError(f"data_source not supported: {body.data_source}")

    except Exception as ex:
        traceback.print_exception(ex, limit=50)
        logger.error("search V3/V2 - Netshoes failed: %s", ex)
        return HTTPException(status_code=500, detail=str(ex))


@app_search.post("/v1/getAll")
async def getAllData(params: getAllDataModelRequest):
    try:
        search_predify = Search_general()

        if params.database == 'netshoes':
            retorno = await search_predify.search_get_all_netshoes(params)
        else:
            retorno = await search_predify.search_get_all(params)

        return JSONResponse(content=retorno)
    except Exception as ex:
        return HTTPException(status_code=500, detail=str(ex))


@ app_search.get("/v2/linx_test/")
async def linx_test():
    return None
    # search_linx = Search_linx()
    # return search_linx.test_connection()

@app_search.get("/get_all_addresses/")
async def getAllAddresses():
    search_addresses = Search_Store_Address()
    result = await search_addresses.get_lidl_addresses()
    return result

@app_search.post("/v1/searchHistory")
async def getSearchHistory(params: SearchHistoryV1):
    try:
        search_predify = Search_History()

        if (params.data_source == search_source_type.predify):
            retorno = await search_predify.search_get_all_by_link(params)
        ##else:
           ##retorno = await search_predify.search_get_all(params)

        return retorno
    except Exception as ex:
        return HTTPException(status_code=500, detail=str(ex))