"""
Módulo para processamento e limpeza de strings.
"""

import re
from html import unescape
from unicodedata import normalize
from typing import List

from nltk.corpus import stopwords


class Processing:

    def __init__(self, aspas=False):
        self.aspas = aspas
        self.stopwords = set(stopwords.words('portuguese'))
        self.stopwords_en = set(stopwords.words('english'))
        self.regex_limpeza = re.compile(r'nan[^\w]+|-|_')

    def limpeza(self, texto: str) -> str:
        return self.regex_limpeza.sub('', texto)

    def tokenizador(self, texto: str) -> List[str]:
        """Separa as palavras em tokens."""
        # return re.findall(r'[\w]+', texto)
        return texto.split()

    def remover_stopwords(self, texto_tokenizado: List[str], language: str) -> List[str]:
        if language == 'pt-br':
            return [t for t in texto_tokenizado if t not in self.stopwords]
        elif language == 'en-us':
            return [t for t in texto_tokenizado if t not in self.stopwords_en]
        else:
            return [t for t in texto_tokenizado if t not in self.stopwords]

    def normalizador(self, texto: str) -> str:
        """Remove acentuação. Codifica em bytes e decodifica em string."""
        texto = texto.lower()
        return normalize('NFKD', texto).encode('latin-1', 'ignore').decode('latin-1')

    def run(self, texto: str, language: str) -> str:
        # decodificar caracteres codificados em HTML
        texto = unescape(texto)
        # excluir dados faltantes
        texto = self.limpeza(texto)
        # letra minúscula
        texto = texto.lower()

        # separar palavras
        texto_tokenizado = self.tokenizador(texto)
        #print(texto_tokenizado ," -------- " ,textooriginal)

        # remover stopwords
        texto_tokenizado = self.remover_stopwords(texto_tokenizado, language)
        #print(texto_tokenizado ," -------- " ,textooriginal)

        # agrupar palavras com espaço
        texto = " ".join(texto_tokenizado)
        #print(texto ," -------- " ,textooriginal)

        # remove acentuação
        texto = self.normalizador(texto)

        #print(textooriginal ," -------- " ,texto)
        # texto = texto.replace(",", "")
        # texto = texto.replace(".", "")
        #texto = texto.replace("110", "")

        return texto.replace(",", ".")
