﻿namespace DI.Repository.Entities
{
    public sealed class ProjectionImpactImportStatusEntity : BaseEntity
    {
        public long CompanyId { get; set; }
        public string? Status { get; set; }
        public DateTime? startDateRequest { get; set; }
        public DateTime? endDateRequest { get; set; }
        public long? PriceGroupId { get; set; }
    }
}
