from predimonitor_type import *
from async_mongo import AsyncMongoConnect

#Class da Nielsen
class Search_nielsen():

    def __init__(self):
        self.dbMongo = AsyncMongoConnect()

    def search_get(self, id_crawlers_offline, data_source, products, start_date, end_date):

        result_list = []

        return result_list
    async def search_get_V1_vem(self, products):
        full_result = []
        result_list = []

        states = None
        if (products.idcrawlers_offline is not None):
            states = [obj.state for obj in products.idcrawlers_offline]
            states = list(filter(lambda x: x is not None and x !=
                          '' and x.strip() != '', states))
            
            
        store_type = None
        if (products.idcrawlers_offline is not None):
            store_type = [obj.store_type for obj in products.idcrawlers_offline]
            store_type = list(filter(lambda x: x is not None and x !=
                          '' and x.strip() != '', store_type))

        ean = None
        start_date = products.start_date
        end_date = products.end_date
        if products is None or products.products[0].ean is None or not products.products[0].ean:
            return []

        ean = products.products[0].ean
        try:
            result_nielsen = await self.dbMongo.get_product_search_nielsen_vem_by_ean(start_date, end_date, ean, states, store_type)

            for documento in result_nielsen:
                try:
                    item = documento["documento"]
                    name = item['PRODUCT_DESCRIPTION']
                    result_list.append({
                        'id': str(item['_id']),
                        'id_crawler': 266,
                        "product_name": name,
                        "product_link": item['EAN']+item['STORE']+item['STATE_UF'],
                        "product_ean": item['EAN'],
                        "site_sku": 0,
                        "source": "Nielsen Vem",
                        "language": "pt-br",
                        "product_brand": item['BRAND'],
                        "id_product_normalized": None,
                        "trash_score": 0,
                        "crawler_date": item["DATE"],
                        "sellers": [
                            {
                                "seller_name": item["STORE_NAME"],
                                "format_market": item.get("FORMAT_MARKET"),
                                "coordinates": {
                                    "longitude": item['coordinates']['coordinates'][0],
                                    "latitude": item['coordinates']['coordinates'][1],
                                } if 'coordinates' in item and 'coordinates' in item['coordinates'] and len(item['coordinates']['coordinates']) == 2 else None,
                                "prices":[
                                    {
                                        'price': str(item['WEEKLY_PRICE']),
                                        "price_currency": "BRL"
                                    }
                                ]
                            }
                        ],
                        "product_local":
                            {
                                'state': item['STATE_UF'],
                                'city': item['CITY']
                            },
                        "product_manufacture_year": None,
                        "product_used_hours": None
                    })
                except Exception as ex:
                    print(" ------ Erro dados Nielsen Inner  ------")
                    print(str(ex))

            full_result.append({
                "name": products.products[0].name,
                "results": result_list
            })

        except Exception as ex:
            print(" ------ Erro dados Nielsen  ------")
            print(str(ex))

        return full_result
    
    async def search_get_V1(self, products):
        full_result = []
        result_list = []

        states = None
        stores = None
        if (products.idcrawlers_offline is not None):
            states = [obj.state for obj in products.idcrawlers_offline]
            states = list(filter(lambda x: x is not None and x !=
                          '' and x.strip() != '', states))
            
            stores = [obj.store for obj in products.idcrawlers_offline]
            stores = list(map(int, filter(lambda x: x is not None and x !=
                          '' and x.strip() != '', stores)))

        ean = None
        start_date = products.start_date
        end_date = products.end_date
        if products is None or products.products[0].ean is None or not products.products[0].ean:
            return []

        ean = products.products[0].ean
        try:
            result_nielsen = await self.dbMongo.get_product_search_nielsen_by_ean(start_date, end_date, ean, states, stores)

            for documento in result_nielsen:

                item = documento["documento"]
                name = item['PRODUCT_DESCRIPTION']
                result_list.append({'id': str(item['_id']),
                                    'id_crawler': 255,
                                    "product_name": name,
                                    "product_link": item['EAN']+item['STORE']+item['STATE_UF'],
                                    "product_ean": item['EAN'],
                                    "site_sku": 0,
                                    "source": "Nielsen",
                                    "language": "pt-br",
                                    "product_brand": item['BRAND'],
                                    "id_product_normalized": None,
                                    "trash_score": 0,
                                    "crawler_date": item["DATE"],
                                    "sellers": [
                    {"seller_name": item["STORE_NAME"],
                     "prices":[{
                         'price': str(item['WEEKLY_PRICE']),
                         "price_currency": "BRL"
                     }]
                     }],
                    "product_local":
                    {'state': item['STATE_UF'],
                     'city': item['STORE']},
                    "product_manufacture_year": None,
                    "product_used_hours": None
                })

            full_result.append({
                "name": products.products[0].name,
                "results": result_list
            })

        except Exception as ex:
            print(" ------ Erro dados Nielsen  ------")
            print(str(ex))

        return full_result

    async def search_get_v2_vem(self, products):
        """Busca base Nielsen para a Vem
        Args:
            products (_type_): conjunto de argumentos para a busca
                            start_date
                            end_date
                            eans
                            products
                            idcrawlers_offline
                            local_states

        Returns:
            _type_: resultado da busca no mongoDB
        """
        ean_where = []
        start_date = ""
        end_date = ""
        full_result = []
        lista_result = []
        result_list = []

        if (products.filters.eans is not None and len(products.filters.eans) != 0):
            for i in products.filters.eans:
                # if (i.description in products.filters.products):
                ean_where.append(i.ean)

            # ean_where = ean_where[:-4]

        if (products.start_date is not None and products.end_date is not None):
            start_date = products.start_date
            end_date = products.end_date

        # data=2022-09-11 23:59:56,
        # print('========================================')
        # print('products', products['idcrawlers_offline'])

        states = None
        # if (products.idcrawlers_offline is not None):
        #     states = [obj.state for obj in products.idcrawlers_offline]
        #     states = list(filter(lambda x: x is not None and x !=
        #                   '' and x.strip() != '', states))
        if (products.filters.local_states is not None):
            states = products.filters.local_states
            states = list(filter(lambda x: x is not None and x !=
                          '' and x.strip() != '', states))

        store_type = None
        if (products.idcrawlers_offline is not None):
            store_type = [obj.store_type for obj in products.idcrawlers_offline]
            store_type = list(filter(lambda x: x is not None and x !=
                          '' and x.strip() != '', store_type))
            
        t_brand = products.filters.brands
        t_categories = products.filters.categories
        t_sellers = products.filters.sellers

        try:
            if (ean_where is not None and ean_where and start_date != "" and end_date != ""):
                for ean in ean_where:
                    result_ean = await self.dbMongo.get_product_search_nielsen_by_ean_v2_vem(start_date, end_date, ean, states, store_type, t_brand, t_categories, t_sellers)
                    if (result_ean is not None):
                        lista_result.append(result_ean)

            for documento in lista_result[0]:
                try:
                    item = documento
                    name = item['PRODUCT_DESCRIPTION']
                    result_list.append({
                        'id': str(item['_id']),
                        'id_crawler': 266,
                        "product_name": name,
                        "product_link": item['EAN']+item['STORE']+item['STATE_UF'],
                        "product_ean": item['EAN'],
                        "site_sku": 0,
                        "source": "Nielsen",
                        "language": "pt-br",
                        "product_brand": item['BRAND'],
                        "id_product_normalized": None,
                        "trash_score": 0,
                        "crawler_date": item["DATE"],
                        "seller_name": item["STORE_NAME"],
                        "format_market": item.get("FORMAT_MARKET"),
                        "coordinates": {
                            "longitude": item['coordinates']['coordinates'][0],
                            "latitude": item['coordinates']['coordinates'][1],
                        } if 'coordinates' in item and 'coordinates' in item['coordinates'] and len(item['coordinates']['coordinates']) == 2 else None,
                        "prices": [
                            {
                                'price': str(item['WEEKLY_PRICE'])
                            }
                        ],
                        "product_local":
                        {
                            'state': item['STATE_UF'],
                            'city': item['CITY']
                        },
                        "product_manufacture_year": None,
                        "product_used_hours": None
                    })
                
                except Exception as ex:
                    print(" ------ Erro dados Nielsen V2 Inner  ------")
                    print(str(ex))
                    
            full_result.append({
                "product": ean_where[0],
                "result": result_list
            })

        except Exception as ex:
            print(" ------ Erro dados Nielsen V2  ------")
            print(str(ex))
        print(" ------ Fim dados Nielsen V2  ------")
        return full_result

    async def search_get_v2_peralta(self, products):
        ean_where = []
        start_date = ""
        end_date = ""
        full_result = []
        lista_result = []
        result_list = []
        print(products.filters.local_states)

        if (products.filters.eans is not None and len(products.filters.eans) != 0):
            for i in products.filters.eans:
                # if (i.description in products.filters.products):
                ean_where.append(i.ean)

            # ean_where = ean_where[:-4]

        if (products.start_date is not None and products.end_date is not None):
            start_date = products.start_date
            end_date = products.end_date

        # data=2022-09-11 23:59:56,
        # print('========================================')
        # print('products', products['idcrawlers_offline'])

        states = None
        stores = None
        if (products.idcrawlers_offline is not None):
            states = [obj.state for obj in products.idcrawlers_offline]
            states = list(filter(lambda x: x is not None and x !=
                                 '' and x.strip() != '', states))

            stores = [obj.store for obj in products.idcrawlers_offline]
            stores = list(map(int, filter(lambda x: x is not None and x !=
                          '' and x.strip() != '', stores)))

        t_brand = products.filters.brands
        t_categories = products.filters.categories
        t_sellers = products.filters.sellers

        try:
            if (ean_where is not None and len(ean_where) > 0 and start_date != "" and end_date != ""):
                for ean in ean_where:
                    result_ean = await self.dbMongo.get_product_search_nielsen_by_ean_v2(start_date, end_date, ean, states, stores, t_brand, t_categories, t_sellers)
                    if (result_ean is not None):
                        lista_result.append(result_ean)

            for documento in lista_result[0]:
                item = documento
                name = item['PRODUCT_DESCRIPTION']
                result_list.append({'id': str(item['_id']),
                                    'id_crawler': 255,
                                    "product_name": name,
                                    "product_link": item['EAN']+item['STORE']+item['STATE_UF'],
                                    "product_ean": item['EAN'],
                                    "site_sku": 0,
                                    "source": "Nielsen",
                                    "language": "pt-br",
                                    "product_brand": item['BRAND'],
                                    "id_product_normalized": None,
                                    "trash_score": 0,
                                    "crawler_date": item["DATE"],
                                    "seller_name": item["STORE_NAME"],
                                    "prices": [{'price': str(item['WEEKLY_PRICE'])}],
                                    "product_local":
                                    {'state': item['STATE_UF'],
                                     'city': item['STORE']},
                                    "product_manufacture_year": None,
                                    "product_used_hours": None
                                    })

            full_result.append({
                "product": item['EAN'],
                "result": result_list
            })

        except Exception as ex:
            print(" ------ Erro dados Nielsen V2  ------")
            print(str(ex))
        print(" ------ Fim dados Nielsen V2  ------")
        return full_result
