﻿using DI.Repository.Enum;

namespace DI.Domain.ValueObjects
{
    /// <summary>
    /// Esta classe contém os dados para UMA tabela dentro de um worksheet do excel para o relatório de impacto
    /// </summary>
    public class ImpactReportTable
    {
        public string Header { get; set; }
        public string[] SubHeaders { get; set; }
        public string[] NumberValueFormats { get; set; }
        public EConditionGenerateDataTableType Type { get; set; }

        public IEnumerable<ImpactReportTableLine> Lines { get; set; }
    }

    public class ImpactReportTableLine
    {
        public string? Value { get; set; }
        public decimal? BeforeIA { get; set; }
        public decimal? Projection { get; set; }
        public decimal? AfterIA { get; set; }
        public decimal? DifferentPredifyXCompany { get; set; }
        public decimal? Variation { get; set; }
        public EConditionGenerateDataTableType Type { get; set; }
    }

}
