﻿using Newtonsoft.Json;
using PredifyClientAPI.Services.PredifyAPI.Models;
using PredifyClientAPI.Services.PredifyAPI.PriceGroup.Models;
using System.Text;

namespace PredifyClientAPI.Services.PredifyAPI.PriceGroup
{
    public class PriceGroupService : IPriceGroupService
    {
        private readonly HttpClient _client;

        public PriceGroupService(HttpClient client)
        {
            _client = client;
        }

        public async Task<GeneralResponse<List<EnterpriseListGroupsResponse>>> List(EnterpriseListGroupsRequest request)
        {
            string jsonPayload = JsonConvert.SerializeObject(request);

            StringContent payload = new StringContent(jsonPayload, Encoding.UTF8, "application/json");

            var response = await _client.PostAsync($"/api/v2/Enterprise/PriceGroups/List", payload);
            var content = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
                return JsonConvert.DeserializeObject<GeneralResponse<List<EnterpriseListGroupsResponse>>>(content);
            else if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                throw new UnauthorizedAccessException();

            throw new Exception(content);
        }
    }
}
