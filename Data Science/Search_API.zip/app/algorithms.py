import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from sklearn.metrics.pairwise import cosine_similarity
from rank_bm25 import BM25Okapi


class Algorithm:

    def __init__(self):
        pass

    def process_tfidf_similarity(self, base_document, documents):
        # tratamento de caps

        documents2 = []
        for d in documents:
            documents2.append(d.strip())

        vectorizer = TfidfVectorizer()

        # To make uniformed vectors, both documents need to be combined first.
        documents.insert(0, base_document)

        embeddings = vectorizer.fit_transform(documents)

        # caso de busca simples
        cosine = list(cosine_similarity(
            embeddings[0:1], embeddings[1:]).flatten())

        # caso de busca múltipla
        #cosine = float(cosine_similarity(embeddings[0:1], embeddings[1:]).flatten())

        return cosine

    def process_bm25_similarity(self, base_document, documents):
        # tratamento de caps

        base_document = base_document.lower()

        base_document = base_document.split()
        # print(f'base document : {base_document}')
        #base_document = " ".join(list2)

        documents2 = []

        if len(documents) == 0:
            return []

        else:

            for d in documents:
                d = d.lower()
                word2 = d.split()
                documents2.append(word2)

            bm25 = BM25Okapi(documents2)

            #print('Iniciando scores')
            doc_scores = list(bm25.get_scores(base_document))
            #bm25.get_top_n(base_document,documents2, n=10)

            return doc_scores

    def cossine(self, X, Y):

        X = X.lower()
        Y = Y.lower()

        # tokenization
        X_list = word_tokenize(X)
        Y_list = word_tokenize(Y)

        # sw contains the list of stopwords
        sw = stopwords.words('portuguese')
        l1 = []
        l2 = []

        # remove stop words from the string
        X_set = {w for w in X_list if not w in sw}
        Y_set = {w for w in Y_list if not w in sw}

        # form a set containing keywords of both strings
        rvector = X_set.union(Y_set)
        for w in rvector:
            if w in X_set:
                l1.append(1)  # create a vector
            else:
                l1.append(0)
            if w in Y_set:
                l2.append(1)
            else:
                l2.append(0)
        c = 0

        # print(l1,l2)
        # cosine formula
        for i in range(len(rvector)):
            c += l1[i]*l2[i]
        # print(c)
        cosine = c / float((sum(l1)*sum(l2))**0.5)
        #print("similarity: ", cosine)

        return cosine
