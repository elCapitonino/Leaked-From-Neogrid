﻿using Domain.IndexGenerator.Models;

namespace Domain.IndexGenerator.DataSourceDomains.Interfaces
{
    public interface IIndexGeneratorNielsenPeraltaDomain
    {
        Task GenerateIndexAsync(long companyId, int crawlerId, IEnumerable<MonitoringItemTags> monitoringItems, DateTime startDate, DateTime endDate, IEnumerable<string?> stores, IEnumerable<string?> states, Guid? taskId, List<long> monitoringResultIdsDelete);
    }
}
