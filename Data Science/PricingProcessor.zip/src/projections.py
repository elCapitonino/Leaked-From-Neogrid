from collections import defaultdict
from datetime import date, datetime
from typing import Any, NamedTuple, Optional

import pandas as pd
from sqlalchemy import (
    Column,
    MetaData,
    String,
    Table,
    and_,
    bindparam,
    case,
    func,
    select,
    text,
)

from src.db import PostgreSQLConnection, SQLServerConnection
from src.exceptions import ConsistencyError
from src.logger import logger
from src.utils import ADOPTION_TOLERANCE_PCT, build_product_id

MAP_SALES_HISTORY_PRICES_PROJECTION = {
    "Description": "ProductName",
}
MAP_PRICES_PROJECTION_SALES_HISTORY = {
    v: k for k, v in MAP_SALES_HISTORY_PRICES_PROJECTION.items()
}


def read_price_groups(
    *,
    conn: SQLServerConnection,
    metadata: MetaData,
    id_company: int,
    initial_date: date,
    final_date: Optional[date] = None,
):
    table_price_groups = Table("Enterprise_Price_Groups", metadata, autoload_with=conn)

    stmt = select(table_price_groups.c.IdEnterprisePriceGroups).where(
        table_price_groups.c.IdCompany == id_company,
        table_price_groups.c.IsDeletado == 0,
        table_price_groups.c.CalcDate.isnot(None),
        table_price_groups.c.PublishedDate >= initial_date,
        table_price_groups.c.Published == 1,
    )

    if final_date is not None:
        stmt = stmt.where(table_price_groups.c.PublishedDate < final_date)

    logger.debug(
        "reading price groups with query:\n%s\nparams: %s", stmt, stmt.compile().params
    )
    df_groups = pd.read_sql_query(stmt, conn)
    return df_groups


def get_price_group_info(
    *,
    conn: SQLServerConnection,
    metadata: MetaData,
    granularity: list[str],
    id_company: int,
    id_price_group: int,
) -> Optional[pd.DataFrame]:
    table_prices_projection = Table(
        "Enterprise_Prices_Projection", metadata, autoload_with=conn
    )
    table_workflow = Table(
        "EnterprisePriceProjection_Workflow", metadata, autoload_with=conn
    )
    table_workflow_action = Table(
        "EnterprisePriceProjection_WorkflowAction", metadata, autoload_with=conn
    )

    gran_columns = [
        table_prices_projection.c[MAP_PRICES_PROJECTION_SALES_HISTORY.get(col, col)]
        for col in granularity
    ]
    # NOTE join para eliminar projeções que não passaram pelas regras
    stmt = (
        select(*gran_columns)
        .where(
            table_prices_projection.c.IdEnterprisePriceGroups == id_price_group,
            table_prices_projection.c.IsDeletado == 0,
        )
        .join(
            table_workflow,
            table_prices_projection.c.IdEnterprisePricesProjection
            == table_workflow.c.IdEnterprisePriceProjection,
        )
        .join(
            table_workflow_action,
            table_workflow.c.IdLastAction
            == table_workflow_action.c.IdEnterprisePriceProjection_WorkflowAction,
        )
    )
    df = pd.read_sql(stmt, conn)
    if df.empty:
        logger.info(
            "no price_group found with ID %d and id_company %d",
            id_price_group,
            id_company,
        )
        return None

    df["ProductId"] = build_product_id(df, granularity)
    df["PublishedDate"] = get_published_date(
        conn=conn,
        metadata=metadata,
        id_company=id_company,
        id_price_group=id_price_group,
    )
    df["CompanyId"] = id_company
    df["PriceGroupId"] = id_price_group
    logger.debug("%d product_ids in price_group %d", df.shape[0], id_price_group)
    return df


def get_published_date(
    *,
    conn: SQLServerConnection,
    metadata: MetaData,
    id_company: int,
    id_price_group: int,
) -> Optional[datetime]:
    table_price_groups = Table("Enterprise_Price_Groups", metadata, autoload_with=conn)
    stmt = select(table_price_groups.c.PublishedDate).where(
        table_price_groups.c.IdEnterprisePriceGroups == id_price_group,
        table_price_groups.c.IdCompany == id_company,
    )
    result = conn.execute(stmt).fetchone()
    return result[0] if result else None


def get_previous_published_pricegroups(
    *,
    pg_conn: PostgreSQLConnection,
    pg_metadata: MetaData,
    df_price_group_info: pd.DataFrame,
    id_company: int,
) -> pd.DataFrame:
    price_group = int(df_price_group_info["PriceGroupId"].iloc[0])
    logger.debug(
        "searching previous published price_groups for price_group %d", price_group
    )

    # NOTE há limite de ~65 mil parâmetros em query no PostgreSQL.
    # Com tabela temporária não há essa limitação
    tmp_table_name = f"tmp_product_ids_{price_group}"
    tmp_table = Table(
        tmp_table_name,
        pg_metadata,
        Column("ProductId", String, primary_key=True),
        prefixes=["TEMPORARY"],
        postgresql_on_commit="DROP",
        extend_existing=True,
    )
    pg_metadata.create_all(pg_conn, tables=[tmp_table])

    df_product_ids = df_price_group_info[["ProductId"]].copy().set_index("ProductId")
    df_product_ids.to_sql(tmp_table_name, pg_conn, if_exists="append")

    published_date = df_price_group_info["PublishedDate"].iloc[0]
    table_later_period = Table("ProductLaterPeriod", pg_metadata, autoload_with=pg_conn)
    pg_stmt = (
        select(
            tmp_table.c.ProductId,
            table_later_period.c.PriceGroupId,
            table_later_period.c.ApprovedDate,
        )
        .join(
            tmp_table,
            table_later_period.c.ProductId == tmp_table.c.ProductId,
        )
        .where(
            table_later_period.c.Found.is_(False),
            table_later_period.c.PriceGroupId != price_group,
            table_later_period.c.ApprovedDate <= published_date,
            table_later_period.c.CompanyId == id_company,
        )
    )

    df_out = pd.read_sql(pg_stmt, pg_conn)
    df_out["NewPriceGroupId"] = price_group
    df_out["NewApprovedDate"] = published_date
    pg_metadata.remove(tmp_table)
    return df_out


def get_next_published_pricegroups(
    *,
    sql_conn: SQLServerConnection,
    sql_metadata: MetaData,
    pg_conn: PostgreSQLConnection,
    pg_metadata: MetaData,
    price_group: int,
    id_company: int,
) -> pd.DataFrame:
    logger.debug(
        "searching next published price_groups for price_group %d", price_group
    )

    table_later_period = Table("ProductLaterPeriod", pg_metadata, autoload_with=pg_conn)
    pg_stmt = select(
        table_later_period.c.ProductId,
        table_later_period.c.PriceGroupId,
        table_later_period.c.LaterPeriod,
        table_later_period.c.ApprovedDate,
    ).where(
        table_later_period.c.PriceGroupId == price_group,
        table_later_period.c.CompanyId == id_company,
    )

    df_out = pd.read_sql(pg_stmt, pg_conn)
    df_out = df_out.rename(
        columns={
            "PriceGroupId": "IdEnterprisePriceGroups",
            "LaterPeriod": "NextPriceDate",
            "ApprovedDate": "PublishedDate",
        }
    )
    if df_out.empty:
        return df_out

    table_sales_history = Table(
        "Enterprise_Sales_History", sql_metadata, autoload_with=sql_conn
    )
    stmt = select(func.max(table_sales_history.c.Issuance)).where(
        table_sales_history.c.IdCompany == id_company,
        table_sales_history.c.IsDeletado == 0,
    )
    newest_issuance = sql_conn.execute(stmt).fetchone()[0]
    stmt = select(func.min(table_sales_history.c.Issuance)).where(
        table_sales_history.c.IdCompany == id_company,
        table_sales_history.c.IsDeletado == 0,
    )
    oldest_issuance = sql_conn.execute(stmt).fetchone()[0]

    df_out["MaxIssuance"] = newest_issuance
    df_out["MaxIssuance"] = df_out["MaxIssuance"].dt.tz_localize(None)
    df_out["PublishedDate"] = df_out["PublishedDate"].dt.tz_localize(None)
    df_out["NextPriceDate"] = df_out["NextPriceDate"].fillna(df_out["MaxIssuance"])
    df_out["NextPriceDate"] = pd.to_datetime(
        df_out["NextPriceDate"], utc=True
    ).dt.tz_localize(None)
    df_out["NextPriceDate"] = df_out[["NextPriceDate", "MaxIssuance"]].min(axis=1)
    df_out["NextPriceDate"] = df_out[["NextPriceDate", "PublishedDate"]].max(axis=1)

    df_out["Impact_days"] = (
        df_out["NextPriceDate"].dt.date - df_out["PublishedDate"].dt.date
    )
    df_out["max_impact_days"] = df_out["PublishedDate"].dt.date - oldest_issuance.date()
    df_out["Impact_days"] = df_out[["Impact_days", "max_impact_days"]].min(axis=1)

    df_out["LookbackPriceDate"] = (
        df_out["PublishedDate"].dt.date - df_out["Impact_days"]
    )

    df_out["lookback_overflow"] = df_out["LookbackPriceDate"] < oldest_issuance.date()

    return df_out


def insert_projections_into_later_period(
    *,
    pg_conn: PostgreSQLConnection,
    pg_metadata: MetaData,
    df_price_group_info: pd.DataFrame,
) -> None:
    table_later_period = Table("ProductLaterPeriod", pg_metadata, autoload_with=pg_conn)

    price_group = df_price_group_info["PriceGroupId"].unique().tolist()
    check_stmt = (
        select(func.count())
        .select_from(table_later_period)
        .where(table_later_period.c.PriceGroupId.in_(price_group))
    )
    result = pg_conn.execute(check_stmt).fetchone()
    if result is not None and result[0] > 0:
        logger.info(
            "price_groups %s are already in table ProductLaterPeriod, skipping insert and updates",
            price_group,
        )
        return

    df = df_price_group_info.copy()
    df["Found"] = False
    df["LaterPeriod"] = None
    df = df.rename(columns={"PublishedDate": "ApprovedDate"})
    df = df[
        [
            "ProductId",
            "PriceGroupId",
            "Found",
            "ApprovedDate",
            "LaterPeriod",
            "CompanyId",
        ]
    ]

    rows = df.to_dict("records")
    stmt = table_later_period.insert().values(
        {col: bindparam(col) for col in df.columns}
    )
    pg_conn.execute(stmt, rows)


def update_later_period(
    *,
    pg_conn: PostgreSQLConnection,
    pg_metadata: MetaData,
    df_price_group_map: pd.DataFrame,
):
    table_later_period = Table("ProductLaterPeriod", pg_metadata, autoload_with=pg_conn)

    if df_price_group_map["PriceGroupId"].nunique() > 1:
        raise ConsistencyError("multiple price groups in dataframe")
    if df_price_group_map["NewPriceGroupId"].nunique() > 1:
        raise ConsistencyError("multiple new price groups in dataframe")

    old_pg = int(df_price_group_map["PriceGroupId"].iloc[0])
    new_pg = int(df_price_group_map["NewPriceGroupId"].iloc[0])

    cte_base = (
        select(
            table_later_period.c.Id,
            table_later_period.c.ProductId,
            table_later_period.c.ApprovedDate,
        )
        .where(table_later_period.c.PriceGroupId == new_pg)
        .compile()
    )

    stmt = text(
        f"""
        WITH tb_new AS ({cte_base})
        UPDATE "ProductLaterPeriod" AS lp
        SET "ReferenceId" = tb_new."Id", "LaterPeriod" = tb_new."ApprovedDate", "Found" = true
        FROM tb_new
        WHERE lp."ProductId" = tb_new."ProductId"
        AND lp."PriceGroupId" = :old_pg
        """
    )

    stmt = stmt.bindparams(old_pg=old_pg, **cte_base.params)
    logger.debug(
        "ProductLaterPeriod update query:\n%s\nparams:%s", stmt, stmt.compile().params
    )
    result = pg_conn.execute(stmt)
    logger.info("ProductLaterPeriod update query affected %d rows", result.rowcount)


def find_last_price_projection(
    *,
    conn: SQLServerConnection,
    metadata: MetaData,
    id_company: int,
    granularity: list[str],
    initial_date: date,
    final_date: Optional[date],
):
    table_prices_projection = Table(
        "Enterprise_Prices_Projection", metadata, autoload_with=conn
    )
    table_price_groups = Table("Enterprise_Price_Groups", metadata, autoload_with=conn)

    stmt = select(
        table_price_groups.c.IdEnterprisePriceGroups, table_price_groups.c.PublishedDate
    ).where(
        table_price_groups.c.IdCompany == id_company,
        table_price_groups.c.IsDeletado == 0,
        table_price_groups.c.CalcDate.isnot(None),
        table_price_groups.c.PublishedDate >= initial_date,
        table_price_groups.c.Published == 1,
    )

    if final_date is not None:
        stmt = stmt.where(table_price_groups.c.PublishedDate < final_date)

    pg_subquery = stmt.subquery()

    gran_columns = [
        table_prices_projection.c[MAP_PRICES_PROJECTION_SALES_HISTORY.get(col, col)]
        for col in granularity
    ]
    pp_subquery = (
        select(
            table_prices_projection.c.IdEnterprisePriceGroups,
            pg_subquery.c.PublishedDate,
            *gran_columns,
            func.row_number()
            .over(
                partition_by=gran_columns,
                order_by=pg_subquery.c.PublishedDate.desc(),
            )
            .label("rn"),
        )
        .join(
            pg_subquery,
            table_prices_projection.c.IdEnterprisePriceGroups
            == pg_subquery.c.IdEnterprisePriceGroups,
        )
        .subquery()
    )

    gran_columns = [pp_subquery.c[col] for col in granularity]
    stmt = select(
        pp_subquery.c.IdEnterprisePriceGroups,
        *gran_columns,
    ).where(pp_subquery.c.rn == 1)

    logger.debug(
        "finding last price with query:\n%s\nparams: %s", stmt, stmt.compile().params
    )
    df_last_pg = pd.read_sql(stmt, conn)
    return df_last_pg


def fetch_projections(
    *,
    conn: SQLServerConnection,
    metadata: MetaData,
    id_price_groups: list[int],
    granularity: list[str],
    consolidade_group_by_col: str,
    include_manual_price: bool = True,
) -> pd.DataFrame:
    table_prices_projection = Table(
        "Enterprise_Prices_Projection", metadata, autoload_with=conn
    )
    table_values_overrides = Table(
        "Enterprise_Values_Overrides", metadata, autoload_with=conn
    )
    table_workflow = Table(
        "EnterprisePriceProjection_Workflow", metadata, autoload_with=conn
    )
    table_workflow_action = Table(
        "EnterprisePriceProjection_WorkflowAction", metadata, autoload_with=conn
    )
    table_price_groups = Table("Enterprise_Price_Groups", metadata, autoload_with=conn)

    gran_columns = [
        table_prices_projection.c[MAP_SALES_HISTORY_PRICES_PROJECTION.get(col, col)]
        for col in granularity
    ]

    stmt = (
        select(
            table_prices_projection.c.IdEnterprisePriceGroups,
            table_price_groups.c.PublishedDate,
            *gran_columns,
            table_prices_projection.c[consolidade_group_by_col],
            table_prices_projection.c.Issuance.label("last_sale_datetime"),
            table_prices_projection.c.PbCost.label("cost"),
            table_workflow_action.c.Action,
        )
        .join(
            table_price_groups,
            table_prices_projection.c.IdEnterprisePriceGroups
            == table_price_groups.c.IdEnterprisePriceGroups,
        )
        .join(
            table_values_overrides,
            and_(
                table_prices_projection.c.ProjectionsReference
                == table_values_overrides.c.ProjectionsReference,
                table_values_overrides.c.IsDeletado == 0,
            ),
        )
        .join(
            table_workflow,
            table_prices_projection.c.IdEnterprisePricesProjection
            == table_workflow.c.IdEnterprisePriceProjection,
        )
        .join(
            table_workflow_action,
            table_workflow.c.IdLastAction
            == table_workflow_action.c.IdEnterprisePriceProjection_WorkflowAction,
        )
        .where(
            table_prices_projection.c.IdEnterprisePriceGroups.in_(id_price_groups),
            table_prices_projection.c.IsDeletado == 0,
        )
    )

    if include_manual_price:
        stmt = stmt.add_columns(
            case(
                (
                    table_values_overrides.c.IsManual == 1,
                    table_values_overrides.c.Manual_Price,
                ),
                else_=func.coalesce(
                    table_values_overrides.c.Price, table_prices_projection.c.SalePrice
                ),
            ).label("price"),
            case(
                (
                    table_values_overrides.c.IsManual == 1,
                    table_values_overrides.c.Manual_Price_Demand,
                ),
                else_=func.coalesce(
                    table_values_overrides.c.Price_Demand,
                    table_prices_projection.c.SalePrice_Demand,
                ),
            ).label("demand"),
        )
    else:
        stmt = stmt.add_columns(
            func.coalesce(
                table_values_overrides.c.Price, table_prices_projection.c.SalePrice
            ).label("price"),
            func.coalesce(
                table_values_overrides.c.Price_Demand,
                table_prices_projection.c.SalePrice_Demand,
            ).label("demand"),
        )

    logger.debug(
        "fetching projections with query:\n%s\nparams: %s", stmt, stmt.compile().params
    )
    df_proj = pd.read_sql(stmt, conn)
    df_proj = df_proj.rename(columns=MAP_PRICES_PROJECTION_SALES_HISTORY)
    return df_proj


class PriceGroupInfo(NamedTuple):
    id_price_group: int
    consolidate_group_by: str
    published_datetime: datetime
    suggested_price: float
    approved: bool


def calculate_adoption(
    *,
    conn: SQLServerConnection,
    metadata: MetaData,
    df_projections: pd.DataFrame,
    id_company: int,
    granularity: list[str],
    consolidate_group_by_col: str,
    initial_date: date,
    final_date: Optional[date],
    limit: Optional[int] = None,
):
    table_sales_history = Table(
        "Enterprise_Sales_History", metadata, autoload_with=conn
    )

    # NOTE heurística para tentar reduzir consulta à Enterprise_Sales_History
    simpler_gran_col = df_projections[granularity].nunique().sort_values().index[0]
    simpler_gran_values = df_projections[simpler_gran_col].unique().tolist()
    price_suggestions = {}
    sorted_gran = sorted(granularity)
    logger.debug("sorted granularity to calculate adoption: %s", sorted_gran)
    df_projections = df_projections.sort_values(["PublishedDate", *sorted_gran])

    for _, row in df_projections.iterrows():
        key = tuple(row[col] for col in sorted_gran)
        price_group = row["IdEnterprisePriceGroups"]
        # TODO padronizar arredondamentos na plataforma
        price = round(row["price"], 2)
        approved = row["Action"] == 0
        pg_info = PriceGroupInfo(
            price_group,
            row[consolidate_group_by_col],
            row["PublishedDate"],
            price,
            approved,
        )
        price_suggestions.setdefault(key, [{price}, {pg_info}])
        value = price_suggestions[key]

        if price not in value[0]:
            value[0].add(price)
            value[1].add(pg_info)

        price_suggestions[key] = value

    # NOTE precificação mais recente primeiro
    price_suggestions = {
        k: sorted(pg_info, key=lambda pg_info: pg_info.published_datetime, reverse=True)
        for k, (_, pg_info) in price_suggestions.items()
    }
    df_suggestions = pd.DataFrame(
        (
            (
                *gran_values,
                pg_info.suggested_price,
                pg_info.consolidate_group_by,
                pg_info.id_price_group,
                pg_info.published_datetime,
                pg_info.approved,
            )
            for gran_values, pg_infos in price_suggestions.items()
            for pg_info in pg_infos
        ),
        columns=[
            *sorted_gran,
            "SuggestedPrice",
            "ConsolidateGroupBy",
            "IdEnterprisePriceGroups",
            "PublishedDate",
            "Approved",
        ],
    )

    gran_columns = [
        table_sales_history.c[MAP_SALES_HISTORY_PRICES_PROJECTION.get(col, col)]
        for col in sorted_gran
    ]
    logger.debug("gran_columns: %s", gran_columns)
    stmt = select(
        table_sales_history.c.SalePrice,
        table_sales_history.c.Issuance,
        *gran_columns,
    ).where(
        table_sales_history.c.IdCompany == id_company,
        table_sales_history.c.IsDeletado == 0,
        table_sales_history.c.Issuance >= initial_date,
        table_sales_history.c[simpler_gran_col].in_(simpler_gran_values),
    )

    if final_date is not None:
        stmt = stmt.where(table_sales_history.c.Issuance < final_date)

    if limit is not None:
        stmt = stmt.limit(limit)

    logger.debug(
        "consulta Enterprise_Sales_History:\n%s\nparams: %s",
        stmt,
        stmt.compile().params,
    )
    result = conn.execute(stmt)
    adoptions = []
    seen_dates_dict: dict[tuple[Any, ...], set[date]] = defaultdict(set)
    for row in result:
        sale_price, issuance, *gran_values = row
        pg_infos: list[PriceGroupInfo] = price_suggestions.get(tuple(gran_values))

        if not isinstance(issuance, datetime):
            logger.error(
                "skipping row with unexpected type for Issuance: %s of type %s. Expected datetime",
                issuance,
                type(issuance),
            )
            continue

        if pg_infos is None:
            continue

        for i, pg_info in enumerate(pg_infos):

            if pg_info.published_datetime > issuance:
                continue

            seen_dates_key = (*gran_values, pg_info.suggested_price)
            seen_dates = seen_dates_dict.get(seen_dates_key)
            if seen_dates is not None and issuance.date() in seen_dates:
                continue

            seen_dates_dict[seen_dates_key].add(issuance.date())

            diff = abs(pg_info.suggested_price - float(sale_price))
            adoption_criteria_1 = (
                i == 0 and (diff / pg_info.suggested_price) <= ADOPTION_TOLERANCE_PCT
            )
            adotion_criteria_2 = i != 0 and diff < 0.01
            if adoption_criteria_1 or adotion_criteria_2:
                adoptions.append(
                    (
                        *gran_values,
                        issuance,
                        sale_price,
                        pg_info.id_price_group,
                    )
                )

    adoptions_cols = [
        *sorted_gran,
        "AdoptionIssuance",
        "SalePrice",
        "IdEnterprisePriceGroups",
    ]
    df_adoption = pd.DataFrame(adoptions, columns=adoptions_cols)
    logger.info("df_adoption shape: %s", df_adoption.shape)
    logger.info("df_suggestions shape: %s", df_suggestions.shape)

    out = pd.merge(
        df_suggestions,
        df_adoption,
        how="left",
        on=[*sorted_gran, "IdEnterprisePriceGroups"],
    )
    logger.info("df_adoption after merge shape: %s", df_adoption.shape)
    return out
