using Domain.Product.Models;
using Domain.ProductSeller;
using Domain.ProductSeller.Models;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;

namespace PredimonitorAPI.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ProductSellerController : ControllerBase
{
    private readonly ILogger<ProductController> _logger;
    private readonly IProductSellerDomain _domain;

    public ProductSellerController(ILogger<ProductController> logger, IProductSellerDomain domain)
    {
        _logger = logger;
        _domain = domain;
    }

    [HttpPost]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(ProductSellerResponse))]
    [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(string))]
    [ProducesResponseType(StatusCodes.Status401Unauthorized, Type = typeof(string))]
    [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
    [SwaggerOperation(Summary = "Retrieves data accordingly to filters for the predimonitor screen", Description = "Get results from database accordingly to filters for the predimonitor screen")]

    public async Task<IActionResult> SearchPrices(FiltersRequest request)
    {
        if (request == null)
        {
            _logger.LogDebug("Null request received.");
            return BadRequest("Request cannot be null.");
        }

        if (!ModelState.IsValid)
        {
            _logger.LogDebug("Invalid request received.");
            return BadRequest("Invalid request data.");
        }

        try
        {
            var response = await _domain.GetProductSellersWithPrices(request);

            if (response.SellerPrices == null || !response.SellerPrices.Any())
            {
                _logger.LogDebug("No data found");
                return NoContent();
            }

            return Ok(response);
        }
        catch (UnauthorizedAccessException ex)
        {
            _logger.LogError(ex, "Unauthorized access");
            return Unauthorized("Unauthorized access.");
        }
        catch (ArgumentException ex)
        {
            _logger.LogError(ex, "Bad request");
            return BadRequest("Invalid argument: " + ex.Message);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error executing the request");
            return StatusCode(StatusCodes.Status500InternalServerError, "An unexpected error occurred.");
        }
    }
}