﻿using Repository.DbContexts;
using Repository.Entity;
using Repository.EntityRepository.Bases;

namespace Repository.EntityRepository
{
    public class InfoPriceSaoJoaoRepository : GenericMongoRepository<InfoPriceSaoJoaoEntity>, IInfoPriceSaoJoaoRepository
    {
        public InfoPriceSaoJoaoRepository(InfoPriceSaoJoaoDbContext dbContext) : base(dbContext)
        {
        }
        public static string DbContextName => nameof(InfoPriceSaoJoaoDbContext);
    }
}
