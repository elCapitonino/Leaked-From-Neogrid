
import requests

class geoApiService:
    def __init__(self):
        self.base_url = 'https://app-geolocation-api-prd-westus3.azurewebsites.net/geosearch'
        self.headers = {'Content-Type': 'application/json'}
        
    #data:
    # {
    #     "address_info": {
    #         "base": "indireta",
    #         "id_consulta": "",
    #         "address": "",
    #         "neighborhood": "",
    #         "city": "",
    #         "state": "",
    #         "country": ""
    #     },
    #     "use_cache": True
    # }
    def get_address(self, address_info, use_cache=True):
        
        data = {
            "address_info": address_info,
            "use_cache": use_cache
        }
        
        response = requests.post(self.base_url, json=data, headers=self.headers)
        
        if response.status_code == 200:
            return response.json()
        else:
            response.raise_for_status()