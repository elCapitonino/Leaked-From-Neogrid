﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using Repository.Attributes;
using Repository.DbContexts;
using Repository.Entity;
using MongoDB.EntityFrameworkCore.Extensions;

namespace Repository.TypeConfiguration
{
    [DbContextTypeConfiguration(typeof(SmarketCompetitorDbContext))]
    public class AbvTypeConfiguration : TypeConfigurationBase<AbvEntity>, IEntityTypeConfiguration<AbvEntity>
    {
        public override void Configure(EntityTypeBuilder<AbvEntity> builder)
        {
            builder.ToTable("abv").ToCollection("abv");
        }
    }
}
