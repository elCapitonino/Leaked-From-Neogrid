"""
Classes e funções para extrair informações do banco SQL.
"""

from datetime import date, datetime, timedelta
from typing import Any, Optional

import pandas as pd
from pyodbc import Connection


MAP_SALES_HISTORY_PRICES_PROJECTION = {
    "Description": "ProductName",
}


def filtros_to_query(filtros: dict) -> str:
    """Função para transformar o dicionario de filtros em uma string para queries."""
    ret = ""
    for k in filtros.keys():
        if ret != "":
            ret += "\n\tAND "

        if filtros[k][0] == "in":
            valores = ", ".join([f"'{str(v)}'" for v in filtros[k][1]])
            ret += f"{str(k)} in ({valores}) "
        else:
            print(f'Filtros do tipo "{filtros[k][0]}" ainda não implementados.')
            continue

    return ret


def query_selected_price_groups(
    conn_obj: Connection,
    id_company: int,
    price_groups: list[int],
    group_granularity: Optional[list[str]] = None,
    group_info: Optional[list[str]] = None,
    days_lookback: int = 7,
    days_interval: int = 0,
    days_lookforward: int = 7,
) -> pd.DataFrame:
    """Função para puxar as `datas` e os `ids` referentes aos ids em `price_groups`."""
    placeholders = ", ".join(["?"] * len(price_groups))
    initial_query = f"""
        WITH tb_groups AS (
            SELECT
                DataHoraCriacao AS PricingDate,
                IdEnterprisePriceGroups
            FROM Enterprise_Price_Groups AS t1
            WHERE IdCompany = ?
            AND IsDeletado = 0
            AND CalcDate IS NOT NULL
            AND IdEnterprisePriceGroups IN ({placeholders})
        ),
    """
    params = (id_company, *price_groups)
    return _query_price_groups(
        conn_obj,
        id_company=id_company,
        initial_query=initial_query,
        query_params=params,
        group_granularity=group_granularity,
        group_info=group_info,
        days_lookback=days_lookback,
        days_interval=days_interval,
        days_lookforward=days_lookforward,
    )


# TODO atualizar procedure vem? Elas pegam até próxima precificação ou DIA DE HOJE!
def query_published_price_groups(
    conn_obj: Connection,
    id_company: int,
    group_lookback: int,
    group_granularity: Optional[list[str]] = None,
    group_info: Optional[list[str]] = None,
    days_lookback: int = 7,
    days_interval: int = 0,
    days_lookforward: int = 7,
) -> pd.DataFrame:
    """Função para pegar a tabela de `idsPriceGroups` filtrados pela data de publicação (`group_lookback`)."""
    initial_date = datetime.today() - timedelta(days=group_lookback)
    initial_query = """
        WITH tb_groups AS (
            SELECT
                DataHoraCriacao,
                PublishedDate AS PricingDate,
                IdEnterprisePriceGroups
            FROM Enterprise_Price_Groups AS t1
            WHERE IdCompany = ?
            AND IsDeletado = 0
            AND Published = 1
            AND PublishedDate >= ?
            AND CalcDate IS NOT NULL
        ),
    """
    params = (id_company, initial_date)
    return _query_price_groups(
        conn_obj,
        id_company=id_company,
        initial_query=initial_query,
        query_params=params,
        group_granularity=group_granularity,
        group_info=group_info,
        days_lookback=days_lookback,
        days_interval=days_interval,
        days_lookforward=days_lookforward,
    )


def _query_price_groups(
    conn_obj: Connection,
    *,
    id_company: int,
    initial_query: str,
    query_params: tuple[Any, ...],
    group_granularity: Optional[list[str]] = None,
    group_info: Optional[list[str]] = None,
    days_lookback: int = 7,
    days_interval: int = 0,
    days_lookforward: int = 7,
):
    """Função complementar para puxar a tabela dos `idsPriceGroups`."""
    group_granularity = group_granularity or []
    group_info = group_info or []

    group_granularity = [MAP_SALES_HISTORY_PRICES_PROJECTION.get(x, x) for x in group_granularity]
    group_info = [MAP_SALES_HISTORY_PRICES_PROJECTION.get(x, x) for x in group_info]

    info_cols = group_granularity + group_info
    str_granularity = ", ".join(group_granularity)

    pp_cols = ", ".join(f"pp.{col}" for col in info_cols)
    tb_info_cols = ", ".join(f"tb_info.{col}" for col in info_cols)
    str_partition = f"PARTITION BY {str_granularity}" if group_granularity else ""

    query = f"""
        {initial_query}
        tb_info AS (
            SELECT tg.IdEnterprisePriceGroups,
            {pp_cols},
            ROW_NUMBER() OVER (
                PARTITION BY pp.IdEnterprisePriceGroups ORDER BY Issuance DESC
            ) AS rn
            FROM Enterprise_Prices_Projection AS pp
            JOIN tb_groups AS tg
            ON pp.IdEnterprisePriceGroups = tg.IdEnterprisePriceGroups
        ),
        tb_join AS (
            SELECT
                tb_groups.*,
                {tb_info_cols}
            FROM tb_groups
            JOIN tb_info
            ON tb_groups.IdEnterprisePriceGroups = tb_info.IdEnterprisePriceGroups
            WHERE tb_info.rn = 1
        ),
        tb_last_date AS (
            SELECT MAX(Issuance) AS MaxIssuance
            FROM Enterprise_Sales_History
            WHERE IdCompany = ?
            AND IsDeletado = 0
        ),
        tb_affiliate AS (
            SELECT
                *,
                DATEADD(day, -{days_lookback}, PricingDate) AS InitialDateBack,
                PricingDate AS EndDateBack,
                LEAST(
                    DATEADD(day, {days_interval}, PricingDate),
                    MaxIssuance
                ) AS InitialDateFwd,
                LEAST(
                    -- NOTE: "If one or more arguments aren't NULL, then NULL arguments are ignored during comparison"
                    -- age como coalesce + least e garante intervalo de NO MÁXIMO `days_lookforward`
                    LEAST(
                        lead(PricingDate) OVER (
                            {str_partition}
                            ORDER BY PricingDate
                        ),
                        DATEADD(day, {days_interval + days_lookforward}, PricingDate)
                    ),
                    MaxIssuance
                ) AS EndDateFwd
            FROM tb_join
            CROSS JOIN tb_last_date
            WHERE PricingDate <= MaxIssuance
        )
        SELECT * FROM tb_affiliate
    """

    query_params = query_params + (id_company,)
    # print(f'\n{query_params = } \n\n {query}')
    price_groups = pd.read_sql_query(query, conn_obj, params=query_params)
    price_groups.rename(columns={"PricingDate": "Data_Precificação"}, inplace=True)
    price_groups["Data_Precificação"] = pd.to_datetime(price_groups["Data_Precificação"]).dt.date
    return price_groups


def query_projections(
    conn_obj: Connection,
    id_pg: int,
    granularidade: list[str],
    product_info: Optional[list[str]] = None,
    filtros: Optional[dict] = None,
) -> pd.DataFrame:
    """Função para puxar a tabela de precificações."""
    granularidade = [MAP_SALES_HISTORY_PRICES_PROJECTION.get(x, x) for x in granularidade]
    gran_str = ", ".join([str(g) for g in granularidade])
    pp_gran = ", ".join([f"PP.{g}" for g in granularidade])

    product_info_sql = "1 AS dummy" # NOTE para funcionar por conta de trailing comma
    if product_info:
        product_info_sql = ""
        for col in product_info:
            product_info_sql += f"\nFIRST_VALUE({col}) OVER (PARTITION BY {pp_gran} ORDER BY Issuance DESC) AS {col},"
        product_info_sql = product_info_sql.strip(",")

    aux = " AND ".join([f"t1.{g} = t2.{g}" for g in granularidade])
    gran_join = "ON " + aux

    query = f"""
    WITH tb_base AS (
        SELECT
            *
        FROM Enterprise_Prices_Projection
        WHERE IdEnterprisePriceGroups = {id_pg}
        AND IsDeletado = 0
    ),
    tb_num as (
        SELECT 
            PP.SalePrice as p_sem_regra_projecao,
            CASE WHEN VO.IsManual IS NULL THEN PP.SalePrice
                WHEN VO.IsManual in (0, 1) THEN VO.Price
                END AS p_projecao,
            CASE WHEN VO.IsManual IS NULL THEN PP.SalePrice_Demand
                WHEN VO.IsManual in (0, 1) THEN VO.Price_Demand
                END AS d_projecao,
            PP.PbCost as custo_projecao, {pp_gran}
        FROM tb_base AS PP
        LEFT JOIN Enterprise_Values_Overrides AS VO
        ON VO.ProjectionsReference = PP.ProjectionsReference
    ),
    tb_str as (
        select DISTINCT {pp_gran}, PP.AffiliateName,
            PP.ProductName as Description,
            CASE
                WHEN ppwa.[Action] = 0 THEN 'Aprovado'
                WHEN ppwa.[Action] = 1 THEN 'Reprovado'
                ELSE 'Escalado'
            END AS Aproval,
            {product_info_sql}
        FROM tb_base AS PP
        JOIN enterprisepriceprojection_workflow ppw
        ON ppw.identerprisepriceprojection = PP.IdEnterprisePricesProjection
        JOIN enterprisepriceprojection_workflowaction ppwa
        ON ppwa.idpriceprojection_workflow = ppw.IdEnterprisePriceProjection_Workflow
    ),
    tb_agrup as (
        SELECT {gran_str},
            AVG(custo_projecao) as custo_projecao,
            AVG(p_sem_regra_projecao) as p_sem_regra_projecao,
            AVG(p_projecao) as p_projecao,
            SUM(d_projecao) as d_projecao
        FROM tb_num
        GROUP BY {gran_str}
    ),
    tb_final as (
        SELECT t2.*, t1.custo_projecao, t1.p_sem_regra_projecao,
            t1.p_projecao, t1.d_projecao,
            case when custo_projecao = 0 then 1
                when p_projecao = 0 then 0
                else 1 - (custo_projecao/p_projecao) end as m_projecao,
            p_projecao * d_projecao as r_projecao,
            (p_projecao - custo_projecao) * d_projecao as l_projecao
        FROM tb_agrup AS t1
        JOIN tb_str AS t2
        {gran_join}
    )
    SELECT * FROM tb_final
    """

    if filtros:
        str_filtros = filtros_to_query(filtros)
        query += f"WHERE {str_filtros}"

    # print(f"query projections:\n{query}")
    atual = pd.read_sql_query(query, conn_obj)
    atual["IdEnterprisePriceGroups"] = id_pg
    return atual


def query_history(
    conn_obj: Connection,
    data_1: date,
    data_2: date,
    granularidade: list,
    idcompany: int,
    nome: str = "anterior",
    filtros: Optional[dict] = None,
    sales_history_filters: Optional[list[tuple[str, str]]] = None,
    period_last_price: int = 180,
    keep_na: bool = True,
    preco: str = 'SalePrice',
) -> pd.DataFrame:
    """Função para puxar uma tabela bem específica.
    Suas colunas são:
    - (colunas da granularidade)
    - (custo_nome) - Preco de custo
    - (p_nome)     - Preco de venda
    - (q_nome)     - Quantidade de itens vendidos
    - (m_nome)     - Margem de Lucro sobre as vendas
    - (r_nome)     - Receita
    - (l_nome)     - Lucro

    Todas as informações são referentes o intervalo entre `data_1` e `data_2`.
    Contudo, nos casos em que não houveram vendas neste período, o preço é o último observado (até `data_2`).
    """

    gran_str = ", ".join([str(g) for g in granularidade])
    t2_str = ", ".join(["t2." + str(g) for g in granularidade])

    aux = " AND ".join(["t1." + str(g) + " = t2." + str(g) for g in granularidade])
    gran_join = "ON " + aux

    data_3 = data_2 - timedelta(days=period_last_price)

    sales_history_filters = sales_history_filters or []
    filters = "\n".join(f"AND {col} = ?" for col, _ in sales_history_filters)

    min_date = min(data_1, data_2, data_3)
    query_sh = f"""
    WITH tb_base AS (
        SELECT
            Issuance,
            {preco} as SalePrice,
            PbCost,
            Quantity,
            {gran_str}
        FROM Enterprise_Sales_History WITH (NOLOCK)
        WHERE IdCompany = ?
        AND IsDeletado = 0
        AND Issuance >= ?
        {filters}
    """

    if filtros:
        query_sh += f"\tAND {filtros_to_query(filtros)}\n"

    query_complementar = f"""
    ),
    tb_vendas AS (
        SELECT {gran_str},
            AVG(SalePrice) as p_{nome},
            AVG(PbCost) as custo_{nome},
            SUM(Quantity) as q_{nome}
        FROM tb_base
        WHERE Issuance >= ? AND Issuance < ?
        GROUP BY {gran_str}
    ),
    tb_ult_obs AS (
        SELECT {gran_str}, Issuance, salePrice, pbCost,
            ROW_NUMBER() over (
                PARTITION BY {gran_str} ORDER BY Issuance DESC
            ) AS ordem
        FROM tb_base
        WHERE Issuance >= ? AND Issuance < ?
    ),
    tb_final AS (
        SELECT {t2_str},
            ISNULL(t1.p_{nome}, t2.salePrice) AS p_{nome},
            ISNULL(t1.custo_{nome}, t2.pbCost) AS custo_{nome},
            t1.q_{nome},
            t2.Issuance
        FROM tb_vendas AS t1
        RIGHT JOIN tb_ult_obs AS t2
        {gran_join}
        WHERE t2.ordem = 1
    )
    SELECT
        {gran_str},
        custo_{nome},
        p_{nome},
        q_{nome},
        CASE WHEN custo_{nome} = 0 THEN 1
            WHEN p_{nome} = 0 THEN 0
            ELSE 1 - (custo_{nome}/p_{nome})
        END AS m_{nome},
        p_{nome} * q_{nome} AS r_{nome},
        (p_{nome} - custo_{nome}) * q_{nome} AS l_{nome}
    FROM tb_final
    """
    query = query_sh + query_complementar

    params = (idcompany, min_date, *[value for _, value in sales_history_filters], data_1, data_2, data_3, data_2)
    # print(f"query history {nome}:\n{query}")
    # print('\n', params)
    df = pd.read_sql_query(query, conn_obj, params=params)
    if not keep_na:
        df[f"q_{nome}"] = df[f"q_{nome}"].fillna(0)
        df[f"r_{nome}"] = df[f"r_{nome}"].fillna(0)
        df[f"l_{nome}"] = df[f"l_{nome}"].fillna(0)
    return df
