﻿namespace Repository.Enums
{
    public enum ERuleType
    {
        WeekDay = 0,
        CompetitorMargin = 1,
        LimitMargin = 2,
        Increment_Decrement_Value = 3,
        CompetitorPrice = 4,
        StockQTD = 5,
        Rounding_Generic = 6,
        Rounding_09 = 7,
        Rounding_99 = 8,
        Rounding_50 = 9,
        Last_Price = 10,
        Rounding_90 = 11,
        Rounding_10 = 12,
        Rounding_Last_Cent = 13,
        Variation_Profit_Reset = 14,
        CompetitorIC = 15,
        Rounding_Cent = 16,
        DemandVariation = 17,
        StockXDemand = 18,
        SalePriceVariation = 19,
        RevenueVariation = 20,
        MinimumMarginNetwork = 21,

        Enterprise_BlockMargin = 901,

        PML_MARGIN = 10000
    }
}
