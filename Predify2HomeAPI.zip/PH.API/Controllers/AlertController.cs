﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Server.IIS.Core;
using PH.Domain.Interfaces.Services;

namespace PH.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AlertController : ControllerBase
    {
        private readonly ILogger<AlertController> _logger;
        private readonly IAlertServices _service;

        public AlertController(ILogger<AlertController> logger,
                                IAlertServices service)
        {
            _logger = logger;
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> Get(long? idCompany, long? idPriceGroup)
        {
            _logger.LogInformation("Controller: Buscando todos os Alerts");

            try
            {
                if (idCompany == null || idCompany == 0 || idPriceGroup == null || idPriceGroup == 0)
                    throw new Exception("Id da Compania ou Id do grupo não podem ser nulo ou 0");

                var recipes = await _service.Get(idCompany.Value, idPriceGroup.Value);
                return Ok(recipes);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Controller: Erro ao buscar todos os Alerts. {ex.Message}");
                return StatusCode(500, "Erro ao buscar todos os Alerts");
            }
        }
    }
}
