﻿using DI.Repository.Attributes;
using DI.Repository.Contexts;
using DI.Repository.Entities;
using DI.Repository.Enum;
using DI.Repository.Interfaces.Repositories;
using DI.Repository.Repositories.Base;
using Microsoft.EntityFrameworkCore;

namespace DI.Repository.Repositories
{
    [UsePostgreContext]
    public sealed class MonthlyImpactDataRepository : PostgreGenericNoModifyRepository<MonthlyImpactDataEntity>, IMonthlyImpactDataRepository
    {
        public MonthlyImpactDataRepository(PostgreContext dbContext) : base(dbContext)
        {
        }

        public IEnumerable<MonthlyImpactDataEntity> GetAll(long CompanyId, int startYearMonth, int endYearMonth, MonthlyImpactDataType dataType)
        {
            return _dbContext
                .Set<MonthlyImpactDataEntity>()
                .Where(x => x.CompanyId == CompanyId && x.YearMonth >= startYearMonth && x.YearMonth <= endYearMonth && x.DataType == dataType);
        }

        public async Task<IEnumerable<MonthlyImpactDataEntity>> GetAll(long CompanyId, int YearMonth, MonthlyImpactDataType dataType, CancellationToken cancellationToken)
        {
            return await _dbContext
                .Set<MonthlyImpactDataEntity>()
                .AsNoTracking()
                .Where(x => x.CompanyId == CompanyId && x.YearMonth == YearMonth && x.DataType == dataType)
                .ToArrayAsync(cancellationToken);
        }
    }
}