﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DI.Repository.Migrations.PostgreMigrations
{
    /// <inheritdoc />
    public partial class CreatingIndex : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateIndex(
                name: "IX_MonthlySaleHistoryData_CompanyId_YearMonth",
                table: "MonthlySaleHistoryData",
                columns: new[] { "CompanyId", "YearMonth" });

            migrationBuilder.CreateIndex(
                name: "IX_MonthlyProjectionData_CompanyId_YearMonth",
                table: "MonthlyProjectionData",
                columns: new[] { "CompanyId", "YearMonth" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_MonthlySaleHistoryData_CompanyId_YearMonth",
                table: "MonthlySaleHistoryData");

            migrationBuilder.DropIndex(
                name: "IX_MonthlyProjectionData_CompanyId_YearMonth",
                table: "MonthlyProjectionData");
        }
    }
}
