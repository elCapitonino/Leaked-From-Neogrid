﻿using Repository.DbContexts;
using Repository.Entity;
using Repository.EntityRepository.Bases;

namespace Repository.EntityRepository
{
    public class MonitoringItemResultsRepository : GenericRepository<MonitoringItemResultsEntity, long>, IMonitoringItemResultsRepository
    {
        public MonitoringItemResultsRepository(ApplicationDbContext dbContext) : base(dbContext)
        {

        }
        public static string DbContextName => nameof(ApplicationDbContext);
    }
}
