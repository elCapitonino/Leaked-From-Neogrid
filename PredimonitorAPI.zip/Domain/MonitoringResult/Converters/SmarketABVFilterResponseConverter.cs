﻿using AutoMapper;
using Domain.MonitoringResult.Models;
using Repository.Entity;
using Repository.Enums;

namespace Domain.MonitoringResult.Converters
{
    public class SmarketABVFilterResponseConverter : ITypeConverter<AbvEntity, ResultFilterResponse>
    {
        public ResultFilterResponse Convert(AbvEntity source, ResultFilterResponse destination, ResolutionContext context)
        {
            var dest = new ResultFilterResponse()
            {
                ProductName = source.ProdutoDescricao.Descricao,
                ProductLink = source.Hash,
                ProductBrand = source.ProdutoDescricao.Marca,
                SellerName = source.Concorrente.RazaoSocial,
                Marketplace = (string)context.Items["CrawlerName"],
                Price = decimal.Parse(source.PesquisaProduto.PrecoVarejo),
                PaymentType = "-",
                Price_unit_type = PriceUnitType.UNITARIO,
                CrawlerDate = source.PesquisaProduto.DtPesquisa,
                Disregarded = false,
                IdCrawler = (int)context.Items["CrawlerId"],
                City = source.Concorrente.Cidade,
                State = source.Concorrente.Estado,
                Coordinates = new PrediMonitorProduct_CoordinatesModel()
            };

            return dest;
        }
    }
}
