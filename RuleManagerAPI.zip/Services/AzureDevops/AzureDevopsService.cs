﻿using Newtonsoft.Json.Linq;
using Services.AzureDevops.Models;
using System.Net.Http.Headers;

namespace Services.AzureDevops
{
    public class AzureDevopsService
    {
        private readonly HttpClient client;

        public AzureDevopsService(HttpClient client)
        {
            this.client = client;
            this.client.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue("application/json")
            );
        }

        public async Task<string> GetJson(AzureDevopsGetItemParams _params)
        {
            var response = await this.client.GetAsync($"/predify/{_params.ProjectId}/_apis/git/repositories/{_params.RepositoryId}/items?path={_params.Path}&includeContent=true&versionDescriptor.version=master");
            response.EnsureSuccessStatusCode();
            string stringifiedBody = await response.Content.ReadAsStringAsync();

            var body = JObject.Parse(stringifiedBody);
            if (body is null)
            {
                throw new InvalidOperationException("Failed to parse JSON Body: response is null or invalid.");
            }
            if ( ! body.ContainsKey("content") && body["content"]?.ToString() != "")
            {
                throw new InvalidOperationException("Failed to parse JSON Body: response.content is null or invalid.");
            }

            return body["content"]!.ToString();
        }
    }
}

