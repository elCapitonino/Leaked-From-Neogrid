﻿namespace DI.Repository.Entities
{
    public sealed class EnterprisePriceProjection_WorkflowEntity : BaseNoKeyEntity
    {
        public long EnterprisePriceProjection_WorkflowId { get; set; }

        public long EnterprisePriceProjectionId { get; set; }
        public EnterprisePriceProjectionEntity? EnterprisePriceProjection { get; set; }
        public long? WorkflowId { get; set; }

        public long? FirstActionId { get; set; }

        public long? LastActionId { get; set; }
        public EnterprisePriceProjection_WorkflowActionEntity? LastAction { get; set; }

        public long CurrentNodeId { get; set; }

        public bool IsDeleted { get; set; }
    }
}
