﻿using AutoMapper;
using Domain.BackgroundTasks;
using Domain.IndexGenerator.DataSourceDomains.Interfaces;
using Domain.IndexGenerator.Models;
using Domain.Models;
using Domain.Status;
using Domain.Status.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using Repository.Entity;
using Repository.Enums;
using Repository.UnitOfWork;

namespace Domain.IndexGenerator
{
    public class IndexGeneratorDomain : IIndexGeneratorDomain
    {
        private readonly ILogger<IndexGeneratorDomain> _logger;
        private readonly IUnitOfWork _uow;
        private readonly IMapper _mapper;
        private readonly IOptions<AppsettingsOptions> _appsettings;
        private readonly IBackgroundTaskQueue _backgroundTaskQueue;
        private readonly IServiceProvider _services;
        private readonly IStatusDomain _statusDomain;

        public IndexGeneratorDomain(ILogger<IndexGeneratorDomain> logger, IUnitOfWork uow, IMapper mapper, IOptions<AppsettingsOptions> appsettings,
            IBackgroundTaskQueue backgroundTaskQueue, IServiceProvider services, IStatusDomain statusDomain)
        {
            _logger = logger;
            _uow = uow;
            _mapper = mapper;
            _appsettings = appsettings;
            _backgroundTaskQueue = backgroundTaskQueue;
            _services = services;
            _statusDomain = statusDomain;
        }
        private void UpdateStatus(int step, long companyId, Guid? taskId, string message = "")
        {
            if (taskId.HasValue)
            {
                _statusDomain.AddOrUpdate(new MonitoringItemResultsStatusRequest()
                {
                    CompanyId = companyId,
                    Step = step,
                    TaskId = taskId,
                    Message = message
                });
            }
        }

        public async Task GenerateIndexAsync(IndexGeneratorRequest request)
        {
            ArgumentNullException.ThrowIfNull(request);
            ArgumentNullException.ThrowIfNull(request.TaskId);

            _logger.LogInformation("Generating index for company {CompanyId}", request.CompanyId);

            _logger.LogDebug("{NewMonitoringItems} Monitoring Items to Insert from {CompanyId}", request.NewMonitoringItems.Count(), request.CompanyId);
            _logger.LogDebug("{UpdateMonitoringItems} Monitoring Items to Update from {CompanyId}", request.UpdatedMonitoringItems.Count(), request.CompanyId);
            _logger.LogDebug("{DeleteMonitoringItems} Monitoring Items to Delete from {CompanyId}", request.DeletedMonitoringItemIds.Count(), request.CompanyId);
            _logger.LogInformation("Request Body: {BodyJson}", Newtonsoft.Json.JsonConvert.SerializeObject(request));

            _statusDomain.AddOrUpdate(new MonitoringItemResultsStatusRequest()
            {
                TaskId = request.TaskId,
                Status = MonitoringItemResultsStatusType.Running,
                Message = string.Empty,
                CompanyId = request.CompanyId
            });

            UpdateStatus(MonitoringItemResultStatusSteps.CLEANUP_ITEMS, request.CompanyId, request.TaskId);
            _statusDomain.AddToCache(request.TaskId.Value);

            var crawlerSources = await _uow.CompanyMonitoringCrawler.GetAll()
                .Where(x => x.CompanyId == request.CompanyId && !x.IsDeleted)
                .Include(x => x.MonitoringCrawler)
                .GroupBy(x => x.MonitoringCrawler.Source)
                .ToListAsync();

            _logger.LogDebug("{TotalCrawlerSource} Sources and {TotalMonitoringCrawlers} crawlers from company {CompanyId}",
                            crawlerSources.Count,
                            crawlerSources.SelectMany(x => x.Select(y => y.MonitoringCrawlerId)).Distinct().Count(),
                            request.CompanyId);

            DateTime endDate = DateTime.Now.AddDays(1).AddHours(23);
            DateTime startDate = endDate.AddMonths(-_appsettings.Value.IndexConfiguration.PeriodyInMonthToIndexing);

            List<long> listMonitoringItemIdsDelete =
                [
                 .. request.DeletedMonitoringItemIds,
                 .. request.UpdatedMonitoringItems.Select(x => x.MonitoringItemId),
                ];

            UpdateStatus(MonitoringItemResultStatusSteps.REINDEXING_DATABASE, request.CompanyId, request.TaskId, $"Total de bases: {crawlerSources.Count}");
            foreach (var source in crawlerSources)
            {
                List<long> monitoringResultIdsDelete = new List<long>();

                if (listMonitoringItemIdsDelete != null && listMonitoringItemIdsDelete.Any())
                {
                    monitoringResultIdsDelete.AddRange(await RemoveIndex(listMonitoringItemIdsDelete, source.Key));
                }

                if (source.Key == CrawlerSourceType.Predify)
                    ProcessingDataBasesOnline(source.Select(x => x.MonitoringCrawlerId), request, startDate, endDate, monitoringResultIdsDelete);
                else
                    ProcessingDataBasesOffline(source.Key, [.. source], request.CompanyId, request.NewMonitoringItems.Union(request.UpdatedMonitoringItems), startDate, endDate, request.TaskId, monitoringResultIdsDelete);
            }
        }

        public async Task GenerateIndexForCrawlerAsync(IndexGeneratorForCrawlerRequest request)
        {
            ArgumentNullException.ThrowIfNull(request);

            _logger.LogInformation("Generating index for monitoring items {TaskIds}", string.Join(",", request.TaskId));

            DateTime endDate = DateTime.Now.AddDays(1).AddHours(23);
            DateTime startDate = endDate.AddDays(-1);
            var results = await _uow.MonitoringItem.GetAll()
                  .Include(x => x.Configs)
                  .Where(x => x.Configs.Any(y => !y.IsDeleted && !y.IsExternalSearch))
                  .Where(x => x.CompanyId == request.CompanyId && !x.IsDeleted)
                  .Select(x => new { MonitoringItemId = x.Id, Ean = x.EanGtin, x.RequiredWords, x.RestrictedWords, x.Configs })
                  .ToListAsync();
            var model = new IndexGeneratorRequest()
            {
                CompanyId = request.CompanyId,
                NewMonitoringItems = results.Select(results => new MonitoringItemTags()
                {
                    MonitoringItemId = results.MonitoringItemId,
                    Eans = new List<string> { results.Ean },
                    RequiredWords = results.RequiredWords,
                    RestrictedWords = results.RestrictedWords,
                    Tags = results.Configs.Select(x => x.Description).ToList()
                }),
                CrawlerTaskId = request.TaskId
            };
            ProcessingDataBasesOnline(crawlers: null, model, startDate, endDate, new List<long>());
        }
        public async Task GenerateIndexForOfflineAsync(IndexGeneratorForOfflineRequest request)
        {
            ArgumentNullException.ThrowIfNull(request);

            _logger.LogDebug("Generating index for source {CompanyId} - base offline", request.Source);

            var crawlerSources = await _uow.CompanyMonitoringCrawler.GetAll()
                                        .Include(x => x.MonitoringCrawler)
                                        .Where(x => x.MonitoringCrawler.Source == request.Source && !x.IsDeleted)
                                        .GroupBy(x => x.CompanyId)
                                        .ToListAsync();
            foreach (var company in crawlerSources)
            {
                var monitoringItems = await _uow.MonitoringItem.GetAll()
                                        .Include(x => x.Configs)
                                        .Where(x => x.CompanyId == company.Key && !x.IsDeleted)
                                        .ToListAsync();

                monitoringItems.Select(x => x.Configs).Where(x => x.Any(y => !y.IsDeleted && !y.IsExternalSearch)).ToList();


                var monitoringItemsTag = _mapper.Map<IEnumerable<MonitoringItemTags>>(monitoringItems);

                ProcessingDataBasesOffline(request.Source, [.. company], company.Key, monitoringItemsTag, request.StartDate, request.EndDate, taskId: null, new List<long>());
            }
        }

        private async void ProcessingDataBasesOnline(IEnumerable<int> crawlers, IndexGeneratorRequest request, DateTime startDate, DateTime endDate, List<long> listIdsDelete)
        {
            QueueItemForPredify(request, crawlers, startDate, endDate, listIdsDelete);
        }

        private async void ProcessingDataBasesOffline(CrawlerSourceType source, IEnumerable<CompanyMonitoringCrawlerEntity> monitoringCrawlerEntities, long companyId, IEnumerable<MonitoringItemTags> monitoringItems, DateTime startDate, DateTime endDate, Guid? taskId, List<long> monitoringResultIdsDelete)
        {
            _logger.LogInformation("Processing database offline for company {CompanyId}", companyId);
            foreach (var crawler in monitoringCrawlerEntities.GroupBy(x => x.MonitoringCrawlerId))
            {
                _logger.LogInformation("Processing database offline for company {CompanyId} and source {Source} and crawler {CrawlerId}", companyId, source.ToString(), crawler.Key);
                switch (source)
                {
                    case CrawlerSourceType.Horus:
                        QueueItemForHorus(companyId, monitoringItems, crawler.Key, crawler, startDate, endDate, taskId, monitoringResultIdsDelete);
                        break;

                    case CrawlerSourceType.HorusAtacado:
                        QueueItemForHorusAtacado(companyId, monitoringItems, crawler.Key, crawler, startDate, endDate, taskId, monitoringResultIdsDelete);
                        break;

                    case CrawlerSourceType.InfoPriceSaoJoao:
                        QueueItemForInfoPriceSaoJoao(companyId, monitoringItems, crawler.Key, startDate, endDate, taskId, monitoringResultIdsDelete);
                        break;

                    case CrawlerSourceType.Indireta:
                        QueueItemForIndireta(companyId, monitoringItems, crawler.Key, startDate, endDate, taskId, monitoringResultIdsDelete);
                        break;

                    case CrawlerSourceType.SmarketABV:
                        QueueItemForSmarketABV(companyId, monitoringItems, crawler.Key, startDate, endDate, taskId, monitoringResultIdsDelete);
                        break;

                    case CrawlerSourceType.NielsenPeralta:
                        QueueItemForNielsenPeralta(companyId, monitoringItems, crawler.Key, crawler, startDate, endDate, taskId, monitoringResultIdsDelete);
                        break;

                    case CrawlerSourceType.NielsenVem:
                        QueueItemForNielsenVem(companyId, monitoringItems, crawler.Key, crawler, startDate, endDate, taskId, monitoringResultIdsDelete);
                        break;

                    case CrawlerSourceType.InfoPricePeralta:
                        QueueItemForInfoPricePeralta(companyId, monitoringItems, crawler.Key, startDate, endDate, taskId, monitoringResultIdsDelete);
                        break;

                    case CrawlerSourceType.OfflineSupermarketTorre:
                        QueueItemForOfflineSupermarketTorre(companyId, monitoringItems, crawler.Key, startDate, endDate, taskId, monitoringResultIdsDelete);
                        break;

                    case CrawlerSourceType.InfoPriceTorre:
                        QueueItemForInfoPriceTorre(companyId, monitoringItems, crawler.Key, startDate, endDate, taskId, monitoringResultIdsDelete);
                        break;
                    case CrawlerSourceType.ScantechSupermaxi:
                        QueueItemForScantechSupermaxi(companyId, monitoringItems, crawler.Key, startDate, endDate, taskId, monitoringResultIdsDelete);
                        break;
                }
            }
        }

        private void QueueItemForInfoPricePeralta(long companyId, IEnumerable<MonitoringItemTags> monitoringItems, int crawlerId, DateTime startDate, DateTime endDate, Guid? taskId, List<long> monitoringResultIdsDelete)
        {
            _backgroundTaskQueue.QueueBackgroundWorkItem(async (cancelation, service) =>
            {
                using var scope = service.CreateScope();
                await scope.ServiceProvider.GetService<IIndexGeneratorInfoPricePeraltaDomain>()!
                    .GenerateIndexInfoPricePeraltaAsync(companyId,
                                                crawlerId,
                                                monitoringItems,
                                                startDate, endDate, taskId, monitoringResultIdsDelete);
            });
        }

        private void QueueItemForInfoPriceTorre(long companyId, IEnumerable<MonitoringItemTags> monitoringItems, int crawlerId, DateTime startDate, DateTime endDate, Guid? taskId, List<long> monitoringResultIdsDelete)
        {
            _backgroundTaskQueue.QueueBackgroundWorkItem(async (cancelation, service) =>
            {
                using var scope = service.CreateScope();
                await scope.ServiceProvider.GetService<IIndexGeneratorInfoPriceTorreDomain>()!
                    .GenerateIndexInfoPriceTorreAsync(companyId,
                                                crawlerId,
                                                monitoringItems,
                                                startDate, endDate, taskId, monitoringResultIdsDelete);
            });
        }

        private void QueueItemForInfoPriceSaoJoao(long companyId, IEnumerable<MonitoringItemTags> monitoringItems, int crawlerId, DateTime startDate, DateTime endDate, Guid? taskId, List<long> monitoringResultIdsDelete)
        {
            _backgroundTaskQueue.QueueBackgroundWorkItem(async (cancelation, service) =>
            {
                using var scope = service.CreateScope();
                await scope.ServiceProvider.GetService<IIndexGeneratorInfoPriceDomain>()!
                    .GenerateIndexSaoJoaoAsync(companyId,
                                                crawlerId,
                                                monitoringItems,
                                                startDate, endDate, taskId, monitoringResultIdsDelete);
            });
        }

        private void QueueItemForIndireta(long companyId, IEnumerable<MonitoringItemTags> monitoringItems, int crawlerId, DateTime startDate, DateTime endDate, Guid? taskId, List<long> monitoringResultIdsDelete)
        {
            _backgroundTaskQueue.QueueBackgroundWorkItem(async (cancelation, service) =>
            {
                using var scope = service.CreateScope();
                await scope.ServiceProvider.GetService<IIndexGeneratorIndiretaDomain>()!
                    .GenerateIndexAsync(companyId,
                                        crawlerId,
                                        monitoringItems,
                                        startDate, endDate, taskId, monitoringResultIdsDelete);
            });
        }

        private void QueueItemForSmarketABV(long companyId, IEnumerable<MonitoringItemTags> monitoringItems, int crawlerId, DateTime startDate, DateTime endDate, Guid? taskId, List<long> monitoringResultIdsDelete)
        {
            _backgroundTaskQueue.QueueBackgroundWorkItem(async (cancelation, service) =>
            {
                using var scope = service.CreateScope();
                await scope.ServiceProvider.GetService<IIndexGeneratorSmarketDomain>()!
                    .GenerateIndexABVAsync(companyId, crawlerId, monitoringItems, startDate, endDate, taskId, monitoringResultIdsDelete);
            });
        }

        private void QueueItemForHorus(long companyId, IEnumerable<MonitoringItemTags> monitoringItems, int crawlerId, IEnumerable<CompanyMonitoringCrawlerEntity> crawler, DateTime startDate, DateTime endDate, Guid? taskId, List<long> monitoringResultIdsDelete)
        {
            var request = CreateHorusMonitoringRequest(companyId, monitoringItems, crawlerId, crawler, startDate, endDate, taskId, monitoringResultIdsDelete);

            _backgroundTaskQueue.QueueBackgroundWorkItem(async (cancelation, service) =>
            {
                using var scope = service.CreateScope();
                await scope.ServiceProvider.GetService<IIndexGeneratorHorusDomain>()!
                    .GenerateIndexAsync(request);
            });
        }

        private void QueueItemForHorusAtacado(long companyId, IEnumerable<MonitoringItemTags> monitoringItems, int crawlerId, IEnumerable<CompanyMonitoringCrawlerEntity> crawler, DateTime startDate, DateTime endDate, Guid? taskId, List<long> monitoringResultIdsDelete)
        {
            var request = CreateHorusMonitoringRequest(companyId, monitoringItems, crawlerId, crawler, startDate, endDate, taskId, monitoringResultIdsDelete);

            _backgroundTaskQueue.QueueBackgroundWorkItem(async (cancelation, service) =>
            {
                using var scope = service.CreateScope();
                await scope.ServiceProvider.GetService<IIndexGeneratorHorusDomain>()!
                    .GenerateIndexAtacadoAsync(request);
            });
        }

        private void QueueItemForNielsenPeralta(long companyId, IEnumerable<MonitoringItemTags> monitoringItems, int crawlerId, IEnumerable<CompanyMonitoringCrawlerEntity> crawler, DateTime startDate, DateTime endDate, Guid? taskId, List<long> monitoringResultIdsDelete)
        {
            _backgroundTaskQueue.QueueBackgroundWorkItem(async (cancelation, service) =>
            {
                using var scope = service.CreateScope();
                await scope.ServiceProvider.GetService<IIndexGeneratorNielsenPeraltaDomain>()!
                    .GenerateIndexAsync(companyId
                        , crawlerId
                        , monitoringItems
                        , startDate, endDate
                        , crawler.Select(x => x.Store).Where(x => !string.IsNullOrWhiteSpace(x))
                        , crawler.Select(x => x.State).Where(x => !string.IsNullOrWhiteSpace(x)), taskId, monitoringResultIdsDelete);
            });
        }

        private void QueueItemForScantechSupermaxi(long companyId, IEnumerable<MonitoringItemTags> monitoringItems, int crawlerId, DateTime startDate, DateTime endDate, Guid? taskId, List<long> monitoringResultIdsDelete)
        {
            _backgroundTaskQueue.QueueBackgroundWorkItem(async (cancelation, service) =>
            {
                using var scope = service.CreateScope();
                await scope.ServiceProvider.GetService<IIndexGeneratorScantechSupermaxiDomain>()!
                    .GenerateIndexScantechSupermaxiAsync(companyId,
                                                crawlerId,
                                                monitoringItems,
                                                startDate, endDate, taskId, monitoringResultIdsDelete);
            });
        }

        private HorusMonitoringRequest CreateHorusMonitoringRequest(
            long companyId,
            IEnumerable<MonitoringItemTags> monitoringItems,
            int crawlerId,
            IEnumerable<CompanyMonitoringCrawlerEntity> crawler,
            DateTime startDate,
            DateTime endDate,
            Guid? taskId,
            List<long> monitoringResultIdsDelete)
        {
            return new HorusMonitoringRequest
            {
                CompanyId = companyId,
                CrawlerId = crawlerId,
                MonitoringItems = monitoringItems,
                StartDate = startDate,
                EndDate = endDate,
                Cnpjs = crawler.Select(x => x.Cnpj).Where(x => !string.IsNullOrWhiteSpace(x)),
                Cities = crawler.Select(x => x.City).Where(x => !string.IsNullOrWhiteSpace(x)),
                States = crawler.Select(x => x.State).Where(x => !string.IsNullOrWhiteSpace(x)),
                StoreType = crawler.Select(x => x.StoreType).Where(x => !string.IsNullOrWhiteSpace(x)),
                TaskId = taskId,
                MonitoringResultIdsDelete = monitoringResultIdsDelete
            };
        }

        private void QueueItemForNielsenVem(long companyId, IEnumerable<MonitoringItemTags> monitoringItems, int crawlerId, IEnumerable<CompanyMonitoringCrawlerEntity> crawler, DateTime startDate, DateTime endDate, Guid? taskId, List<long> monitoringResultIdsDelete)
        {
            _backgroundTaskQueue.QueueBackgroundWorkItem(async (cancelation, service) =>
            {
                using var scope = service.CreateScope();
                await scope.ServiceProvider.GetService<IIndexGeneratorNielsenVemDomain>()!
                    .GenerateIndexAsync(companyId
                        , crawlerId
                        , monitoringItems
                        , startDate, endDate
                        , crawler.Select(x => x.StoreType).Where(x => !string.IsNullOrWhiteSpace(x))
                        , crawler.Select(x => x.State).Where(x => !string.IsNullOrWhiteSpace(x)), taskId, monitoringResultIdsDelete);
            });
        }
        private async void QueueItemForPredify(IndexGeneratorRequest request, IEnumerable<int> crawlerIds, DateTime startDate, DateTime endDate, List<long> listIdsDelete)
        {
            _backgroundTaskQueue.QueueBackgroundWorkItem(async (cancelation, service) =>
            {
                using var scope = service.CreateScope();
                if (request.CrawlerTaskId.HasValue)
                    await scope.ServiceProvider.GetService<IIndexGeneratorPredifyDomain>()!
                      .GenerateIndexForCrawlersAsync(request.CompanyId
                          , request.NewMonitoringItems.Union(request.UpdatedMonitoringItems)
                          , request.CrawlerTaskId);
                else
                    await scope.ServiceProvider.GetService<IIndexGeneratorPredifyDomain>()!
                    .GenerateIndexAsync(request.CompanyId
                        , crawlerIds
                        , request.NewMonitoringItems.Union(request.UpdatedMonitoringItems)
                        , startDate, endDate, request.TaskId, listIdsDelete);


            });
        }

        private void QueueItemForOfflineSupermarketTorre(long companyId, IEnumerable<MonitoringItemTags> monitoringItems, int crawlerId, DateTime startDate, DateTime endDate, Guid? taskId, List<long> monitoringResultIdsDelete)
        {
            _backgroundTaskQueue.QueueBackgroundWorkItem(async (cancelation, service) =>
            {
                using var scope = service.CreateScope();
                await scope.ServiceProvider.GetService<IIndexGeneratorOfflineSupermarketTorreDomain>()!
                    .GenerateIndexAsync(companyId
                        , crawlerId
                        , monitoringItems
                        , startDate, endDate
                        , taskId, monitoringResultIdsDelete);
            });
        }

        private async Task<List<long>> RemoveIndex(IEnumerable<long> monitoringItemIds, CrawlerSourceType source)
        {
            return await _uow.MonitoringItemResults.GetAll()
                .Where(x => monitoringItemIds
                .Contains(x.MonitoringItemId)
                && x.MonitoringCrawler.Source == source)
                .Select(x => x.Id)
                .ToListAsync();
        }
    }
}
