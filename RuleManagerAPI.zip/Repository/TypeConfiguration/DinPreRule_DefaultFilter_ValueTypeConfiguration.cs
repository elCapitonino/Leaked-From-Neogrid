﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Repository.Entity;

namespace Repository.TypeConfiguration
{
    public sealed class DinPreRule_DefaultFilter_ValueTypeConfiguration : TypeConfigurationBase<DinPreRule_DefaultFilter_ValueEntity>, IEntityTypeConfiguration<DinPreRule_DefaultFilter_ValueEntity>
    {
        public override void Configure(EntityTypeBuilder<DinPreRule_DefaultFilter_ValueEntity> builder)
        {
            ConfigureTableName(builder, "DinPreRule_DefaultFilter_Value");
            builder.ToTable("DinPreRule_DefaultFilter_Value", table => table.ExcludeFromMigrations());
            builder.Ignore(x => x.Id);
            builder.HasKey(x => x.DinPreRule_DefaultFilter_ValueId);
            builder.Property(x => x.DinPreRule_DefaultFilter_ValueId).HasColumnName("IdDinPreRule_DefaultFilter_Value");
            builder.Property(x => x.CreatedDate).HasColumnName("DataHoraCriacao");
            builder.Property(x => x.UpdatedDate).HasColumnName("DataHoraUltimaAlteracao");

            builder.HasOne(x => x.Rule).WithMany(x => x.Filters).HasForeignKey(x => x.IdRule);
            builder.HasOne(x => x.DefaultFilter).WithMany().HasForeignKey(x => x.IdEnterprisePriceGroups_DefaultFilter);
        }
    }
}
