﻿namespace DI.Repository.Entities
{
    public sealed class MonthlySaleHistoryImportStatusEntity : BaseEntity
    {
        public required long CompanyId { get; set; }
        public DateTime? RegisterLastCreateDate { get; set; }
        public required string Status { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public DateTime? MaxIssuance { get; set; }
        public DateTime? MinIssuance { get; set; }
    }
}
