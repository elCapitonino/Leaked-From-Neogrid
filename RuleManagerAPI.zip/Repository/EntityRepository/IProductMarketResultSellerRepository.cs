﻿using Repository.Entity;

namespace Repository.EntityRepository
{
    public interface IProductMarketResultSellerRepository : IGenericRepository<ProductMarketResultSellerEntity>
    {
    }
}
