from processing import Processing

from logger import logger


class Processing_product:
    def __init__(self):
        self.prep = Processing()
        # print("inicio Processing_product ")

    def run(self, texto: str) -> str:
        texto = texto.split(' ')
        list = []
        for i in texto:
            texto_processado = self.prep.normalizador(i)
            #texto_processado = texto_processado.replace(' ', '')

            list.append(texto_processado)

        list = ' '.join(list)
        #list = list.replace(',', ' ')
        logger.info(list)
        return list

    def get_products_time(self, product_p):
        # print(product_p)
        tail = product_p
        list_remove = []
        while len(tail) > 1:
            head, *tail = tail
            # print("######################################")

            for i in tail:
                # print("---------------------------------------------")
                if(head['product_link'] == i['product_link']):
                    # print("igual")
                    # print("head : ", head['product_link'])
                    # print("i : ", i['product_link'])
                    # print("head id : ", head['id'], " i id : ", i['id'])
                    if(head['crawler_date'] > i['crawler_date']):
                        # print("head> ", head["crawler_date"],
                        #       " i ", i["crawler_date"])
                        list_remove.append(i['id'])
                    if(head['crawler_date'] < i['crawler_date']):
                        # print("head< ", head["crawler_date"],
                        #       " i ", i["crawler_date"])

                        list_remove.append(head['id'])
                    if(head['crawler_date'] == i['crawler_date']):
                        list_remove.append(head['id'])

        list_remove_set = set(list_remove)
        #print("list_remove_set ", list_remove_set)

        for i in list_remove_set:
            for j in product_p:
                if(i == j['id']):
                    product_p.remove(j)

        # print(product_p)

        return product_p

        # print("######################################")
        # print("result ", product_p)
