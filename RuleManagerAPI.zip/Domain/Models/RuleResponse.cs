﻿using Repository.Enums;

namespace Domain.Models
{
    public sealed class RuleResponse
    {
        public long ConditionId { get; set; }

        public ERuleType ConditionType { get; set; }

        public string ConditionDescription
        {
            get
            {
                return ConditionType.ToString();
            }
        }

        public int NumberOrder { get; set; }

        public bool IsActive { get; set; }

        public ICollection<RuleValueResponse>? Values { get; set; }
    }

    public sealed class RuleValueResponse
    {
        public required string StringValue { get; set; }
        public decimal DecimalValue { get; set; }
        public bool BooleanValue { get; set; }
    }
}
