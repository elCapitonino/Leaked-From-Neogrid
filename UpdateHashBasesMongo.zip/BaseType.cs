﻿namespace UpdateHashHorus
{
    public enum BaseType
    {
        None,
        Horus,
        NilsenPeralta,
        NielsenVem,
        InfoPrice,
        Indireta,
        Smarket,
    }
}
