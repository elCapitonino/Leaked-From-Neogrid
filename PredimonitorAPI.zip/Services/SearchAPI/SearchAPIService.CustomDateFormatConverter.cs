﻿using Newtonsoft.Json;

namespace Services.SearchAPI
{
    public partial class SearchAPIService
    {
        public class CustomDateFormatConverter : JsonConverter
        {
            private readonly string _format;

            public CustomDateFormatConverter(string format)
            {
                _format = format;
            }

            public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
            {
                var dateTime = (DateTime)value;
                writer.WriteValue(dateTime.ToString(_format));
            }

            public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
            {
                var dateTimeString = (string)reader.Value;
                return DateTime.ParseExact(dateTimeString, _format, null);
            }

            public override bool CanConvert(Type objectType)
            {
                return objectType == typeof(DateTime);
            }
        }
    }
}
