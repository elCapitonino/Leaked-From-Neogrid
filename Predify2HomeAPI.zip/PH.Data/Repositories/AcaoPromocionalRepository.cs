﻿using Microsoft.Extensions.Options;
using MongoDB.Driver;
using PH.Domain.Domain;
using PH.Domain.Interfaces.Repositories;
using PH.Domain.Settings;

namespace PH.Data.Repositories
{
    public class AcaoPromocionalRepository : IAcaoPromocionalRepository
    {
        private readonly IMongoCollection<AcaoPromocional> _collection;
        private static string COLLECTION_NAME = "AcaoPromocional";

        public AcaoPromocionalRepository(IOptions<MongoSettings> mongoSettings)
        {
            var mongoClient = new MongoClient(mongoSettings.Value.ConnectionString);
            var mongoDatabase = mongoClient.GetDatabase(mongoSettings.Value.DatabaseName);
            _collection = mongoDatabase.GetCollection<AcaoPromocional>(COLLECTION_NAME);
        }

        public async Task<AcaoPromocional> GetById(string acaoPromocionalId)
        {
            var acaoPromocionals = await _collection.FindAsync(c => c.Id == acaoPromocionalId);
            return acaoPromocionals.FirstOrDefault();
        }

        public async Task<List<AcaoPromocional>> GetAll()
        {
            var acaoPromocionals = await _collection.FindAsync(c => true);
            return acaoPromocionals.ToList();
        }

        public async Task Add(AcaoPromocional acaoPromocional)
        {
            await _collection.InsertOneAsync(acaoPromocional);
        }

        public async Task RemoveById(string acaoPromocionalId)
        {
            await _collection.DeleteOneAsync(c => c.Id == acaoPromocionalId);
        }

        public async Task Update(string acaoPromocionalId, AcaoPromocional newAcaoPromocional)
        {
            await _collection.ReplaceOneAsync(c => c.Id == acaoPromocionalId, newAcaoPromocional);
        }
    }
}
