﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;
using MongoDB.Driver.GeoJsonObjectModel;

namespace Repository.Entity.ProductPrices
{
    public class ProductPricesSeller
    {
        [BsonElement("stock_quantity")]
        public decimal? StockQuantity { get; set; }

        [BsonElement("seller_name")]
        public string? SellerName { get; set; }

        [BsonElement("seller_link")]
        public string? SellerLink { get; set; }

        [BsonElement("seller_cpf_cnpj")]
        public string? SellerCPF_CNPJ { get; set; }

        [BsonElement("complete_address")]
        public string? CompleteAddress { get; set; }

        [BsonElement("country_name")]
        public string? CountryName { get; set; }

        [BsonElement("country_iso_code")]
        public string? CountryIsoCode { get; set; }

        [BsonElement("state_uf")]
        public string? StateUF { get; set; }

        [BsonElement("city")]
        public string? City { get; set; }

        [BsonElement("neighborhood")]
        public string? Neighborhood { get; set; }

        [BsonElement("street")]
        public string? Street { get; set; }

        [BsonElement("number")]
        public string? Number { get; set; }

        [BsonElement("address_complement")]
        public string? AddressComplement { get; set; }

        [BsonElement("zip_code")]
        public string? ZipCode { get; set; }

        [BsonElement("prices")]
        public List<ProductPricesSellerPrice>? Prices { get; set; }

        [BsonElement("shippings")]
        [BsonIgnoreIfNull]
        public List<ProductPricesShipping>? Shippings { get; set; } = new List<ProductPricesShipping>();

        [BsonElement("product_manufacture_year")]
        public int? ManufactureYear { get; set; }

        [BsonElement("product_used_hours")]
        public int? UsedHours { get; set; }

        [BsonElement("coordinates")]
        public GeoJson2DGeographicCoordinatesWrapper? Coordinates { get; set; }
    }
}
