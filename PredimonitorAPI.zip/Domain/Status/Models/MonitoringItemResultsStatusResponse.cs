﻿using Repository.Enums;

namespace Domain.Status.Models
{
    public class MonitoringItemResultsStatusResponse
    {
        public long CompanyId { get; set; }
        public MonitoringItemResultsStatusType Status { get; set; }
        public int CurrentStep { get; set; }
        public string? Message{ get; set; }
        public Guid? TaskId { get; set; }
        public double? Percent { get; internal set; }
        public int Total { get; internal set; }
        public int Indexed { get; internal set; }
    }
}
