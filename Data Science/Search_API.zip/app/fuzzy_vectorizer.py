"""
Vetorizador fuzzy. Utiliza fuzzy search para considerar palavras muito semelhantes como
a mesma palavra. Em seguida, constrói-se um vetor para cada string com a contagem de cada
palavra (token).
"""

import re
from typing import List

import numpy as np
from rapidfuzz import process, distance

from logger import logger


class FuzzyCountVectorizer:
    def __init__(
        self,
        min_fuzzy_similarity=0.8,
        token_pattern=r"(?u)\b\w\w+\b",
        max_length: int = 128,
    ):
        self.token_pattern = re.compile(token_pattern)
        self.min_fuzzy_similarity = min_fuzzy_similarity
        self.max_length = max_length
        self.vocabulary = None
        self.fuzzy_lookup = None

    def _tokenize(self, txt: str) -> List[str]:
        return self.token_pattern.findall(txt)

    def _fuzzy_mapping(self, vocabulary: List[str]):
        fuzzy_lookup = {}
        for token in vocabulary:
            # TODO solução temporária para evitar fuzzy com número de modelo
            if not token.isalpha():
                fuzzy_lookup[token] = [token]
                continue
            fuzzy_match = process.extract(
                token,
                vocabulary,
                score_cutoff=self.min_fuzzy_similarity,
                scorer=distance.Levenshtein.normalized_similarity,
            )
            fuzzy_lookup[token] = [x[0] for x in fuzzy_match]
        return fuzzy_lookup

    def fit_transform(self, raw_documents: List[str], y=None):
        # fit
        tokenized_docs = [
            self._tokenize(doc) for doc in raw_documents
        ]
        if any(len(doc) > self.max_length for doc in tokenized_docs):
            logger.warning(
                "string com mais de %d tokens fornecida, limitando a %d tokens",
                self.max_length,
                self.max_length,
            )
        tokens = {token for doc in tokenized_docs for token in doc}
        vocabulary = sorted(tokens)
        self.fuzzy_lookup = self._fuzzy_mapping(vocabulary)
        self.vocabulary = {token: i for i, token in enumerate(vocabulary)}
        matrix = np.zeros((2, len(self.vocabulary)))

        # transform
        for i, doc in enumerate(tokenized_docs):
            for token in doc:
                aliases = self.fuzzy_lookup.get(token, [token])
                for alias in aliases:
                    matrix[i, self.vocabulary[alias]] += 1

        lengths = [len(doc) for doc in tokenized_docs]
        return (matrix, lengths)
