﻿namespace Repository.Entity
{
    public class CompanyMonitoringCrawlerFiltersValuesEntity : BaseEntity
    {
        public long CompanyMonitoringCrawlerFiltersId { get; set; }
        public CompanyMonitoringCrawlerFiltersEntity CompanyMonitoringCrawlerFilters { get; set; }

        public string Values { get; set; }

        public bool IsDeleted { get; set; }

    }
}
