using Repository.Entity.Databricks;
using Repository.EntityRepository.Bases;

namespace Repository.EntityRepository;

public interface ICompanyProductPriceRepository : IGenericDatabricksRepository<CompanyProductPriceEntity>
{
}