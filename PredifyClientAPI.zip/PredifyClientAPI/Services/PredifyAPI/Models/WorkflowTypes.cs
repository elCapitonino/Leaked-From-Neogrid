﻿namespace PredifyClientAPI.Services.PredifyAPI.Models
{
    public enum WorkflowType
    {
        None = 0,
        PriceProjection = 1,
    }

    public enum WorkflowUserType
    {
        User = 0,
        System = 1,
    }

    public enum WorkflowAction_Action
    {
        Approval = 0,
        Repproval = 1,
        RankUp = 2,
    }

    public enum ApprovalType_OLD
    {
        None = 0,
        PriceBeacon = 1,
        User = 2
    }

    public enum ApprovalStatus_OLD
    {
        None = 0,
        Pending = 1,
        Approved = 2,
        Rejected = 3,
        Scaled = 4
    }
}
