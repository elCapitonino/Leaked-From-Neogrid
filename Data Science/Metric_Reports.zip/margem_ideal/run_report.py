import argparse
import json
import os
import sys
from datetime import datetime

CONFIG_FILENAME = ".config_ipynb"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--env", type=str, default="producao", choices=["producao", "preproducao"]
    )
    parser.add_argument("--id-company", type=int, required=True)
    parser.add_argument(
        "--start-date",
        type=lambda s: datetime.strptime(s, "%Y-%m-%d").date().isoformat(),
        required=True,
    )
    parser.add_argument("--ipynb-filename", type=str, default="margem_ideal.ipynb")
    parser.add_argument(
        "--cat-fields",
        type=str,
        nargs="+",
        required=True,
        help="colunas de categoria que entrarão no relatório.",
    )
    parser.add_argument(
        "--debug", action="store_true", help="debugging mode. Saves data locally."
    )
    args = parser.parse_args()

    if args.debug:
        print(
            "!!!WARNING!!!: modo DEBUG, usando dados LOCAIS se disponíveis. Apenas para desenvolvimento."
        )

    with open(CONFIG_FILENAME, "w", encoding="utf-8") as f:
        json.dump(vars(args), f)

    file_format = "pdf" if sys.platform == "linux" else "html"
    os.system(f"jupyter nbconvert --execute {args.ipynb_filename} --to {file_format} --no-input")


if __name__ == "__main__":
    main()
