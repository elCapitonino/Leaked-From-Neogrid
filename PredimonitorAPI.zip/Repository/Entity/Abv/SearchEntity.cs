﻿using MongoDB.Bson.Serialization.Attributes;

namespace Repository.Entity.Abv
{
    public class SearchEntity
    {
        [BsonElement("SEQPESQUISA")]
        public long? SeqPesquisa { get; set; }

        [BsonElement("DESCRICAO")]
        public string? Descricao { get; set; }

        [BsonElement("DH_INICIO")]
        public DateTime? DhInicio { get; set; }

        [BsonElement("DH_FIM")]
        public DateTime? DhFim { get; set; }
    }

}
