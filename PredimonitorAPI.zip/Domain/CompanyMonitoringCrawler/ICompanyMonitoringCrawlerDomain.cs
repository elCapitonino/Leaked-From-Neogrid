using Repository.Entity;
using Repository.Enums;
using Repository.Models.Databricks;

namespace Domain.CompanyMonitoringCrawler;

public interface ICompanyMonitoringCrawlerDomain
{
    Task<List<CompanyMonitoringCrawlerEntity>> GetCompanyMonitoringCrawler(long companyId, bool IsCost);
}