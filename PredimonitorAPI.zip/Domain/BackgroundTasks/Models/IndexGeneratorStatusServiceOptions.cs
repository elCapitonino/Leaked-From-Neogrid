﻿namespace Domain.BackgroundTasks.Models
{
    public class IndexGeneratorStatusServiceOptions
    {
        public TimeSpan Interval { get; set; }
        public bool Enabled { get; set; }
    }
}
