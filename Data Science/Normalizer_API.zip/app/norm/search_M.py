from norm.search import Search


class Search_M:
    def __init__(self):
        self.search = Search()
        # self.ean = ''
        # self.ncm = ''
        # self.model = ''
        #print("----------- Search_M ----------------")

    def search_products(self, ean, ncm, model, product, language):
        """_summary_

        Args:
            ean (_type_): numero ean
            ncm (_type_): numero ncm
            model (_type_):modelo
            product (_type_): nome do produto
            language (_type_): idioma

        Returns:
            _type_: lista com id dos produtos encontrados
        """
        self.search_Market = Search()
        # if(product["product"] != None):
        #     print(product)
        # list_product = self.search_Market.search_full(product["product"], product["brands"], product['voltage'], product['materials'], product['metric_units'],
        #                                               product['power'], product['trash'], product['dimensions'], product['energy_source'], product['size'], product['language'])

        product = [product]
        list_product = self.search_Market.search_full_pred_monitor(
            product, language)
        #print("list_product:", list_product)
        return list_product

    def search_pred_monitor(self, list_product, language, exactVector:bool=True):

        #print("list_product 05:", list_product, language)
        list_product_predmonitor = self.search.search_full_pred_monitor(
            list_product, language, exactVector)
        #print("list_product_predmonitor 05:", list_product_predmonitor)

        return list_product_predmonitor

    def search_brand_pred_monitor(self, list_product, language):

        #print("list_product 05:", list_product)

        list_product_predmonitor = self.search.search_brand_pred_monitor(
            list_product, language)

        return list_product_predmonitor

    def search_category_pred_monitor_unique(self, list_product, language):

        #print("list_product 05:", list_product)

        list_product_predmonitor = self.search.search_category_pred_monitor(
            list_product, language)

        return list_product_predmonitor
