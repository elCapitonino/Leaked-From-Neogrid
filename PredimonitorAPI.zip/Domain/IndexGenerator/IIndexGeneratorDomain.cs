﻿using Domain.IndexGenerator.Models;

namespace Domain.IndexGenerator
{
    public interface IIndexGeneratorDomain
    {
        Task GenerateIndexAsync(IndexGeneratorRequest request);
        Task GenerateIndexForCrawlerAsync(IndexGeneratorForCrawlerRequest request);
        Task GenerateIndexForOfflineAsync(IndexGeneratorForOfflineRequest request);
    }
}
