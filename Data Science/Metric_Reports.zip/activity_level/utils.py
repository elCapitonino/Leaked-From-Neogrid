from datetime import timedelta

import pandas as pd

from xlsxwriter.utility import xl_col_to_name


def activity_level_sheet(conn, id_company: int, granularity: list[str]) -> pd.DataFrame:
    data = pd.read_sql_query(
        """
        SELECT * FROM EnterpriseActivityLevel
        WHERE IdCompany = ? AND IsDeleted = 0
        AND CreateDate = (
            SELECT MAX(CreateDate)
            FROM EnterpriseActivityLevel
            WHERE IdCompany = ? AND IsDeleted = 0
        )
        """,
        conn,
        params=[id_company, id_company],
    )

    data = data.rename(columns={"Frequency1": "Frequency"})
    for i, col in enumerate(granularity):
        data = data.rename(columns={f"Granularity{i+1}": col})

    data["Frequency"] = data["Frequency"].astype(int)
    data["TotalTickets"] = data["TotalTickets"].astype(int)
    data["PercentTickets"] = data["Frequency"] / data["TotalTickets"]

    # NOTE frequências maiores primeiro
    data = data.sort_values(
        [*granularity[1:], "Frequency"],
        ascending=[*[True for _ in range(len(granularity) - 1)], False],
    )
    data = data[
        [
            *granularity,
            "Frequency",
            "TotalTickets",
            "MeanFrequencyDay",
            "PercentTickets",
            "StorageIndex",
            "ActivityLevel",
        ]
    ]

    return data


def activity_level_pivot(
    conn, id_company: int, lookback: int, prod_id: str, granularity: list[str]
):
    cur = conn.cursor()
    cur.execute(
        """
        SELECT MAX(Issuance) FROM Enterprise_Sales_History
        WHERE IdCompany = ? AND IsDeletado = 0
        """,
        id_company,
    )
    min_issuance = cur.fetchone()[0] - timedelta(days=lookback)
    cur.close()

    cols_str = ",".join([prod_id, *granularity])
    data = pd.read_sql_query(
        f"""
        SELECT Issuance, {cols_str}, ALTotalTickets, ALGranularityTickets
        FROM Enterprise_Sales_History
        WHERE IdCompany = ? AND IsDeletado = 0 AND Issuance > ?
        """,
        conn,
        params=[id_company, min_issuance],
    )

    df_total = (
        data.groupby([*granularity, "Issuance"])["ALTotalTickets"].first().reset_index()
    )

    # NOTE cross join
    df_total["dummy"] = 0
    data["dummy"] = 0
    df_description = data.groupby("Description")["dummy"].first().reset_index()
    df_total = pd.merge(df_total, df_description, how="outer")
    data = pd.merge(
        df_total,
        data.drop(columns=["ALTotalTickets"]),
        on=[prod_id, *granularity, "Issuance"],
        how="outer",
    )

    data["ALGranularityTickets"] = data["ALGranularityTickets"].fillna(0)
    data = data.sort_values("Issuance", ascending=False)

    data["str_freq"] = (
        data["ALGranularityTickets"].astype(int).astype(str)
        + "/"
        + data["ALTotalTickets"].astype(int).astype(str)
    )

    data = data.sort_values("Issuance")
    data = (
        data.pivot(columns="Issuance", index=[prod_id, *granularity], values="str_freq")
        .reset_index()
        .fillna("0/0")
    )
    data = data.sort_values([prod_id, *granularity])

    return data


def remove_missing_granularity(
    pivot_sheet: pd.DataFrame,
    al_sheet: pd.DataFrame,
    granularity: list[str],
) -> pd.DataFrame:
    pivot_sheet = pivot_sheet.copy()
    al_sheet = al_sheet.copy()

    al_sheet["dummy"] = 0
    pivot_sheet["dummy"] = 0
    present_gran = al_sheet.groupby(granularity)["dummy"].first().reset_index()
    pivot_sheet = pd.merge(
        pivot_sheet, present_gran, on=[*granularity, "dummy"], how="inner"
    )

    al_sheet = al_sheet.drop(columns="dummy")
    pivot_sheet = pivot_sheet.drop(columns="dummy")

    return pivot_sheet


def reorder_pivot_columns(
    pivot_sheet: pd.DataFrame, granularity: list[str]
) -> pd.DataFrame:
    pivot_cols = pivot_sheet.columns
    date_cols = list(sorted(pivot_cols[len(granularity) + 1 :]))
    pivot_sheet = pivot_sheet[[*pivot_cols[: len(granularity) + 1], *date_cols]]
    pivot_sheet.columns = [
        *pivot_cols[: len(granularity) + 1],
        *[d.strftime("%d-%m-%Y") for d in date_cols],
    ]
    return pivot_sheet


def save_excel(fname: str, al_sheet: pd.DataFrame, pivot_sheet: pd.DataFrame) -> None:
    with pd.ExcelWriter(fname, engine="xlsxwriter") as writer:
        al_sheet.to_excel(writer, sheet_name="Nível de Atividade", index=False)
        pivot_sheet.to_excel(writer, sheet_name="Dados Diários", index=False)
        # Get the xlsxwriter workbook and worksheet objects.
        workbook = writer.book
        worksheet = writer.sheets["Nível de Atividade"]

        float_cols = [i for i, type in enumerate(al_sheet.dtypes) if type == "float"]
        format1 = workbook.add_format({"num_format": "0.00"})
        format2 = workbook.add_format({"num_format": "0.00%"})
        for col in float_cols:
            worksheet.set_column(
                f"{xl_col_to_name(col)}:{xl_col_to_name(col)}", None, format1
            )
        pct_col = al_sheet.columns.to_list().index("PercentTickets")
        worksheet.set_column(
            f"{xl_col_to_name(pct_col)}:{xl_col_to_name(pct_col)}", None, format2
        )
        worksheet.autofit()

        worksheet = writer.sheets["Dados Diários"]
        worksheet.autofit()
