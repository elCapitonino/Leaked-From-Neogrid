﻿namespace Repository.Enums
{
    public enum PreSegmentoSource
    {
        Predify = 0,
        Linx = 1,
        Horus_Search = 2,
        Smarket = 3,
        Neogrid = 4,
        Nielsen = 5,
        NielsenVem = 6,
        Europe_products = 7,
        Mercantil_Nova_Era = 8,
        Linx_Vem = 9,
        VEM_Distribuidores = 10,
        Demo_Varejo = 11,
        ABV = 12,
        Sao_Joao_InfoPrice = 13,
        LinxFarmaSellout = 14,
    }
}
