import calendar
from contextlib import contextmanager
from datetime import date, datetime, timedelta, timezone
from typing import Any, NamedTuple, Optional
from uuid import UUID

import numpy as np
import pandas as pd
from dateutil.relativedelta import relativedelta
from sqlalchemy import MetaData, Table, and_, bindparam, delete, func, select

from src.db import (
    PostgreSQLConnection,
    PostgreSQLEngine,
    SQLServerConnection,
    SQLServerEngine,
)
from src.exceptions import ConfigError, DatabaseResultError
from src.granularity import GranularityGroup, GranularityType, load_granularity
from src.logger import logger
from src.utils import build_product_id, get_royalty, get_sale_price_column


def get_consolidate_group_by(
    pg_conn: PostgreSQLConnection,
    metadata: MetaData,
    id_company: int,
    granularity: list[str],
) -> Optional[str]:
    table = Table("ImpactReportConfiguration", metadata, autoload_with=pg_conn)
    stmt = (
        select(table.c.ConsolidateFieldGroupBy)
        .where(table.c.CompanyId == id_company)
        .order_by(func.coalesce(table.c.UpdatedDate, table.c.CreatedDate).desc())
        .limit(1)
    )
    row = pg_conn.execute(stmt).fetchone()
    consolidate_group_by = row[0] if row else None
    consolidate_group_by = (
        consolidate_group_by if consolidate_group_by else granularity[0]
    )
    return consolidate_group_by


def calculate_history_metrics(
    *,
    sql_conn: SQLServerConnection,
    metadata: MetaData,
    id_company: int,
    granularity: list[str],
    consolidate_group_by: str,
    sale_price_col: str,
    initial_date: date,
    final_date: Optional[date] = None,
):
    table_sales_history = Table(
        "Enterprise_Sales_History", metadata, autoload_with=sql_conn
    )
    gran_columns = [table_sales_history.c[col] for col in granularity]

    consolidate_subquery = (
        select(
            *gran_columns,
            table_sales_history.c[consolidate_group_by].label("ConsolidateGroupBy"),
            func.row_number()
            .over(
                partition_by=gran_columns,
                order_by=table_sales_history.c.Issuance.desc(),
            )
            .label("rn"),
        ).where(
            table_sales_history.c.IdCompany == id_company,
            table_sales_history.c.IsDeletado == 0,
            table_sales_history.c.Issuance >= initial_date,
            table_sales_history.c.Issuance < final_date,
        )
    ).subquery()

    num_subquery = (
        select(
            *gran_columns,
            func.sum(table_sales_history.c.Quantity).label("total_demand"),
            func.sum(
                table_sales_history.c[sale_price_col] * table_sales_history.c.Quantity
            ).label("total_revenue"),
            func.sum(
                table_sales_history.c.PbCost * table_sales_history.c.Quantity
            ).label("total_cost"),
            func.avg(table_sales_history.c[sale_price_col]).label("average_price"),
            func.avg(table_sales_history.c.PbCost).label("average_cost"),
            func.avg(table_sales_history.c.Quantity).label("average_demand"),
            func.min(table_sales_history.c.Issuance).label("first_sale"),
            func.max(table_sales_history.c.Issuance).label("last_sale"),
        )
        .where(
            table_sales_history.c.IdCompany == id_company,
            table_sales_history.c.IsDeletado == 0,
            table_sales_history.c.Issuance >= initial_date,
            table_sales_history.c.Issuance < final_date,
        )
        .group_by(*gran_columns)
        .subquery()
    )

    gran_columns = [num_subquery.c[col] for col in granularity]
    gran_join = and_(
        *[num_subquery.c[col] == consolidate_subquery.c[col] for col in granularity]
    )
    stmt = (
        select(
            *gran_columns,
            num_subquery.c.total_demand,
            num_subquery.c.total_revenue,
            num_subquery.c.total_cost,
            num_subquery.c.average_price,
            num_subquery.c.average_cost,
            num_subquery.c.average_demand,
            num_subquery.c.first_sale,
            num_subquery.c.last_sale,
            consolidate_subquery.c.ConsolidateGroupBy,
        )
        .join(consolidate_subquery, gran_join)
        .where(consolidate_subquery.c.rn == 1)
    )

    logger.debug(
        "history metrics statement:\n%s\nparams: %s", stmt, stmt.compile().params
    )
    df_metrics = pd.read_sql(stmt, sql_conn)
    df_metrics["ConsolidateGroupBy"] = df_metrics["ConsolidateGroupBy"].astype(str)
    df_metrics["total_profit"] = df_metrics["total_revenue"] - df_metrics["total_cost"]
    df_metrics["gross_margin"] = (
        df_metrics["total_profit"] / df_metrics["total_revenue"]
    )
    df_metrics["gross_margin"] = df_metrics["gross_margin"].replace(
        [np.inf, -np.inf], 0
    )
    df_metrics["id_company"] = id_company
    return df_metrics


def _delete_monthly_metrics(
    *,
    pg_conn: PostgreSQLConnection,
    metadata: MetaData,
    id_company: int,
    year_month: int,
    granularity_group: GranularityGroup,
) -> None:
    table_monthly_sale_history_data = Table(
        "MonthlySaleHistoryData", metadata, autoload_with=pg_conn
    )

    stmt = delete(table_monthly_sale_history_data).where(
        table_monthly_sale_history_data.c.CompanyId == id_company,
        table_monthly_sale_history_data.c.YearMonth == year_month,
        table_monthly_sale_history_data.c.GranularityGroupId
        == granularity_group.group_id,
    )
    result = pg_conn.execute(stmt)
    logger.info(
        "deleted %d rows with filter id_company = %d and year_month = %d",
        result.rowcount,
        id_company,
        year_month,
    )


def _prepare_history_metrics(
    *,
    df_metrics: pd.DataFrame,
    granularity_group: GranularityGroup,
    royalty: Optional[float],
):
    granularity = granularity_group.to_columns()
    df_metrics["ProductId"] = build_product_id(df_metrics, granularity)

    major_granularity = granularity[0]
    df_metrics["MajorGranularity"] = df_metrics[major_granularity]
    df_metrics = df_metrics.drop(columns=granularity)
    df_metrics = df_metrics.rename(
        columns={
            "id_company": "CompanyId",
            "total_demand": "TotalQuantity",
            "total_revenue": "Revenue",
            "total_cost": "TotalCost",
            "total_profit": "Profit",
            "average_price": "AveragePrice",
            "average_cost": "AverageCost",
            "first_sale": "FirstSale",
            "last_sale": "LastSale",
            "gross_margin": "Margin",
        }
    ).drop(columns=["average_demand"])

    df_metrics["RoyaltyReal"] = 0
    df_metrics["RoyaltyPercentage"] = 0
    if royalty is not None:
        df_metrics["RoyaltyPercentage"] = royalty
        df_metrics["RoyaltyReal"] = df_metrics["Revenue"] * royalty

    return df_metrics


def _insert_history_metrics(
    *,
    pg_conn: PostgreSQLConnection,
    metadata: MetaData,
    id_company: int,
    year_month: int,
    df_metrics: pd.DataFrame,
    granularity_group: GranularityGroup,
):
    now = datetime.now(timezone.utc)
    df_metrics["CreatedDate"] = now
    df_metrics["GranularityGroupId"] = granularity_group.group_id
    df_metrics["YearMonth"] = year_month
    metric_rows = df_metrics.to_dict("records")

    table_monthly_sale_history_data = Table(
        "MonthlySaleHistoryData", metadata, autoload_with=pg_conn
    )
    stmt = table_monthly_sale_history_data.insert().values(
        {col: bindparam(col) for col in df_metrics.columns}
    )
    logger.info(
        "inserting %d rows for id_company %d and year_month %d into MonthlySaleHistoryData",
        len(metric_rows),
        id_company,
        year_month,
    )
    pg_conn.execute(stmt, metric_rows)


# FIXME pode gerar problema de concorrência
def upsert_monthly_metrics(
    *,
    pg_conn: PostgreSQLConnection,
    metadata: MetaData,
    id_company: int,
    year_month: int,
    df_metrics: pd.DataFrame,
    granularity_group: GranularityGroup,
):
    _delete_monthly_metrics(
        pg_conn=pg_conn,
        metadata=metadata,
        id_company=id_company,
        year_month=year_month,
        granularity_group=granularity_group,
    )
    _insert_history_metrics(
        pg_conn=pg_conn,
        metadata=metadata,
        id_company=id_company,
        year_month=year_month,
        df_metrics=df_metrics,
        granularity_group=granularity_group,
    )


def import_monthly_metrics(
    *,
    id_company: int,
    initial_date: date,
    final_date: date,
    pg_engine: PostgreSQLEngine,
    pg_metadata: MetaData,
    sql_engine: SQLServerEngine,
    sql_metadata: MetaData,
) -> None:
    logger.info(
        "loading granularity for id_company %d to update last price flag", id_company
    )
    with pg_engine.connect() as pg_conn:
        proj_granularity_group = load_granularity(
            pg_conn=pg_conn,
            metadata=pg_metadata,
            id_company=id_company,
            granularity_type=GranularityType.PROJECTION,
        )
        proj_granularity_cols = proj_granularity_group.to_columns()
        sale_price_col = get_sale_price_column(
            pg_conn=pg_conn,
            metadata=pg_metadata,
            id_company=id_company,
        )
        consolidate_group_by = get_consolidate_group_by(
            pg_conn, pg_metadata, id_company, proj_granularity_cols
        )

    if consolidate_group_by is None:
        raise ConfigError(
            f"no ConsolidateGroupBy configured for IdCompany {id_company}"
        )

    logger.info("using projection granularity group: %s", proj_granularity_group)
    logger.info("using sale_price column name %s", sale_price_col)

    with sql_engine.connect() as sql_conn:
        logger.info(
            "calculating monthly metrics with dates between %s and %s",
            initial_date,
            final_date,
        )
        df_metrics = calculate_history_metrics(
            sql_conn=sql_conn,
            metadata=sql_metadata,
            id_company=id_company,
            sale_price_col=sale_price_col,
            granularity=proj_granularity_cols,
            consolidate_group_by=consolidate_group_by,
            initial_date=initial_date,
            final_date=final_date,
        )

    if df_metrics.empty:
        logger.warning(
            "no data found for id_company %d between dates %s and %s",
            id_company,
            initial_date,
            final_date,
        )
        return

    year_month = int(initial_date.strftime("%Y%m"))
    with pg_engine.begin() as pg_conn_write:
        royalty = get_royalty(pg_conn_write, pg_metadata, id_company)
        df_metrics = _prepare_history_metrics(
            df_metrics=df_metrics,
            granularity_group=proj_granularity_group,
            royalty=royalty,
        )
        upsert_monthly_metrics(
            pg_conn=pg_conn_write,
            metadata=pg_metadata,
            id_company=id_company,
            year_month=year_month,
            df_metrics=df_metrics,
            granularity_group=proj_granularity_group,
        )


class MonthlyTask(NamedTuple):
    id_company: int
    initial_date: date
    final_date: date


class ImportJob(NamedTuple):
    last_create_date: datetime
    initial_issuance: date
    final_issuance: date
    tasks: list[MonthlyTask]


def get_monthly_tasks(
    id_company: int,
    pg_engine: PostgreSQLEngine,
    pg_metadata: MetaData,
    sql_engine: SQLServerEngine,
    sql_metadata: MetaData,
) -> Optional[ImportJob]:
    with pg_engine.connect() as pg_conn:
        table_auxiliary = Table(
            "MonthlySaleHistoryImportStatus", pg_metadata, autoload_with=pg_conn
        )
        stmt = select(func.max(table_auxiliary.c.RegisterLastCreateDate)).where(
            table_auxiliary.c.CompanyId == id_company,
            table_auxiliary.c.Status == "success",
        )
        logger.debug(
            "last import statement:\n%s\nparams: %s", stmt, stmt.compile().params
        )
        result = pg_conn.execute(stmt).fetchone()

    last_run = None if not result else result[0]
    logger.debug("last successful import for id_company %d: %s", id_company, last_run)

    # NOTE requer que Issuance não possa ser nulo
    with sql_engine.connect() as sql_conn:
        table_sales_history = Table(
            "Enterprise_Sales_History", sql_metadata, autoload_with=sql_conn
        )
        stmt = select(
            func.min(table_sales_history.c.Issuance).label("min_issuance"),
            func.max(table_sales_history.c.Issuance).label("max_issuance"),
            func.max(table_sales_history.c.DataHoraCriacao).label("last_create_date"),
        ).where(
            table_sales_history.c.IdCompany == id_company,
            table_sales_history.c.IsDeletado == 0,
        )
        if last_run is not None:
            stmt = stmt.where(table_sales_history.c.DataHoraCriacao > last_run)

        logger.debug(
            "new sales history inserts statement:\n%s\nparams: %s",
            stmt,
            stmt.compile().params,
        )
        result = sql_conn.execute(stmt).fetchone()

    if result is None:
        return None

    logger.debug("pending Issuance range: %s", result)
    initial_datetime, final_datetime, last_create_date = result
    if initial_datetime is None:
        logger.info("no new data found in id_company %d", id_company)
        return None

    _, num_days = calendar.monthrange(final_datetime.year, final_datetime.month)
    final_date = date(final_datetime.year, final_datetime.month, num_days)

    tasks = []
    current = initial_datetime.date().replace(day=1)
    while current <= final_date:
        _, num_days = calendar.monthrange(current.year, current.month)
        tasks.append(
            MonthlyTask(
                id_company,
                date(current.year, current.month, 1),
                date(current.year, current.month, num_days) + timedelta(days=1),
            )
        )
        current += relativedelta(months=1)

    logger.debug(
        "found %d pending tasks between datetimes %s and %s",
        len(tasks),
        initial_datetime,
        final_datetime,
    )
    initial_date = initial_datetime.date()
    return ImportJob(last_create_date, initial_date, final_datetime.date(), tasks)


@contextmanager
def prepare_import_status_manager(
    pg_engine: PostgreSQLEngine,
    metadata: MetaData,
    import_id: UUID,
):
    with pg_engine.begin() as pg_conn:
        _update_status(pg_conn, metadata, import_id, "preparing")

    try:
        yield
    except Exception as exc:
        logger.error("import with ID %s, failed: %s", import_id, exc)
        with pg_engine.begin() as pg_conn:
            _update_status(
                pg_conn=pg_conn, metadata=metadata, import_id=import_id, status="failed"
            )
        raise exc
    else:
        with pg_engine.begin() as pg_conn:
            _update_status(
                pg_conn=pg_conn,
                metadata=metadata,
                import_id=import_id,
                status="prepared",
            )
        logger.debug("prepare import with ID %s completed successfully", import_id)

    finally:
        with pg_engine.begin() as pg_conn:
            _finish_task(pg_conn=pg_conn, metadata=metadata, import_id=import_id)
        logger.debug("prepare import with ID %s finished successfully", import_id)


@contextmanager
def import_status_manager(
    pg_engine: PostgreSQLEngine,
    metadata: MetaData,
    import_id: UUID,
    last_create_date: datetime,
    min_issuance: date,
    max_issuance: date,
):
    with pg_engine.begin() as pg_conn:
        _update_status(
            pg_conn,
            metadata,
            import_id,
            "running",
            {
                "RegisterLastCreateDate": last_create_date,
                "MinIssuance": min_issuance,
                "MaxIssuance": max_issuance,
            },
        )

    try:
        yield
    except Exception as exc:
        logger.error("import with ID %s, failed: %s", import_id, exc)
        with pg_engine.begin() as pg_conn:
            _update_status(
                pg_conn=pg_conn, metadata=metadata, import_id=import_id, status="failed"
            )
        raise exc
    else:
        with pg_engine.begin() as pg_conn:
            _update_status(
                pg_conn=pg_conn,
                metadata=metadata,
                import_id=import_id,
                status="success",
                values={"EndDate": datetime.now(timezone.utc)},
            )
        logger.debug("import with ID %s completed successfully", import_id)
    finally:
        with pg_engine.begin() as pg_conn:
            _finish_task(pg_conn=pg_conn, metadata=metadata, import_id=import_id)
        logger.debug("import with ID %s finished successfully", import_id)


def insert_import_status(
    pg_conn: PostgreSQLConnection,
    metadata: MetaData,
    id_company: int,
) -> UUID:
    table = Table("MonthlySaleHistoryImportStatus", metadata, autoload_with=pg_conn)

    now = datetime.now(timezone.utc)
    stmt = (
        table.insert()
        .values(
            CompanyId=id_company,
            Status="pending",
            StartDate=now,
            CreatedDate=now,
        )
        .returning(table.c.Id)
    )

    logger.debug("insert task statement:\n%s\nparams: %s", stmt, stmt.compile().params)
    result = pg_conn.execute(stmt).fetchone()
    if not result:
        raise DatabaseResultError(
            f"no task ID returned after insertion of id_company {id_company} task"
        )

    return result[0]


def get_import_status(
    pg_conn: PostgreSQLConnection, metadata: MetaData, import_id: UUID
):
    table = Table("MonthlySaleHistoryImportStatus", metadata, autoload_with=pg_conn)
    stmt = select(
        table.c.CompanyId,
        table.c.Status,
        table.c.RegisterLastCreateDate,
        table.c.MinIssuance,
        table.c.MaxIssuance,
        func.coalesce(table.c.UpdatedDate, table.c.CreatedDate),
    ).where(table.c.Id == import_id)
    result = pg_conn.execute(stmt).fetchone()
    if not result:
        return None

    min_issuance = result[3].date().isoformat() if result[3] is not None else None
    max_issuance = result[4].date().isoformat() if result[4] is not None else None
    return {
        "id_company": result[0],
        "status": result[1],
        "last_create_date": result[2],
        "min_issuance": min_issuance,
        "max_issuance": max_issuance,
        "last_change": result[5],
    }


def _update_status(
    pg_conn: PostgreSQLConnection,
    metadata: MetaData,
    import_id: UUID,
    status: str,
    values: Optional[dict[str, Any]] = None,
):
    table = Table("MonthlySaleHistoryImportStatus", metadata, autoload_with=pg_conn)
    now = datetime.now(timezone.utc)
    values = values or {}
    stmt = (
        table.update()
        .where(table.c.Id == import_id)
        .values(Status=status, UpdatedDate=now, **values)
    )
    logger.debug("update task statement:\n%s\nparams: %s", stmt, stmt.compile().params)
    result = pg_conn.execute(stmt)
    logger.info(
        "marked task ID %s as %s with %d rows affected",
        import_id,
        status,
        result.rowcount,
    )


def _finish_task(pg_conn: PostgreSQLConnection, metadata: MetaData, import_id: UUID):
    table = Table("MonthlySaleHistoryImportStatus", metadata, autoload_with=pg_conn)
    now = datetime.now(timezone.utc)
    stmt = (
        table.update()
        .where(
            table.c.Id == import_id,
            table.c.Status.in_(("running", "pending", "preparing")),
        )
        .values(Status="interrupted", UpdatedDate=now)
    )
    logger.debug("finish task statement:\n%s\nparams: %s", stmt, stmt.compile().params)
    result = pg_conn.execute(stmt)
    logger.info("finished task ID %s with %d rows affected", import_id, result.rowcount)


def update_empty_import(
    pg_conn: PostgreSQLConnection, metadata: MetaData, import_id: UUID
):
    _update_status(
        pg_conn, metadata, import_id, "empty", {"EndDate": datetime.now(timezone.utc)}
    )
