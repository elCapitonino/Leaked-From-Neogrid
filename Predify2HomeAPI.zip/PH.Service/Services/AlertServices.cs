﻿using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using PH.Domain.DTO;
using PH.Domain.Interfaces.Repositories;
using PH.Domain.Interfaces.Services;

namespace PH.Service.Services
{
    public class AlertServices : IAlertServices
    {
        private readonly ILogger<AlertServices> _logger;
        private readonly IAlertRepository _repository;
        private readonly IMemoryCache _memoryCache;
        private readonly ICacheControlService _cacheControlService;

        public AlertServices(ILogger<AlertServices> logger,
                             IAlertRepository repository,
                             IMemoryCache memoryCache,
                             ICacheControlService cacheControlService)
        {
            _logger = logger;
            _repository = repository;
            _memoryCache = memoryCache;
            _cacheControlService = cacheControlService;
        }

        public async Task<AlertMainDTO> Get(long idCompany, long idPriceGroup)
        {
            _logger.LogInformation("Service: buscando todos os Alert");

            try
            {
                return await _repository.Get(idCompany, idPriceGroup);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Service: erro ao buscar todos os Alert. {ex.Message}");
                throw;
            }
        }
    }
}
