﻿using MongoDB.Bson;
using Repository.Entity;
using Repository.EntityRepository.Bases;

namespace Repository.EntityRepository
{
    public interface IPeraltaRepository : IGenericRepository<PeraltaEntity, ObjectId>, IMongoRepository
    {
    }
}
