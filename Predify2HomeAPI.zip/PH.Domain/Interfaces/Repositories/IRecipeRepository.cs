﻿using PH.Domain.Domain;

namespace PH.Domain.Interfaces.Repositories
{
    public interface IRecipeRepository
    {
        Task<Recipe> Get(string? loja, string? curva, string? categoria);
        Task<double> GetLastMonthSales(string? loja, string? curva, string? categoria);
    }
}
