﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Domain.MonitoringResult.Models
{
    public class DynamicFilterResponse
    {
        public IEnumerable<ProductData> Products { get; set; }
        public IEnumerable<string?>? Categories { get; set; }
        public IEnumerable<string?>? Sellers { get; set; }
        public IEnumerable<string?>? Brands { get; set; }
        public IEnumerable<string?>? States { get; set; }
        public IEnumerable<string?>? Years { get; set; }
        public IEnumerable<string?>? Models { get; set; }
        public IEnumerable<string>? Origins { get; set; }
    }

    public class ProductData
    {
        public string ProductName { get; set; }
        public long IdMonitoringItem { get; set; }
        public bool Selected { get; set; }
        [JsonIgnore]
        public int CrawlerId { get; set; }
    }

}
