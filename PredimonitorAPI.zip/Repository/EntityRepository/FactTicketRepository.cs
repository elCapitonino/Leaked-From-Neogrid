﻿using Repository.DbContexts;
using Repository.Entity;
using Repository.EntityRepository.Bases;

namespace Repository.EntityRepository
{
    public class FactTicketRepository : GenericMongoRepository<FactTicketEntity>, IFactTicketRepository
    {
        public FactTicketRepository(LinxDbContext dbContext) : base(dbContext)
        {
        }

        public static string DbContextName => nameof(LinxDbContext);
    }
}
