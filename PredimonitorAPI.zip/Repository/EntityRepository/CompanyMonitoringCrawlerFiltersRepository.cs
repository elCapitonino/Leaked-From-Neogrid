﻿using Repository.DbContexts;
using Repository.Entity;
using Repository.EntityRepository.Bases;

namespace Repository.EntityRepository
{
    public class CompanyMonitoringCrawlerFiltersRepository : GenericRepository<CompanyMonitoringCrawlerFiltersEntity, long>, ICompanyMonitoringCrawlerFiltersRepository
    {
        public CompanyMonitoringCrawlerFiltersRepository(ApplicationDbContext dbContext) : base(dbContext)
        {
        }
        public static string DbContextName => nameof(ApplicationDbContext);
    }
}
