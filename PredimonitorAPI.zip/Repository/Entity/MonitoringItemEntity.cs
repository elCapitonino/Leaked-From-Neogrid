﻿namespace Repository.Entity
{
    public class MonitoringItemEntity : BaseEntity
    {
        public long CompanyId { get; set; }

        public long? ProductId { get; set; }

        public string? ImportId { get; set; }

        public string? Description { get; set; }

        public string? InternalSearch { get; set; }

        public string? ExternalSearch { get; set; }

        public int? LifeTimeMonitoring { get; set; }

        public DateTime? LastDateSearched { get; set; }

        public decimal? PortionDeflatorIndex { get; set; }

        public bool? UsePriceRange { get; set; }

        public decimal? LowerPriceRange { get; set; }

        public decimal? UpperPriceRange { get; set; }

        public string? MandatoryTagModel { get; set; }

        public string? EanGtin { get; set; }

        public string? MandatoryTagBrand { get; set; }

        public string? RequiredWords { get; set; }

        public string? RestrictedWords { get; set; }

        public string? HashTags { get; set; }

        public bool IsDeleted { get; set; }

        public virtual ICollection<MonitoringItemConfigEntity> Configs { get; set; }
        public virtual ICollection<MonitoringProductMarketResultEntity> MonitoringProductMarketResults { get; set; }
    }
}
