﻿using PredifyClientAPI.Services.PredifyAPI.Models;
using System.ComponentModel;

namespace PredifyClientAPI.Services.PredifyAPI.PriceGroup.Models
{
    /// <summary>
    /// Modelo para listagem de grupos de precificação Predify Enterprise.
    /// </summary>
    public class EnterpriseListGroupsRequest : AccessBase
    {
        /// <summary>
        /// Indica se o request é para simulação enterprise ou produção enterprise
        /// </summary>
        [DefaultValue(false)]
        public bool IsSimulation { get; set; } = false;

        [DefaultValue(true)]
        public bool isPublished { get; set; } = true;

        public DateTime? Start_date { get; set; } = null;

        public DateTime? End_date { get; set; } = null;

        /// <summary>
        /// Lista de filtros a serem utilizados
        /// </summary>
        public List<EnterpriseListPriceGroupsFilterRequest> Filters { get; set; } = new List<EnterpriseListPriceGroupsFilterRequest>();

        public List<long> IdEnterprisePriceGroups { get; set; } = new List<long>();
    }

    /// <summary>
    /// Modelo para identificar quais filtros a serem usados
    /// </summary>
    public class EnterpriseListPriceGroupsFilterRequest
    {
        /// <summary>
        /// valor do filtro
        /// </summary>
        public string value { get; set; }

        /// <summary>
        /// identificador dos filtros 
        /// </summary>
        public long idEnterprisePriceGroupDefaultFilter { get; set; }
    }
}
