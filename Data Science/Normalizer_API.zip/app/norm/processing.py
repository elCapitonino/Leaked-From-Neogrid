import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from nltk.corpus import stopwords
import re
from unicodedata import normalize


class Processing:

    def __init__(self, aspas=False):
        self.aspas = aspas
        self.stopwords = stopwords.words('portuguese')
        self.stopwords_en = stopwords.words('english')
        self.regex_limpeza = re.compile(r'nan[^\w]+')
        # '|Monitor[^\S]+'
        # '|"[^\s]+'
    # remover dados nan

    def limpeza(self, texto: str) -> str:
        texto = self.regex_limpeza.sub('', texto)
        texto = re.sub(r'-|_', '', texto)
        return texto
    # separar palavras

    def tokenizador(self, texto: str) -> list:
        # return re.findall(r'[\w]+', texto)
        return texto.split()
    # remover stopwords

    def remover_stopwords(self, texto_tokenizado: list, language) -> list:
        if language == 'pt-br':
            return [t for t in texto_tokenizado if t not in self.stopwords]
        elif language == 'en-us':
            return [t for t in texto_tokenizado if t not in self.stopwords_en]
        else:
            return [t for t in texto_tokenizado if t not in self.stopwords]

    # remove acentuação - codifica em bytes de decodifica em string
    def normalizador(self, texto: str) -> str:
        texto = texto.lower()
        return normalize('NFKD', texto).encode('latin-1', 'ignore').decode('latin-1')

    def run(self, texto: str, language) -> str:

        # excluir dados faltantes
        texto = self.limpeza(texto)
        # letra minúscula
        texto = texto.lower()

        # separar palavras
        texto_tokenizado = self.tokenizador(texto)
        #print(texto_tokenizado ," -------- " ,textooriginal)

        # remover stopwords
        texto_tokenizado = self.remover_stopwords(texto_tokenizado, language)
        #print(texto_tokenizado ," -------- " ,textooriginal)

        # agrupar palavras com espaço
        texto = " ".join(texto_tokenizado)
        #print(texto ," -------- " ,textooriginal)

        # remove acentuação
        texto = self.normalizador(texto)

        #print(textooriginal ," -------- " ,texto)

        return texto
