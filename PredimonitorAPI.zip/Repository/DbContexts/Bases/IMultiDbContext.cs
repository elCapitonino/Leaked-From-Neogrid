﻿namespace Repository.DbContexts.Bases
{
    public interface IMultiDbContext
    {
        public string DbContextName { get; }
    }

}
