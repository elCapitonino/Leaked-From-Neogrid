import os
from typing import Any

from dotenv import load_dotenv
from motor.core import AgnosticClient
from motor.motor_asyncio import AsyncIOMotorClient
from pymongo import ASCENDING

from models.internal import AddressInfo
from src.env import config
from src.logger import logger


def get_async_mongo_connection() -> AgnosticClient:
    client = AsyncIOMotorClient(
        config.get("MONGO_URI"), serverSelectionTimeoutMS=60_000
    )
    return client


async def create_unique_address_index(conn: AgnosticClient) -> None:
    await conn.location_data.location_data.create_index(
        [("id_consulta", ASCENDING)], unique=True
    )


async def fetch_address_info(conn: AgnosticClient, address: str):
    logger.debug("fetching address info from mongo: << %s >>", address)
    coll = conn.location_data.location_data
    doc = await coll.find_one({"id_consulta": address})
    doc = doc or {}
    return doc


async def fetch_discover_info(
    conn: AgnosticClient, query: str, lat: float, long: float
):
    logger.debug("fetching discover info from mongo: << %s >>", query)
    coll = conn.location_data.discover_data

    doc = {}

    if lat != 0 and long != 0:
        doc = await coll.find_one({"name": query, "latitude": lat, "longitude": long})
    else:
        doc = await coll.find_one({"name": query})

    if doc is not None:
        doc.pop("_id", None)

    return doc


async def upsert_address_info(conn: AgnosticClient, address_info: AddressInfo) -> None:
    logger.debug("upserting address << %s >> in mongo", address_info.id_consulta)
    doc = address_info.model_dump(mode="json")
    coll = conn.location_data.location_data
    await coll.update_one(
        {"id_consulta": address_info.id_consulta}, {"$set": doc}, upsert=True
    )


async def upsert_discover_info(
    conn: AgnosticClient, query: str, lat: float, long: float, result: dict[str, Any]
) -> None:
    logger.debug("upserting discover info << %s >> in mongo", query)
    coll = conn.location_data.discover_data
    await coll.update_one(
        {"name": query, "latitude": lat, "longitude": long},
        {"$set": result},
        upsert=True,
    )
