﻿using Asp.Versioning;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PredifyClientAPI.Services.PredifyAPI;
using PredifyClientAPI.Services.PredifyAPI.Models;
using PredifyClientAPI.Services.PredifyAPI.MonitoringItem.Models;

namespace PredifyClientAPI.Controllers
{
    [ApiController]
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiVersion("1.0")]
    [Authorize]
    public class MonitoringItemController : ControllerBase
    {
        private readonly ILogger<MonitoringItemController> _logger;
        private readonly PredifyAPIUserManager _predifyAPIUserManager;

        public MonitoringItemController(ILogger<MonitoringItemController> logger, PredifyAPIUserManager predifyAPIUserManager)
        {
            _logger = logger;
            _predifyAPIUserManager = predifyAPIUserManager;
        }

        [HttpPost("ListMonitoringItems")]
        [MapToApiVersion("0.0")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(GeneralResponse<IEnumerable<MonitoringItemResponse>>))]
        [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status401Unauthorized, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
        public async Task<IActionResult> ListMonitoringItems([FromBody] ListMonitoringItemRequest request)
        {
            try
            {
                var response = await _predifyAPIUserManager.MonitoringItemService.ListMonitoringItem(request);

                return Ok(response);
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized(ex.Message);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("ListMonitoringItemPaginated")]
        [MapToApiVersion("1.0")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(GeneralResponse<PaginationResponse<MonitoringItemResponse>>))]
        [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status401Unauthorized, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
        public async Task<IActionResult> ListMonitoringItemPaginated([FromBody] ListMonitoringItemPaginatedRequest request)
        {
            try
            {
                var response = await _predifyAPIUserManager.MonitoringItemService.ListMonitoringItemResponsePaginated(request);

                return Ok(response);
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized(ex.Message);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
