﻿using Repository.Entity;
using Repository.EntityRepository.Bases;

namespace Repository.EntityRepository
{
    public interface IMonitoringProductMarketResultItemRepository : IGenericRepository<MonitoringProductMarketResultItemEntity, long>
    {
    }
}
