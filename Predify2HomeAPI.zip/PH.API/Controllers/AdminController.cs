﻿using Microsoft.AspNetCore.Mvc;

namespace PH.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        [HttpGet]
        public IActionResult GetAdminEmail()
        {
            List<string> listEmailsAdm = new List<string>();
            listEmailsAdm.Add("andre.marcondes@predify.me");
            listEmailsAdm.Add("vitor.eduardo@predify.me");
            return Ok(listEmailsAdm);
        }
    }
}
