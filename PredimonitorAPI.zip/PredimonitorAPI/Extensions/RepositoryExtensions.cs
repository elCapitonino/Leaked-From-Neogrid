﻿using Domain.Models;
using Microsoft.EntityFrameworkCore;
using MongoDB.Driver;
using Repository.DbContexts;
using Repository.UnitOfWork;

namespace PredimonitorAPI.Extensions
{
    public static class RepositoryExtensions
    {
        public static void AddRepository(this IServiceCollection services, IConfiguration configuration)
        {
            AppsettingsOptions appsettings = new AppsettingsOptions();
            configuration.Bind(appsettings);

            var mongoClient = new MongoClient(appsettings.MongoDBSettings.ConnectionString);

            services.AddTransient<IMongoClient>(provider => mongoClient);
            services.AddTransient<IUnitOfWork, UnitOfWork>();


            services.AddDbContext<ApplicationDbContext>(options => options.UseSqlServer(configuration.GetConnectionString("ApplicationDbContext")), ServiceLifetime.Transient);

            services.AddDbContext<HorusDbContext>(options => options.UseMongoDB(mongoClient, appsettings.MongoDBSettings.Databases.Horus), ServiceLifetime.Transient);
            services.AddDbContext<InfoPriceSaoJoaoDbContext>(options => options.UseMongoDB(mongoClient, appsettings.MongoDBSettings.Databases.InfroPriceSaoJoao), ServiceLifetime.Transient);
            services.AddDbContext<NormalizerDbContext>(options => options.UseMongoDB(mongoClient, appsettings.MongoDBSettings.Databases.Normalizer), ServiceLifetime.Transient);
            services.AddDbContext<LinxDbContext>(options => options.UseMongoDB(mongoClient, appsettings.MongoDBSettings.Databases.Linx), ServiceLifetime.Transient);
            services.AddDbContext<NeogridDbContext>(options => options.UseMongoDB(mongoClient, appsettings.MongoDBSettings.Databases.Neogrid), ServiceLifetime.Transient);
            services.AddDbContext<NielsenDbContext>(options => options.UseMongoDB(mongoClient, appsettings.MongoDBSettings.Databases.Nielsen), ServiceLifetime.Transient);
            services.AddDbContext<SmarketCompetitorDbContext>(options => options.UseMongoDB(mongoClient, appsettings.MongoDBSettings.Databases.SmarketCompetitor), ServiceLifetime.Transient);
            services.AddDbContext<OfflineDbContext>(options => options.UseMongoDB(mongoClient, appsettings.MongoDBSettings.Databases.Offline), ServiceLifetime.Transient);
            services.AddDbContext<ScantechSupermaxiDbContext>(options => options.UseMongoDB(mongoClient, appsettings.MongoDBSettings.Databases.Scantech), ServiceLifetime.Transient);

            services.AddTransient(provider => new DatabricsDbContext(appsettings.DatabricksSettings.ConnectionString, appsettings.DatabricksSettings.Schema));
        }
    }
}