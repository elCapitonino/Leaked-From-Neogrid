﻿using DI.Repository.Interfaces;

namespace DI.Test.Unit.Repositories
{
    public class EnterprisePriceProjectionRepositoryTest
    {
        private readonly IUnitOfWork _unitOfWork;

        public EnterprisePriceProjectionRepositoryTest(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        [Fact]
        public void TestGetById_ValidId()
        {
            long priceGroupId = 500;
            var getPriceProjection = _unitOfWork.EnterprisePriceProjectionRepository.GetByIdPriceGroup(priceGroupId);

            Assert.NotNull(getPriceProjection);
        }

        [Fact]
        public void TestGetById_InvalidId()
        {
            long invalidPriceGroupId = -1;
            var idInvalid = _unitOfWork.EnterprisePriceProjectionRepository.GetByIdPriceGroup(invalidPriceGroupId);

            Assert.NotNull(idInvalid);
            Assert.Empty(idInvalid);
        }

        [Fact]
        public void TestGetById_NonExistentId()
        {
            long nonExistentPriceGroupId = 00000;
            var nonExistentId = _unitOfWork.EnterprisePriceProjectionRepository.GetByIdPriceGroup(nonExistentPriceGroupId);
            Assert.NotNull(nonExistentId);
            Assert.Empty(nonExistentId);
        }

        [Fact]
        public void TestGetCompany_DetailsAsync()
        {
            long priceGroupId = 500;
            var getPriceProjection = _unitOfWork.EnterprisePriceProjectionRepository.GetByIdPriceGroup(priceGroupId);

            Assert.NotNull(getPriceProjection);
            Assert.NotNull(getPriceProjection.FirstOrDefault(e => e.EnterprisePricesProjectionId == 1828407));
        }

        [Fact]
        public void TestGetAllById_ValidIds()
        {

            var validPriceGroupIds = new List<long> { 500, 501 };
            var result = _unitOfWork.EnterprisePriceProjectionRepository.GetByIdPriceGroup(validPriceGroupIds);

            Assert.NotNull(result);
            Assert.True(result.Any(), "Expected to have results, but got none.");
            Assert.Contains(result, x => x.EnterprisePriceGroupsId == 500);
            Assert.Contains(result, x => x.EnterprisePriceGroupsId == 501);
        }

        [Fact]
        public void TestGetAllById_InvalidIds()
        {
            var invalidPriceGroupIds = new List<long> { -1, -2 };

            var result = _unitOfWork.EnterprisePriceProjectionRepository.GetByIdPriceGroup(invalidPriceGroupIds);

            Assert.NotNull(result);
            Assert.Empty(result);
        }

        [Fact]
        public void TestGetAllById_EmptyList()
        {
            var emptyPriceGroupIds = new List<long>();
            var result = _unitOfWork.EnterprisePriceProjectionRepository.GetByIdPriceGroup(emptyPriceGroupIds);

            Assert.NotNull(result);
            Assert.Empty(result);
        }

        [Fact]
        public void TestGetAllById_SomeIdsNotFound()
        {
            var someIdsNotFound = new List<long> { 500, 0000 };

            var result = _unitOfWork.EnterprisePriceProjectionRepository.GetByIdPriceGroup(someIdsNotFound);

            Assert.NotNull(result);
            Assert.Contains(result, x => x.EnterprisePriceGroupsId == 500);
            Assert.DoesNotContain(result, x => x.EnterprisePriceGroupsId == 0000);
        }
    }
}
