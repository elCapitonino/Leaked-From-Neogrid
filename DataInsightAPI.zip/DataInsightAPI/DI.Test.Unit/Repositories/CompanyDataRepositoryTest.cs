﻿using DI.Repository.Interfaces;

namespace DI.Test.Unit.Repositories
{
    public class CompanyDataRepositoryTest
    {
        private readonly IUnitOfWork _unitOfWork;

        public CompanyDataRepositoryTest(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        [Fact]
        public async Task TestGetById_ValidId()
        {
            var companyId = 3220;
            var getCompanyName = await _unitOfWork.CompanyDataRepository.GetCompanyName(companyId);
            Assert.NotNull(getCompanyName);
        }

        [Fact]
        public async Task TestGetCompanyNameAsync_InvalidId()
        {
            var invalidCompanyId = -1;
            var getCompanyName = await _unitOfWork.CompanyDataRepository.GetCompanyName(invalidCompanyId);
            Assert.Null(getCompanyName);
        }
        [Fact]
        public async Task TestGetCompanyDetailsAsync()
        {
            var companyId = 3220;
            var companyDetails = await _unitOfWork.CompanyDataRepository.GetCompanyName(companyId);

            Assert.NotNull(companyDetails);
            Assert.Equal("Predify", companyDetails);
        }
    }
}