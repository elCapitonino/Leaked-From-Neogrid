# Normalizer API

## Versões do python 
- 3.8.*
- 3.9.*

## Instalação
No terminal execute:
1. pip install -r requirements.txt
2. python -m nltk.downloader stopwords

## Comfiguração
1. Crie um arquivo config.py dentro do diretorio [app](/app)
```
# conectar mongo

Server = {
    "host": 'ip do banco',
    "port": 'porta do banco',
    "user": '',
    "password": ''
}
url_normalizer = "http://127.0.0.1:{porta do normalizador}/"


url_normalizer_predmonitor = "http://127.0.0.1:{Porta do normalizador}/search_pred_monitor/"
```
__Opcional__:: 
2. No arquivo [conect_mongo](./app/norm/conect_mongo.py) insira as databases normalizer ou test_normalizer e dictionary ou test_dictionary:
self.database_normalizer = self.client['test_normalizer']
self.database_dictionary = self.client['test_dictionary']

## Execução
1. Certifique-se que está conectado à VPN 
1. execute  python -m uvicorn main:app_search --host 0.0.0.0 --port 8081 --reload [app](./app/main.py) ou execute pelo launch da IDE/Depurador
