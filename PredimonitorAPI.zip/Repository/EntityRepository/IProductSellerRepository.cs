using Repository.Entity.Databricks;
using Repository.EntityRepository.Bases;
using System;

namespace Repository.EntityRepository;

public interface IProductSellerRepository : IGenericDatabricksRepository<ProductSellerEntity>
{
}
