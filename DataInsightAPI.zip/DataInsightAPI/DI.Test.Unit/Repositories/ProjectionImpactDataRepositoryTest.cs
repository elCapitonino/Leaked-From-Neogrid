﻿using DI.Repository.Interfaces;

namespace DI.Test.Unit.Repositories
{
    public class ProjectionImpactDataRepositoryTest
    {
        private readonly IUnitOfWork _unitOfWork;

        public ProjectionImpactDataRepositoryTest(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        [Fact]
        public void TestGetById_ValidId()
        {
            long priceGroupId = 3999;
            var getPriceGroup = _unitOfWork.ProjectionImpactDataRepository.GetAllByPriceGroupId(priceGroupId);

            Assert.NotNull(getPriceGroup);
            Assert.NotEmpty(getPriceGroup);
        }

        [Fact]
        public void TestGetById_InvalidId()
        {
            long invalidPriceGroupId = -1;
            var idInvalid = _unitOfWork.ProjectionImpactDataRepository.GetAllByPriceGroupId(invalidPriceGroupId);

            Assert.NotNull(idInvalid);
            Assert.Empty(idInvalid);
        }

        [Fact]
        public void TestGetById_NonExistentId()
        {

            long nonExistentPriceGroupId = 000;
            var idInvalid = _unitOfWork.ProjectionImpactDataRepository.GetAllByPriceGroupId(nonExistentPriceGroupId);

            Assert.NotNull(idInvalid);
            Assert.Empty(idInvalid);
        }

        [Fact]
        public void TestGetCompany_DetailsAsync()
        {
            long priceGroupId = 3999;
            var getPriceGroup = _unitOfWork.ProjectionImpactDataRepository.GetAllByPriceGroupId(priceGroupId);
            var companyValidate = getPriceGroup.FirstOrDefault(c => c.CompanyId == 3026);

            Assert.NotNull(getPriceGroup);
            Assert.NotEmpty(getPriceGroup);
            Assert.Equal(3026, companyValidate.CompanyId);
        }

        [Fact]
        public void TestGetAllById_ValidIds()
        {

            var validPriceGroupIds = new List<long> { 3999, 7303 };
            var result = _unitOfWork.ProjectionImpactDataRepository.GetAllByPriceGroupId(validPriceGroupIds);

            Assert.NotNull(result);
            Assert.True(result.Any(), "Expected to have results, but got none.");
            Assert.Contains(result, x => x.PriceGroupId == 3999);
            Assert.Contains(result, x => x.PriceGroupId == 7303);
        }

        [Fact]
        public void TestGetAllById_InvalidIds()
        {
            var invalidPriceGroupIds = new List<long> { -1, -2 };

            var result = _unitOfWork.ProjectionImpactDataRepository.GetAllByPriceGroupId(invalidPriceGroupIds);

            Assert.NotNull(result);
            Assert.Empty(result);
        }

        [Fact]
        public void TestGetAllById_EmptyList()
        {
            var emptyPriceGroupIds = new List<long>();
            var result = _unitOfWork.ProjectionImpactDataRepository.GetAllByPriceGroupId(emptyPriceGroupIds);

            Assert.NotNull(result);
            Assert.Empty(result);
        }

        [Fact]
        public void TestGetAllById_SomeIdsNotFound()
        {
            var someIdsNotFound = new List<long> { 3999, 0000 };

            var result = _unitOfWork.ProjectionImpactDataRepository.GetAllByPriceGroupId(someIdsNotFound);

            Assert.NotNull(result);
            Assert.NotEmpty(result);
            Assert.Contains(result, x => x.PriceGroupId == 3999);
        }
    }
}
