﻿using DI.Repository.Interfaces;
using DI.Repository.UnitOfWork;

namespace DI.API.IoC
{
    public static class RepositoryExtensions
    {
        public static void AddRepository(this IServiceCollection services)
        {
            services.AddScoped<IUnitOfWork, UnitOfWork>();
        }
    }
}