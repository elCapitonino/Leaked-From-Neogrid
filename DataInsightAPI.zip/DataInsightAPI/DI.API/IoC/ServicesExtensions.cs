﻿using DI.Domain.Services.Interfaces.Reports;
using DI.Domain.Services.Reports;

namespace DI.API.IoC
{
    public static class ServicesExtensions
    {
        public static void AddServices(this IServiceCollection services)
        {
            services.AddTransient<IGenerateImpactReportExcelFileService, GenerateImpactReportExcelFileService>();
            services.AddTransient<IGetImpactReportDataService, GetImpactReportDataService>();
        }
    }
}
