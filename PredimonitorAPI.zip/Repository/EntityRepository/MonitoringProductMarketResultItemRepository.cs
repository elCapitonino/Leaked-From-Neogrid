﻿using Repository.DbContexts;
using Repository.Entity;
using Repository.EntityRepository.Bases;

namespace Repository.EntityRepository
{
    public class MonitoringProductMarketResultItemRepository : GenericRepository<MonitoringProductMarketResultItemEntity, long>, IMonitoringProductMarketResultItemRepository
    {
        public MonitoringProductMarketResultItemRepository(ApplicationDbContext dbContext) : base(dbContext)
        {

        }
        public static string DbContextName => nameof(ApplicationDbContext);
    }
}
