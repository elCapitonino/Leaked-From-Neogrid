﻿using Repository.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Status.Models
{
    public class StatusCacheModel
    {
        public CrawlerSourceType SourceType { get; set; }
        public MonitoringItemResultsStatusType Status { get; set; } = MonitoringItemResultsStatusType.None;
        public string Message { get; set; }

        public Guid? TaskId { get; set; }
        public int Indexed { get; internal set; }
        public int Total { get; internal set; }
    }
}
