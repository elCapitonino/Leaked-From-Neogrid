using Amazon.Runtime.Internal;
using Amazon.Runtime.Internal.Util;
using AutoMapper;
using Azure.Core;
using Domain.CompanyMonitoringCrawler;
using Domain.Product.Models;
using Domain.Utils;
using Microsoft.Extensions.Logging;
using Repository.Entity;
using Repository.Entity.Databricks;
using Repository.Enums;
using Repository.Models.Databricks;
using Repository.UnitOfWork;
using System.Collections.Generic;
using System.Diagnostics;

namespace Domain.Product;

public class ProductDomain : IProductDomain
{
    private readonly IUnitOfWork _uow;
    private readonly ICompanyMonitoringCrawlerDomain _companyMonitoringCrawlerDomain;
    private readonly ILogger<ProductDomain> _logger;

    public ProductDomain(ILogger<ProductDomain> logger, IUnitOfWork uow, ICompanyMonitoringCrawlerDomain companyMonitoringCrawlerDomain)
    {
        _logger = logger;
        _uow = uow;
        _companyMonitoringCrawlerDomain = companyMonitoringCrawlerDomain;
    }

    private async Task<List<CompanyMonitoringCrawlerEntity>> GetCompanyCrawlers(int companyId, bool isCost)
    {
        var companyCrawlers = await _companyMonitoringCrawlerDomain.GetCompanyMonitoringCrawler(companyId, isCost);

        if (companyCrawlers == null || companyCrawlers.Count == 0)
        {
            _logger.LogError("No crawlers found for company {CompanyId}", companyId);
            throw new ArgumentException($"No crawlers found for company {companyId}");
        }

        return companyCrawlers;
    }

    public async Task<ProductResponse> GetGroupedProducts(FiltersRequest request)
    {
        var companyCrawlers = await GetCompanyCrawlers(request.CompanyId, request.IsCost);

        var query = CreateGroupedProductsQuery(request, companyCrawlers, _uow.ProductRepository.GetSchema());

        _logger.LogInformation("Searching products for company {CompanyId}.", request.CompanyId);

        var sw = Stopwatch.StartNew();
        var products = await _uow.ProductRepository.GetWithJoin<ProductGroupedResponse>(query);
        var count = await _uow.ProductRepository.GetCount(query);
        sw.Stop();
        _logger.LogInformation("Product query took {ms} ms to execute for company {CompanyId}", sw.ElapsedMilliseconds, request.CompanyId);

        products = CalculateCompetitivenessIndexForGroupedProducts(products);

        _logger.LogInformation("{ProductsFound} products found for company {CompanyId}: ", products.Count, request.CompanyId);

        var response = new ProductResponse
        {
            Products = products,
            TotalCount = count
        };

        return response;
    }

    private QueryParameters CreateGroupedProductsQuery(FiltersRequest request, List<CompanyMonitoringCrawlerEntity> companyCrawlers, string? schema = null)
    {
        var query = new QueryParameters();

        query.Joins.AddRange([
            new (){ JoinTable = "product_sellers AS ps", JoinCondition = "Id = ps.ProductId", JoinWithMainTable = true },
            new (){ JoinTable = "product_prices AS pp", JoinCondition = "ps.Id = pp.ProductSellerId" },
            new (){ JoinTable = "ignored_prices AS ip", JoinCondition = $"pp.Id = ip.ProductPriceId and ip.CompanyId = {request.CompanyId}", JoinType = "LEFT"},
            new (){ JoinSQL = $" LEFT JOIN (SELECT ProductId, Price as LatestPrice FROM {schema}.company_product_prices WHERE CompanyId = {request.CompanyId} ORDER BY Date DESC LIMIT 1) cpp ON cpp.ProductId = {schema}.products.Id"}
        ]);

        query.Select.AddRange([
            new (){ Column = "Name" },
            new (){ Column = "COLLECT_SET(products.Id) as ProductIds" },
            new (){ Column = "MIN(pp.Price) as MinPrice" },
            new (){ Column = "MAX(pp.Price) as MaxPrice" },
            new (){ Column = "AVG(pp.Price) as AvgPrice" },
            new (){ Column = "cpp.LatestPrice as LatestPrice" }
        ]);

        query.Filters.AddRange(DatabricksQueryHelper.CreateResultBaseFilters(request, companyCrawlers));
        query.SqlFilters.AddRange(DatabricksQueryHelper.CreateCompanyMandatoryFilters(companyCrawlers));

        query.GroupBy.AddRange([
            new () { Column = "Name" },
            new () { Column = "products.Id" },
            new () { Column = "LatestPrice" }
        ]);

        query.OrderBy.Add(new() { Column = "Name ASC" });

        request.Page = request.Page == 0 ? 1 : request.Page;
        request.Take = request.Take == 0 ? 10 : request.Take;

        query.Skip = (request.Page - 1) * request.Take;
        query.Take = request.Take;

        return query;
    }

    public void SaveCompanyProductPrice(CompanyProductPriceRequest request)
    {
        try
        {
            if (request.ProductIds == null || request.ProductIds.Count == 0)
            {
                throw new ArgumentException($"No product id was provided");
            }

            if (request.Price <= 0)
            {
                throw new ArgumentException($"No product price was provided");
            }

            var prices = new List<CompanyProductPriceEntity>();

            foreach (var productId in request.ProductIds)
            {
                prices.Add(new CompanyProductPriceEntity()
                {
                    Id = Guid.NewGuid().ToString(),
                    CompanyId = request.CompanyId,
                    ProductId = productId,
                    Date = DateTime.Now,
                    Price = request.Price
                });
            }

            _uow.CompanyProductPriceRepository.Insert(prices);
        }
        catch (Exception ex)
        {
            throw;
        }
    }

    public static List<ProductGroupedResponse> CalculateCompetitivenessIndexForGroupedProducts(List<ProductGroupedResponse> products)
    {
        if (products != null)
        {
            for (int i = 0; i < products.Count; i++)
            {
                if (products[i].LatestPrice > 0)
                {
                    products[i].CompetitivenessIndex = CalculateCompetitivenessIndex(products[i].LatestPrice, products[i].AvgPrice);
                }
            }
        }

        return products;
    }

    private static decimal CalculateCompetitivenessIndex(decimal price, decimal average)
    {
        return Math.Round((((price - average) / average) * 100) + 100, 2);
    }

    public async Task<MapDataResponse> GetMapData(FiltersRequest request)
    {
        var companyCrawlers = await GetCompanyCrawlers(request.CompanyId, request.IsCost);

        var query = CreateMapDataQuery(request, companyCrawlers);

        _logger.LogInformation("Searching map data for company {CompanyId}.", request.CompanyId);

        var productData = await _uow.ProductRepository.GetWithJoin<MapDataDatabricksResponse>(query);

        var mapData = ExtractMapInfoFromDatabricksResponse(productData);

        return mapData;
    }

    private QueryParameters CreateMapDataQuery(FiltersRequest request, List<CompanyMonitoringCrawlerEntity> companyCrawlers)
    {
        var query = new QueryParameters();

        query.Joins.AddRange(
        [
            new (){ JoinTable = "product_sellers AS ps", JoinCondition = "Id = ps.ProductId", JoinWithMainTable = true },
            new (){ JoinTable = "product_prices AS pp", JoinCondition = "ps.Id = pp.ProductSellerId" },
            new (){ JoinTable = "ignored_prices AS ip", JoinCondition = $"pp.Id = ip.ProductPriceId and ip.CompanyId == {request.CompanyId}", JoinType = "LEFT"}
        ]);

        query.Select.AddRange([
            new (){ Column = "Name" },
            new (){ Column = "ps.Seller" },
            new (){ Column = "ps.Address" },
            new (){ Column = "ps.Latitude" },
            new (){ Column = "ps.Longitude" },
            new (){ Column = "ps.UF" },
            new (){ Column = "AVG(pp.Price) as AvgPrice" },
            new (){ Column = "COUNT(pp.Price) as AdsQuantity" }
        ]);

        query.Filters.AddRange(DatabricksQueryHelper.CreateResultBaseFilters(request, companyCrawlers));
        query.SqlFilters.AddRange(DatabricksQueryHelper.CreateCompanyMandatoryFilters(companyCrawlers));

        query.GroupBy.AddRange
        ([
            new (){ Column = "Name"},
            new (){ Column = "Seller"},
            new (){ Column = "ps.UF"},
            new (){ Column = "ps.Address"},
            new (){ Column = "ps.Latitude"},
            new (){ Column = "ps.Longitude"},
        ]);

        query.Take = 1000;

        return query;
    }

    private MapDataResponse ExtractMapInfoFromDatabricksResponse(IEnumerable<MapDataDatabricksResponse> productData)
    {
        var mapData = new MapDataResponse()
        {
            Products = [],
            Sellers = [],
            States = []
        };

        if (productData is null || !productData.Any())
        {
            return mapData;
        }

        try
        {
            mapData.Sellers = productData.Select(x => x.Seller).Distinct();

            mapData.Products = productData.Select(x => new MapProductSellerPoints
            {
                Name = x.Name,
                Address = x.Address,
                AdsQuantity = x.AdsQuantity,
                Latitude = x.Latitude,
                Longitude = x.Longitude,
                Price = x.AvgPrice,
                Seller = x.Seller,
                Type = ""
            }).ToList();

            mapData.States = productData.GroupBy(x => x.UF).Select(x => new MapStateData
            {
                UF = x.Key,
                AvgPrice = x.Average(p => p.AvgPrice),
                SellerQuantity = x.Select(s => s.Seller).Distinct().Count(),
                AdsQuantity = x.Sum(x => x.AdsQuantity)
            }).ToList();

            return mapData;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error extracting map data from databricks");
            throw new Exception("An error occurred while extracting map data.", ex);
        }
    }

    public async Task<IEnumerable<ProductComparisonResponse>> GetProductComparisonData(FiltersRequest request)
    {
        var companyCrawlers = await GetCompanyCrawlers(request.CompanyId, request.IsCost);

        var query = CreateProductComparisonQuery(request, companyCrawlers);

        _logger.LogInformation("Searching product comparison data for company {CompanyId}.", request.CompanyId);

        var sw = Stopwatch.StartNew();
        var products = await _uow.ProductRepository.GetWithJoin<ProductComparisonPricesResponse>(query);

        sw.Stop();
        _logger.LogInformation("Product comparison query took {ms} ms to execute for company {CompanyId}", sw.ElapsedMilliseconds, request.CompanyId);

        var comparisonData = CalculateProductComparison(products);

        return comparisonData;
    }

    private static QueryParameters CreateProductComparisonQuery(FiltersRequest request, List<CompanyMonitoringCrawlerEntity> companyCrawlers)
    {
        var query = new QueryParameters();

        query.Joins.AddRange([
            new (){ JoinTable = "product_sellers AS ps", JoinCondition = "Id = ps.ProductId", JoinWithMainTable = true },
            new (){ JoinTable = "product_prices AS pp", JoinCondition = "ps.Id = pp.ProductSellerId" },
            new (){ JoinTable = "ignored_prices AS ip", JoinCondition = $"pp.Id = ip.ProductPriceId and ip.CompanyId = {request.CompanyId}", JoinType = "LEFT"}
        ]);

        query.Select.AddRange([
            new (){ Column = "Name" },
            new (){ Column = "pp.Price" }
        ]);

        query.Filters.AddRange(DatabricksQueryHelper.CreateResultBaseFilters(request, companyCrawlers));
        query.SqlFilters.AddRange(DatabricksQueryHelper.CreateCompanyMandatoryFilters(companyCrawlers));

        query.OrderBy.Add(new() { Column = "Name ASC" });

        query.TakeAll = true;

        return query;
    }

    public IEnumerable<ProductComparisonResponse> CalculateProductComparison(List<ProductComparisonPricesResponse> productPrices)
    {
        var products = new List<ProductComparisonResponse>();

        try
        {
            var groupedProducts = productPrices.GroupBy(x => x.Name).ToList();

            foreach (var group in groupedProducts)
            {
                var product = new ProductComparisonResponse();
                var prices = group.Select(x => x.Price).ToList();

                product.Min = prices.Min();
                product.Q1 = CalculateQuartile(prices, 1);
                product.Median = CalculateQuartile(prices, 2);
                product.Q3 = CalculateQuartile(prices, 3);
                product.Max = prices.Max();
                product.Avg = prices.Average();
                product.MostFrequently = GetMostFrequent(prices);
                product = CalculateOutliers(product, prices);

                products.Add(product);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error while calculating product comparison data");
            throw;
        }

        return products;
    }

    private static decimal CalculateQuartile(List<decimal> prices, int quartile)
    {
        if (prices.Count == 1) return prices[0];

        if (prices.Count == 2)
        {
            if (quartile == 1) return prices.Min();
            if (quartile == 3) return prices.Max();
            if (quartile == 2) return prices.Average();
        }

        var sortedArray = prices.OrderBy(x => x).ToList();
        var pos = (quartile / 4m) * (sortedArray.Count + 1);

        if (pos % 1 == 0)
        {
            return sortedArray[(int)(pos - 1)];
        }
        else
        {
            int lower = (int)Math.Floor(pos) - 1;
            int upper = (int)Math.Ceiling(pos) - 1;
            return sortedArray[lower] + (sortedArray[upper] - sortedArray[lower]) * (pos - Math.Floor(pos));
        }
    }
    private static decimal GetMostFrequent(List<decimal> prices)
    {
        if (prices.Count == 1) return prices[0];

        var frequency = new Dictionary<decimal, int>();
        decimal mostFrequent = prices[0];
        int maxFreq = 0;

        foreach (var price in prices)
        {
            if (frequency.TryGetValue(price, out int value))
            {
                frequency[price] = ++value;
            }
            else
            {
                frequency[price] = 1;
            }

            if (frequency[price] > maxFreq)
            {
                maxFreq = frequency[price];
                mostFrequent = price;
            }
        }

        return mostFrequent;
    }

    private static ProductComparisonResponse CalculateOutliers(ProductComparisonResponse product, List<decimal> prices)
    {
        decimal IQR = product.Q3 - product.Q1;
        decimal lowerLimit = Math.Max(product.Q1 - 1.5m * IQR, product.Min);
        decimal upperLimit = Math.Min(product.Q3 + 1.5m * IQR, product.Max);

        var outliers = prices
            .Where(value => value < lowerLimit || value > upperLimit)
            .Distinct()
            .ToList();

        product.Outliers = outliers;
        product.Low = lowerLimit;
        product.High = upperLimit;

        return product;
    }

    public async Task<CompetitivenessIndexResponse> GetCompetitivenessIndexData(FiltersRequest request)
    {
        var companyCrawlers = await GetCompanyCrawlers(request.CompanyId, request.IsCost);

        var query = CreateCompetitivenessIndexQuery(request, companyCrawlers, _uow.ProductRepository.GetSchema());

        _logger.LogInformation("Searching competitiveness index data for company {CompanyId}.", request.CompanyId);

        var sw = Stopwatch.StartNew();
        var products = await _uow.ProductRepository.GetWithJoin<CompetitivenessQueryResponse>(query);

        sw.Stop();
        _logger.LogInformation("Product competitiveness index query took {ms} ms to execute for company {CompanyId}", sw.ElapsedMilliseconds, request.CompanyId);

        var competitivenessIndex = CalculateProductsCompetitivenessIndex(request, products);

        return competitivenessIndex;
    }

    private static QueryParameters CreateCompetitivenessIndexQuery(FiltersRequest request, List<CompanyMonitoringCrawlerEntity> companyCrawlers, string schema)
    {
        var query = new QueryParameters();

        query.Joins.AddRange([
            new (){ JoinTable = "product_sellers AS ps", JoinCondition = "Id = ps.ProductId", JoinWithMainTable = true },
            new (){ JoinTable = "product_prices AS pp", JoinCondition = "ps.Id = pp.ProductSellerId" },
            new (){ JoinTable = "ignored_prices AS ip", JoinCondition = $"pp.Id = ip.ProductPriceId and ip.CompanyId = {request.CompanyId}", JoinType = "LEFT"},
            new (){ JoinSQL = $" LEFT JOIN (SELECT ProductId, Price as LatestPrice FROM {schema}.company_product_prices WHERE CompanyId = {request.CompanyId} ORDER BY Date DESC LIMIT 1) cpp ON cpp.ProductId = {schema}.products.Id"}
        ]);

        query.Select.AddRange([
            new (){ Column = "Name" },
            new (){ Column = "CAST(pp.collectedDate AS DATE) AS Date" },
            new (){ Column = "AVG(pp.Price) AS AveragePrice" },
            new (){ Column = "cpp.LatestPrice as LatestPrice" },
        ]);

        query.Filters.AddRange(DatabricksQueryHelper.CreateResultBaseFilters(request, companyCrawlers));
        query.Filters.Add(new QueryFilter { Column = "LatestPrice", Operator = "IS", Value = "NOT NULL" });
        query.SqlFilters.AddRange(DatabricksQueryHelper.CreateCompanyMandatoryFilters(companyCrawlers));

        query.GroupBy.AddRange([
            new() { Column = "Name" },
            new() { Column = "Date" },
            new() { Column = "LatestPrice" }
        ]);
        query.OrderBy.Add(new() { Column = "Name ASC" });

        query.TakeAll = true;

        return query;
    }

    private static CompetitivenessIndexResponse CalculateProductsCompetitivenessIndex(FiltersRequest request, List<CompetitivenessQueryResponse> productPrices)
    {
        var result = new CompetitivenessIndexResponse();

        foreach (var product in productPrices)
        {
            product.CompetitivenessIndex = CalculateCompetitivenessIndex(product.LatestPrice, product.AveragePrice);
        }

        result.AverageCompetitiveness = productPrices.Average(x => x.CompetitivenessIndex);

        var productsHistory = new List<CompetitivenessIndexHistoryProduct>();
        var dates = new List<DateTime>();

        foreach (var product in productPrices.GroupBy(x => x.Name))
        {
            var productHistory = new CompetitivenessIndexHistoryProduct()
            {
                Name = product.Key,
                CompetitivenessIndex = []
            };

            for (DateTime date = request.StartDate; date <= request.EndDate; date = date.AddDays(1))
            {
                dates.Add(date.Date);
                var icForDay = product.FirstOrDefault(x => x.Date.Date == date.Date)?.CompetitivenessIndex ?? null;
                productHistory.CompetitivenessIndex.Add(icForDay);
            }

            productsHistory.Add(productHistory);
        }

        result.CompetitivenessIndexHistory = new CompetitivenessIndexHistory
        {
            Dates = dates.OrderBy(x => x).Select(x => x.ToString("yyyy-MM-dd")).ToList(),
            Products = productsHistory
        };

        return result;
    }
}