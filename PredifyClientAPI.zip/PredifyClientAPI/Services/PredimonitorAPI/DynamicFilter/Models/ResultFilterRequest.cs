﻿namespace PredifyClientAPI.Services.PredimonitorAPI.DynamicFilter.Models
{
    public sealed class ResultFilterRequest : DynamicFilterRequest
    {
        /// <summary>
        /// Inicio do periodo a se considerar os resultados
        /// </summary>
        public DateTime StartDate { get; set; }

        /// <summary>
        /// Fim do periodo a se considerar os resultados
        /// </summary>
        public DateTime EndDate { get; set; }

        /// <summary>
        /// Modelo para definir intervalo de horas de uso de veiculos inicialmente ou qualquer outro maquinário
        /// </summary>
        public ResultFilterHourmeterRangeRequest? HourMeter { get; set; }

        public long CompanyId { get; set; }
    }

    public sealed class ResultFilterHourmeterRangeRequest
    {
        public int? Min { get; set; }
        public int? Max { get; set; }
    }
}
