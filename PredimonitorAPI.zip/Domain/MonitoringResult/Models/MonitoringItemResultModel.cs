﻿using Repository.Enums;

namespace Domain.MonitoringResult.Models
{
    public class MonitoringItemResultModel
    {
        public long MonitoringItemId { get; set; }
        public string Description { get; set; }
        public string Hash { get; set; }
        public int CrawlerId { get; set; }
        public CrawlerSourceType Source { get; set; }
        public string CrawlerName { get; set; }
    }
}
