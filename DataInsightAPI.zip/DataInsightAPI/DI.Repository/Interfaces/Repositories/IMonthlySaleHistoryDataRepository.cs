﻿using DI.Repository.Entities;
using DI.Repository.Enum;

namespace DI.Repository.Interfaces.Repositories
{
    public interface IMonthlySaleHistoryDataRepository
    {
        IEnumerable<MonthlySaleHistoryDataEntity> GetAll(long CompanyId, int startYearMonth, int endYearMonth, EGranularityType eGranularityType);
        IEnumerable<MonthlySaleHistoryDataEntity> GetAll(long CompanyId, EGranularityType eGranularityType);
        Task<int> GetCountSkus(long CompanyId, EGranularityType granularityType, IEnumerable<string> majorGranularityFilter, CancellationToken cancellationToken);
        Task<int> GetCountSkus(long CompanyId, EGranularityType granularityType, CancellationToken cancellationToken);

    }
}