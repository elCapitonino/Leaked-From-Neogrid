﻿namespace DI.Repository.Enum
{
    [Flags]
    public enum EContextType
    {
        None = 0,
        SqlServer = 1,
        Postgre = 2,
        All = SqlServer | Postgre
    }
}
