using Repository.Entity.Databricks;

namespace DomainTests.Product.Seed
{

    public class ProductSeed
    {
        public static ProductTestData GetProductTestData(int crawlerId = 1)
        {
            var testData = new ProductTestData()
            {
                Products = [],
                Sellers = [],
                Prices = [],
                IgnoredPrices = []
            };

            //MAÇÃ
            var maca = new ProductEntity { Id = Guid.NewGuid().ToString(), Name = "Maçã", Brand = "Fazenda XV", EAN = "123456", CrawlerId = crawlerId, Year = DateTime.Now.Year };

            var sellerMaca = new ProductSellerEntity { Id = Guid.NewGuid().ToString(), ProductId = maca.Id, Seller = "Mercado Oliveira", Category = "Frutas", SellerGroup = "Mercado Oliveira", Segment = "Supermercados", Region = "Sul", UF = "RS", City = "Passo Fundo" };
            var sellerDoisMaca = new ProductSellerEntity { Id = Guid.NewGuid().ToString(), ProductId = maca.Id, Seller = "Feira Central", Category = "Frutas", SellerGroup = "Feira Livre", Segment = "Feiras", Region = "Sudeste", UF = "SP", City = "São Paulo" };

            testData.Prices.Add(new ProductPriceEntity { Id = Guid.NewGuid().ToString(), ProductSellerId = sellerMaca.Id, ImportDate = DateTime.Now, CollectedDate = DateTime.Now.AddDays(-1), Price = 12.60m });
            testData.Prices.Add(new ProductPriceEntity { Id = Guid.NewGuid().ToString(), ProductSellerId = sellerMaca.Id, ImportDate = DateTime.Now, CollectedDate = DateTime.Now, Price = 13.20m });
            testData.Prices.Add(new ProductPriceEntity { Id = Guid.NewGuid().ToString(), ProductSellerId = sellerDoisMaca.Id, ImportDate = DateTime.Now, CollectedDate = DateTime.Now, Price = 11.00m });
            var macaPrice = new ProductPriceEntity { Id = Guid.NewGuid().ToString(), ProductSellerId = sellerDoisMaca.Id, ImportDate = DateTime.Now, CollectedDate = DateTime.Now, Price = 10.50m };

            testData.IgnoredPrices.Add(new IgnoredPriceEntity { Id = Guid.NewGuid().ToString(), CompanyId = 1, ProductPriceId = macaPrice.Id });

            testData.Products.Add(maca);
            testData.Sellers.Add(sellerMaca);
            testData.Sellers.Add(sellerDoisMaca);
            testData.Prices.Add(macaPrice);

            //MAÇÃ DOIS
            var macaDois = new ProductEntity { Id = Guid.NewGuid().ToString(), Name = "Maçã", Brand = "Fazenda Dez", EAN = "1234567", CrawlerId = crawlerId, Year = DateTime.Now.Year };

            var sellerMacaDois = new ProductSellerEntity { Id = Guid.NewGuid().ToString(), ProductId = macaDois.Id, Seller = "Feira Central", Category = "Frutas", SellerGroup = "Feira Livre", Segment = "Feiras", Region = "Sudeste", UF = "SP", City = "São Paulo" };

            testData.Prices.Add(new ProductPriceEntity { Id = Guid.NewGuid().ToString(), ProductSellerId = sellerMacaDois.Id, ImportDate = DateTime.Now, CollectedDate = DateTime.Now, Price = 9.50m });
            testData.Prices.Add(new ProductPriceEntity { Id = Guid.NewGuid().ToString(), ProductSellerId = sellerMacaDois.Id, ImportDate = DateTime.Now, CollectedDate = DateTime.Now, Price = 12.75m });
            testData.Prices.Add(new ProductPriceEntity { Id = Guid.NewGuid().ToString(), ProductSellerId = sellerMacaDois.Id, ImportDate = DateTime.Now, CollectedDate = DateTime.Now, Price = 11.20m });
            testData.Prices.Add(new ProductPriceEntity { Id = Guid.NewGuid().ToString(), ProductSellerId = sellerMacaDois.Id, ImportDate = DateTime.Now, CollectedDate = DateTime.Now, Price = 14.38m });

            testData.Products.Add(macaDois);
            testData.Sellers.Add(sellerMacaDois);

            //MELANCIA
            var melancia = new ProductEntity { Id = Guid.NewGuid().ToString(), Name = "Melancia", Brand = "Fazenda XV", EAN = "654321", CrawlerId = crawlerId, Year = DateTime.Now.Year };

            var sellerMelancia = new ProductSellerEntity { Id = Guid.NewGuid().ToString(), ProductId = melancia.Id, Seller = "Mercado Oliveira", Category = "Frutas", SellerGroup = "Mercado Oliveira", Segment = "Supermercados", Region = "Sul", UF = "RS", City = "Passo Fundo" };
            var sellerDoisMelancia = new ProductSellerEntity { Id = Guid.NewGuid().ToString(), ProductId = melancia.Id, Seller = "Supermercado Bom Preço", Category = "Frutas", SellerGroup = "Supermercado Bom Preço", Segment = "Supermercados", Region = "Nordeste", UF = "BA", City = "Salvador" };

            testData.Prices.Add(new ProductPriceEntity { Id = Guid.NewGuid().ToString(), ProductSellerId = sellerMelancia.Id, ImportDate = DateTime.Now, CollectedDate = DateTime.Now, Price = 25.30m });
            testData.Prices.Add(new ProductPriceEntity { Id = Guid.NewGuid().ToString(), ProductSellerId = sellerMelancia.Id, ImportDate = DateTime.Now, CollectedDate = DateTime.Now, Price = 24.00m });
            testData.Prices.Add(new ProductPriceEntity { Id = Guid.NewGuid().ToString(), ProductSellerId = sellerDoisMelancia.Id, ImportDate = DateTime.Now, CollectedDate = DateTime.Now, Price = 22.80m });
            testData.Prices.Add(new ProductPriceEntity { Id = Guid.NewGuid().ToString(), ProductSellerId = sellerDoisMelancia.Id, ImportDate = DateTime.Now, CollectedDate = DateTime.Now, Price = 23.50m });

            testData.Products.Add(melancia);
            testData.Sellers.Add(sellerMelancia);
            testData.Sellers.Add(sellerDoisMelancia);


            //LARANJA
            var laranja = new ProductEntity { Id = Guid.NewGuid().ToString(), Name = "Laranja", Brand = "Fazenda Dez", EAN = "987456", CrawlerId = crawlerId, Year = DateTime.Now.Year };

            var sellerLaranja = new ProductSellerEntity { Id = Guid.NewGuid().ToString(), ProductId = laranja.Id, Seller = "Feira Central", Category = "Frutas", SellerGroup = "Feira Livre", Segment = "Feiras", Region = "Sudeste", UF = "SP", City = "São Paulo" };
            var sellerDoisLaranja = new ProductSellerEntity { Id = Guid.NewGuid().ToString(), ProductId = laranja.Id, Seller = "Quitanda Silva", Category = "Frutas", SellerGroup = "Quitandas Locais", Segment = "Comércios Locais", Region = "Sul", UF = "PR", City = "Curitiba" };

            testData.Prices.Add(new ProductPriceEntity { Id = Guid.NewGuid().ToString(), ProductSellerId = sellerLaranja.Id, ImportDate = DateTime.Now, CollectedDate = DateTime.Now, Price = 7.60m });
            testData.Prices.Add(new ProductPriceEntity { Id = Guid.NewGuid().ToString(), ProductSellerId = sellerLaranja.Id, ImportDate = DateTime.Now, CollectedDate = DateTime.Now, Price = 8.20m });
            testData.Prices.Add(new ProductPriceEntity { Id = Guid.NewGuid().ToString(), ProductSellerId = sellerDoisLaranja.Id, ImportDate = DateTime.Now, CollectedDate = DateTime.Now, Price = 7.90m });
            testData.Prices.Add(new ProductPriceEntity { Id = Guid.NewGuid().ToString(), ProductSellerId = sellerDoisLaranja.Id, ImportDate = DateTime.Now, CollectedDate = DateTime.Now, Price = 8.50m });

            testData.Products.Add(laranja);
            testData.Sellers.Add(sellerLaranja);
            testData.Sellers.Add(sellerDoisLaranja);

            //PAO
            var pao = new ProductEntity { Id = Guid.NewGuid().ToString(), Name = "Pão", Brand = "Padaria Trigo", EAN = "678910", CrawlerId = crawlerId, Year = DateTime.Now.Year };

            var sellerPao = new ProductSellerEntity { Id = Guid.NewGuid().ToString(), ProductId = pao.Id, Seller = "Padaria Trigo", Category = "Padarias", SellerGroup = "Padaria Trigo", Segment = "Padarias", Region = "Sul", UF = "SC", City = "Florianópolis" };

            testData.Prices.Add(new ProductPriceEntity { Id = Guid.NewGuid().ToString(), ProductSellerId = sellerPao.Id, ImportDate = DateTime.Now, CollectedDate = DateTime.Now, Price = 5.00m });
            testData.Prices.Add(new ProductPriceEntity { Id = Guid.NewGuid().ToString(), ProductSellerId = sellerPao.Id, ImportDate = DateTime.Now, CollectedDate = DateTime.Now, Price = 5.50m });

            testData.Products.Add(pao);
            testData.Sellers.Add(sellerPao);

            //SUCO DE UVA
            var sucoUva = new ProductEntity { Id = Guid.NewGuid().ToString(), Name = "Suco de Uva", Brand = "E-Sucos", EAN = "13579", CrawlerId = crawlerId, Year = DateTime.Now.Year };

            var sellerSucoUva = new ProductSellerEntity { Id = Guid.NewGuid().ToString(), ProductId = sucoUva.Id, Seller = "Mercado Oliveira", Category = "Bebidas", SellerGroup = "Mercado Oliveira", Segment = "Supermercados", Region = "Sul", UF = "RS", City = "Passo Fundo" };
            var sellerDoisSucoUva = new ProductSellerEntity { Id = Guid.NewGuid().ToString(), ProductId = sucoUva.Id, Seller = "Loja de Bebidas Uva Pura", Category = "Bebidas", SellerGroup = "Loja de Bebidas", Segment = "Comércios Locais", Region = "Centro-Oeste", UF = "GO", City = "Goiânia" };
            var sellerTresSucoUva = new ProductSellerEntity { Id = Guid.NewGuid().ToString(), ProductId = sucoUva.Id, Seller = "Supermercado Nacional", Category = "Bebidas", SellerGroup = "Supermercado Nacional", Segment = "Supermercados", Region = "Sul", UF = "RS", City = "Porto Alegre" };

            testData.Prices.Add(new ProductPriceEntity { Id = Guid.NewGuid().ToString(), ProductSellerId = sellerSucoUva.Id, ImportDate = DateTime.Now, CollectedDate = DateTime.Now, Price = 15.70m });
            testData.Prices.Add(new ProductPriceEntity { Id = Guid.NewGuid().ToString(), ProductSellerId = sellerSucoUva.Id, ImportDate = DateTime.Now, CollectedDate = DateTime.Now, Price = 16.00m });
            testData.Prices.Add(new ProductPriceEntity { Id = Guid.NewGuid().ToString(), ProductSellerId = sellerDoisSucoUva.Id, ImportDate = DateTime.Now, CollectedDate = DateTime.Now, Price = 14.50m });
            testData.Prices.Add(new ProductPriceEntity { Id = Guid.NewGuid().ToString(), ProductSellerId = sellerDoisSucoUva.Id, ImportDate = DateTime.Now, CollectedDate = DateTime.Now, Price = 14.80m });
            testData.Prices.Add(new ProductPriceEntity { Id = Guid.NewGuid().ToString(), ProductSellerId = sellerTresSucoUva.Id, ImportDate = DateTime.Now, CollectedDate = DateTime.Now, Price = 15.90m });
            testData.Prices.Add(new ProductPriceEntity { Id = Guid.NewGuid().ToString(), ProductSellerId = sellerTresSucoUva.Id, ImportDate = DateTime.Now, CollectedDate = DateTime.Now, Price = 16.50m });

            testData.Products.Add(sucoUva);
            testData.Sellers.Add(sellerSucoUva);
            testData.Sellers.Add(sellerDoisSucoUva);
            testData.Sellers.Add(sellerTresSucoUva);

            return testData;
        }
    }

    public class ProductTestData
    {
        public List<ProductEntity> Products { get; set; }
        public List<ProductSellerEntity> Sellers { get; set; }
        public List<ProductPriceEntity> Prices { get; set; }
        public List<IgnoredPriceEntity> IgnoredPrices { get; set; }
    }
}