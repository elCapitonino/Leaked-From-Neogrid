﻿using Repository.Enums;

namespace Domain.MonitoringResult.Models
{
    public sealed class ResultFilterResponse
    {
        public string? ProductName { get; set; }
        public string? ProductLink { get; set; }
        public string? ProductBrand { get; set; }
        public string? SellerName { get; set; }
        public string? Marketplace { get; set; }
        public decimal? Price { get; set; }
        public decimal? PriceFrom { get; set; }
        public string? PaymentType { get; set; }
        public PriceUnitType? Price_unit_type { get; set; }
        public decimal? Price_unit { get; set; }
        public decimal? Price_unit_quantity { get; set; }
        public DateTime? CrawlerDate { get; set; }
        public long? IdCrawler { get; set; }
        public bool? Disregarded { get; set; }
        public bool? PriceAlert { get; set; }
        public string? Country { get; set; }
        public string? State { get; set; }
        public string? City { get; set; }
        public int? ProductManufactureYear { get; set; }
        public int? ProductUsedHours { get; set; }
        public string? ProductAxles { get; set; }
        public int? ProductMileage { get; set; }
        public string? ProductMileageSymbol { get; set; }
        public decimal? ProductFuelTankCapacity { get; set; }
        public string? ProductFuelTankCapacitySymbol { get; set; }
        public string? ProductTruckBodyType { get; set; }
        public string? ProductVehicleYearModel { get; set; }
        public string? ProductManufacturer { get; set; }
        public bool? On_request { get; set; }
        public decimal? Price_tax_st { get; set; }
        public int? QuantityInstallment { get; set; }
        public decimal? Total_priceInstallment { get; set; }
        public decimal? PriceInstallment { get; set; }
        public string? Price_currencyInstallment { get; set; }
        public decimal? DeflatedValue { get; set; }
        public string? Format_market { get; set; }

        public PrediMonitorProduct_CoordinatesModel? Coordinates { get; set; }
        public long MonitoringItemId { get; set; }
        public string? ProductModel { get; set; }
    }

    public class PrediMonitorProduct_CoordinatesModel
    {
        public decimal? Longitude { get; set; }
        public decimal? Latitude { get; set; }
    }
}
