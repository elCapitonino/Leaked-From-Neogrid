﻿using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using PH.Domain.DTO;
using PH.Domain.Interfaces.Repositories;
using PH.Domain.Interfaces.Services;

namespace PH.Service.Services
{
    public class GraficoServices : IGraficoServices
    {
        private readonly ILogger<GraficoServices> _logger;
        private readonly IGraficoRepository _repository;
        private readonly IMemoryCache _memoryCache;
        private readonly ICacheControlService _cacheControlService;

        public GraficoServices(ILogger<GraficoServices> logger,
                               IGraficoRepository repository,
                               IMemoryCache memoryCache,
                               ICacheControlService cacheControlService)
        {
            _logger = logger;
            _repository = repository;
            _memoryCache = memoryCache;
            _cacheControlService = cacheControlService;
        }

        public async Task<List<GraficoDTO>> Get(string? loja, string? curva, string? categoria)
        {
            _logger.LogInformation("Service: buscando todos os Graficos");

            try
            {
                return await _repository.Get(loja, curva, categoria);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Service: erro ao buscar todos os Graficos. {ex.Message}");
                throw;
            }
        }

        public async Task<List<GraficoReceitaDTO>> GetGraficoReceita(long idCompany, string loja)
        {
            _logger.LogInformation("Service: buscando o Graficos de Receita ");
            string chaveCache = $"GraficoReceita-{idCompany}-loja{loja}";

            try
            {
                List<GraficoReceitaDTO> response = (List<GraficoReceitaDTO>)_memoryCache.Get(chaveCache);

                if (response == null)
                {

                    var list = await _repository.GetGraficoReceita(idCompany, loja);

                    _cacheControlService.SettingTimeAndCache(list, chaveCache, 24);
                }

                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Service: erro ao buscar Graficos de Receita. {ex.Message}");
                throw;
            }
        }
    }
}
