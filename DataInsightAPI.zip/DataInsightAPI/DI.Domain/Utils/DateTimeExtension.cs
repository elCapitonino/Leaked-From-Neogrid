﻿using System.Globalization;

namespace DI.Domain.Utils
{
    public static class DateTimeExtension
    {
        public static int ToYearMonth(this DateTime dateTime)
        {
            return int.Parse(dateTime.ToString("yyyyMM"));
        }

        public static readonly string[] MonthNameInYearMonth = new[]
        {
            "TXT_NONE",
            "TXT_JANUARY", "TXT_FEBRUARY", "TXT_MARCH", "TXT_APRIL",
            "TXT_MAY", "TXT_JUNE", "TXT_JULY", "TXT_AUGUST",
            "TXT_SEPTEMBER", "TXT_OCTOBER", "TXT_NOVEMBER", "TXT_DECEMBER"
        };

        public static string GetMonthName(this int monthNumber, string cultureInfoLocateName = "pt-BR") =>
            new CultureInfo(cultureInfoLocateName).DateTimeFormat.GetMonthName(monthNumber);
    }
}
