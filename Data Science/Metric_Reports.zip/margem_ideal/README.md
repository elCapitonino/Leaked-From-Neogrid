# Margem Ideal

Relatório com sugestões de intervalo de margem por categoria.

## Ambiente

Crie um ambiente virtual (Python >= 3.10). Em seguida, instale as dependências:

```bash
python -m pip install requirements.txt
```

Se estiver utilizando Linux como SO, também é necessário possuir as bibliotecas `xelatex` e `pandoc` instaladas e disponíveis na sua variável de ambiente `PATH` para salvar o arquivo como PDF diretamente.

## Gerando o Jupyter Notebook (ipynb)

A biblioteca `jupytext` é utilizada para gerar um jupyter notebook a partir de um arquivo Python. **Todas as alterações devem ser feitas no _script_ `margem_ideal.py`, o qual está no git.** Outros _scripts_ alternativos podem existir para atender a requisitos específicos, todos começando com `margem_ideal_`. Você pode especificar qual arquivo `.ipynb` deve ser usado com o argumento `--ipynb-filename`.

Para gerar o arquivo jupyter pela primeira vez ou sincronizá-lo com o _script_ Python, rode:

```bash
jupytext --sync margem_ideal.py
```

## Gerando o relatório

Utilize o _script_ `run_report` para gerar o relatório em PDF:

```bash
python run_report.py --id-company 1234 --start-date 2023-12-01 --cat-fields Category1 Category2
```

### Linux

Um PDF será gerado diretamente por meio da biblioteca `pandoc`.

### Windows

Um arquivo HTML do relatório será gerado. Esse arquivo pode ser convertido em arquivo PDF pelo navegador, com a função _"imprimir para PDF"_.

**Substituindo os argumentos pelos valores corretos.** Um gráfico de intervalo de margem será gerado para cada combinação distinta dos valores concatenados das colunas de categoria (`--cat-fields`).

## Desenvolvimento

É possível rodar o _scipt_ `margem_ideal` diretamente ou de forma interativa (`ipykernel`). É necessário ter um arquivo de configuração com parâmetros do relatório no caminho determinado na variável CONFIG_FILE.

Esse arquivo é um JSON com os parâmetros, conforme exemplo abaixo:

```json
{"env": "producao", "id_company": 1234, "start_date": "2023-11-01", "cat_fields": ["Category3"], "debug": true}
```

Para desenvolvimento e _debugging_, a forma mais amigável é colocar valores fixos nesse arquivo e rodar o _script_ `margem_ideal` diretamente. O valor `debug=true` permite que se utilize um cache local dos dados para agilizar o desenvolvimento.

O _script_ `run_report` fornece a mesma opção `debug` para desenvolvimento.