﻿using Services.SearchAPI.Models;

namespace Services.SearchAPI
{
    public interface ISearchAPIService
    {
        Task<IEnumerable<SearchAPIResponse>> SearchV4(SearchAPIRequest request);
        Task<IEnumerable<SearchAPIResponse>> SearchV4WithTask(SearchAPIRequest request);
    }
}
