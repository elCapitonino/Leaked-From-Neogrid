﻿using PredifyClientAPI.Services.PredimonitorAPI.DynamicFilter.Models;

namespace PredifyClientAPI.Services.PredimonitorAPI.DynamicFilter
{
    public interface IDynamicFilterService
    {
        Task<DynamicFilterResponse> GetFilter(long companyId, DynamicFilterRequest request);
        Task<List<SeeResultResponse>> GetResult(ResultFilterRequest request);
    }
}
