﻿namespace Repository.Enums
{
    public enum PriceUnitType
    {
        UNITARIO = 0,
        CAIXA = 1,
    }
}
