# Introdução

Neste repositório temos um apanhado de códigos para geração de relatórios.
Indo direto ao ponto, na pasta geral temos um código genérico que faz o relatório.
