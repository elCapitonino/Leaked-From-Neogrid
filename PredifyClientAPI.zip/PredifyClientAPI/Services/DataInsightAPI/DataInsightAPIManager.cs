﻿using Microsoft.Extensions.Options;
using PredifyClientAPI.Services.DataInsightAPI.DataImpact;
using PredifyClientAPI.Services.PredimonitorAPI.Models;

namespace PredifyClientAPI.Services.DataInsightAPI
{
    public class DataInsightAPIManager
    {
        public DataInsightAPIManager(HttpClient client, IOptions<PredimonitorAPIOptions> options)
        {
            DataImpactDataService = new ImpactDataService(client);
        }

        public IImpactDataService DataImpactDataService { get; }
    }
}
