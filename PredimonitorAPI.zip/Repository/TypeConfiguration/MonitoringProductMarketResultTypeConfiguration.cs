﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Repository.Attributes;
using Repository.DbContexts;
using Repository.Entity;

namespace Repository.TypeConfiguration
{
    [DbContextTypeConfiguration(typeof(ApplicationDbContext))]
    public class MonitoringProductMarketResultTypeConfiguration : TypeConfigurationBase<MonitoringProductMarketResultEntity>, IEntityTypeConfiguration<MonitoringProductMarketResultEntity>
    {
        public override void Configure(EntityTypeBuilder<MonitoringProductMarketResultEntity> builder)
        {
            builder.ToTable("Monitoring_ProductMarketResult");
            builder.Property(x => x.Id).HasColumnName("IdMonitoring_ProductMarketResult");
            builder.Property(x => x.CompanyId).HasColumnName("IdCompany").IsRequired();
            builder.Property(x => x.ProductId).HasColumnName("IdProduct");
            builder.Property(x => x.MaxPriceCrawlerId).HasColumnName("MaxPriceIdCrawler");
            builder.Property(x => x.MinPriceCrawlerId).HasColumnName("MinPriceIdCrawler");
            builder.Property(x => x.MonitoringItemId).HasColumnName("IdMonitoringItem");
            builder.HasOne(w => w.MonitoringItem).WithMany(b => b.MonitoringProductMarketResults).HasForeignKey(w => w.MonitoringItemId);
        }
    }
}
