﻿namespace DI.Domain.ImpactGraph.Models
{
    public class ProfitGraphResponseModel
    {
        public ProfitGraphResponseModel()
        {
            Categories = new List<GraphCategoryModel>();
            PreviousProfit = new GraphDataModel();
            ProjectedProfit = new GraphDataModel();
            RealizedProfit = new GraphDataModel();
        }

        public List<GraphCategoryModel> Categories { get; set; }
        public GraphDataModel PreviousProfit { get; set; }
        public GraphDataModel ProjectedProfit { get; set; }
        public GraphDataModel RealizedProfit { get; set; }
    }
}
