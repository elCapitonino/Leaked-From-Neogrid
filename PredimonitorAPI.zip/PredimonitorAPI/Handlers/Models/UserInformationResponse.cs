﻿namespace PredimonitorAPI.Handlers.Models
{
    public class UserInformationResponse
    {
        public string idUsuario { get; set; }
        public string nome { get; set; }
        public string email { get; set; }
        public string telefone { get; set; }
        public bool predifyAdmin { get; set; }
        public string lang { get; set; }
        public bool addCompany { get; set; }
        public bool isProprietario { get; set; }
        public string[] adminRoles { get; set; }
    }

}
