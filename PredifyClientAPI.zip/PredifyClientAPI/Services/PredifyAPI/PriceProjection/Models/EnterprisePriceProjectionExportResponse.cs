﻿using PredifyClientAPI.Services.PredifyAPI.Models;

namespace PredifyClientAPI.Services.PredifyAPI.PriceProjection.Models
{
    /// <summary>
    /// Response de projeções de preço
    /// </summary>
    public class EnterprisePriceProjectionExportResponse
    {
        /// <summary>
        /// Identificador do grupo.
        /// </summary>
        public virtual long IdEnterprisePriceGroup { get; set; }

        /// <summary>
        /// Nome do Produto 
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        /// EAN do Produto 
        /// </summary>
        public string PackageDescription { get; set; }

        /// <summary>
        /// Código do produto.
        /// </summary>
        public string Product { get; set; }

        /// <summary>
        /// Nome da filial.
        /// </summary>
        public string AffiliateName { get; set; }

        /// <summary>
        /// Codigo da filial.
        /// </summary>
        public string Affiliate { get; set; }

        /// <summary>
        /// Estado.
        /// País da Filial.
        /// </summary>
        public string AffiliateCountry { get; set; }

        /// <summary>
        /// Estado da Filial.
        /// </summary>
        public string AffiliateState { get; set; }

        /// <summary>
        /// Cidade da Filial.
        /// </summary>
        public string AffiliateCity { get; set; }

        /// <summary>
        /// Grupo Economico.
        /// </summary>
        public string EconomicGroupCode { get; set; }

        /// <summary>
        /// Grupo Economico.
        /// </summary>
        public string EconomicGroup { get; set; }

        /// <summary>
        /// Codigo do Segmento.
        /// </summary>
        public string CodSegment { get; set; }

        /// <summary>
        /// Segmento.
        /// </summary>
        public string NameSegment { get; set; }

        /// <summary>
        /// Grupo de produtos.
        /// </summary>
        public string ProductGroup { get; set; }

        /// <summary>
        /// NBM.
        /// </summary>
        public long? NBM { get; set; }

        /// <summary>
        /// Preço utilizado na ultima venda feita de acordo com a data do calculo
        /// </summary>
        public decimal? LastSalePrice { get; set; }

        /// <summary>
        /// Margem utilizado na ultima venda feita de acordo com a data do calculo
        /// </summary>
        public decimal? LastSalePrice_Margin { get; set; }

        /// <summary>
        /// Preço de venda da IA.
        /// </summary>
        public decimal? SalePrice { get; set; }

        /// <summary>
        /// Ultima ação no Fluxo  de aprovação da PriceProjection
        /// </summary>
        public WorkflowAction_Action? Action { get; set; }

        /// <summary>
        /// Usuario da ultima ação no Fluxo  de aprovação da PriceProjection
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// Retorna true ou false para enviar ao ERP a ultima ação do Fluxo
        /// </summary>
        public bool ToSendERP { get; set; }

        /// <summary>
        /// Indica se a projeção foi publicada
        /// </summary>
        public bool IsPublished { get; set; }

        /// <summary>
        /// Referencia da projeção para se identificar na prices overrides por questões de granularidade
        /// </summary>
        public decimal? ManualMaxPriceMarketResult { get; set; }

        /// <summary>
        /// Referencia da projeção para se identificar na prices overrides por questões de granularidade
        /// </summary>
        public decimal? ManualMinPriceMarketResult { get; set; }

        /// <summary>
        /// Referencia da projeção para se identificar na prices overrides por questões de granularidade
        /// </summary>
        public decimal? ManualAvgPriceMarketResult { get; set; }

        /// <summary>
        /// Minimo
        /// </summary>
        public decimal? MinPrice { get; set; }

        /// <summary>
        /// Maximmo
        /// </summary>
        public decimal? MaxPrice { get; set; }

        /// <summary>
        /// Medio
        /// </summary>
        public decimal? AvgPrice { get; set; }

        /// <summary>
        /// Link do produto monitorado com o maior preço
        /// </summary>
        public string MaxPriceProductLink { get; set; }

        /// <summary>
        /// Link do produto monitorado com o menor preço
        /// </summary>
        public string MinPriceProductLink { get; set; }

        /// <summary>
        /// Verifica se o preço minimo utilizado na precificação é manual
        /// </summary>
        public bool IsMinMarketResultManual { get => ManualMinPriceMarketResult != null; }

        /// <summary>
        /// Verifica se o preço Maximo utilizado na precificação é manual
        /// </summary>
        public bool IsMaxMarketResultManual { get => ManualMaxPriceMarketResult != null; }


        /// <summary>
        /// Verifica se o preço médio utilizado na precificação é manual
        /// </summary>
        public bool IsAvgMarketResultManual { get => ManualAvgPriceMarketResult != null; }

        /// <summary>
        /// Margin do Preço de venda da IA.
        /// </summary>
        public decimal? SalePrice_Margin { get; set; }

        /// <summary>
        /// Categoria mais ampla | Exemplo: Bebidas
        /// </summary>
        public string Category1 { get; set; }

        /// <summary>
        /// Categoria Intermediária | Exemplo: Cervejas
        /// </summary>
        public string Category2 { get; set; }

        /// <summary>
        /// Categoria Menor | Exemplo: Cerveja Light
        /// </summary>
        public string Category3 { get; set; }

        /// <summary>
        /// Região de venda da Filial ou produto | Exemplo: Sul
        /// </summary>
        public string Category4 { get; set; }

        /// <summary>
        /// Tipo de venda(preços diferentes por canal) | Exemplo: Varejo, Atacado, ecommerce etc
        /// </summary>
        public string Category5 { get; set; }

        /// <summary>
        /// Identificador da Categoria1.
        /// </summary>
        public string Category1Id { get; set; }

        /// <summary>
        /// Identificador da Categoria2.
        /// </summary>
        public string Category2Id { get; set; }

        /// <summary>
        /// Identificador da Categoria3
        /// </summary>
        public string Category3Id { get; set; }

        /// <summary>
        /// Identificador da Categoria4
        /// </summary>
        public string Category4Id { get; set; }

        /// <summary>
        /// Identificador da Categoria5
        /// </summary>
        public string Category5Id { get; set; }

        /// <summary>
        /// Data da emissão da NF
        /// </summary>
        public DateTime DateLastSale { get; set; }

        /// <summary>
        /// Código que identifica o cliente da venda
        /// </summary>
        public string Customer { get; set; }

        /// <summary>
        /// Segment 2
        /// </summary>
        public string Segment2 { get; set; }

        /// <summary>
        /// Document
        /// </summary>
        public string Document { get; set; }

        /// <summary>
        /// PackageUnity
        /// </summary>
        public string PackageUnity { get; set; }

        /// <summary>
        /// Nome do cliente que comprou
        /// </summary>
        public string CustomerName { get; set; }

        /// <summary>
        /// Categoria do cliente
        /// </summary>
        public string ClientType { get; set; }

        /// <summary>
        /// Código da promoção. Utilizado para algumas filiais da Farmácia São João
        /// </summary>
        public string StatusProduct { get; set; }

        /// <summary>
        /// Response de Value Overrides (Preço sobrescrito)
        /// </summary>
        public EnterprisePricesProjectionOverrideExportResponse Override { get; set; }

        /// <summary>
        /// Quantidade de competidores monitorados
        /// </summary>
        public decimal? QuantityCompetitors { get; set; }

        /// <summary>
        /// Curva ABC da Demanda do Preço de venda (AI)
        /// </summary>
        public string SalePrice_Demand_CurveABC { get; set; }

        /// <summary>
        /// Campo calculado a partir da elasticidade, Demanda do Preço de venda (AI)
        /// </summary>
        public decimal? CalculatedDemand { get; set; }

        /// <summary>
        /// [Obsoleto]Caso tenha elasticidade, retorna o MeanQuantity dela
        /// </summary>
        public decimal? MeanQuantity { get; set; }

        /// <summary>
        /// [Obsoleto]Caso tenha elasticidade, retorna o MeanPrice dela
        /// </summary>
        public decimal? MeanPrice { get; set; }

        /// <summary>
        /// Custo
        /// </summary>
        public decimal? Cost { get; set; }

        /// <summary>
        /// Centro de distribuição. Somente Fujioka utiliza
        /// </summary>
        public string DistributionCenter { get; set; }

        /// <summary>
        /// Quantidade do estoque no momento da precificação. Somente Fujioka utiliza
        /// </summary>
        public decimal? StockQuantity { get; set; }

        /// <summary>
        /// Taxa de Venda do produto. Somente Fujioka utiliza
        /// </summary>
        public decimal? SaleTax { get; set; }

        /// <summary>
        /// Código da Loja
        /// </summary>
        public string Store { get; set; }

        /// <summary>
        /// Número do Pedido
        /// </summary>
        public string InvoceNumber { get; set; }

        /// <summary>
        /// Preço de venda final, que o cliente vai pagar.
        /// </summary>
        public decimal? ClientSalesPrice { get; set; }

        /// <summary>
        /// Local de venda. Ex: loja fisica, callcenter ou loja virtual
        /// </summary>
        public string TypeOfStore { get; set; }

        /// <summary>
        /// Date do ultimo calculo realizado
        /// </summary>
        public DateTime? CalcDate { get; set; }

        /// <summary>
        /// Nome do Grupo de Precificação
        /// </summary>
        public string PriceGroupName { get; set; }

        /// <summary>
        /// Código do fornecedor.
        /// </summary>
        public string SupplierCode { get; set; }

        /// <summary>
        /// Nome do fornecedor.
        /// </summary>
        public string SupplierName { get; set; }

        /// <summary>
        /// TypeOfShipping
        /// </summary>
        public string TypeOfShipping { get; set; }

        /// <summary>
        /// ClientCountry
        /// </summary>
        public string ClientCountry { get; set; }

        /// <summary>
        /// ClientState
        /// </summary>
        public string ClientState { get; set; }

        /// <summary>
        /// Custo Médio da rede
        /// </summary>
        public decimal? AverageNetworkCost { get; set; }

        /// <summary>
        /// Coleta o Preço Maximo que será utilizado nas precificações
        /// </summary>
        public decimal? GetMaxPriceMarketResult
        {
            get
            {
                if (ManualMaxPriceMarketResult != null)
                    return ManualMaxPriceMarketResult;

                return MaxPrice;
            }
        }

        /// <summary>
        /// Coleta o Preço Minimo que será utilizado nas precificações
        /// </summary>
        public decimal? GetMinPriceMarketResult
        {
            get
            {
                if (ManualMinPriceMarketResult != null)
                    return ManualMinPriceMarketResult;

                return MinPrice;
            }
        }

        /// <summary>
        /// Coleta o Preço Médio que será utilizado nas precificações
        /// </summary>
        public decimal? GetAvgPriceMarketResult
        {
            get
            {
                if (ManualAvgPriceMarketResult != null)
                    return ManualAvgPriceMarketResult;

                return AvgPrice;
            }
        }

        /// <summary>
        /// Coleta qual preço devera ser usado
        /// </summary>
        public decimal? SuggestedPrice
        {
            get
            {
                if (Override != null)
                {
                    if (Override.IsManual == true)
                        return Override.Manual_Price;
                    else
                        return Override.Price;
                }
                else
                {
                    return SalePrice;
                }
            }
        }


        /// <summary>
        /// Coleta qual margin devera ser usado
        /// </summary>
        public decimal? SuggestedPrice_Margin
        {
            get
            {
                if (Override != null)
                {
                    if (Override.IsManual == true)
                        return Override.Manual_Price_Margin;
                    else
                        return Override.Price_Margin;
                }
                else
                {
                    return SalePrice_Margin;
                }
            }
        }

        /// <summary>
        /// Coleta qual margin devera ser usado
        /// </summary>
        public decimal? IC
        {
            get
            {
                if (SuggestedPrice != null && GetAvgPriceMarketResult != null)
                    return (SuggestedPrice * 100) / GetAvgPriceMarketResult;
                else
                    return null;
            }
        }

        /// <summary>
        /// Parâmetro no get da API usado para a tradução. (pt-br, en-us, es-es)
        /// </summary>
        public string Language { get; set; }

        /// <summary>
        /// Retorna a ação traduzida conforma a Language (Aprovado, Reprovado ou Escalado traduzindo)
        /// </summary>
        public string GetTranslateAction
        {
            get
            {
                if (Action != null)
                {
                    if (Language != null)
                    {
                        if (Language == "pt-br")
                        {
                            if (Action == WorkflowAction_Action.Approval)
                                return "Aprovado";
                            else if (Action == WorkflowAction_Action.Repproval)
                                return "Reprovado";
                            else
                                return "Escalado";
                        }
                        else if (Language == "en-us")
                        {
                            if (Action == WorkflowAction_Action.Approval)
                                return "Approval";
                            else if (Action == WorkflowAction_Action.Repproval)
                                return "Repproval";
                            else
                                return "RankUp";
                        }
                        else
                        {
                            if (Action == WorkflowAction_Action.Approval)
                                return "Aprobado";
                            else if (Action == WorkflowAction_Action.Repproval)
                                return "Rechazado";
                            else
                                return "Escalado";
                        }
                    }
                    else
                    {
                        if (Action == WorkflowAction_Action.Approval)
                            return "Approval";
                        else if (Action == WorkflowAction_Action.Repproval)
                            return "Repproval";
                        else
                            return "RankUp";
                    }
                }

                return "";
            }
        }

        /// <summary>
        /// Coleta qual demanda devera ser usado
        /// </summary>
        public decimal? SuggestedPrice_Demand
        {
            get
            {
                if (Override != null)
                {
                    if (Override.IsManual == true)
                        return Override.Manual_Price_Demand;
                    else
                        return Override.Price_Demand;
                }
                else
                {
                    return CalculatedDemand;
                }
            }
        }

        /// <summary>
        /// Variação de lucro calculada
        /// </summary>
        public decimal? ProfitVariation
        {
            get
            {
                return (SuggestedPrice_Demand * (SuggestedPrice - Cost)) - (MeanQuantity * (MeanPrice - Cost));
            }
        }

        /// <summary>
        /// Variação de vendas calculada
        /// </summary>
        public decimal? SalesVariation
        {
            get
            {
                return (SuggestedPrice * SuggestedPrice_Demand) - (MeanPrice * MeanQuantity);
            }
        }

        /// <summary>
        /// Margem IA calculada
        /// </summary>
        public decimal? MarginIA
        {
            get
            {
                return ((SuggestedPrice / Cost) - 1) * 100;
            }
        }
        /// <summary>
        /// Ultima margem calculada
        /// </summary>
        public decimal? LastMargin
        {
            get
            {
                return ((LastSalePrice / Cost) - 1) * 100;
            }
        }

        public string GetProjectionName(EnterprisePricesProjectionDefaultFilterType dbField)
        {
            switch (dbField)
            {
                case EnterprisePricesProjectionDefaultFilterType.AffiliateName:
                    return AffiliateName;
                case EnterprisePricesProjectionDefaultFilterType.Store:
                    return Store;
                case EnterprisePricesProjectionDefaultFilterType.Customer:
                    return Customer;
                case EnterprisePricesProjectionDefaultFilterType.SupplierName:
                    return SupplierName;
                case EnterprisePricesProjectionDefaultFilterType.ProductName:
                    return ProductName;
                case EnterprisePricesProjectionDefaultFilterType.EconomicGroup:
                    return EconomicGroup;
                case EnterprisePricesProjectionDefaultFilterType.NameSegment:
                    return NameSegment;
                case EnterprisePricesProjectionDefaultFilterType.Segment2:
                    return Segment2;
                case EnterprisePricesProjectionDefaultFilterType.Product_Group:
                    return ProductGroup;
                case EnterprisePricesProjectionDefaultFilterType.StatusProduct:
                    return StatusProduct;
                case EnterprisePricesProjectionDefaultFilterType.Product:
                    return Product;
                case EnterprisePricesProjectionDefaultFilterType.Affiliate:
                    return Affiliate;
                case EnterprisePricesProjectionDefaultFilterType.CustomerName:
                    return CustomerName;
                case EnterprisePricesProjectionDefaultFilterType.Document:
                    return Document;
                case EnterprisePricesProjectionDefaultFilterType.CodSegment:
                    return CodSegment;
                case EnterprisePricesProjectionDefaultFilterType.EconomicGroupCode:
                    return EconomicGroupCode;
                case EnterprisePricesProjectionDefaultFilterType.InvoceNumber:
                    return InvoceNumber;
                case EnterprisePricesProjectionDefaultFilterType.SupplierCode:
                    return SupplierCode;
                case EnterprisePricesProjectionDefaultFilterType.PackageDescription:
                    return PackageDescription;
                case EnterprisePricesProjectionDefaultFilterType.PackageUnity:
                    return PackageUnity;
                case EnterprisePricesProjectionDefaultFilterType.TypeOfShipping:
                    return TypeOfShipping;
                case EnterprisePricesProjectionDefaultFilterType.ClientCountry:
                    return ClientCountry;
                case EnterprisePricesProjectionDefaultFilterType.ClientState:
                    return ClientState;
                case EnterprisePricesProjectionDefaultFilterType.TypeOfStore:
                    return TypeOfStore;
                case EnterprisePricesProjectionDefaultFilterType.ClientType:
                    return ClientType;
                case EnterprisePricesProjectionDefaultFilterType.AffiliateCountry:
                    return AffiliateCountry;
                case EnterprisePricesProjectionDefaultFilterType.AffiliateState:
                    return AffiliateState;
                case EnterprisePricesProjectionDefaultFilterType.AffiliateCity:
                    return AffiliateCity;
                case EnterprisePricesProjectionDefaultFilterType.DistributionCenter:
                    return DistributionCenter;
                case EnterprisePricesProjectionDefaultFilterType.Category1:
                    return Category1;
                case EnterprisePricesProjectionDefaultFilterType.Category2:
                    return Category2;
                case EnterprisePricesProjectionDefaultFilterType.Category3:
                    return Category3;
                case EnterprisePricesProjectionDefaultFilterType.Category4:
                    return Category4;
                case EnterprisePricesProjectionDefaultFilterType.Category5:
                    return Category5;
                case EnterprisePricesProjectionDefaultFilterType.SalePrice_Demand_CurveABC:
                    return SalePrice_Demand_CurveABC;
                case EnterprisePricesProjectionDefaultFilterType.Category1Id:
                    return Category1Id;
                case EnterprisePricesProjectionDefaultFilterType.Category2Id:
                    return Category2Id;
                case EnterprisePricesProjectionDefaultFilterType.Category3Id:
                    return Category3Id;
                case EnterprisePricesProjectionDefaultFilterType.Category4Id:
                    return Category4Id;
                case EnterprisePricesProjectionDefaultFilterType.Category5Id:
                    return Category5Id;
                default:
                    return String.Empty;
            }
        }
    }

    /// <summary>
    /// Response de Value Overrides (Preço sobrescrito)
    /// </summary>
    public class EnterprisePricesProjectionOverrideExportResponse
    {
        /// <summary>
        /// Identificador de Values Overrides.
        /// </summary>
        public virtual long IdEnterpriseValuesOverrides { get; set; }

        /// <summary>
        /// Referência da projeção.
        /// </summary>
        public string ProjectionsReference { get; set; }

        /// <summary>
        /// Preço a ser utilizado.
        /// </summary>
        public decimal? Price { get; set; }

        /// <summary>
        /// Margin do Preço a ser utilizado.
        /// </summary>
        public decimal? Price_Margin { get; set; }

        /// <summary>
        /// Preço Manual a ser utilizado para ser utilizado.
        /// </summary>
        public decimal? Manual_Price { get; set; }

        /// <summary>
        /// Margin do Preço Manual a ser utilizado.
        /// </summary>
        public decimal? Manual_Price_Margin { get; set; }

        /// <summary>
        /// se o preço foi alterado manualmente
        /// </summary>
        public bool IsManual { get; set; }

        /// <summary>
        /// Indica se o preço está bloqueado
        /// </summary>
        public bool? IsBlocked { get; set; }

        /// <summary>
        /// Indica se o preço de ia 
        /// </summary>
        public bool? IsAIPrice { get; set; }

        /// <summary>
        /// Margin do Preço a ser utilizado.
        /// </summary>
        public decimal? Price_Demand { get; set; }


        /// <summary>
        /// Percentual de Desconto Calculado em cima do Preço Otimizado.
        /// </summary>
        public decimal? Price_IdealDiscount { get; set; }

        /// <summary>
        /// Margin do Preço Manual a ser utilizado.
        /// </summary>
        public decimal? Manual_Price_Demand { get; set; }

        /// <summary>
        /// Percentual de Desconto Calculado em cima do Preço Otimizado Manual.
        /// </summary>
        public decimal? Manual_Price_IdealDiscount { get; set; }

        /// <summary>
        /// Retorna qual cor do semaforo
        /// </summary>
        public EnterprisePriceProjectionSemaphoreType Semaphore { get; set; }
    }
}
