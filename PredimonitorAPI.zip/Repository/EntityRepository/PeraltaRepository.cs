﻿using Repository.DbContexts;
using Repository.Entity;
using Repository.EntityRepository.Bases;

namespace Repository.EntityRepository
{
    public class PeraltaRepository : GenericMongoRepository<PeraltaEntity>, IPeraltaRepository
    {
        public PeraltaRepository(NielsenDbContext dbContext) : base(dbContext)
        {
        }

        public static string DbContextName => nameof(NielsenDbContext);
    }

}
