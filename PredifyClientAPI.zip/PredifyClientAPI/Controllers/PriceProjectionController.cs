﻿using Asp.Versioning;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PredifyClientAPI.Services.PredifyAPI;
using PredifyClientAPI.Services.PredifyAPI.Models;
using PredifyClientAPI.Services.PredifyAPI.PriceProjection.Models;

namespace PredifyClientAPI.Controllers
{
    [ApiController]
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiVersion("1.0")]
    [Authorize]
    public class PriceProjectionController : ControllerBase
    {
        private readonly ILogger<PriceProjectionController> _logger;
        private readonly PredifyAPIUserManager _predifyAPIUserManager;

        public PriceProjectionController(ILogger<PriceProjectionController> logger, PredifyAPIUserManager predifyAPIUserManager)
        {
            _logger = logger;
            _predifyAPIUserManager = predifyAPIUserManager;
        }

        [HttpGet("ProjectionToSendERP")]
        [MapToApiVersion("1.0")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(GeneralResponse<List<EnterprisePriceProjectionExportResponse>>))]
        [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status401Unauthorized, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
        public async Task<IActionResult> List(long idEnterprisePriceGroup)
        {
            try
            {
                var response = await _predifyAPIUserManager.PriceProjectionService.ProjectionToSendERP(idEnterprisePriceGroup);

                return Ok(response);
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized(ex.Message);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
