﻿using Microsoft.Extensions.Caching.Memory;
using PH.Domain.Interfaces.Services;

namespace PH.CrossCutting.Services
{
    public class CacheControlService : ICacheControlService
    {
        private readonly IMemoryCache _memoryCache;

        public CacheControlService(IMemoryCache memoryCache)
        {
            _memoryCache = memoryCache;
        }

        public void SettingTimeAndCache(object cacheObject, string cacheKey, int timeToLive = 1)
        {
            var cacheEntryOptions = new MemoryCacheEntryOptions()
                               .SetAbsoluteExpiration(TimeSpan.FromHours(timeToLive));

            _memoryCache.Set(cacheKey, cacheObject, cacheEntryOptions);
        }
    }
}