﻿namespace DI.Repository.Entities
{
    public class GrupoRecursoEntity : BaseEntity
    {
        public long IdGrupoRecurso { get; set; }
        public long IdEmpresa { get; set; }
        public string? Nome { get; set; }
        public string? Descricao { get; set; }
        public long? IdGrupoRecursoPai { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime DataHoraCriacao { get; set; }
        public DateTime DataHoraUltimaAlteracao { get; set; }
        public ICollection<UsuarioGrupoRecursoEntity>? UsuarioGrupoRecursos { get; set; }
    }
}
