from concurrent.futures import process
import threading
import time
from datetime import datetime
from norm.memorycache import MemoryCache
from norm.processing import Processing
from norm.extraction import Extraction
from norm.validate_products import ValidateProducts
from norm.conect_mongo import MongoConnect
from norm.NormalizerExtraction import NormalizerExtraction
from norm.log_normalizador import LogNormalizador


class Renormalization(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)
        self.prep = Processing()
        self.Validate_P = ValidateProducts()
        self.memory = MemoryCache()
        self.dbMongo = MongoConnect()
        self.norm_extraction = NormalizerExtraction()
        self.log_norm = LogNormalizador()
        self._event = threading.Event()

        self.status_renorm = True
        self.status_real_renorm = True
        self.comleted_renorm = False

    def set_status(self, status_renorm):
        self.status_renorm = status_renorm
        # self.comleted_renorm = False
        # self.status_real_renorm = True
        # print("status_renorm set: ", self.status_renorm)
        # return True

    def pause(self):
        self.status_real_renorm = True
        self.status_renorm = True
        print("renormalization pausada --- ",
              datetime.now().strftime('%d-%m-%Y %H:%M:%S.%f'))
        self._event.clear()
        self._event.wait()

    def resume(self, renormalization):
        self.start_date = renormalization.start_date
        self.end_date = renormalization.end_date
        self.idcrawlers = renormalization.idcrawlers
        self.status_renormalization = renormalization.status_renormalization

        self.status_renorm = False
        self.status_real_renorm = False
        print("renormalization executando --- ",
              datetime.now().strftime('%d-%m-%Y %H:%M:%S.%f'))
        self._event.set()

    def run(self):

        ean = ''
        ncm = ''
        product_model = ''
        shipping = ''
        stock_quantity = ''
        product_link = ''
        site_sku = ''

        while True:

            print("Renormalizador reiniciada")
            if self.status_renorm == True:
                # print("Renormalizador Pausado")
                # self.comleted_renorm = True
                self.pause()

            print('start_date ', self.start_date, 'end_date ', self.end_date,
                  'idcrawlers ', self.idcrawlers, 'status_renormalization ', self.status_renormalization)

            for crawler in self.idcrawlers:

                # if crawler == 0:
                #     print("renormalizador concluida ---------------------")
                #     time.sleep(5)
                #     self.comleted_renorm = True
                #     self.pause()
                #     break
                if self.status_renorm == True:
                    # print("Renormalizador em pausa")
                    # self.comleted_renorm = True
                    self.pause()

                print("---------------------------------- crawler : ", crawler)

                data = self.dbMongo.get_products_Renormalization(
                    crawler, self.start_date, self.end_date)

                results = list(data)
                tamanho = len(results)

                product_concat = ''
                for i in results:
                    product_concat = i["product_name"]
                    if "product_category_name" in i:
                        category_name = self.norm_extraction.normalizer_extraction_category_dafiti(
                            i["product_category_name"])
                    if (category_name != None):
                        if str(category_name).lower() not in str(i["product_name"]).lower():

                            product_concat = product_concat + " - " + category_name

                            self.dbMongo.update_renormalizer_product_name(
                                i['_id'], product_concat, "product_name")

                    product = self.norm_extraction.normalizer_extraction(
                        product_concat, i["language"])

                    self.dbMongo.update_renormalizer_product_name(
                        i['_id'], product['trash'], "trash")
                    product_concat = ''

            print("len results: ", tamanho)
            print("renormalizador concluida ---------------------")
            time.sleep(5)
            self.comleted_renorm = True
            self.pause()

            #     # variavaies
            # ListNorm = None
            # product = None
            # produto_valido = None
            # insert = None
            # # print("----------------------------------")
            # # print("Produto: ", i['_id'])
            # # process_product = self.norm_extraction.normalize_preprocessing(
            # #     i["product_name"])
            # product = self.norm_extraction.normalizer_extraction(
            #     i["product_name"])

            # # print("products  : ", product)

            # produto_valido, log = self.Validate_P.validate_products(
            #     product)
            # # print("valido : ", produto_valido)

            # #########################################################################
            # if "product_ean" in i:
            #     ean = i["product_ean"]
            # if "product_ncm" in i:
            #     ncm = i["product_ncm"]
            # if "product_model" in i:
            #     product_model = i["product_model"]
            # if "shipping" in i:
            #     shipping = i["shipping"]
            # # if "stock_quantity" in i:
            # #    stock_quantity = i["stock_quantity"]
            # if "product_link" in i:
            #     # print("------- ", i["product_link"])
            #     product_link = i["product_link"]
            # if "site_sku" in i:
            #     # print("------- ", i["site_sku"])
            #     site_sku = i["site_sku"]

            #     ########################################################################

            #     ########################################################################

            #     # Verifica de produto esta na lista de produtos normalizados

            #     if produto_valido == True:

            #         product.update({"model": product_model, "ean": ean,
            #                         "ncm": ncm, "idcrawlers": i["id_crawler"]})

            #         # print("product: ", product)

            #         ListNorm = self.Validate_P.checks_products_register(
            #             self.memory.products_normalized, product)
            #         # print("ListNorm: ", ListNorm)
            #     ################################################################################

            # #   Produto é valido e não esta na lista de produtos normalizados
            # # - Salvar no mongo e na lista de produtos normalizados

            #     # print("Registrado 1 ---- ", len(self.memory.products_normalized))
            #     if (produto_valido == True and ListNorm == None):

            #         # print(i["_id"], product, brands, categories, materials, voltage, metric_units, power, leftover,

            #         #      product_model, ean, ncm, i["id_crawler"])
            #         ListNorm, insert = self.dbMongo.register_renorm(
            #             product)

            #         ListNorm = ListNorm.inserted_id

            #         # print("ListNorm: ", ListNorm, "insert: ", insert)

            #         # atualizar lista de produtos normalizados em memoria
            #         # print("insert ", insert)
            #         if(insert != None):
            #             # print(insert)
            #             self.memory.update_products_nomal(insert)
            #             # print("Registrado 2 ---- ",
            #             #       len(self.memory.products_normalized))
            #     ################################################################################

            #     if produto_valido == True and ListNorm != None:

            #         ListNorm = str(ListNorm)

            #         # print(" id_produto: ", i["_id"])

            #         if ListNorm != i["id_product_normalized"]:

            #             id_price = self.dbMongo.update_renorm_price(
            #                 ListNorm, i['_id'])

            #             self.log_norm.log_normalization(
            #                 id_price, ListNorm, product["product"], 1)

            #             # print("atualizar id produto normalizado ----- ")

            #     if produto_valido == False:

            #         self.dbMongo.insert_failed_to_normalize(i, log)
