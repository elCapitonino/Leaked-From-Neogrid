﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Repository.Attributes;
using Repository.DbContexts;
using Repository.Entity;

namespace Repository.TypeConfiguration
{
    [DbContextTypeConfiguration(typeof(ApplicationDbContext))]
    public class Monitoring_ProductMarketResultItemTypeconfiguration : TypeConfigurationBase<MonitoringProductMarketResultItemEntity>, IEntityTypeConfiguration<MonitoringProductMarketResultItemEntity>
    {
        public override void Configure(EntityTypeBuilder<MonitoringProductMarketResultItemEntity> builder)
        {
            ConfigureTableName(builder, "Monitoring_ProductMarketResultItem");

            builder.Property(p => p.Id).HasColumnName("IdMonitoring_ProductMarketResultItem");
            builder.Property(p => p.MonitoringProductMarketResultId).HasColumnName("IdMonitoring_ProductMarketResult").IsRequired();
            builder.Property(p => p.CrawlerId).HasColumnName("IdCrawler");
            builder.Property(p => p.MonitoringItemProductManualResultId).HasColumnName("IdMonitoringItemProductManualResult");
            builder.Property(p => p.ProductName).HasMaxLength(800);
            builder.Property(p => p.CrawlerName).HasMaxLength(64);
            builder.Property(p => p.SellerName).HasMaxLength(256);
            builder.Property(p => p.SellerLink).HasMaxLength(256);
            builder.Property(p => p.Brand).HasMaxLength(128);
            builder.Property(p => p.LocalCity).HasMaxLength(256);
            builder.Property(p => p.LocalState).HasMaxLength(256);
            builder.Property(p => p.ZipCode).HasMaxLength(32);
            builder.HasOne(p => p.MonitoringProductMarketResult).WithMany(b => b.MonitoringProductMarketResultItem).HasForeignKey(p => p.MonitoringProductMarketResultId);
        }
    }
}
