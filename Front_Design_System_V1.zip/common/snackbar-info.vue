<template>
  <div class="text-center ma-2">
    <v-snackbar
      :timeout="5000"
      :color="setColor"
      outlined
      v-model="snackbar"
    >
      {{ text }}
    </v-snackbar>
  </div>
</template>

<script>
export default {
  props: {
    text: {
      required: true,
      type: String,
    },
  },
  data() {
    return {
      snackbar: true,
    };
  },

  computed:{
    setColor(){
        return 'success'
    }
  }
};
</script>

<style lang="scss" scoped>
</style>