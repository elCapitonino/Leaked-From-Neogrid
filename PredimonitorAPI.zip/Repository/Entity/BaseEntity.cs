﻿namespace Repository.Entity
{
    public interface IEntityBase<TType>
    {
        TType Id { get; }
    }
    public interface IEntity:IEntityBase<long>
    {
        long Id { get; }
    }
    public abstract class BaseEntity<TPkType> : IEntityBase<TPkType>
    {
        public TPkType Id { get; set; }
        public DateTime? CreateDate { get; set; }
        public DateTime? UpdateDate { get; set; }
    }

    public abstract class BaseEntity : BaseEntity<long>
    {

    }

    public abstract class BaseNoKeyEntity : BaseEntity
    {
        public new Guid Id
        {
            get => throw new Exception($"The property {nameof(Id)} can not be set for Type {nameof(BaseNoKeyEntity)}");
            set => throw new Exception($"The property {nameof(Id)} can not be set for Type {nameof(BaseNoKeyEntity)}");
        }
    }

}
