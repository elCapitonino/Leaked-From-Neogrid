using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using MongoDB.Bson;
using MongoDB.EntityFrameworkCore.Extensions;
using Repository.Attributes;
using Repository.DbContexts;
using Repository.Entity;
using System;

namespace Repository.TypeConfiguration
{
    [DbContextTypeConfiguration(typeof(HorusDbContext))]
    public class HorusProductsTypeConfiguration : TypeConfigurationBase<HorusProductsEntity>, IEntityTypeConfiguration<HorusProductsEntity>
    {
        public override void Configure(EntityTypeBuilder<HorusProductsEntity> builder)
        {
            builder.ToTable("products").ToCollection("products");
        }
    }
   
}
