﻿using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Entity
{
    public class ScantechSupermaxiEntity : BaseMongoEntity
    {
        [BsonElement("data")]
        public DateTime? DataPreco { get; set; }

        [BsonElement("codigo_barras_sku")]
        public string? EAN { get; set; } 

        [BsonElement("nome_sku")]
        public string? Nome { get; set; }

        [BsonElement("fabricante_sku")]
        public string? Fabricante { get; set; }

        [BsonElement("marca_sku")]
        public string? Marca { get; set; }

        [BsonElement("cesta")]
        public string? Cesta { get; set; }

        [BsonElement("categoria_sku")]
        public string? Categoria { get; set; }

        [BsonElement("sub_categoria")]
        public string? SubCategoria { get; set; }

        [BsonElement("preco_min_grupo")]
        public decimal? PrecoMinGrupo { get; set; }

        [BsonElement("preco_medio_grupo")]
        public decimal? PrecoMedioGrupo { get; set; }

        [BsonElement("preco_moda_grupo")]
        public decimal? PrecoModaGrupo { get; set; }

        [BsonElement("preco_max_grupo")]
        public decimal? PrecoMaxGrupo { get; set; }

        [BsonElement("preco_min_mercado")]
        public decimal? PrecoMinMercado { get; set; }

        [BsonElement("preco_medio_mercado")]
        public double? PrecoMedioMercado { get; set; }

        [BsonElement("preco_moda_mercado")]
        public decimal? PrecoModaMercado { get; set; }

        [BsonElement("preco_max_mercado")]
        public decimal? PrecoMaxMercado { get; set; }

        [BsonElement("giro_unitario_por_loja_mercado")]
        public decimal? GiroUnitarioPorLojaMercado { get; set; }

        [BsonElement("pdvs_mercado")]
        public string? PDVsMercado { get; set; }

        [BsonElement("created_date")]
        public DateTime? CreatedDate { get; set; }

        [BsonElement("hash")]
        public string? Hash { get; set; }

        [BsonElement("cidade")]
        public string? Cidade { get; set; }

        [BsonElement("estado")]
        public string? Estado { get; set; }

        [BsonElement("coordinates")]
        public GeoJson2DGeographicCoordinatesWrapper? Coordinates { get; set; }
    }
}