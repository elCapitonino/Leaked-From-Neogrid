<template>
  <!--desktop sidebar-->
  <v-navigation-drawer
    v-if="$vuetify.breakpoint.smAndUp"
    style="min-width: 88px"
    v-model="drawer"
    :mini-variant.sync="mini"
    expand-on-hover
    permanent
    app
    id="sidebar"
    color="var(--dark-moderate-blue)"
  >
    <v-list-item class="pa-0 mt-0" style="height: 88px">
      <v-list-item class="pa-1" style="max-width: 88px">
        <v-img
          class="my-0 mx-auto"
          style="max-width: 46px"
          src="../../assets/seta-logo.png"
        ></v-img>
      </v-list-item>
      <v-list-item class="pa-0">
        <v-img
          style="max-width: 126px"
          src="../../assets/name-logo.png"
        ></v-img>
      </v-list-item>
    </v-list-item>
    <v-list dense>
      <v-list-item
        class="ma-1"
        v-for="item in items"
        :key="item.title"
        link
        :to="item.linkTo"
        :style="{ color: 'var(--white)' }"
      >
        <v-list-item-icon center class="my-0 mx-auto pl-2 pr-3 py-3">
          <font-awesome-icon
            :icon="item.icon"
            :style="{ color: 'var(--white)' }"
          />
        </v-list-item-icon>
        <v-list-item-content>
          <v-list-item-title>{{ item.title }}</v-list-item-title>
        </v-list-item-content>
      </v-list-item>
    </v-list>
  </v-navigation-drawer>

  <!--mobile sidebar-->
  <v-navigation-drawer
    v-model="mobile"
    v-else-if="$vuetify.breakpoint.smAndDown"
    style="min-width: 86vw"
    temporary
    absolute
    app
    color="var(--dark-moderate-blue)"
  >
    <v-list-item class="pa-0 mt-0" style="height: 88px">
      <v-list-item class="pa-1" style="max-width: 88px">
        <v-img
          class="my-0 mx-auto"
          style="max-width: 46px"
          src="../../assets/logo_predify_icon.png"
        ></v-img>
      </v-list-item>
      <v-list-item class="pa-0">
        <v-img
          style="max-width: 126px"
          src="../../assets/name-logo.png"
        ></v-img>
      </v-list-item>
      <v-btn icon>
        <v-icon :color="'var(--white)'" @click="hideMenu()"
          >mdi-chevron-left</v-icon
        >
      </v-btn>
    </v-list-item>
    <v-list dense>
      <v-list-item
        class="ma-1"
        v-for="item in items"
        :key="item.title"
        link
        :to="item.linkTo"
        :style="{ color: 'var(--white)' }"
      >
        <v-list-item-icon center class="my-0 mx-auto pl-2 pr-3 py-3">
          <font-awesome-icon
            :icon="item.icon"
            :style="{ color: 'var(--white)' }"
          />
        </v-list-item-icon>
        <v-list-item-content>
          <v-list-item-title>{{ item.title }}</v-list-item-title>
        </v-list-item-content>
      </v-list-item>
    </v-list>
  </v-navigation-drawer>
</template>

<script>
export default {
  name: "appBarComponent",
  props: {
    drawerMobile: Boolean,
  },
  data: () => ({
    items: [
      { title: "Home", icon: "fa-solid fa-home", linkTo: "/main/home" },
      
      {
        title: "Dashboard",
        icon: "fa-solid fa-table-columns",
        linkTo: "/main/#",
      },
      {
        title: "Configurações da empresa",
        icon: "fa-solid fa-gear",
        linkTo: "/main/company-config",
      },
      {
        title: "Configuração do Enterprise",
        icon: "fa-solid fa-gear",
        linkTo: "/main/config-dashboard",
      },
     
      { title: "Usuários", icon: "fa-solid fa-circle-user", linkTo: "/main/#" },
    
     
      
    ],
    mini: true,
    drawer: true,
    mobile: false,
  }),
  watch: {
    drawerMobile(newvalue) {
      this.mobile = newvalue;
    },
  },
  methods: {
    hideMenu() {
      this.$emit("showOrHideMenu");
    },
  },
};
</script>

<style scoped lang="scss">
#sidebar ::-webkit-scrollbar {
  width: 0 !important;
}
</style>
