﻿namespace DI.Domain.ImpactGraph.Models
{
    public class GraphDataModel
    {
        public GraphDataModel()
        {
            Data = [];
        }
        public List<decimal?> Data { get; set; }
    }
}
