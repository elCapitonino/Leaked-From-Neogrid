﻿using Repository.Enums;

namespace Repository.Entity
{
    public class MonitoringCrawlerEntity : BaseEntity<int>
    {
        public string Description { get; set; }

        public bool IsOffline { get; set; } = false;

        public CrawlerSourceType Source { get; set; }

        public CrawlersTypes? CrawlerType { get; set; }

        public string? Language { get; set; }

        public long? CountryId { get; set; }

        public bool IsDeleted { get; set; }

        public ICollection<CompanyMonitoringCrawlerEntity>? CompanyMonitorings { get; set; }
    }
}
