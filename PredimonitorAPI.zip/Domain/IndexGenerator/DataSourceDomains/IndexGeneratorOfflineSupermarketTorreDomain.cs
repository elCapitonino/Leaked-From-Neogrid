using AutoMapper;
using Domain.IndexGenerator.DataSourceDomains.Interfaces;
using Domain.IndexGenerator.Models;
using Domain.Status;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using MongoDB.Bson;
using MongoDB.Driver;
using Repository.Entity;
using Repository.Enums;
using Repository.UnitOfWork;
using System.Diagnostics;

namespace Domain.IndexGenerator.DataSourceDomains
{
    public class IndexGeneratorOfflineSupermarketTorreDomain : IndexGeneratorBase, IIndexGeneratorOfflineSupermarketTorreDomain
    {
        private readonly ILogger<IndexGeneratorOfflineSupermarketTorreDomain> _logger;
        private readonly IUnitOfWork _uow;
        private readonly IMapper _mapper;
        private readonly IStatusDomain _statusDomain;

        public IndexGeneratorOfflineSupermarketTorreDomain(ILogger<IndexGeneratorOfflineSupermarketTorreDomain> logger, IUnitOfWork uow, IMapper mapper, IStatusDomain statusDomain)
            : base(statusDomain)
        {
            _logger = logger;
            _uow = uow;
            _mapper = mapper;
            _statusDomain = statusDomain;
        }

        public async Task GenerateIndexAsync(long companyId, int crawlerId, IEnumerable<MonitoringItemTags> monitoringItems, DateTime startDate, DateTime endDate,
            Guid? taskId, List<long> monitoringResultIdsDelete)
        {
            try
            {
                _logger.LogInformation("Iniciando Geração de index da OfflineSupermarketTorre");
                var total = monitoringItems.Count();
                var count = 0;
                UpdateStatus(taskId, CrawlerSourceType.OfflineSupermarketTorre, MonitoringItemResultsStatusType.Running, total, count);
                Stopwatch totalStopwatch = new Stopwatch();
                totalStopwatch.Start();
                _logger.LogInformation("OfflineSupermarketTorre - Total de monitoring items para serem processados: {total}", total);
                List<ObjectId> listUpdateHash = new List<ObjectId>();
                EnsureAllMonitoringItemId(monitoringItems);
                foreach (var monitoringItem in monitoringItems)
                {
                    try
                    {
                        if (!monitoringItem.Eans.Any())
                            continue;

                        var query = _uow.OfflineSupermarketTorres.GetAll()
                        .Where(x => x.Date >= startDate && x.Date <= endDate && monitoringItem.Eans.Contains(x.EAN));

                        var products = await query
                            .Select(x => new
                            {
                                x.Id,
                                x.EAN,
                                x.Hash,
                                Seller = x.SellerName,
                                UF = x.State,
                            }).ToListAsync();

                        listUpdateHash.AddRange(products.Where(x => string.IsNullOrEmpty(x.Hash)).Select(x => x.Id));

                        var entities = products.GroupBy(x => $"{GetOrGenerateHash(x.Hash, $"{x.EAN}|{x.Seller}")}")
                            .Select(x => x.First())
                            .Select(x => new MonitoringItemResultsEntity()
                            {
                                Brand = null,
                                Category = null,
                                Hash = GetOrGenerateHash(x.Hash, $"{x.EAN}|{x.Seller}"),
                                CompanyId = companyId,
                                CrawlerId = crawlerId,
                                MonitoringItemId = monitoringItem.MonitoringItemId,
                                Seller = x.Seller,
                                State = x.UF,
                            }).ToList();

                        _uow.MonitoringItemResults.AddRange(entities, true);
                        count++;
                        UpdateStatus(taskId, CrawlerSourceType.OfflineSupermarketTorre, MonitoringItemResultsStatusType.Running, monitoringItems.Count(), count);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, $"Error Search Monitoring Item {monitoringItem.MonitoringItemId} OfflineSupermarketTorre");
                        UpdateStatus(taskId, CrawlerSourceType.OfflineSupermarketTorre, MonitoringItemResultsStatusType.Error, monitoringItems.Count(), count);
                    }
                }
                if (monitoringResultIdsDelete != null && monitoringResultIdsDelete.Any())
                {
                    _uow.MonitoringItemResults.DeleteAll(monitoringResultIdsDelete);
                }

                if (listUpdateHash.Any())
                {
                    var productsToUpdate = _uow.HorusProducts
                              .GetAll()
                              .Where(x => listUpdateHash.Contains(x.Id))
                              .ToList();

                    foreach (var product in productsToUpdate)
                    {
                        product.Hash = CalculateSHA256($"{product.Ean}|{product.Cnpj}");
                    }

                    _uow.HorusProducts.Update(productsToUpdate, true);
                }

                totalStopwatch.Stop();
                _logger.LogInformation($"Finalizado Geração de index da OfflineSupermarketTorre - {totalStopwatch.Elapsed.TotalSeconds}s");
                UpdateStatus(taskId, CrawlerSourceType.OfflineSupermarketTorre, MonitoringItemResultsStatusType.Finished, total, count);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error {MethodName}", nameof(GenerateIndexAsync));
                throw;
            }
        }
    }
}
