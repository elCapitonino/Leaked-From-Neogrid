import os
import pickle

from dotenv import load_dotenv
from sqlalchemy import URL, Connection, Engine, MetaData, Table, create_engine

from src.logger import logger

# habilita configuração local
load_dotenv(dotenv_path=".env", override=True)
load_dotenv(dotenv_path=".env.local", override=True)

PostgreSQLConnection = Connection
SQLServerConnection = Connection

PostgreSQLEngine = Engine
SQLServerEngine = Engine


def _pickle_metadata(metadata: MetaData, database: str):
    os.makedirs("./cache", exist_ok=True)
    fname = f"./cache/{database}_metadata.pkl"
    logger.warning("saving %s metadata to %s", database, fname)
    with open(fname, "wb") as f:
        pickle.dump(metadata, f)


def _unpickle_metadata(database: str):
    try:
        fname = f"./cache/{database}_metadata.pkl"
        with open(fname, "rb") as f:
            metadata = pickle.load(f)
            logger.warning("loading %s metadata from %s", database, fname)
            return metadata
    except Exception:
        pass
    return None


def _preload_postgresql_tables(engine: PostgreSQLEngine, metadata: MetaData):
    _ = Table("ImpactReportConfiguration", metadata, autoload_with=engine)
    _ = Table("MonthlySaleHistoryImportStatus", metadata, autoload_with=engine)
    _ = Table("MonthlySaleHistoryData", metadata, autoload_with=engine)
    _ = Table("GranularityGroup", metadata, autoload_with=engine)
    _ = Table("GranularityLevel", metadata, autoload_with=engine)


def _preload_sql_server_tables(engine: SQLServerEngine, metadata: MetaData):
    _ = Table("Enterprise_Company", metadata, autoload_with=engine)
    _ = Table("Enterprise_Sales_History", metadata, autoload_with=engine)


def create_postgresql_engine() -> tuple[PostgreSQLEngine, MetaData]:
    postgresql_url = URL.create(
        "postgresql+psycopg",
        username=os.getenv("POSTGRESQL_USERNAME"),
        password=os.getenv("POSTGRESQL_PASSWORD"),
        database=os.getenv("POSTGRESQL_DATABASE"),
        host=os.getenv("POSTGRESQL_NET_ADDRESS"),
        port=5432,
    )

    logger.debug(
        "creating PostgreSQL engine on address %s", os.getenv("POSTGRESQL_NET_ADDRESS")
    )
    pg_engine = create_engine(
        postgresql_url,
        connect_args={
            "connect_timeout": 15,
        },
        pool_pre_ping=True,
    )
    pg_metadata_obj = MetaData()

    if os.getenv("DEBUG"):
        logger.warning("!!! USING LOCAL CACHE OF POSTGRESQL METADATA")
        logger.warning("!!! DELETE THE FILE IF THERE ARE SCHEMA CHANGES")
        cached_metadata = _unpickle_metadata("postgresql")
        if cached_metadata is not None:
            pg_metadata_obj = cached_metadata

    _preload_postgresql_tables(pg_engine, pg_metadata_obj)

    if os.getenv("DEBUG"):
        _pickle_metadata(pg_metadata_obj, "postgresql")

    return pg_engine, pg_metadata_obj


def create_sql_server_engine() -> tuple[SQLServerEngine, MetaData]:
    sql_server_url = URL.create(
        "mssql+pyodbc",
        username=os.getenv("SQL_SERVER_UID"),
        password=os.getenv("SQL_SERVER_PASSWORD"),
        database=os.getenv("SQL_SERVER_DATABASE"),
        host=os.getenv("SQL_SERVER_NET_ADDRESS"),
        port=1433,
        query={
            "driver": "ODBC Driver 17 for SQL Server",
            "TrustServerCertificate": "yes",
        },
    )

    logger.debug(
        "creating SQL Server engine on address %s", os.getenv("SQL_SERVER_NET_ADDRESS")
    )
    sql_server_engine = create_engine(
        sql_server_url, connect_args={"timeout": 15}, pool_pre_ping=True
    )
    sql_server_metadata_obj = MetaData()

    if os.getenv("DEBUG"):
        logger.warning("!!! USING LOCAL CACHE OF SQL SERVER METADATA")
        logger.warning("!!! DELETE THE FILE IF THERE ARE SCHEMA CHANGES")
        cached_metadata = _unpickle_metadata("mssql")
        if cached_metadata is not None:
            sql_server_metadata_obj = cached_metadata

    _preload_sql_server_tables(sql_server_engine, sql_server_metadata_obj)

    if os.getenv("DEBUG"):
        _pickle_metadata(sql_server_metadata_obj, "mssql")

    return sql_server_engine, sql_server_metadata_obj
