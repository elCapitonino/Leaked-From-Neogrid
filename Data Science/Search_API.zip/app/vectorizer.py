"""
Vetorizadores textuais com a mesma interface do BM25Okapi.
"""

from typing import List
from abc import ABC, abstractmethod

from rank_bm25 import BM25Okapi
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from logger import logger


class Vectorizer(ABC):
    @abstractmethod
    def __init__(self, corpus: List[str]):
        pass

    @abstractmethod
    def get_scores(self, doc: str) -> float:
        pass


class BM25(Vectorizer):
    """
    Vetorizador e score: BM25
    """

    def __init__(self, corpus: List[str]):
        logger.debug("vectorizer: BM25 with %d documents", len(corpus))
        split_corpus = [x.lower().split() for x in corpus]
        self.vec = BM25Okapi(split_corpus)

    def get_scores(self, doc: str) -> float:
        return self.vec.get_scores(doc.lower().split())


class SimpleVectorizer(Vectorizer):
    """
    Vetorizador: contagem de palavras
    Score: similaridade de coseno

    Diferença em relação ao BM25: o score de um documento não é influenciado
    pelos outros (frequência global de palavras).
    """

    def __init__(self, corpus: List[str]):
        logger.debug("vectorizer: SimpleVectorizer with %d documents", len(corpus))
        self.vec = CountVectorizer()
        self.matrix = self.vec.fit_transform(corpus)

    def get_scores(self, doc: str) -> float:
        doc_vector = self.vec.transform([doc])
        return 100 * cosine_similarity(self.matrix, doc_vector)


class UltraSimpleVectorizer(Vectorizer):
    """
    Vetorizador: contagem de palavras
    Score: produto interno de vetores

    Diferença em relação ao BM25: o score de um documento não é influenciado
    pelos outros (frequência global de palavras) nem penalizado por palavras
    que estão em um documento mas não em outro.
    """

    def __init__(self, corpus: List[str]):
        logger.debug("vectorizer: UltraSimpleVectorizer with %d documents", len(corpus))
        self.vec = CountVectorizer()
        self.matrix = self.vec.fit_transform(corpus)

    def get_scores(self, doc: str) -> float:
        doc_vector = self.vec.transform([doc])
        return 10 * (self.matrix.multiply(doc_vector)).sum(axis=1)
