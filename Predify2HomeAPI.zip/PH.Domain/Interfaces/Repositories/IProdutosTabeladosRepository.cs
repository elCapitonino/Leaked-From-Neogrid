﻿using PH.Domain.Domain;
using PH.Domain.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PH.Domain.Interfaces.Repositories
{
    public interface IProdutosTabeladosRepository
    {
        Task InsertMany(List<ProdutosTabelados> produtosTabelados);
        Task<List<ProdutosTabelados>> GetListProdutosTabelados(long idCompany);
        Task<List<LastSales>> GetLastSales(long idCompany, string affiliate);
    }
}
