﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PH.Domain.DTO
{
    public class GraficoICDTO
    {
        public DateTime Date { get; set; }
        public decimal IC { get; set; }
    }
}
