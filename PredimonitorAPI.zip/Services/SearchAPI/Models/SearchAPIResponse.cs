﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Services.SearchAPI.Models
{
    public class SearchAPIResponse
    {
        [JsonProperty("id_monitoring_item")]
        public int MonitoringItemId { get; set; }

        [JsonProperty("product_link")]
        public string ProductLink { get; set; }

        [JsonProperty("crawler_id")]
        public int CrawlerId { get; set; }

        [JsonProperty("company_id")]
        public int CompanyId { get; set; }

        [JsonProperty("seller")]
        public string Seller { get; set; }

        [JsonProperty("category")]
        public string? Category { get; set; }

        [JsonProperty("brand")]
        public string? Brand { get; set; }

        [JsonProperty("year")]
        public string? Year { get; set; }

        [JsonProperty("product_model")]
        public string? Model { get; set; }

        [JsonProperty("region")]
        public string? Region { get; set; }
    }
}
