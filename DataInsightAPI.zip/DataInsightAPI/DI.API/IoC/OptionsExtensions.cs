﻿using DI.Domain.Models;
using DI.Service.PredifyAPI.Models;

namespace DI.API.IoC
{
    public static class OptionsExtensions
    {
        public static IServiceCollection AddCustomOptions(this IServiceCollection services, IConfiguration configuration)
        {
            services.Configure<AppsettingsOptions>(configuration);
            services.Configure<PredifyAPIOptions>(configuration.GetSection("Services").GetSection("PredifyAPI"));
            return services;
        }
    }
}
