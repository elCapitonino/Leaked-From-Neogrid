﻿using DocumentFormat.OpenXml.Drawing.Charts;
using Microsoft.AspNetCore.Mvc;
using PH.Domain.Interfaces.Services;
using PH.Service.Services;

namespace PH.API.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class GraficoICController : ControllerBase
    {
        private readonly ILogger<GraficoICController> _logger;
        private readonly IGraficoICServices _graficoICServices;

        public GraficoICController(ILogger<GraficoICController> logger,
                                 IGraficoICServices GraficoICServices)
        {
            _logger = logger;
            _graficoICServices = GraficoICServices;
        }

        [HttpGet]
        [Route("GetAllFilterCategories")]
        public async Task<IActionResult> GetAllFilterCategories()
        {
            _logger.LogInformation($"Controller: Buscando todos as categorias");

            try
            {
                var result = await _graficoICServices.GetAllFilterCategories();
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Controller: Erro ao buscar todos as categorias. {ex.Message}");
                return StatusCode(500, "Erro ao buscar todas as categorias");
            }
        }

        [HttpGet]
        [Route("GetGraficoIC")]
        public async Task<IActionResult> GetGraficoIC(string category, string compType, string? state, string period , string? coordinator)
        {
            _logger.LogInformation($"Controller: Buscando dados do grafico de IC");

            try
            {
                var result = await _graficoICServices.GetGraficoIC(category, compType, state, period, coordinator);

                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Controller: Erro ao buscar dados do grafico de IC. {ex.Message}");
                return StatusCode(500, "Erro ao buscar dados do grafico de IC");
            }
        }

        [HttpGet]
        [Route("GetStateByIdGroup")]
        public async Task<IActionResult> GetStateByIdGroup(long idPriceGroup)
        {
            _logger.LogInformation($"Controller: Buscando estado pelo id do grupo");

            try
            {
                var result = await _graficoICServices.GetStateByIdGroup(idPriceGroup);

                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Controller: Erro ao buscar estado pelo id do grupo. {ex.Message}");
                return StatusCode(500, "Erro ao buscar dados do grafico de IC");
            }
        }

        [HttpGet]
        [Route("GetMarginByIdCompany")]
        public async Task<IActionResult> GetMarginByIdCompany(long idCompany)
        {
            _logger.LogInformation($"Controller: Buscando margem da empresa");

            try
            {
                var result = await _graficoICServices.GetMarginByIdCompany(idCompany);

                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Controller: Erro ao buscar margem da empresa{idCompany}. {ex.Message}");
                return StatusCode(500, "Erro ao buscar margem");
            }
        }
    }
}
