﻿using Dapper;
using Microsoft.Extensions.Configuration;
using PH.Domain.Domain;
using PH.Domain.Interfaces.Repositories;
using System.Data;
using System.Data.SqlClient;

namespace PH.Data.Repositories
{
    public class RecipeRepository : IRecipeRepository
    {
        private string _sQLConnectionString;
        private readonly IConfiguration _configuration;

        public RecipeRepository(IConfiguration configuration)
        {
            _configuration = configuration;
            _sQLConnectionString = _configuration.GetConnectionString("SQLConnectionString");
        }

        public async Task<Recipe> Get(string? loja, string? curva, string? categoria)
        {
            Recipe recipe = new Recipe();
            recipe.TotalRecipe = new TotalRecipe()
            {
                LastWeek = 1500.00,
                WeekProjection = 1500.00,
                MonthProjection = 10500.00,
            };
            recipe.TotalMargin = new TotalMargin()
            {
                LastWeek = 1500.00,
                WeekProjection = 1500.00,
                MonthProjection = 10500.00,
            };

            return recipe;
        }

        public async Task<double> GetLastMonthSales(string? loja, string? curva, string? categoria)
        {
            double lastMonthSale = 0;

            try
            {
                IDbConnection connection = CreateSqlConnection();
                var parametros = new { FILIAL = loja };
                var result = connection.Query<double>("VEM_VENDA_ULTIMOS_30_DIAS", parametros, commandType: CommandType.StoredProcedure);

                if (result.Any())
                    lastMonthSale = result.FirstOrDefault();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return lastMonthSale;
        }

        private IDbConnection CreateSqlConnection() => new SqlConnection(_sQLConnectionString);
    }
}
