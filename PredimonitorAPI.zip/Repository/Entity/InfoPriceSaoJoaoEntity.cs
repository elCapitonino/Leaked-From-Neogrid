﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace Repository.Entity
{
    public class InfoPriceSaoJoaoEntity : BaseMongoEntity
    {

        [BsonElement("data_preco")]
        public DateTime? DataPreco { get; set; }

        [BsonElement("origem_preco")]
        public string? OrigemPreco { get; set; }

        [BsonElement("uf")]
        public string? UF { get; set; }

        [BsonElement("regiao")]
        public string? Regiao { get; set; }

        [BsonElement("cidade")]
        public string? Cidade { get; set; }

        [BsonElement("rede")]
        public string? Rede { get; set; }

        [BsonElement("tipo_loja")]
        public string? TipoLoja { get; set; }

        [BsonElement("loja")]
        public string? Loja { get; set; }

        [BsonElement("cnpj")]
        public string? CNPJ { get; set; }

        [BsonElement("cep")]
        public string? CEP { get; set; }

        [BsonElement("logradouro")]
        public string? Logradouro { get; set; }

        [BsonElement("numero_logradouro")]
        public string? NumeroLogradouro { get; set; }

        [BsonElement("complemento")]
        public string? Complemento { get; set; }

        [BsonElement("bairro")]
        public string? Bairro { get; set; }

        [BsonElement("categoria")]
        public string? Categoria { get; set; }

        [BsonElement("secao")]
        public string? Secao { get; set; }

        [BsonElement("descricao")]
        public string? Descricao { get; set; }

        [BsonElement("conteudo_qtd")]
        public double? ConteudoQtd { get; set; }

        [BsonElement("conteudo_unidade")]
        public string? ConteudoUnidade { get; set; }

        [BsonElement("conteudo_descricao")]
        public string? ConteudoDescricao { get; set; }

        [BsonElement("conteudo_qtd_padronizada")]
        public string? ConteudoQtdPadronizada { get; set; }

        [BsonElement("conteudo_unidade_padronizada")]
        public string? ConteudoUnidadePadronizada { get; set; }

        [BsonElement("gtin")]
        public string? GTIN { get; set; }

        [BsonElement("id_produto")]
        public string? IdProduto { get; set; }

        [BsonElement("id_loja")]
        public string? IdLoja { get; set; }

        [BsonElement("tipo_produto")]
        public string? TipoProduto { get; set; }

        [BsonElement("tipo_promocao")]
        public string? TipoPromocao { get; set; }

        [BsonElement("flag_promocao")]
        public bool? FlagPromocao { get; set; }

        [BsonElement("latitude")]
        public double? Latitude { get; set; }

        [BsonElement("longitude")]
        public double? Longitude { get; set; }

        [BsonElement("fabricante")]
        public string? Fabricante { get; set; }

        [BsonElement("cnpj_fabricante")]
        public string? CNPJFabricante { get; set; }

        [BsonElement("marca_propria")]
        public bool? MarcaPropria { get; set; }

        [BsonElement("preco_pago")]
        public decimal? PrecoPago { get; set; }

        [BsonElement("preco_regular")]
        public double? PrecoRegular { get; set; }

        [BsonElement("preco_unidade_padrao")]
        public double? PrecoUnidadePadrao { get; set; }

        [BsonElement("valor_promocao")]
        public double? ValorPromocao { get; set; }

        [BsonElement("anuncio_flag")]
        public string? AnuncioFlag { get; set; }

        [BsonElement("anuncio_campanha")]
        public string? AnuncioCampanha { get; set; }

        [BsonElement("anuncio_mecanica")]
        public string? AnuncioMecanica { get; set; }

        [BsonElement("anuncio_mecanica_detalhe")]
        public string? AnuncioMecanicaDetalhe { get; set; }

        [BsonElement("anuncio_grupo_de_midia")]
        public string? AnuncioGrupoDeMidia { get; set; }

        [BsonElement("anuncio_midia")]
        public string? AnuncioMidia { get; set; }

        [BsonElement("gtin_formated")]
        public string? GTINFormated { get; set; }

        [BsonElement("hash")]
        public string? Hash { get; set; }
    }
}
