"""
Módulo para gerar relatórios agregados a partir de precificações individuais.
"""

from collections import defaultdict
from typing import Any, Callable, Hashable, NamedTuple

import pandas as pd

from report import Report


class AggregationStep(NamedTuple):
    column: str  # coluna a ser agregada
    column_target: str  # nome da coluna após agregação
    # funções devem receber coluna (pd.Series)
    operation: Callable[[pd.Series], Hashable]  # função a ser aplicada sobre a coluna dos dados


def partition_reports(reports: list[Report], partition_keys: list[str]) -> dict[tuple[Hashable, ...], list[Report]]:
    partition = defaultdict(list)
    for report in reports:
        values = tuple(report.metadata[partition_key] for partition_key in partition_keys)
        partition[values].append(report)
    return partition


def _group_reports(reports: list[Report], group_key: str) -> list[Report]:
    grouping = defaultdict(list)
    for report in reports:
        value = report.metadata[group_key]
        grouping[value].append(report)

    reports = []
    for grouped_reports in grouping.values():
        report = Report.merge_reports(grouped_reports)
        report.use_as_name(group_key)
        reports.append(report)
    return reports


def _agg_reports(
    reports: list[Report],
    metadata: dict[str, Any],
    id_col: str,
    agg_steps: list[AggregationStep],
    final: bool = False,
) -> Report:
    out = []
    for report in reports:
        agg = {}
        agg[id_col] = report.metadata[id_col]
        for step in agg_steps:
            try:
                agg[step.column_target] = step.operation(report.get_report()[step.column])
            except KeyError as exc:
                print(report.get_report().dtypes)
                raise KeyError(
                    f"coluna {step.column} não encontrada - verifique o nome e se não está na blocklist de colunas. {exc}"
                ) from exc
        agg["ref_id"] = report.id
        out.append(agg)

    df = pd.DataFrame(out)
    df.sort_values(id_col, inplace=True)
    report = Report(df, metadata, final=final)
    return report


def aggregate(reports: list[Report], params: dict[str, Any], agg_steps: list[list[AggregationStep]]) -> list[Report]:
    reports = _group_reports(reports, params["agg_order"][-1])

    all_aggs = []
    assert len(agg_steps) == len(params["agg_order"])
    i = len(params["agg_order"]) - 1  # NOTE do final para o começo
    for agg_step in agg_steps:
        if i == 0:
            break
        aggs = []
        partition_keys = params["agg_order"][:i]
        partitions = partition_reports(reports, partition_keys)
        agg_id = params["agg_order"][i]
        for values, reports_ in partitions.items():
            metadata = dict(zip(partition_keys, values))
            # print(f"{i = } {agg_id = } {metadata = } {params['agg_order'] = } {partition_keys = }")
            agg = _agg_reports(reports_, metadata, agg_id, agg_step)
            agg.use_as_name(params["agg_order"][i - 1])
            aggs.append(agg)
        all_aggs.append(aggs)
        i += -1

    final_agg = _agg_reports(all_aggs[-1], {}, params["agg_order"][0], agg_steps[-1], final=True)
    return list(reversed(reports + [agg for aggs in all_aggs for agg in aggs] + [final_agg]))
