﻿using Domain.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainTests.DatabricksQuery
{
    [TestClass()]
    public class DatabricksQueryHelperTests
    {
        [DataTestMethod]
        [DataRow("=", "Standard")]
        [DataRow(">", "Standard")]
        [DataRow("IN", "List")]
        [DataRow("LIKE", "Like")]
        public void ValidateSqlOperator_ValidOperator_ReturnsExpectedType(string inputOperator, string expectedType)
        {
            string result = DatabricksQueryHelper.ValidateSqlOperator(inputOperator);

            Assert.AreEqual(expectedType, result);
        }

        [DataTestMethod]
        [DataRow("  =  ", "Standard")]
        [DataRow(" IN ", "List")]
        [DataRow(" like ", "Like")]
        public void ValidateSqlOperator_OperatorWithWhitespace_ReturnsNormalizedResult(string inputOperator, string expectedType)
        {
            string result = DatabricksQueryHelper.ValidateSqlOperator(inputOperator);

            Assert.AreEqual(expectedType, result);
        }
    }
}
