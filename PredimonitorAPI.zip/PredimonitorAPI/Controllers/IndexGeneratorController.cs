﻿using Domain.IndexGenerator;
using Domain.IndexGenerator.Models;
using Microsoft.AspNetCore.Mvc;

namespace PredimonitorAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class IndexGeneratorController : ControllerBase
    {
        private readonly ILogger<IndexGeneratorController> _logger;
        private readonly IIndexGeneratorDomain _domain;

        public IndexGeneratorController(ILogger<IndexGeneratorController> logger, IIndexGeneratorDomain domain)
        {
            _logger = logger;
            _domain = domain;           
        }

        [HttpPost]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(long))]
        [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status401Unauthorized, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
        public async Task<IActionResult> IndexGeneratorAll([FromBody] IndexGeneratorRequest request)
        {
            try
            {
                if (request == null || !ModelState.IsValid)
                {
                    _logger.LogDebug("Invalid request received in IndexGeneratorController.Post");
                    return BadRequest();
                }

                await _domain.GenerateIndexAsync(request);

                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogDebug("Error execute IndexGeneratorAll {Ex}",ex);
                throw;
            }
        }

        [HttpPost]
        [Route("Crawler")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(long))]
        [ProducesResponseType(StatusCodes.Status401Unauthorized, Type = typeof(string))]
        public async Task<IActionResult> IndexGeneratorForCrawler([FromBody] IndexGeneratorForCrawlerRequest request)
        {
            try
            {
                if (request == null || !ModelState.IsValid)
                {
                    _logger.LogDebug("Invalid request received in IndexGeneratorController.Post");
                    return BadRequest();
                }

                await _domain.GenerateIndexForCrawlerAsync(request);

                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogDebug("Error execute IndexGeneratorAll {Ex}",ex);
                throw;
            }
        }

        [HttpPost]
        [Route("Offline")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(long))]
        [ProducesResponseType(StatusCodes.Status401Unauthorized, Type = typeof(string))]
        public async Task<IActionResult> IndexGeneratorForOffline([FromBody] IndexGeneratorForOfflineRequest request)
        {
            ArgumentNullException.ThrowIfNull(_logger);
            try
            {
                if (request == null || !ModelState.IsValid)
                {
                    _logger.LogDebug("Invalid request received in IndexGeneratorController.Post");
                    return BadRequest();
                }

                await _domain.GenerateIndexForOfflineAsync(request);

                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogDebug("Error execute IndexGeneratorForOffline {Exception}", ex);
                throw;
            }
        }
    }
}
