﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Enums
{
    public enum MonitoringItemResultsStatusType
    {
        None = -1,
        Pending = 0,
        Running = 1,
        Finished = 2,
        Error = 3
    }
}
