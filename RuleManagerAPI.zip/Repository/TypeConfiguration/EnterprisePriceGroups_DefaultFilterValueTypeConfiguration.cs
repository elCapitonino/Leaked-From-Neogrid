﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Repository.Entity;

namespace Repository.TypeConfiguration
{
    public sealed class EnterprisePriceGroups_DefaultFilterValueTypeConfiguration : TypeConfigurationBase<EnterprisePriceGroups_DefaultFilterValueEntity>, IEntityTypeConfiguration<EnterprisePriceGroups_DefaultFilterValueEntity>
    {
        public override void Configure(EntityTypeBuilder<EnterprisePriceGroups_DefaultFilterValueEntity> builder)
        {
            ConfigureTableName(builder, "EnterprisePriceGroups_DefaultFilterValue");
            builder.ToTable("EnterprisePriceGroups_DefaultFilterValue", table => table.ExcludeFromMigrations());
            builder.Ignore(x => x.Id);
            builder.HasKey(x => x.IdEnterprisePriceGroups_DefaultFilterValue);
            builder.Property(x => x.Value).HasMaxLength(255);
            builder.Property(x => x.Description).HasMaxLength(255);
            builder.Property(x => x.CreatedDate).HasColumnName("CreateDate");
            builder.Ignore(x => x.UpdatedDate);

            builder.HasOne(x => x.Parent).WithMany().HasForeignKey(x => x.IdParent);
            builder.HasOne(x => x.EnterprisePriceGroups_DefaultFilter).WithMany(x => x.Values).HasForeignKey(x => x.IdEnterprisePriceGroups_DefaultFilter);
        }
    }
}
