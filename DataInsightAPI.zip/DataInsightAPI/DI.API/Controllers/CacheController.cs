﻿using DI.API.Utils.Cache;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;

namespace DI.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class CacheController : ControllerBase
    {
        private readonly ICacheService _cacheService;
        private readonly ILogger<CacheController> _logger;

        public CacheController(ICacheService cacheService, ILogger<CacheController> logger)
        {
            _cacheService = cacheService;
            _logger = logger;
        }

        [HttpPost]
        [Route("ClearAll")]
        [ProducesResponseType<string>(StatusCodes.Status200OK)]
        [ProducesResponseType<string>(StatusCodes.Status400BadRequest)]
        [SwaggerOperation(Summary = "Clears all cache entries", Description = "Clears all cache entries")]
        public IActionResult ClearAllCache()
        {
            try
            {
                _cacheService.ClearAll();
                _logger.LogInformation("All cache entries cleared.");
                return Ok("Cache cleared successfully.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error clearing cache");
                return BadRequest("An error occurred while clearing the cache.");
            }
        }

        [HttpPost]
        [Route("Clear")]
        [ProducesResponseType<string>(StatusCodes.Status200OK)]
        [ProducesResponseType<string>(StatusCodes.Status400BadRequest)]
        [SwaggerOperation(Summary = "Clears a specific cache entry", Description = "Clears a specific cache entry based on the provided key")]
        public IActionResult ClearCache([FromBody] string cacheKey)
        {
            try
            {
                _cacheService.Remove(cacheKey);
                _logger.LogInformation("Cache entry with key '{cacheKey}' cleared.", cacheKey);
                return Ok($"Cache entry with key '{cacheKey}' cleared successfully.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error clearing cache entry");
                return BadRequest("An error occurred while clearing the cache entry.");
            }
        }
    }
}
