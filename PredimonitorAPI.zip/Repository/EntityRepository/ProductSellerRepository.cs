using Repository.DbContexts;
using Repository.Entity.Databricks;
using Repository.EntityRepository.Bases;
using System;

namespace Repository.EntityRepository;

public class ProductSellerRepository : GenericDatabricksRepository<ProductSellerEntity>, IProductSellerRepository
{
    public ProductSellerRepository(DatabricsDbContext dbContext) : base(dbContext, "product_sellers")
    {
    }
}