﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DI.Repository.Migrations.PostgreMigrations
{
    /// <inheritdoc />
    public partial class UpdateMonthlyTables : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "SubCategory",
                table: "MonthlySaleHistoryData",
                newName: "ConsolidateGroupBy");

            migrationBuilder.RenameColumn(
                name: "Affiliate",
                table: "MonthlyProjectionData",
                newName: "MajorGranularity");

            migrationBuilder.AddColumn<string>(
                name: "ConsolidateGroupBy",
                table: "MonthlyProjectionData",
                type: "character varying(128)",
                maxLength: 128,
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ConsolidateGroupBy",
                table: "MonthlyProjectionData");

            migrationBuilder.RenameColumn(
                name: "ConsolidateGroupBy",
                table: "MonthlySaleHistoryData",
                newName: "SubCategory");

            migrationBuilder.RenameColumn(
                name: "MajorGranularity",
                table: "MonthlyProjectionData",
                newName: "Affiliate");
        }
    }
}
