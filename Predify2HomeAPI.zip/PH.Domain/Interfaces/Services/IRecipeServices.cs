﻿using PH.Domain.Domain;

namespace PH.Domain.Interfaces.Services
{
    public interface IRecipeServices
    {
        Task<Recipe> Get(string? loja, string? curva, string? categoria);
        Task<double> GetLastMonthSales(string? loja, string? curva, string? categoria);
    }
}
