﻿using Repository.DbContexts;
using Repository.Entity;
using Repository.EntityRepository.Bases;

namespace Repository.EntityRepository
{
    public class HorusProductsRepository : GenericMongoRepository<HorusProductsEntity>, IHorusProductsRepository
    {

        public HorusProductsRepository(HorusDbContext dbContext) : base(dbContext)
        {
        }
        public static string DbContextName => nameof(HorusDbContext);
       

    }
}
