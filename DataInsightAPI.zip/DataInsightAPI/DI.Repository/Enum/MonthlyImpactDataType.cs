﻿namespace DI.Repository.Enum
{
    public enum MonthlyImpactDataType
    {
        Normal = 0,
        Priced = 1,
        Approved = 2,
        Adopted = 3,
        AllLastYear = 4,
        PricedLastYear = 5,
        ApprovedLastYear = 6,
        AdoptedLastYear = 7,

        Geral = 1000,
    }
}
