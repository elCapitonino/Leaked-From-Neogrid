﻿namespace DI.Repository.Entities
{
    public sealed class EnterprisePriceGroupEntity : BaseNoKeyEntity
    {
        public long EnterprisePriceGroupsId { get; set; }

        public long? CompanyId { get; set; }

        public long AITrainingId { get; set; }

        public string Name { get; set; }

        public DateTime? CalcDate { get; set; }

        public bool Published { get; set; }

        public bool Archive { get; set; } = false;

        public DateTime? PublishedDate { get; set; }

        public bool Automatic { get; set; } = false;

        public bool HasWarnings { get; set; }

        public bool IsCalculating { get; set; }

        public string? UserPublishedId { get; set; }

        public bool IsProjectionEdited { get; set; }

        public bool IsDeleted { get; set; }
    }
}
