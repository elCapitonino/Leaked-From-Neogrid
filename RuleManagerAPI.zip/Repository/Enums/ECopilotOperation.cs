﻿namespace Repository.Enums
{
    public enum ECopilotOperation
    {
        Error = -1,
        None = 0,
        CreateGroup = 1,
        RemoveGroup = 2,
        CreateRule = 3,
    }
}
