﻿using Domain.IndexGenerator.Models;

namespace Domain.IndexGenerator.DataSourceDomains.Interfaces
{
    public interface IIndexGeneratorHorusDomain
    {
        Task GenerateIndexAsync(HorusMonitoringRequest monitoringRequest);
        Task GenerateIndexAtacadoAsync(HorusMonitoringRequest monitoringRequest);
    }
}
