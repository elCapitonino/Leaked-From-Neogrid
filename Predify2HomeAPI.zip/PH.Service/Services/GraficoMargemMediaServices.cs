﻿using Microsoft.Extensions.Logging;
using PH.Domain.DTO;
using PH.Domain.Interfaces.Repositories;
using PH.Domain.Interfaces.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PH.Service.Services
{
    public class GraficoMargemMediaServices : IGraficoMargemMediaServices
    {
        private readonly ILogger<GraficoMargemMediaServices> _logger;
        private readonly IGraficoMargemMediaRepository _graficoMargemMediaRepository;

        public GraficoMargemMediaServices(ILogger<GraficoMargemMediaServices> logger, 
            IGraficoMargemMediaRepository GraficoMargemMediaRepository                     )
        {
            _logger = logger;
            _graficoMargemMediaRepository = GraficoMargemMediaRepository;   
        }

        public async Task<List<GraficoMargemMediaDTO>> GetGraficoMargem(string loja)
        {
            _logger.LogInformation($"Service: Buscando dados do grafico de margem media da loja {loja}");

            try
            {
                return await _graficoMargemMediaRepository.GetGraficoMargem(loja);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Service: Erro ao buscar dados do grafico de margem media da loja {loja}. {ex.Message}");
                throw;
            }
        }
    }
}
