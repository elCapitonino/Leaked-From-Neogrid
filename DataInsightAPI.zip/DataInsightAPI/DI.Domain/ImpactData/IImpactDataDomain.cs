﻿using DI.Domain.ImpactData.Models;
using DI.Domain.Utils;

namespace DI.Domain.ImpactData
{
    public interface IImpactDataDomain
    {
        IEnumerable<GranularityGroupResponse> GetGranularities(long companyId);
        IEnumerable<MonthlyImpactDataResponse> GetMonthlyImpactData(long companyId, YearMonth startDate, YearMonth endDate);
        IEnumerable<ProjectionImpactDataResponse> GetProjectionImpactData(long companyId, long priceGroupId);
    }
}
