﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;

namespace Repository.Entity
{
    public interface IMongoEntity : IEntityBase<ObjectId>
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public ObjectId Id { get; set; }
    }
    public abstract class BaseMongoEntity : IMongoEntity
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public ObjectId Id { get; set; }
    }

}
