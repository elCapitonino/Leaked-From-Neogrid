# %% - Importações
import pandas as pd
import datetime as dt
import config

pd.set_option('display.float_format', '{:.2f}'.format)
pd.set_option("display.max_rows", 30)
pd.set_option("display.max_columns", None)
pd.set_option('display.expand_frame_repr', False)


# %% - Puxando os dados
query = f"""
Select Top 50 IdEnterprisePriceGroups as Id,
    IdCompany, Name, IsDeletado,
    DataHoraCriacao as [Data de Ref],
    DATEADD(Day, 6, DataHoraCriacao) as [Data Limite]
From Enterprise_Price_Groups
Where idcompany=2941 and IsDeletado=0
Order by DataHoraCriacao Desc
"""

with config.getDadosAWSSession("producao") as conn:
    groups = pd.read_sql_query(query, conn)
    groups["Data de Ref"] = groups["Data de Ref"].dt.date
    groups["Data Limite"] = groups["Data Limite"].dt.date

print(groups.shape)
print(groups.head())


# %%
ids = groups["Id"].unique()
ids = ",\n\t\t".join([str(i) for i in ids])

query = f"""
With tb_base as (
    SELECT *
    FROM Enterprise_Prices_Projection
    WHERE IdEnterprisePriceGroups in ({ids})
    AND IsDeletado = 0
),
tb_num as (
    SELECT 
        PP.SalePrice as p_sem_regra_projecao,
        CASE WHEN VO.IsManual IS NULL THEN PP.SalePrice
            WHEN VO.IsManual in (0, 1) THEN VO.Price
            END AS p_projecao,
        CASE WHEN VO.IsManual IS NULL THEN PP.SalePrice_Demand
            WHEN VO.IsManual in (0, 1) THEN VO.Price_Demand
            END AS d_projecao,
        PP.PbCost as custo_projecao,
        Product, Affiliate, Customer, IdElasticity,
        ProductName as Description, EconomicGroup,
        PP.IdEnterprisePriceGroups as Id
    FROM tb_base AS PP
    LEFT JOIN Enterprise_Values_Overrides AS VO
    ON VO.ProjectionsReference = PP.ProjectionsReference
),
tb_str as (
    select DISTINCT Product, Affiliate,
        CASE WHEN ppwa.[Action] = 0 THEN 'Aprovado'
            WHEN ppwa.[Action] = 1 THEN 'Reprovado'
            ELSE 'Escalado' END AS Aproval
    FROM tb_base AS PP
    JOIN enterprisepriceprojection_workflow ppw
    ON ppw.identerprisepriceprojection = PP.IdEnterprisePricesProjection
    JOIN enterprisepriceprojection_workflowaction ppwa
    ON ppwa.idpriceprojection_workflow = ppw.IdEnterprisePriceProjection_Workflow
)
SELECT t1.Id, t2.*, t1.EconomicGroup, t1.Customer, t1.Description,
    t1.custo_projecao, t1.p_sem_regra_projecao, t1.p_projecao, t1.d_projecao,
    Case When ABS(t3.Elasticity) <= 1 THEN 'Inelástico'
        Else 'Elástico' END AS [Elasticidade]
FROM tb_num AS t1
JOIN tb_str AS t2
ON t1.Product = t2.Product AND t1.Affiliate = t2.Affiliate
JOIN enterprise_ElasticityNew as t3
ON t1.IdElasticity = t3.Identerprise_ElasticityNew
"""

with config.getDadosAWSSession("producao") as conn:
    proj = pd.read_sql_query(query, conn)

print(proj.shape)
print(proj.head())


# %%
query = f"""
Select Issuance, Product, AVG(PbCost) as custo,
    AVG(ClientSalesPrice) as preco, SUM(Quantity) as Qtd
From Enterprise_Sales_History with (nolock)
Where idcompany=2941 and Affiliate=237 and Issuance >= '2023-06-01'
Group By Issuance, Product
"""

with config.getDadosAWSSession("producao") as conn:
    hist = pd.read_sql_query(query, conn)

print(hist.shape)
print(hist.head())


# %% - to excel
nome = "Peralta-dados_relatorio.xlsx"


with pd.ExcelWriter(
    nome,
    # if_sheet_exists='new' - apenas na versao 1.3.0
    engine="openpyxl",
    date_format="YYYY-MM-DD",
    datetime_format="YYYY-MM-DD HH:MM:SS",
) as writer:
    
    groups.to_excel(writer, sheet_name="Grupos", index=False)
    proj.to_excel(writer, sheet_name="Preços", index=False)
    hist.to_excel(writer, sheet_name="Histórico", index=False)

# %%
