﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;
using Repository.Entity.ProductPrices;

namespace Repository.Entity
{
    public class ProductPricesEntity : BaseMongoEntity
    {
        
        [BsonElement("id_task")]
        public string? IdTask { get; set; }

        [BsonElement("id_crawler")]
        public int IdCrawler { get; set; }

        [BsonElement("crawler_date")]
        public DateTime CrawlerDate { get; set; }

        [BsonElement("product_name")]
        public string? ProductName { get; set; }

        [BsonElement("product_link")]
        public string? ProductLink { get; set; }

        [BsonElement("product_brand")]
        public string? ProductBrand { get; set; }

        [BsonElement("product_ean")]
        public string? ProductEAN { get; set; }

        [BsonElement("product_ncm")]
        public string? ProductNCM { get; set; }

        [BsonElement("product_model")]
        public string? ProductModel { get; set; }

        [BsonElement("product_segment")]
        public string? ProductSegment { get; set; }

        [BsonIgnoreIfNull]
        [BsonElement("product_local")]
        public ProductPricesProductLocal? ProductLocal { get; set; }

        [BsonElement("product_category_name")]
        public string? CategoryName { get; set; }

        [BsonElement("site_sku")]
        public string? SiteSku { get; set; }

        [BsonElement("source")]
        public string? Source { get; set; }

        [BsonElement("text_search")]
        public string? TextSearch { get; set; }

        [BsonElement("id_product")]
        public long? IdProduct { get; set; }

        [BsonElement("id_monitoring_item")]
        public long? IdMonitoringItem { get; set; }

        [BsonElement("language")]
        public string? Language { get; set; }

        [BsonElement("sellers")]
        public List<ProductPricesSeller>? Sellers { get; set; }

        [BsonIgnoreIfNull]
        [BsonElement("shippings")]
        public List<ProductPricesShipping>? Shippings { get; set; }

        [BsonIgnoreIfNull]
        [BsonElement("attributes")]
        public List<ProductPricesAttribute>? Attributes { get; set; }

        [BsonElement("product_manufacture_year")]
        public int? ManufactureYear { get; set; }

        [BsonElement("product_used_hours")]
        public int? UsedHours { get; set; }

        [BsonElement("product_voltage")]
        public string? ProductVoltage { get; set; }

        [BsonElement("product_gender")]
        public string? ProductGender { get; set; }

        [BsonElement("product_description")]
        public string? ProductDescription { get; set; }

        [BsonElement("product_energy_source")]
        public string? ProductEnergySource { get; set; }

        [BsonElement("product_materials")]
        public string? ProductMaterials { get; set; }

        [BsonElement("product_metric_units")]
        public List<string>? ProductMetricUnits { get; set; }

        [BsonElement("product_power")]
        public string? ProductPower { get; set; }

        [BsonElement("product_size")]
        public string? ProductSize { get; set; }

        [BsonElement("product_dimensions")]
        public string? ProductDimensions { get; set; }

        [BsonElement("product_color")]
        public string? ProductColor { get; set; }

        [BsonElement("product_axles")]
        public string? ProductAxles { get; set; }

        [BsonElement("product_mileage")]
        public int? ProductMileage { get; set; }

        [BsonElement("product_mileage_symbol")]
        public string? ProductMileageSymbol { get; set; }

        [BsonElement("product_fuel_tank_capacity")]
        public decimal? ProductFuelTankCapacity { get; set; }

        [BsonElement("product_fuel_tank_capacity_symbol")]
        public string? ProductFuelTankCapacitySymbol { get; set; }

        [BsonElement("product_truck_body_type")]
        public string? ProductTruckBodyType { get; set; }

        [BsonElement("product_vehicle_year_model")]
        public string? ProductVehicleYearModel { get; set; }

        [BsonElement("product_manufacturer")]
        public string? ProductManufacturer { get; set; }

        [BsonElement("product_manufacturer_number")]
        public string? ProductManufacturerNumber { get; set; }

        [BsonElement("id_company")]
        public long? IdCompany { get; set; }

    }

}
