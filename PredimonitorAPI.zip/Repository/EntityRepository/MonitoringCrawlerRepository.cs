﻿using Repository.DbContexts;
using Repository.Entity;
using Repository.EntityRepository.Bases;

namespace Repository.EntityRepository
{
    public class MonitoringCrawlerRepository : GenericRepository<MonitoringCrawlerEntity, int>, IMonitoringCrawlerRepository
    {
        public MonitoringCrawlerRepository(ApplicationDbContext dbContext) : base(dbContext)
        {
        }
        public static string DbContextName => nameof(ApplicationDbContext);
    }
}
