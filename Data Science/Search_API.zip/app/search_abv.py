from predimonitor_type import *
from async_mongo import AsyncMongoConnect

#Class da Nielsen
class Search_abv():

    def __init__(self):
        self.dbMongo = AsyncMongoConnect()

    async def search_get_v1(self, products):
        full_result = []
        result_list = []

        states = None
        if (products.idcrawlers_offline is not None):
            states = [obj.state for obj in products.idcrawlers_offline]
            states = list(filter(lambda x: x is not None and x !=
                          '' and x.strip() != '', states))
            
            
        store_type = None
        if (products.idcrawlers_offline is not None):
            store_type = [obj.store_type for obj in products.idcrawlers_offline]
            store_type = list(filter(lambda x: x is not None and x !=
                          '' and x.strip() != '', store_type))

        ean = None
        start_date = products.start_date
        end_date = products.end_date
        if products is None or products.products[0].ean is None or not products.products[0].ean:
            return []

        ean = products.products[0].ean
        try:
            result_mongo = await self.dbMongo.get_product_search_abv(start_date, end_date, ean)

            for documento in result_mongo:
                try:
                    item = documento["documento"]
                    name = item['ProdutoDescricao']['DESCRICAO']
                    result_list.append({'id': str(item['_id']),
                                        'id_crawler': 307,
                                        "product_name": name,
                                        "product_link": item['ProdutoEan']['EAN']+str(item['Concorrente']['SEQCONCORRENTE']),
                                        "product_ean": item['ProdutoEan']['EAN'],
                                        "site_sku": 0,
                                        "source": "ABV",
                                        "language": "pt-br",
                                        "product_brand": item['ProdutoDescricao']['MARCA'],
                                        "id_product_normalized": None,
                                        "trash_score": 0,
                                        "crawler_date": item['PesquisaProduto']['DT_PESQUISA'],
                                        "sellers": [
                        {"seller_name": item['Concorrente']['RAZAO_SOCIAL'],
                        "prices":[{
                            'price': str(item['PesquisaProduto']['PRECO_VAREJO']),
                            "price_currency": "BRL"
                        }]
                        }],
                        "product_local":
                        {'state': item['Concorrente']['ESTADO'],
                        'city': item['Concorrente']['CIDADE']},
                        "product_manufacture_year": None,
                        "product_used_hours": None
                    })
                
                except Exception as ex:
                    print(" ------ Erro dados ABV  ------")
                    print(str(ex))

            full_result.append({
                "name": products.products[0].name,
                "results": result_list
            })

        except Exception as ex:
            print(" ------ Erro dados ABV  ------")
            print(str(ex))

        return full_result
    
    async def search_get_v2(self, products):
        ean_where = []
        start_date = ""
        end_date = ""
        full_result = []
        lista_result = []
        result_list = []

        if (products.filters.eans is not None and len(products.filters.eans) != 0):
            for i in products.filters.eans:
                ean_where.append(i.ean)

        if (products.start_date is not None and products.end_date is not None):
            start_date = products.start_date
            end_date = products.end_date

        states = None

        if (products.filters.local_states is not None):
            states = products.filters.local_states
            states = list(filter(lambda x: x is not None and x !=
                          '' and x.strip() != '', states))

        store_type = None
        if (products.idcrawlers_offline is not None):
            store_type = [obj.store_type for obj in products.idcrawlers_offline]
            store_type = list(filter(lambda x: x is not None and x !=
                          '' and x.strip() != '', store_type))
            
        t_brand = products.filters.brands
        t_categories = products.filters.categories

        try:
            if (ean_where is not None and ean_where and start_date != "" and end_date != ""):
                for ean in ean_where:
                    result_ean = await self.dbMongo.get_product_search_abv_v2(start_date, end_date, ean, states, t_brand, t_categories)
                    if (result_ean is not None):
                        lista_result.extend(result_ean)

            for documento in lista_result:
                try:
                    item = documento
                    name = item['ProdutoDescricao']['DESCRICAO']
                    result_list.append({'id': str(item['_id']),
                            'id_crawler': 307,
                            "product_name": name,
                            "product_link": item['ProdutoEan']['EAN']+str(item['Concorrente']['SEQCONCORRENTE']),
                            "product_ean": item['ProdutoEan']['EAN'],
                            "site_sku": 0,
                            "source": "ABV",
                            "language": "pt-br",
                            "product_brand": item['ProdutoDescricao']['MARCA'],
                            "id_product_normalized": None,
                            "trash_score": 0,
                            "crawler_date": item['PesquisaProduto']['DT_PESQUISA'],
                            "seller_name": item['Concorrente']['RAZAO_SOCIAL'],
                            "prices": [{'price': str(item['PesquisaProduto']['PRECO_VAREJO'])}],
                            "product_local":
                            {'state': item['Concorrente']['ESTADO'],
                            'city': item['Concorrente']['CIDADE']},
                            "product_manufacture_year": None,
                            "product_used_hours": None
                            })
                
                except Exception as ex:
                    print(" ------ Erro dados ABV V2  ------")
                    print(str(ex))
            
            full_result.append({
                "product": ean_where[0],
                "result": result_list
            })

        except Exception as ex:
            print(" ------ Erro dados ABV V2  ------")
            print(str(ex))
            
        print(" ------ Fim dados ABV V2  ------")
        return full_result
