﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace PH.Domain.Domain
{
    public class Recipe
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string? Id { get; private set; }
        public TotalRecipe TotalRecipe { get; set; }
        public TotalMargin TotalMargin { get; set; }

        public void SetId(string id)
        {
            Id = id;
        }
    }

    public class TotalRecipe
    {
        public double LastWeek { get; set; }
        public double WeekProjection { get; set; }
        public double MonthProjection { get; set; }
    }

    public class TotalMargin
    {
        public double LastWeek { get; set; }
        public double WeekProjection { get; set; }
        public double MonthProjection { get; set; }
    }
}
