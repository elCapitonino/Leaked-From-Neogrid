﻿namespace Repository.Enums
{
    public enum CrawlerSourceType
    {
        Predify = 0,
        Horus = 1,
        HorusAtacado = 2,
        SmarketABV = 3,
        NielsenVem = 4,
        NielsenPeralta = 5,
        Indireta = 6,
        Linx = 7,
        LinxFarmaSellout = 8,
        InfoPriceSaoJoao = 9,
        InfoPricePeralta = 10,
        OfflineSupermarketTorre = 11,
        InfoPriceTorre = 12,
        ScantechSupermaxi = 13,
    }
}
