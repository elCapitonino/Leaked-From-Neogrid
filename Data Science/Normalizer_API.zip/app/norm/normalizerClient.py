from sklearn import preprocessing
from norm.NormalizerExtraction import NormalizerExtraction
from fastapi.encoders import jsonable_encoder


class normalizerClient:
    def __init__(self):
        self.norm_extraction = NormalizerExtraction()

    def normalize_seearch_client(self, products):

        list_result = []

        for product in products:
            #print("product:", product)

            #print("product name:", product.name)

            if(product.name != None):

                # preprocess_product = self.norm_extraction.normalize_preprocessing(
                #     product.name)
                list_product_norm = self.norm_extraction.normalizer_extraction(
                    product.name, product.language)
                #print("list_product_norm:", type(list_product_norm))

                list_result.append(list_product_norm)

        # print(list_id)
        # print(score)
        print("-------------------")
        # print(list_result)
        #results = {"products_list": list_result}
        result_json = jsonable_encoder(list_result)

        # print(result_json)
        return result_json
