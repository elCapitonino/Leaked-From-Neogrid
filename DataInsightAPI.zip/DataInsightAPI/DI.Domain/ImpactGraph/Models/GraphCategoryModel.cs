﻿namespace DI.Domain.ImpactGraph.Models
{
    public sealed class GraphCategoryModel
    {
        public GraphCategoryModel(string year, string month)
        {
            Year = year;
            Month = month;
        }

        public string Year { get; set; }
        public string Month { get; set; }
    }
}
