from contextlib import asynccontextmanager
from uuid import UUID

from fastapi import BackgroundTasks, FastAPI, HTTPException, Request

from src.db import create_postgresql_engine, create_sql_server_engine
from src.logger import logger
from src.monthly_data import (
    get_import_status,
    get_monthly_tasks,
    import_monthly_metrics,
    import_status_manager,
    insert_import_status,
    prepare_import_status_manager,
    update_empty_import,
)


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.pg_engine, app.state.pg_metadata = create_postgresql_engine()
    app.state.sql_engine, app.state.sql_metadata = create_sql_server_engine()
    yield
    app.state.pg_engine.dispose()
    app.state.sql_engine.dispose()


app = FastAPI(lifespan=lifespan, title="MonthlySaleHistoryProcessor")


@app.get("/health")
async def health():
    """Check health of the application."""
    return "OK"


# FIXME se o serviço que fez a requisição não receber a resposta (falha de rede)
# não será possível saber o range de datas para chamar a API 2. Se fizer a
# requisição novamente, a importação não vai rodar pois já está marcada como
# sucesso. Portanto, gera um buraco nos dados da API 2.
@app.post("/process_monthly_data/{id_company}")
def process_monthly_data(id_company: int, request: Request, bg_tasks: BackgroundTasks):
    """Process sales history of a company to generate accounting metrics aggregated by month."""
    try:
        logger.info("new process_monthly_request for id_company %s", id_company)
        with request.app.state.pg_engine.begin() as pg_conn:
            import_id = insert_import_status(
                pg_conn,
                request.app.state.pg_metadata,
                id_company,
            )

        bg_tasks.add_task(_run_import, id_company, import_id, request)

    except HTTPException as exc:
        raise exc
    except Exception as exc:
        msg = f"unexpected error of type {type(exc).__name__}: {exc}"
        logger.error(msg, exc_info=True)
        raise HTTPException(status_code=500, detail=msg) from exc

    return {
        "id_company": id_company,
        "import_id": import_id,
    }


@app.get("/get_import_status")
def get_import_status_endpoint(import_id: UUID, request: Request):
    """Get status of an import ID."""
    try:
        with request.app.state.pg_engine.connect() as pg_conn:
            out = get_import_status(pg_conn, request.app.state.pg_metadata, import_id)
        if out is None:
            raise HTTPException(
                status_code=404, detail=f"import id {import_id} not found"
            )
        return out

    except HTTPException as exc:
        raise exc
    except Exception as exc:
        msg = f"unexpected error of type {type(exc).__name__}: {exc}"
        logger.error(msg, exc_info=True)
        raise HTTPException(status_code=500, detail=msg) from exc


def _run_import(
    id_company: int,
    import_id: UUID,
    request: Request,
) -> None:
    with prepare_import_status_manager(
        request.app.state.pg_engine, request.app.state.pg_metadata, import_id
    ):
        import_job = get_monthly_tasks(
            id_company,
            pg_engine=request.app.state.pg_engine,
            pg_metadata=request.app.state.pg_metadata,
            sql_engine=request.app.state.sql_engine,
            sql_metadata=request.app.state.sql_metadata,
        )

    if import_job is None:
        with request.app.state.pg_engine.begin() as pg_conn:
            update_empty_import(pg_conn, request.app.state.pg_metadata, import_id)
            return

    with import_status_manager(
        request.app.state.pg_engine,
        request.app.state.pg_metadata,
        import_id,
        import_job.last_create_date,
        import_job.initial_issuance,
        import_job.final_issuance,
    ):
        logger.info("started import with ID %s", import_id)
        num_tasks = len(import_job.tasks)
        logger.info("found %d pending tasks for id_company %d", num_tasks, id_company)
        for i, task in enumerate(import_job.tasks):
            logger.info("-> %d/%d: running monthly data task %s", i, num_tasks, task)
            import_monthly_metrics(
                id_company=task.id_company,
                initial_date=task.initial_date,
                final_date=task.final_date,
                pg_engine=request.app.state.pg_engine,
                pg_metadata=request.app.state.pg_metadata,
                sql_engine=request.app.state.sql_engine,
                sql_metadata=request.app.state.sql_metadata,
            )
