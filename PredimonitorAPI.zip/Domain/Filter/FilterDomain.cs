using Azure.Core;
using Domain.CompanyMonitoringCrawler;
using Domain.Filter.Models;
using Domain.Utils;
using Microsoft.Extensions.Logging;
using Repository.Entity;
using Repository.Models.Databricks;
using Repository.UnitOfWork;
using System.Diagnostics;

namespace Domain.Filter;

public class FilterDomain : IFilterDomain
{
    private readonly ILogger<FilterDomain> _logger;
    private readonly IUnitOfWork _uow;
    private readonly ICompanyMonitoringCrawlerDomain _companyMonitoringCrawlerDomain;

    public FilterDomain(ILogger<FilterDomain> logger, IUnitOfWork uow, ICompanyMonitoringCrawlerDomain companyMonitoringCrawlerDomain)
    {
        _logger = logger;
        _uow = uow;
        _companyMonitoringCrawlerDomain = companyMonitoringCrawlerDomain;
    }

    public async Task<FilterResponse> GetFilters(FilterRequest request)
    {
        if (!string.IsNullOrEmpty(request.ProductName))
            request.ProductName = request.ProductName.ToUpper();

        if (!string.IsNullOrEmpty(request.SellerName))
            request.SellerName = request.SellerName.ToUpper();

        if (!string.IsNullOrEmpty(request.BrandName))
            request.BrandName = request.BrandName.ToUpper();

        var companyCrawlers = await _companyMonitoringCrawlerDomain.GetCompanyMonitoringCrawler(request.CompanyId, request.IsCost);

        if (companyCrawlers == null || companyCrawlers.Count == 0)
        {
            _logger.LogError($"No crawlers found for company {request.CompanyId}");
            throw new ArgumentException($"No crawlers found for company {request.CompanyId}");
        }

        var filters = await GetFilterData(request, companyCrawlers);

        return filters;
    }

    private async Task<FilterResponse> GetFilterData(FilterRequest request, List<CompanyMonitoringCrawlerEntity> companyCrawlers)
    {
        try
        {
            if (request.IsProductPagination || request.IsBrandPagination || request.IsSellerPagination)
            {
                var filterResponse = await GetPaginationData(request, companyCrawlers);

                return filterResponse;
            }

            var sw = Stopwatch.StartNew();
            var productTask = Task.Run(() => _uow.ProductRepository.GetWithJoin<ProductFilterResponse>(CreateProductFilterQuery(request, companyCrawlers)));
            var sellerTask = Task.Run(() => _uow.ProductSellerRepository.GetWithJoin<SellerFilterResponse>(CreateSellerFilterQuery(request, companyCrawlers)));
            var brandsTask = Task.Run(() => _uow.ProductRepository.GetWithJoin<BrandFilterResponse>(CreateBrandFilterQuery(request, companyCrawlers)));
            var categoriesTask = Task.Run(() => _uow.ProductSellerRepository.GetWithJoin<CategoryFilterResponse>(CreateCategoryFilterQuery(request, companyCrawlers)));
            var originsTask = Task.Run(() => _uow.ProductRepository.GetWithJoin<OriginFilterResponse>(CreateOriginFilterQuery(request, companyCrawlers)));
            var regionsTask = Task.Run(() => _uow.ProductSellerRepository.GetWithJoin<RegionFilterResponse>(CreateRegionFilterQuery(request, companyCrawlers)));
            var statesTask = Task.Run(() => _uow.ProductSellerRepository.GetWithJoin<StateFilterResponse>(CreateStateFilterQuery(request, companyCrawlers)));
            var segmentsTask = Task.Run(() => _uow.ProductSellerRepository.GetWithJoin<SegmentFilterResponse>(CreateSegmentFilterQuery(request, companyCrawlers)));
            var yearsTask = Task.Run(() => _uow.ProductSellerRepository.GetWithJoin<YearFilterResponse>(CreateYearFilterQuery(request, companyCrawlers)));
            var modelsTask = Task.Run(() => _uow.ProductSellerRepository.GetWithJoin<ModelFilterResponse>(CreateModelFilterQuery(request, companyCrawlers)));

            await Task.WhenAll(productTask, categoriesTask, originsTask, sellerTask, brandsTask, regionsTask, statesTask, segmentsTask, yearsTask, modelsTask);
            sw.Stop();
            _logger.LogInformation("Filter query took {ms} ms to execute for company {CompanyId}", sw.ElapsedMilliseconds, request.CompanyId);

            var products = (await productTask).Select(x => x.Name).ToList();
            var categories = (await categoriesTask).Select(x => x.Category).ToList();
            var origins = (await originsTask).Select(x => x.CrawlerId).ToList();
            var sellers = (await sellerTask).Select(x => x.Seller).ToList();
            var brands = (await brandsTask).Select(x => x.Brand).ToList();
            var regions = (await regionsTask).Select(x => x.Region).ToList();
            var states = (await statesTask).Select(x => x.UF).ToList();
            var segments = (await segmentsTask).Select(x => x.Segment).ToList();
            var years = (await yearsTask).Select(x => x.Year).ToList();
            var models = (await modelsTask).Select(x => x.Model).ToList();

            products = PrepareResultForPaginationComponent(request.ProductNames, products);
            sellers = PrepareResultForPaginationComponent(request.Sellers, sellers);
            brands = PrepareResultForPaginationComponent(request.Brands, brands);

            var originNames = CompanyMonitoringCrawlerDomain.GetCrawlerNamesByIds(origins, companyCrawlers);

            return new FilterResponse
            {
                Products = products,
                Categories = categories,
                Origins = originNames,
                Sellers = sellers,
                Brands = brands,
                Regions = regions,
                States = states,
                Segments = segments,
                Years = years,
                Models = models
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, $"An error occurred while searching filters for company {request.CompanyId}.");
            throw;
        }
    }

    private async Task<FilterResponse> GetPaginationData(FilterRequest request, List<CompanyMonitoringCrawlerEntity> companyCrawlers)
    {
        if (request.IsProductPagination)
        {
            var productsPagination = (await _uow.ProductRepository.GetWithJoin<ProductFilterResponse>(CreateProductFilterQuery(request, companyCrawlers))).Select(x => x.Name).ToList();

            productsPagination = PrepareResultForPaginationComponent(request.ProductNames, productsPagination);

            return new FilterResponse { Products = productsPagination };
        }
        else if (request.IsSellerPagination)
        {
            var sellerPagination = (await _uow.ProductSellerRepository.GetWithJoin<SellerFilterResponse>(CreateSellerFilterQuery(request, companyCrawlers))).Select(x => x.Seller).ToList();

            sellerPagination = PrepareResultForPaginationComponent(request.Sellers, sellerPagination);

            return new FilterResponse { Sellers = sellerPagination };
        }
        else if (request.IsBrandPagination)
        {
            var brandPagination = (await _uow.ProductRepository.GetWithJoin<BrandFilterResponse>(CreateBrandFilterQuery(request, companyCrawlers))).Select(x => x.Brand).ToList();

            brandPagination = PrepareResultForPaginationComponent(request.Brands, brandPagination);

            return new FilterResponse { Brands = brandPagination };
        }

        return new();
    }

    private List<string?> PrepareResultForPaginationComponent(List<string?> selecteds, List<string?> newNames)
    {
        if (selecteds != null && selecteds.Count > 0)
        {
            newNames.RemoveAll(x => selecteds.Contains(x));

            newNames.InsertRange(0, selecteds);
        }

        return newNames;
    }

    private QueryParameters CreateBaseQuery(FilterRequest request, List<CompanyMonitoringCrawlerEntity> companyCrawlers)
    {
        var query = new QueryParameters()
        {
            Select = [],
            Joins = [],
            Filters = [],
            GroupBy = [],
            OrderBy = [],
            SqlFilters = []
        };

        query.SqlFilters.AddRange(DatabricksQueryHelper.CreateCompanyMandatoryFilters(companyCrawlers));

        request.Page = request.Page == 0 ? 1 : request.Page;
        request.Take = request.Take == 0 ? 100 : request.Take;

        query.Skip = (request.Page - 1) * request.Take;
        query.Take = request.Take;

        return query;
    }

    private QueryParameters CreateProductFilterQuery(FilterRequest request, List<CompanyMonitoringCrawlerEntity> companyCrawlers)
    {
        var query = CreateBaseQuery(request, companyCrawlers);

        query.Joins.AddRange(
        [
            new (){ JoinTable = "product_sellers AS ps", JoinCondition = "Id = ps.ProductId", JoinWithMainTable = true },
        ]);

        query.Select.Add(new() { Column = "DISTINCT Name" });

        query.Filters = DatabricksQueryHelper.CreateFilterBaseFilters(request, companyCrawlers, QueryIgnore.Name);

        query.Filters.AddRange(
        [
            new (){ Column = "Name", Operator = "LIKE", Value = request.ProductName },
            new (){ Column = "Name", Operator = "IS", Value = "NOT NULL" }
        ]);

        query.OrderBy.Add(new QueryOrderBy { Column = "Name ASC" });

        return query;
    }

    private QueryParameters CreateCategoryFilterQuery(FilterRequest request, List<CompanyMonitoringCrawlerEntity> companyCrawlers)
    {
        var query = CreateBaseQuery(request, companyCrawlers);

        query.Joins.AddRange(
        [
            new (){ JoinTable = "products AS p", JoinCondition = "ProductId = p.Id", JoinWithMainTable = true },
        ]);

        query.Select.Add(new() { Column = "DISTINCT Category" });

        query.Filters = DatabricksQueryHelper.CreateFilterBaseFilters(request, companyCrawlers, QueryIgnore.Category);

        query.Filters.AddRange(
        [
            new (){ Column = "Category", Operator = "IS", Value = "NOT NULL" }
        ]);

        query.OrderBy.Add(new() { Column = "Category ASC" });

        query.Take = 10000;

        return query;
    }

    private QueryParameters CreateOriginFilterQuery(FilterRequest request, List<CompanyMonitoringCrawlerEntity> companyCrawlers)
    {
        var query = CreateBaseQuery(request, companyCrawlers);

        query.Joins.AddRange(
        [
            new (){ JoinTable = "product_sellers AS ps", JoinCondition = "Id = ps.ProductId", JoinWithMainTable = true },
        ]);

        query.Select.Add(new() { Column = "DISTINCT CrawlerId" });

        query.Filters = DatabricksQueryHelper.CreateFilterBaseFilters(request, companyCrawlers, QueryIgnore.Crawler);

        query.OrderBy.Add(new() { Column = "CrawlerId" });

        query.Take = 10000;

        return query;
    }

    private QueryParameters CreateSellerFilterQuery(FilterRequest request, List<CompanyMonitoringCrawlerEntity> companyCrawlers)
    {
        var query = CreateBaseQuery(request, companyCrawlers);

        query.Joins.AddRange(
        [
            new (){ JoinTable = "products AS p", JoinCondition = "ProductId = p.Id", JoinWithMainTable = true },
        ]);

        query.Select.Add(new() { Column = "DISTINCT Seller" });

        query.Filters = DatabricksQueryHelper.CreateFilterBaseFilters(request, companyCrawlers, QueryIgnore.Seller);

        query.Filters.AddRange(
        [
            new (){ Column = "Seller", Operator = "LIKE", Value = request.SellerName },
            new (){ Column = "Seller", Operator = "IS", Value = "NOT NULL" }
        ]);

        query.OrderBy.Add(new() { Column = "Seller ASC" });

        return query;
    }

    private QueryParameters CreateBrandFilterQuery(FilterRequest request, List<CompanyMonitoringCrawlerEntity> companyCrawlers)
    {
        var query = CreateBaseQuery(request, companyCrawlers);

        query.Joins.AddRange(
        [
            new (){ JoinTable = "product_sellers AS ps", JoinCondition = "Id = ps.ProductId", JoinWithMainTable = true },
        ]);

        query.Select.Add(new QuerySelect() { Column = "DISTINCT Brand" });

        query.Filters = DatabricksQueryHelper.CreateFilterBaseFilters(request, companyCrawlers, QueryIgnore.Brand);

        query.Filters.AddRange(
        [
            new (){ Column = "Brand", Operator = "LIKE", Value = request.BrandName },
            new (){ Column = "Brand", Operator = "IS", Value = "NOT NULL" }
        ]);

        query.OrderBy.Add(new() { Column = "Brand ASC" });

        return query;
    }

    private QueryParameters CreateRegionFilterQuery(FilterRequest request, List<CompanyMonitoringCrawlerEntity> companyCrawlers)
    {
        var query = CreateBaseQuery(request, companyCrawlers);

        query.Joins.AddRange(
        [
            new (){ JoinTable = "products AS p", JoinCondition = "ProductId = p.Id", JoinWithMainTable = true },
        ]);

        query.Select.Add(new QuerySelect() { Column = "DISTINCT Region" });

        query.Filters = DatabricksQueryHelper.CreateFilterBaseFilters(request, companyCrawlers, QueryIgnore.Region);

        query.Filters.AddRange(
        [
            new (){ Column = "Region", Operator = "IS", Value = "NOT NULL" }
        ]);

        query.OrderBy.Add(new() { Column = "Region ASC" });

        query.Take = 10000;

        return query;
    }

    private QueryParameters CreateStateFilterQuery(FilterRequest request, List<CompanyMonitoringCrawlerEntity> companyCrawlers)
    {
        var query = CreateBaseQuery(request, companyCrawlers);

        query.Joins.AddRange(
        [
            new (){ JoinTable = "products AS p", JoinCondition = "ProductId = p.Id", JoinWithMainTable = true },
        ]);

        query.Select.Add(new QuerySelect() { Column = "DISTINCT UF" });

        query.Filters = DatabricksQueryHelper.CreateFilterBaseFilters(request, companyCrawlers, QueryIgnore.UF);

        query.Filters.AddRange(
        [
            new (){ Column = "UF", Operator = "IS", Value = "NOT NULL" }
        ]);

        query.OrderBy.Add(new() { Column = "UF ASC" });

        query.Take = 10000;

        return query;
    }

    private QueryParameters CreateSegmentFilterQuery(FilterRequest request, List<CompanyMonitoringCrawlerEntity> companyCrawlers)
    {
        var query = CreateBaseQuery(request, companyCrawlers);

        query.Joins.AddRange(
        [
            new (){ JoinTable = "products AS p", JoinCondition = "ProductId = p.Id", JoinWithMainTable = true },
        ]);

        query.Select.Add(new() { Column = "DISTINCT Segment" });

        query.Filters = DatabricksQueryHelper.CreateFilterBaseFilters(request, companyCrawlers, QueryIgnore.Segment);

        query.Filters.AddRange(
        [
            new (){ Column = "Segment", Operator = "IS", Value = "NOT NULL" }
        ]);

        query.OrderBy.Add(new() { Column = "Segment ASC" });

        query.Take = 10000;

        return query;
    }

    private QueryParameters CreateYearFilterQuery(FilterRequest request, List<CompanyMonitoringCrawlerEntity> companyCrawlers)
    {
        var query = CreateBaseQuery(request, companyCrawlers);

        query.Joins.AddRange(
        [
            new (){ JoinTable = "products AS p", JoinCondition = "ProductId = p.Id", JoinWithMainTable = true },
        ]);

        query.Select.Add(new() { Column = "DISTINCT Year" });

        query.Filters = DatabricksQueryHelper.CreateFilterBaseFilters(request, companyCrawlers, QueryIgnore.Segment);

        query.Filters.AddRange(
        [
            new (){ Column = "Year", Operator = "IS", Value = "NOT NULL" }
        ]);

        query.OrderBy.Add(new() { Column = "Year ASC" });

        query.Take = 10000;

        return query;
    }

    private QueryParameters CreateModelFilterQuery(FilterRequest request, List<CompanyMonitoringCrawlerEntity> companyCrawlers)
    {
        var query = CreateBaseQuery(request, companyCrawlers);

        query.Joins.AddRange(
        [
            new (){ JoinTable = "products AS p", JoinCondition = "ProductId = p.Id", JoinWithMainTable = true },
        ]);

        query.Select.Add(new() { Column = "DISTINCT Model" });

        query.Filters = DatabricksQueryHelper.CreateFilterBaseFilters(request, companyCrawlers, QueryIgnore.Segment);

        query.Filters.AddRange(
        [
            new (){ Column = "Model", Operator = "IS", Value = "NOT NULL" }
        ]);

        query.OrderBy.Add(new() { Column = "Model ASC" });

        query.Take = 10000;

        return query;
    }
}