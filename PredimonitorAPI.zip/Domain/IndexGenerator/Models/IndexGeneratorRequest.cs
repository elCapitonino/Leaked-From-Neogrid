﻿namespace Domain.IndexGenerator.Models
{
    public class IndexGeneratorRequest
    {
        public long CompanyId { get; set; }
        public Guid? TaskId { get; set; }
        public Guid? CrawlerTaskId { get; set; }
        public IEnumerable<MonitoringItemTags> NewMonitoringItems { get; set; } = [];
        public IEnumerable<MonitoringItemTags> UpdatedMonitoringItems { get; set; } = [];
        public IEnumerable<long> DeletedMonitoringItemIds { get; set; } = [];
    }

    public class MonitoringItemTags
    {
        public long MonitoringItemId { get; set; }
        public IEnumerable<string>? Tags { get; set; }
        public IEnumerable<string>? Eans { get; set; }
        public string? RequiredWords { get; set; }
        public string? RestrictedWords { get; set; }
    }
}
