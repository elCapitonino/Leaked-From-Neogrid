﻿using Domain.MonitoringResult.Models;

namespace Domain.MonitoringResult
{
    public interface IMonitoringResultDomain
    {
        Task<DynamicFilterResponse> GetMonitoringResultFilteredData(long companyId, DynamicFilterRequest request);
        Task<IEnumerable<SeeResultResponse>> GetMonitoringItemResult(ResultFilterRequest request);
        Task GenerateProductMarketResult(long companyId, DateTime? startDate = null, DateTime? endDate = null, DateTime? refDate = null, int skip = 0, bool? removeOlds = null, bool? removeOutliers = null);
    }
}
