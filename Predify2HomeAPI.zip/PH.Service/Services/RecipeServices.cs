﻿using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using PH.Domain.Domain;
using PH.Domain.Interfaces.Repositories;
using PH.Domain.Interfaces.Services;

namespace PH.Service.Services
{
    public class RecipeServices : IRecipeServices
    {
        private readonly ILogger<RecipeServices> _logger;
        private readonly IRecipeRepository _repository;
        private readonly IMemoryCache _memoryCache;
        private readonly ICacheControlService _cacheControlService;

        public RecipeServices(ILogger<RecipeServices> logger,
                               IRecipeRepository repository,
                               IMemoryCache memoryCache,
                               ICacheControlService cacheControlService)
        {
            _logger = logger;
            _repository = repository;
            _memoryCache = memoryCache;
            _cacheControlService = cacheControlService;
        }

        public async Task<Recipe> Get(string? loja, string? curva, string? categoria)
        {
            _logger.LogInformation("Service: buscando todos os Recipe");

            try
            {
                return await _repository.Get(loja, curva, categoria);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Service: erro ao buscar todos os Recipe. {ex.Message}");
                throw;
            }
        }

        public async Task<double> GetLastMonthSales(string? loja, string? curva, string? categoria)
        {
            _logger.LogInformation("Service: buscando todos os Recipe");

            try
            {
                return await _repository.GetLastMonthSales(loja, curva, categoria);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Service: erro ao buscar todos os Recipe. {ex.Message}");
                throw;
            }
        }
    }
}
