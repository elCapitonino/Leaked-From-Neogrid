﻿using MongoDB.Driver;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UpdateHash.Models;
using UpdateHashHorus;

namespace UpdateHash.Handlers
{
    public class NielsenPeraltaHandler
    {
        private readonly MongoClient _client;

        public NielsenPeraltaHandler(MongoClient client)
        {
            _client = client;
        }

        public async Task ExecuteAsync(string baseName, string collectionName, DateTime startDate, DateTime endDate, int batchSize, bool dryRun = false)
        {
            var database = _client.GetDatabase(baseName);
            var collection = database.GetCollection<NielsenPeraltaProducts>(collectionName);

            var filter = Builders<NielsenPeraltaProducts>.Filter.And(
                Builders<NielsenPeraltaProducts>.Filter.Gte(doc => doc.DATE, startDate),
                Builders<NielsenPeraltaProducts>.Filter.Lte(doc => doc.DATE, endDate)
            );

            var projection = Builders<NielsenPeraltaProducts>.Projection
                .Include(doc => doc.PRODUCT_DESCRIPTION)
                .Include(doc => doc.EAN)
                .Include(doc => doc.STORE)
                .Include(doc => doc.STATE_UF);

            int take = batchSize;
            int skip = 0;

            while (true)
            {
                Log.Information("Buscando Produtos");

                var documents = await collection.Find(filter)
                                                 .Sort(Builders<NielsenPeraltaProducts>.Sort.Descending(doc => doc.DATE))
                                                 .Skip(skip)
                                                 .Limit(take)
                                                 .Project<NielsenPeraltaProducts>(projection)
                                                 .ToListAsync();

                if (documents.Count == 0)
                {
                    break;
                }

                Log.Information("Atualizando Produtos");

                var updates = new List<WriteModel<NielsenPeraltaProducts>>();

                foreach (var doc in documents)
                {
                    var ean = doc.EAN;
                    var store = doc.STORE;
                    var state_uf = doc.STATE_UF;

                    var concatenatedString = $"{ean}|{store}|{state_uf}";

                    var hashValue = Utils.CalculateSHA256(concatenatedString);

                    var filterDoc = Builders<NielsenPeraltaProducts>.Filter.Eq("_id", doc._id);
                    var update = Builders<NielsenPeraltaProducts>.Update.Set("HASH", hashValue);
                    updates.Add(new UpdateOneModel<NielsenPeraltaProducts>(filterDoc, update));
                }

                if (!dryRun)
                    await collection.BulkWriteAsync(updates);

                Log.Information($"Atualizados {skip + take} documentos");

                skip += take;
            }
        }
    }
}
