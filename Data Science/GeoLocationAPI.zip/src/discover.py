from typing import Any, Dict, Optional, Protocol, Tuple

from async_lru import alru_cache
from motor.core import AgnosticClient

from models.internal import AddressInfo, AddressInfoCoordinates, Coordinate
from models.request import DiscoverRequest
from models.response import DiscoverResult
from src.env import config
from src.exceptions import ExternalAPIError, MaxRetriesExceeded, NoCoordinateFound
from src.external_search.enum import ExternalSearchStatus
from src.logger import logger
from src.mongo import fetch_discover_info, upsert_discover_info

MAX_RETRIES = 2


class RemoteSearcher(Protocol):
    async def __call__(
        self, query: str, lat: float, long: float
    ) -> Tuple[Optional[Dict[str, Any]], ExternalSearchStatus]: ...


class Discover:
    def __init__(
        self, mongo_conn: AgnosticClient, remote_searcher: RemoteSearcher, mock: bool
    ) -> None:
        self.conn = mongo_conn
        self.remote_searcher = remote_searcher
        self.__mock = mock

    async def _upsert_discover_info(
        self, query: str, lat: float, long: float, result: DiscoverResult
    ):
        if self.__mock:
            return
        await upsert_discover_info(self.conn, query, lat, long, result.place_info)

    async def __call__(
        self,
        params: DiscoverRequest,
    ) -> DiscoverResult:
        result = DiscoverResult(
            place_info={},
        )

        params.query = params.query.strip().lower()

        logger.debug("searching place info of << %s >>", params.query)

        doc = {}

        if params.use_cache:
            doc = await fetch_discover_info(
                self.conn, params.query, params.lat, params.long
            )

        if doc:
            logger.debug("found place info of << %s >> in mongo", params.query)

            result.place_info = doc
        elif params.lat != 0 and params.long != 0:
            response, status = await self.remote_searcher(
                params.query, params.lat, params.long
            )

            if status is ExternalSearchStatus.HTTP_ERROR:
                raise ExternalAPIError()

            if response is None:
                raise ExternalAPIError()

            result.place_info = response

            await self._upsert_discover_info(
                params.query, params.lat, params.long, result
            )

        return result


@alru_cache(
    maxsize=int(config.get("CACHE_MAXSIZE", "256")),
    ttl=int(config.get("CACHE_TTL", "240")),
)
async def _cache_discover_search(
    searcher: Discover,
    params: DiscoverRequest,
) -> DiscoverResult:
    return await searcher(params=params)


async def discover_search(
    searcher: Discover,
    params: DiscoverRequest,
    use_cache: bool = True,
) -> DiscoverResult:
    if use_cache:
        result = await _cache_discover_search(
            searcher=searcher,
            params=params,
        )
    else:
        result = await searcher(params=params)

    return result
