﻿using Domain.BackgroundTasks.Models;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System.Threading;

namespace Domain.BackgroundTasks
{
    public class QueuedService : BackgroundService
    {
        private readonly ILogger<QueuedService> _logger;
        private readonly IServiceProvider _services;
        private readonly CancellationToken _cancellationToken;
        private readonly SemaphoreSlim _semaphore;

        public QueuedService(IBackgroundTaskQueue taskQueue,
            ILogger<QueuedService> logger,
              IServiceProvider services,
            IHostApplicationLifetime applicationLifetime,
            IOptions<QueueServiceOptions> options)
        {
            TaskQueue = taskQueue;
            _logger = logger;
            _services = services;
            _cancellationToken = applicationLifetime.ApplicationStopping;
            _semaphore = new SemaphoreSlim(options.Value.MaxDegreeOfParallelism);
        }

        public IBackgroundTaskQueue TaskQueue { get; }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation(
                $"Queued Hosted Service is running.");

            await BackgroundProcessing(stoppingToken);
        }

        private async Task BackgroundProcessing(CancellationToken stoppingToken)
        {
            var runningTasks = new List<Task>();
            while (!stoppingToken.IsCancellationRequested)
            {
                var workItem = await TaskQueue.DequeueAsync(stoppingToken);

                if (workItem == null)
                    continue;

                await _semaphore.WaitAsync(stoppingToken);
                var task = Task.Run(async () =>
                {
                    try
                    {
                        await workItem(stoppingToken, _services);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex,
                            "Error occurred executing {WorkItem}.", nameof(workItem));
                    }
                    finally
                    {
                        _semaphore.Release();
                    }
                });

                runningTasks.Add(task);
                runningTasks.RemoveAll(t => t.IsCompleted || t.IsCanceled || t.IsFaulted);

            }

            await Task.WhenAll(runningTasks);
        }

        public override async Task StopAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation("Queued Hosted Service is stopping.");

            await base.StopAsync(stoppingToken);
        }
    }
}
