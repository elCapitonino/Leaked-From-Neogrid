"""
Módulo para determinar se há match entre uma marca e uma string (nome do produto + marca).
"""

import re
from typing import List

from rapidfuzz import process, distance


class BrandMatcher:
    """
    Classe para determinar se há match entre uma marca e uma string (nome do produto + marca).
    """

    def __init__(
        self,
        min_fuzzy_similarity: float = 0.7,
        min_word_length: int = 3,
        token_pattern=r"(?u)\b\w\w+\b",
    ):
        self.min_fuzzy_similarity = min_fuzzy_similarity
        self.min_word_length = min_word_length
        self.token_pattern = re.compile(token_pattern)

    def _build_brand_aliases(self, brand: str) -> List[str]:
        aliases = [brand]
        brand_words = self.token_pattern.findall(brand)
        short_words = [sw[0] for sw in brand_words]  # primeira letra de cada palavra
        aliases.append("".join(short_words))
        aliases.append(" ".join(short_words))

        # single words
        aliases.extend((word for word in brand_words if len(word) >= self.min_word_length))
        return aliases

    def __call__(self, ref_brand: str, query: str) -> bool:
        query_words = self.token_pattern.findall(query)
        brand_aliases = self._build_brand_aliases(ref_brand)
        if any(
            process.extract(
                alias,
                query_words,
                score_cutoff=self.min_fuzzy_similarity,
                scorer=distance.Levenshtein.normalized_similarity,
            )
            for alias in brand_aliases
        ):
            return True

        return False
