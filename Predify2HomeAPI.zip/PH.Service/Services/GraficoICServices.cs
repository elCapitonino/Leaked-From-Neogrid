﻿using AutoMapper;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using PH.Domain.Domain;
using PH.Domain.DTO;
using PH.Domain.Interfaces.Repositories;
using PH.Domain.Interfaces.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PH.Service.Services
{
    public class GraficoICServices : IGraficoICServices
    {
        private readonly ILogger<GraficoICServices> _logger;
        private readonly IGraficoICRepository _graficoICRepository;

        public GraficoICServices(ILogger<GraficoICServices> logger,
                              IGraficoICRepository GraficoICRepository)
        {
            _logger = logger;
            _graficoICRepository = GraficoICRepository;
        }

        public async Task<FiltroCategoriaGraficoICDTO> GetAllFilterCategories()
        {
            _logger.LogInformation("Service: buscando todos os filtros de Categoria");

            try
            {
                return await _graficoICRepository.GetAllFilterCategories();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Service: erro ao buscar todos filtros de Categoria. {ex.Message}");
                throw;
            }
        }

        public async Task<List<GraficoICDTO>> GetGraficoIC(string category, string compType, string? state, string period, string? coordinator)
        {
            _logger.LogInformation("Service: buscando dados do grafico de IC");

            try
            {
                return await _graficoICRepository.GetGraficoIC(category, compType, state, period, coordinator);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Service: erro ao buscar dados do grafico de IC. {ex.Message}");
                throw;
            }
        }

        public async Task<EstadoGraficoICDTO> GetStateByIdGroup(long idPriceGroup)
        {
            _logger.LogInformation("Service: buscando estado pelo id do grupo");

            try
            {
                return await _graficoICRepository.GetStateByIdGroup(idPriceGroup);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Service: erro ao buscar dados do grafico de IC. {ex.Message}");
                throw;
            }
        }
        public async Task<List<IntervaloMargemDTO>> GetMarginByIdCompany(long idCompany)
        {
            _logger.LogInformation("Service: buscando range de margem");

            try
            {
                return await _graficoICRepository.GetMarginByIdCompany(idCompany);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Service: erro ao buscar range de margem. {ex.Message}");
                throw;
            }
        }
    }
}
