﻿using CS.Domain.Domain;
using CS.Domain.DTO;
using CS.Domain.Interfaces.Repositories;
using Dapper;
using Microsoft.Extensions.Configuration;
using System.Data.SqlClient;

namespace CS.Data.Imp
{
    public class EnterpriseSalesHistoryRepository : IEnterpriseSalesHistoryRepository
    {
        private readonly IConfiguration _configuration;

        public EnterpriseSalesHistoryRepository(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public async Task<IEnumerable<EnterpriseSalesHistoryElasticSimpleCalculator>> GetESHWithSimpleFilters(SimpleSearchDTO searchFilter)
        {
            var products = new List<EnterpriseSalesHistory>();

            using var db = new SqlConnection(_configuration["DefaultConnection"]);            
            await db.OpenAsync();
            var query = @$"SELECT TOP 10 ISSUANCE, PRODUCT, QUANTITY, SALEPRICE, AFFILIATE, STORE, NAMESEGMENT,CUSTOMER
						                           FROM  ENTERPRISE_SALES_HISTORY (NOLOCK)
                                                   WHERE IDCOMPANY = {searchFilter.idCompany} AND 
                                                         ISSUANCE = '{searchFilter.referenceStartDate}'";

            var result = await db.QueryAsync<EnterpriseSalesHistoryElasticSimpleCalculator>(query, commandTimeout: int.MaxValue);
            return result;
        }
    }
}
