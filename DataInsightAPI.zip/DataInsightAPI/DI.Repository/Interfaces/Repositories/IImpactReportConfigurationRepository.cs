﻿using DI.Repository.Entities;

namespace DI.Repository.Interfaces.Repositories
{
    public interface IImpactReportConfigurationRepository
    {
        ImpactReportConfigurationEntity? GetByCompanyId(long companyId);
        List<ImpactReportConfigurationEntity> GetAll();

    }
}