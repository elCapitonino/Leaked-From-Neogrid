﻿using Repository.Entity;
using Repository.EntityRepository.Bases;

namespace Repository.EntityRepository
{
    public interface IProductMarketResultSellerRepository : IGenericRepository<ProductMarketResultSellerEntity, long>
    {
    }   
}
