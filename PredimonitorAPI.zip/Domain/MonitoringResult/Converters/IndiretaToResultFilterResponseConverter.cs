﻿using AutoMapper;
using Domain.MonitoringResult.Models;
using Repository.Entity;
using Repository.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.MonitoringResult.Converters
{

    public class IndiretaToResultFilterResponseConverter : ITypeConverter<IndiretaEntity, ResultFilterResponse>
    {
        public ResultFilterResponse Convert(IndiretaEntity source, ResultFilterResponse destination, ResolutionContext context)
        {
            var dest = new ResultFilterResponse()
            {
                ProductName = source.ProductDescription,
                ProductLink = source.Hash,
                ProductBrand = null,
                SellerName = source.DistributorName,
                Marketplace = (string)context.Items["CrawlerName"],
                Price = source.SaleValue,
                PaymentType = "-",
                Price_unit_type = PriceUnitType.UNITARIO,
                CrawlerDate = source.LastSale,
                Disregarded = false,
                IdCrawler = (int)context.Items["CrawlerId"],
                City = source.City,
                On_request = false,
                State = source.State2,
                Coordinates = source.Coordinates == null ? null : new PrediMonitorProduct_CoordinatesModel()
                {
                    Longitude = (decimal)source.Coordinates.Coordinates[0],
                    Latitude = (decimal)source.Coordinates.Coordinates[1],
                },
            };

            return dest;
        }
    }
}
