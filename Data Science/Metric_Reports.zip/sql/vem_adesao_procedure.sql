-------------- ADOÇÃO --------------

declare @FILIAL as NVARCHAR(100);
set @FILIAL = '303071';

WITH tb_groups AS (
    SELECT  
        DataHoraCriacao,
        PublishedDate,
        IdEnterprisePriceGroups
    FROM Enterprise_Price_Groups AS t1
    WHERE IdCompany = 3026
    AND IsDeletado = 0
    -- AND Published = 1
    -- AND PublishedDate IS NOT NULL
    AND CalcDate IS NOT NULL   
),
tb_filters AS (
    SELECT F.IdEnterprisePriceGroups, DF.dbField, F.[Value] AS Affiliate
    FROM Enterprise_Price_Groups_Filter AS F
    JOIN EnterprisePriceGroups_DefaultFilter AS DF
    ON F.IdEnterprisePriceGroups_DefaultFilter = DF.IdEnterprisePriceGroups_DefaultFilter
    WHERE DF.IdCompany = 3026
    AND F.IsDeleted = 0
    AND DF.dbField = 7 -- Affiliate
),
tb_affiliate AS (
    SELECT
        t1.*,
        t2.Affiliate,
        -- FIXME remover coalesce
        DATEADD(day, -30, coalesce(t1.PublishedDate, t1.DataHoraCriacao)) AS InitialDateBack,
        coalesce(t1.PublishedDate, t1.DataHoraCriacao) AS EndDateBack,
        DATEADD(day, 7, coalesce(t1.PublishedDate, t1.DataHoraCriacao)) AS InitialDateFwd,
        DATEADD(
            day,
            0,
            coalesce(lead(t1.PublishedDate) OVER (ORDER BY t1.PublishedDate DESC), GETDATE())
        ) AS EndDateFwd
    FROM tb_groups AS t1
    JOIN tb_filters AS t2
    ON t1.IdEnterprisePriceGroups = t2.IdEnterprisePriceGroups
    WHERE CAST(t2.Affiliate AS nvarchar) = @FILIAL
),
tb_pp AS (
    SELECT
        t2.DataHoraCriacao,
        t2.Affiliate,
        t2.IdEnterprisePriceGroups,
        pp.ProductName AS Description,
        pp.AffiliateName,
        ppwa.[Action],
		t2.EndDateBack,
        CASE
            WHEN vo.identerprisevaluesoverrides IS NOT NULL THEN vo.price
            ELSE pp.saleprice
        END AS SuggestedPrice,
        pp.SalePrice AS IAPrice,
        pp.LastSalePrice AS LastSalePrice
    FROM Enterprise_Prices_Projection AS pp
    JOIN tb_affiliate AS t2
    ON pp.IdEnterprisePriceGroups = t2.IdEnterprisePriceGroups
    LEFT JOIN enterprise_values_overrides vo
    ON vo.projectionsreference = pp.projectionsreference
    JOIN enterprisepriceprojection_workflow ppw
    ON ppw.identerprisepriceprojection = pp.IdEnterprisePricesProjection
    JOIN enterprisepriceprojection_workflowaction ppwa
    ON ppwa.idpriceprojection_workflow = ppw.IdEnterprisePriceProjection_Workflow
),
tb_sales_history_fwd AS (
    SELECT
        t1.[Description],
        t2.InitialDateFwd,
        t2.EndDateFwd,
        t2.IdEnterprisePriceGroups,
        t1.Issuance,
        t1.SalePrice
    FROM Enterprise_Sales_History AS t1
    JOIN tb_affiliate AS t2
    ON t1.Affiliate = t2.Affiliate
    WHERE t1.IdCompany = 3026
    AND t1.IsDeletado = 0
    AND t1.Issuance >= t2.InitialDateFwd
    AND t1.Issuance < t2.EndDateFwd
),
tb_sales_history_fwd_agg AS (
    SELECT
        [Description],
        IdEnterprisePriceGroups,
        avg(SalePrice) AS AvgPriceFwd
    FROM tb_sales_history_fwd
    GROUP BY [Description], IdEnterprisePriceGroups
),
tb_sales_history_back AS (
    SELECT
        t1.[Description],
        t2.IdEnterprisePriceGroups,
        avg(t1.SalePrice) AS AvgPriceBack
    FROM Enterprise_Sales_History AS t1
    JOIN tb_affiliate AS t2
    ON t1.Affiliate = t2.Affiliate
    WHERE t1.IdCompany = 3026
    AND t1.IsDeletado = 0
    AND t1.Issuance >= t2.InitialDateBack
    AND t1.Issuance < t2.EndDateBack
    GROUP BY t1.[Description], t2.IdEnterprisePriceGroups
),
tb_combine AS (
    SELECT
        t1.*,
        t2.AvgPriceFwd,
        t3.AvgPriceBack
    FROM tb_pp AS t1
    LEFT JOIN tb_sales_history_fwd_agg AS t2
    ON t1.IdEnterprisePriceGroups = t2.IdEnterprisePriceGroups
    AND t1.[Description] = t2.[Description]
    LEFT JOIN tb_sales_history_back AS t3
    ON t1.IdEnterprisePriceGroups = t3.IdEnterprisePriceGroups
    AND t1.[Description] = t3.[Description]
)
SELECT
	DATEPART(YEAR, EndDateBack) AS Ano,    
    DATEPART(MONTH, EndDateBack) AS Mes,  
    SUM(CASE WHEN Action = 0 THEN 1 ELSE 0 END) AS Approved,
    SUM(CASE WHEN Action <> 0 THEN 1 ELSE 0 END) AS Reproved,
    SUM(
        CASE WHEN AvgPriceFwd IS NOT NULL
        AND ABS(AvgPriceFwd - SuggestedPrice) <= 0.01
        THEN 1 ELSE 0 END
    ) AS AdoptionSuggested,
    SUM(
        CASE WHEN AvgPriceFwd IS NOT NULL
        AND ABS(AvgPriceFwd - SuggestedPrice) > 0.01
        THEN 1 ELSE 0 END
    ) AS RejectionSuggested,
    SUM(
        CASE WHEN AvgPriceFwd IS NOT NULL
        AND AvgPriceBack IS NOT NULL
        AND ABS(AvgPriceBack - SuggestedPrice) > 0.01
        THEN 1 ELSE 0 END
    ) AS NewPriceSuggested,
    SUM(
        CASE WHEN AvgPriceFwd IS NULL
        THEN 1 ELSE 0 END
    ) AS UnknownPrice 
FROM tb_combine
GROUP BY DATEPART(YEAR, EndDateBack), DATEPART(MONTH, EndDateBack);


-------------- % ADOÇÃO --------------

declare @FILIAL as NVARCHAR(100);
set @FILIAL = '303071';

WITH tb_groups AS (
    SELECT  
        DataHoraCriacao,
        PublishedDate,
        IdEnterprisePriceGroups
    FROM Enterprise_Price_Groups AS t1
    WHERE IdCompany = 3026
    AND IsDeletado = 0
    -- AND Published = 1
    -- AND PublishedDate IS NOT NULL
    AND CalcDate IS NOT NULL   
),
tb_filters AS (
    SELECT F.IdEnterprisePriceGroups, DF.dbField, F.[Value] AS Affiliate
    FROM Enterprise_Price_Groups_Filter AS F
    JOIN EnterprisePriceGroups_DefaultFilter AS DF
    ON F.IdEnterprisePriceGroups_DefaultFilter = DF.IdEnterprisePriceGroups_DefaultFilter
    WHERE DF.IdCompany = 3026
    AND F.IsDeleted = 0
    AND DF.dbField = 7 -- Affiliate
),
tb_affiliate AS (
    SELECT
        t1.*,
        t2.Affiliate,
        -- FIXME remover coalesce
        DATEADD(day, -30, coalesce(t1.PublishedDate, t1.DataHoraCriacao)) AS InitialDateBack,
        coalesce(t1.PublishedDate, t1.DataHoraCriacao) AS EndDateBack,
        DATEADD(day, 7, coalesce(t1.PublishedDate, t1.DataHoraCriacao)) AS InitialDateFwd,
        DATEADD(
            day,
            0,
            coalesce(lead(t1.PublishedDate) OVER (ORDER BY t1.PublishedDate DESC), GETDATE())
        ) AS EndDateFwd
    FROM tb_groups AS t1
    JOIN tb_filters AS t2
    ON t1.IdEnterprisePriceGroups = t2.IdEnterprisePriceGroups
    WHERE CAST(t2.Affiliate AS nvarchar) = @FILIAL
),
tb_pp AS (
    SELECT
        t2.DataHoraCriacao,
        t2.Affiliate,
        t2.IdEnterprisePriceGroups,
        pp.ProductName AS Description,
        pp.AffiliateName,
        ppwa.[Action],
		t2.EndDateBack,
        CASE
            WHEN vo.identerprisevaluesoverrides IS NOT NULL THEN vo.price
            ELSE pp.saleprice
        END AS SuggestedPrice,
        pp.SalePrice AS IAPrice,
        pp.LastSalePrice AS LastSalePrice
    FROM Enterprise_Prices_Projection AS pp
    JOIN tb_affiliate AS t2
    ON pp.IdEnterprisePriceGroups = t2.IdEnterprisePriceGroups
    LEFT JOIN enterprise_values_overrides vo
    ON vo.projectionsreference = pp.projectionsreference
    JOIN enterprisepriceprojection_workflow ppw
    ON ppw.identerprisepriceprojection = pp.IdEnterprisePricesProjection
    JOIN enterprisepriceprojection_workflowaction ppwa
    ON ppwa.idpriceprojection_workflow = ppw.IdEnterprisePriceProjection_Workflow
),
tb_sales_history_fwd AS (
    SELECT
        t1.[Description],
        t2.InitialDateFwd,
        t2.EndDateFwd,
        t2.IdEnterprisePriceGroups,
        t1.Issuance,
        t1.SalePrice
    FROM Enterprise_Sales_History AS t1
    JOIN tb_affiliate AS t2
    ON t1.Affiliate = t2.Affiliate
    WHERE t1.IdCompany = 3026
    AND t1.IsDeletado = 0
    AND t1.Issuance >= t2.InitialDateFwd
    AND t1.Issuance < t2.EndDateFwd
),
tb_sales_history_fwd_agg AS (
    SELECT
        [Description],
        IdEnterprisePriceGroups,
        avg(SalePrice) AS AvgPriceFwd
    FROM tb_sales_history_fwd
    GROUP BY [Description], IdEnterprisePriceGroups
),
tb_sales_history_back AS (
    SELECT
        t1.[Description],
        t2.IdEnterprisePriceGroups,
        avg(t1.SalePrice) AS AvgPriceBack
    FROM Enterprise_Sales_History AS t1
    JOIN tb_affiliate AS t2
    ON t1.Affiliate = t2.Affiliate
    WHERE t1.IdCompany = 3026
    AND t1.IsDeletado = 0
    AND t1.Issuance >= t2.InitialDateBack
    AND t1.Issuance < t2.EndDateBack
    GROUP BY t1.[Description], t2.IdEnterprisePriceGroups
),
tb_combine AS (
    SELECT
        t1.*,
        t2.AvgPriceFwd,
        t3.AvgPriceBack
    FROM tb_pp AS t1
    LEFT JOIN tb_sales_history_fwd_agg AS t2
    ON t1.IdEnterprisePriceGroups = t2.IdEnterprisePriceGroups
    AND t1.[Description] = t2.[Description]
    LEFT JOIN tb_sales_history_back AS t3
    ON t1.IdEnterprisePriceGroups = t3.IdEnterprisePriceGroups
    AND t1.[Description] = t3.[Description]
)
SELECT
	DATEPART(YEAR, EndDateBack) AS Ano,    
    DATEPART(MONTH, EndDateBack) AS Mes,  
    SUM(CASE WHEN Action = 0 THEN 1 ELSE 0 END)  * 100.0 / Count(1) AS Approved,
    SUM(CASE WHEN Action <> 0 THEN 1 ELSE 0 END)  * 100.0 / Count(1) AS Reproved,
    SUM(
        CASE WHEN AvgPriceFwd IS NOT NULL
        AND ABS(AvgPriceFwd - SuggestedPrice) <= 0.01
        THEN 1 ELSE 0 END
    )  * 100.0 / Count(1) AS AdoptionSuggested,
    SUM(
        CASE WHEN AvgPriceFwd IS NOT NULL
        AND ABS(AvgPriceFwd - SuggestedPrice) > 0.01
        THEN 1 ELSE 0 END
    )  * 100.0 / Count(1) AS RejectionSuggested,
    SUM(
        CASE WHEN AvgPriceFwd IS NOT NULL
        AND AvgPriceBack IS NOT NULL
        AND ABS(AvgPriceBack - SuggestedPrice) > 0.01
        THEN 1 ELSE 0 END
    )  * 100.0 / Count(1) AS NewPriceSuggested,
    SUM(
        CASE WHEN AvgPriceFwd IS NULL
        THEN 1 ELSE 0 END
    ) * 100.0 / Count(1) AS UnknownPrice 
FROM tb_combine
GROUP BY DATEPART(YEAR, EndDateBack), DATEPART(MONTH, EndDateBack);


---------- MARGEM MEDIA --------------


declare @FILIAL as NVARCHAR(100);  
set @FILIAL = '303071';

WITH tb_groups AS (
    SELECT  
        DataHoraCriacao,
        PublishedDate,
        IdEnterprisePriceGroups
    FROM Enterprise_Price_Groups AS t1
    WHERE IdCompany = 3026
    AND IsDeletado = 0
    -- AND Published = 1
    -- AND PublishedDate IS NOT NULL
    AND CalcDate IS NOT NULL   
),
tb_filters AS (
    SELECT F.IdEnterprisePriceGroups, DF.dbField, F.[Value] AS Affiliate
    FROM Enterprise_Price_Groups_Filter AS F
    JOIN EnterprisePriceGroups_DefaultFilter AS DF
    ON F.IdEnterprisePriceGroups_DefaultFilter = DF.IdEnterprisePriceGroups_DefaultFilter
    WHERE DF.IdCompany = 3026
    AND F.IsDeleted = 0
    AND DF.dbField = 7 -- Affiliate
),
tb_affiliate AS (
    SELECT
        t1.*,
        t2.Affiliate,
        -- FIXME remover coalesce
        DATEADD(day, -30, coalesce(t1.PublishedDate, t1.DataHoraCriacao)) AS InitialDateBack,
        coalesce(t1.PublishedDate, t1.DataHoraCriacao) AS EndDateBack,
        DATEADD(day, 7, coalesce(t1.PublishedDate, t1.DataHoraCriacao)) AS InitialDateFwd,
        DATEADD(
            day,
            0,
            coalesce(lead(t1.PublishedDate) OVER (ORDER BY t1.PublishedDate DESC), GETDATE())
        ) AS EndDateFwd
    FROM tb_groups AS t1
    JOIN tb_filters AS t2
    ON t1.IdEnterprisePriceGroups = t2.IdEnterprisePriceGroups
    WHERE CAST(t2.Affiliate AS nvarchar) = @FILIAL
),
tb_pp AS (
    SELECT
        t2.DataHoraCriacao,
        t2.Affiliate,
        t2.IdEnterprisePriceGroups,
        pp.ProductName AS Description,
        pp.AffiliateName,
        ppwa.[Action],
		t2.EndDateBack,
        CASE
            WHEN vo.identerprisevaluesoverrides IS NOT NULL THEN vo.price
            ELSE pp.saleprice
        END AS SuggestedPrice,
        pp.SalePrice AS IAPrice,
        pp.LastSalePrice AS LastSalePrice
    FROM Enterprise_Prices_Projection AS pp
    JOIN tb_affiliate AS t2
    ON pp.IdEnterprisePriceGroups = t2.IdEnterprisePriceGroups
    LEFT JOIN enterprise_values_overrides vo
    ON vo.projectionsreference = pp.projectionsreference
    JOIN enterprisepriceprojection_workflow ppw
    ON ppw.identerprisepriceprojection = pp.IdEnterprisePricesProjection
    JOIN enterprisepriceprojection_workflowaction ppwa
    ON ppwa.idpriceprojection_workflow = ppw.IdEnterprisePriceProjection_Workflow
),
tb_sales_history_fwd AS (
    SELECT
        t1.[Description],
        t2.InitialDateFwd,
        t2.EndDateFwd,
        t2.IdEnterprisePriceGroups,
        t1.Issuance,
        t1.SalePrice,
        t1.PbCost
    FROM Enterprise_Sales_History AS t1
    JOIN tb_affiliate AS t2
    ON t1.Affiliate = t2.Affiliate
    WHERE t1.IdCompany = 3026
    AND t1.IsDeletado = 0
    AND t1.Issuance >= t2.InitialDateFwd
    AND t1.Issuance < t2.EndDateFwd
),
tb_sales_history_fwd_agg AS (
    SELECT
        [Description],
        IdEnterprisePriceGroups,
        avg(SalePrice) AS AvgPriceFwd,
        avg(100 * (SalePrice - PbCost) / SalePrice) AS AvgMarginFwd
    FROM tb_sales_history_fwd
    GROUP BY [Description], IdEnterprisePriceGroups
),
tb_sales_history_back AS (
    SELECT
        t1.[Description],
        t2.IdEnterprisePriceGroups,
        avg(t1.SalePrice) AS AvgPriceBack,
        avg(100 * (SalePrice - PbCost) / SalePrice) AS AvgMarginBack
    FROM Enterprise_Sales_History AS t1
    JOIN tb_affiliate AS t2
    ON t1.Affiliate = t2.Affiliate
    WHERE t1.IdCompany = 3026
    AND t1.IsDeletado = 0
    AND t1.Issuance >= t2.InitialDateBack
    AND t1.Issuance < t2.EndDateBack
    GROUP BY t1.[Description], t2.IdEnterprisePriceGroups
),
tb_combine AS (
    SELECT
        t1.*,
        t2.AvgPriceFwd,
        t2.AvgMarginFwd,
        t3.AvgMarginBack,
        t3.AvgPriceBack
    FROM tb_pp AS t1
    LEFT JOIN tb_sales_history_fwd_agg AS t2
    ON t1.IdEnterprisePriceGroups = t2.IdEnterprisePriceGroups
    AND t1.[Description] = t2.[Description]
    LEFT JOIN tb_sales_history_back AS t3
    ON t1.IdEnterprisePriceGroups = t3.IdEnterprisePriceGroups
    AND t1.[Description] = t3.[Description]
)
SELECT
	DATEPART(YEAR, EndDateBack) AS Ano,    
    DATEPART(MONTH, EndDateBack) AS Mes,  
    AVG(
        CASE WHEN AvgPriceFwd IS NOT NULL
        AND ABS(AvgPriceFwd - SuggestedPrice) <= 0.01
        THEN AvgMarginFwd END
    ) AS AvgMarginAdoptionSuggested,
    AVG(
        CASE WHEN AvgPriceFwd IS NOT NULL
        AND ABS(AvgPriceFwd - SuggestedPrice) > 0.01
        THEN AvgMarginFwd END
    ) AS AvgMarginRejectionSuggested,
    SUM(
        CASE WHEN AvgPriceFwd IS NULL
        THEN 1 ELSE 0 END
    ) AS UnknownPrice
FROM tb_combine
GROUP BY DATEPART(YEAR, EndDateBack), DATEPART(MONTH, EndDateBack);


---------- RECEITA ---------------


declare @FILIAL as NVARCHAR(100);  
set @FILIAL = '303071';

WITH tb_groups AS (
    SELECT  
        DataHoraCriacao,
        PublishedDate,
        IdEnterprisePriceGroups
    FROM Enterprise_Price_Groups AS t1
    WHERE IdCompany = 3026
    AND IsDeletado = 0
    -- AND Published = 1
    -- AND PublishedDate IS NOT NULL
    AND CalcDate IS NOT NULL   
),
tb_filters AS (
    SELECT F.IdEnterprisePriceGroups, DF.dbField, F.[Value] AS Affiliate
    FROM Enterprise_Price_Groups_Filter AS F
    JOIN EnterprisePriceGroups_DefaultFilter AS DF
    ON F.IdEnterprisePriceGroups_DefaultFilter = DF.IdEnterprisePriceGroups_DefaultFilter
    WHERE DF.IdCompany = 3026
    AND F.IsDeleted = 0
    AND DF.dbField = 7 -- Affiliate
),
tb_affiliate AS (
    SELECT
        t1.*,
        t2.Affiliate,
        -- FIXME remover coalesce
        DATEADD(day, -30, coalesce(t1.PublishedDate, t1.DataHoraCriacao)) AS InitialDateBack,
        coalesce(t1.PublishedDate, t1.DataHoraCriacao) AS EndDateBack,
        DATEADD(day, 7, coalesce(t1.PublishedDate, t1.DataHoraCriacao)) AS InitialDateFwd,
        DATEADD(
            day,
            0,
            coalesce(lead(t1.PublishedDate) OVER (ORDER BY t1.PublishedDate DESC), GETDATE())
        ) AS EndDateFwd
    FROM tb_groups AS t1
    JOIN tb_filters AS t2
    ON t1.IdEnterprisePriceGroups = t2.IdEnterprisePriceGroups
    WHERE CAST(t2.Affiliate AS nvarchar) = @FILIAL
),
tb_pp AS (
    SELECT
        t2.DataHoraCriacao,
        t2.Affiliate,
        t2.IdEnterprisePriceGroups,
        pp.ProductName AS Description,
        pp.AffiliateName,
        ppwa.[Action],
		t2.EndDateBack,
        CASE
            WHEN vo.identerprisevaluesoverrides IS NOT NULL THEN vo.price
            ELSE pp.saleprice
        END AS SuggestedPrice,
        pp.SalePrice AS IAPrice,
        pp.LastSalePrice AS LastSalePrice
    FROM Enterprise_Prices_Projection AS pp
    JOIN tb_affiliate AS t2
    ON pp.IdEnterprisePriceGroups = t2.IdEnterprisePriceGroups
    LEFT JOIN enterprise_values_overrides vo
    ON vo.projectionsreference = pp.projectionsreference
    JOIN enterprisepriceprojection_workflow ppw
    ON ppw.identerprisepriceprojection = pp.IdEnterprisePricesProjection
    JOIN enterprisepriceprojection_workflowaction ppwa
    ON ppwa.idpriceprojection_workflow = ppw.IdEnterprisePriceProjection_Workflow
),
tb_sales_history_fwd AS (
    SELECT
        t1.[Description],
        t2.InitialDateFwd,
        t2.EndDateFwd,
        t2.IdEnterprisePriceGroups,
        t1.Issuance,
        t1.SalePrice,
        t1.Quantity
    FROM Enterprise_Sales_History AS t1
    JOIN tb_affiliate AS t2
    ON t1.Affiliate = t2.Affiliate
    WHERE t1.IdCompany = 3026
    AND t1.IsDeletado = 0
    AND t1.Issuance >= t2.InitialDateFwd
    AND t1.Issuance < t2.EndDateFwd
),
tb_sales_history_fwd_agg AS (
    SELECT
        [Description],
        IdEnterprisePriceGroups,
        avg(SalePrice) AS AvgPriceFwd,
        sum(SalePrice * Quantity) / DATEDIFF(day, min(InitialDateFwd), LEAST(MAX(EndDateFwd), (SELECT MAX(Issuance) FROM tb_sales_history_fwd))) AS RevenueFwd
    FROM tb_sales_history_fwd
    GROUP BY [Description], IdEnterprisePriceGroups
),
tb_sales_history_back AS (
    SELECT
        t1.[Description],
        t2.IdEnterprisePriceGroups,
        avg(t1.SalePrice) AS AvgPriceBack,
        sum(SalePrice * Quantity) / DATEDIFF(day, min(t2.InitialDateBack), max(t2.EndDateBack)) AS RevenueBack
    FROM Enterprise_Sales_History AS t1
    JOIN tb_affiliate AS t2
    ON t1.Affiliate = t2.Affiliate
    WHERE t1.IdCompany = 3026
    AND t1.IsDeletado = 0
    AND t1.Issuance >= t2.InitialDateBack
    AND t1.Issuance < t2.EndDateBack
    GROUP BY t1.[Description], t2.IdEnterprisePriceGroups
),
tb_combine AS (
    SELECT
        t1.*,
        t2.AvgPriceFwd,
        t2.RevenueFwd,
        t3.RevenueBack,
        t3.AvgPriceBack
    FROM tb_pp AS t1
    LEFT JOIN tb_sales_history_fwd_agg AS t2
    ON t1.IdEnterprisePriceGroups = t2.IdEnterprisePriceGroups
    AND t1.[Description] = t2.[Description]
    LEFT JOIN tb_sales_history_back AS t3
    ON t1.IdEnterprisePriceGroups = t3.IdEnterprisePriceGroups
    AND t1.[Description] = t3.[Description]
)
SELECT
	DATEPART(YEAR, EndDateBack) AS Ano,    
    DATEPART(MONTH, EndDateBack) AS Mes,  
    SUM(CASE WHEN Action = 0 THEN 1 ELSE 0 END) AS Approved,
    SUM(CASE WHEN Action <> 0 THEN 1 ELSE 0 END) AS Reproved,
    SUM(
        CASE WHEN AvgPriceFwd IS NOT NULL
        AND ABS(AvgPriceFwd - SuggestedPrice) <= 0.01
        THEN RevenueFwd ELSE 0 END
    ) AS DailyRevenueAdoptionSuggested,
    SUM(
        CASE WHEN AvgPriceFwd IS NOT NULL
        AND ABS(AvgPriceFwd - SuggestedPrice) > 0.01
        THEN RevenueFwd ELSE 0 END
    ) AS DailyRevenueRejectionSuggested,
    SUM(
        CASE WHEN AvgPriceFwd IS NULL
        THEN 1 ELSE 0 END
    ) AS UnknownPrice
FROM tb_combine
GROUP BY DATEPART(YEAR, EndDateBack), DATEPART(MONTH, EndDateBack);


----------------------------------------------------------------- PRODUCAO (PUBLISHED) -----------------------------------------------------------------

-------------- ADOÇÃO --------------

declare @FILIAL as NVARCHAR(100);
set @FILIAL = '303071';

WITH tb_groups AS (
    SELECT  
        DataHoraCriacao,
        PublishedDate,
        IdEnterprisePriceGroups
    FROM Enterprise_Price_Groups AS t1
    WHERE IdCompany = 3026
    AND IsDeletado = 0
    AND Published = 1
    AND PublishedDate IS NOT NULL
    AND CalcDate IS NOT NULL   
),
tb_filters AS (
    SELECT F.IdEnterprisePriceGroups, DF.dbField, F.[Value] AS Affiliate
    FROM Enterprise_Price_Groups_Filter AS F
    JOIN EnterprisePriceGroups_DefaultFilter AS DF
    ON F.IdEnterprisePriceGroups_DefaultFilter = DF.IdEnterprisePriceGroups_DefaultFilter
    WHERE DF.IdCompany = 3026
    AND F.IsDeleted = 0
    AND DF.dbField = 7 -- Affiliate
),
tb_affiliate AS (
    SELECT
        t1.*,
        t2.Affiliate,
        DATEADD(day, -30, t1.PublishedDate) AS InitialDateBack,
        t1.PublishedDate AS EndDateBack,
        DATEADD(day, 7, t1.PublishedDate) AS InitialDateFwd,
        DATEADD(
            day,
            0,
            coalesce(lead(t1.PublishedDate) OVER (ORDER BY t1.PublishedDate DESC), GETDATE())
        ) AS EndDateFwd
    FROM tb_groups AS t1
    JOIN tb_filters AS t2
    ON t1.IdEnterprisePriceGroups = t2.IdEnterprisePriceGroups
    WHERE CAST(t2.Affiliate AS nvarchar) = @FILIAL
),
tb_pp AS (
    SELECT
        t2.DataHoraCriacao,
        t2.Affiliate,
        t2.IdEnterprisePriceGroups,
        pp.ProductName AS Description,
        pp.AffiliateName,
        ppwa.[Action],
		t2.EndDateBack,
        CASE
            WHEN vo.identerprisevaluesoverrides IS NOT NULL THEN vo.price
            ELSE pp.saleprice
        END AS SuggestedPrice,
        pp.SalePrice AS IAPrice,
        pp.LastSalePrice AS LastSalePrice
    FROM Enterprise_Prices_Projection AS pp
    JOIN tb_affiliate AS t2
    ON pp.IdEnterprisePriceGroups = t2.IdEnterprisePriceGroups
    LEFT JOIN enterprise_values_overrides vo
    ON vo.projectionsreference = pp.projectionsreference
    JOIN enterprisepriceprojection_workflow ppw
    ON ppw.identerprisepriceprojection = pp.IdEnterprisePricesProjection
    JOIN enterprisepriceprojection_workflowaction ppwa
    ON ppwa.idpriceprojection_workflow = ppw.IdEnterprisePriceProjection_Workflow
),
tb_sales_history_fwd AS (
    SELECT
        t1.[Description],
        t2.InitialDateFwd,
        t2.EndDateFwd,
        t2.IdEnterprisePriceGroups,
        t1.Issuance,
        t1.SalePrice
    FROM Enterprise_Sales_History AS t1
    JOIN tb_affiliate AS t2
    ON t1.Affiliate = t2.Affiliate
    WHERE t1.IdCompany = 3026
    AND t1.IsDeletado = 0
    AND t1.Issuance >= t2.InitialDateFwd
    AND t1.Issuance < t2.EndDateFwd
),
tb_sales_history_fwd_agg AS (
    SELECT
        [Description],
        IdEnterprisePriceGroups,
        avg(SalePrice) AS AvgPriceFwd
    FROM tb_sales_history_fwd
    GROUP BY [Description], IdEnterprisePriceGroups
),
tb_sales_history_back AS (
    SELECT
        t1.[Description],
        t2.IdEnterprisePriceGroups,
        avg(t1.SalePrice) AS AvgPriceBack
    FROM Enterprise_Sales_History AS t1
    JOIN tb_affiliate AS t2
    ON t1.Affiliate = t2.Affiliate
    WHERE t1.IdCompany = 3026
    AND t1.IsDeletado = 0
    AND t1.Issuance >= t2.InitialDateBack
    AND t1.Issuance < t2.EndDateBack
    GROUP BY t1.[Description], t2.IdEnterprisePriceGroups
),
tb_combine AS (
    SELECT
        t1.*,
        t2.AvgPriceFwd,
        t3.AvgPriceBack
    FROM tb_pp AS t1
    LEFT JOIN tb_sales_history_fwd_agg AS t2
    ON t1.IdEnterprisePriceGroups = t2.IdEnterprisePriceGroups
    AND t1.[Description] = t2.[Description]
    LEFT JOIN tb_sales_history_back AS t3
    ON t1.IdEnterprisePriceGroups = t3.IdEnterprisePriceGroups
    AND t1.[Description] = t3.[Description]
)
SELECT
	DATEPART(YEAR, EndDateBack) AS Ano,    
    DATEPART(MONTH, EndDateBack) AS Mes,  
    SUM(CASE WHEN Action = 0 THEN 1 ELSE 0 END) AS Approved,
    SUM(CASE WHEN Action <> 0 THEN 1 ELSE 0 END) AS Reproved,
    SUM(
        CASE WHEN AvgPriceFwd IS NOT NULL
        AND ABS(AvgPriceFwd - SuggestedPrice) <= 0.01
        THEN 1 ELSE 0 END
    ) AS AdoptionSuggested,
    SUM(
        CASE WHEN AvgPriceFwd IS NOT NULL
        AND ABS(AvgPriceFwd - SuggestedPrice) > 0.01
        THEN 1 ELSE 0 END
    ) AS RejectionSuggested,
    SUM(
        CASE WHEN AvgPriceFwd IS NOT NULL
        AND AvgPriceBack IS NOT NULL
        AND ABS(AvgPriceBack - SuggestedPrice) > 0.01
        THEN 1 ELSE 0 END
    ) AS NewPriceSuggested,
    SUM(
        CASE WHEN AvgPriceFwd IS NULL
        THEN 1 ELSE 0 END
    ) AS UnknownPrice 
FROM tb_combine
GROUP BY DATEPART(YEAR, EndDateBack), DATEPART(MONTH, EndDateBack);


-------------- % ADOÇÃO --------------

declare @FILIAL as NVARCHAR(100);
set @FILIAL = '303071';

WITH tb_groups AS (
    SELECT  
        DataHoraCriacao,
        PublishedDate,
        IdEnterprisePriceGroups
    FROM Enterprise_Price_Groups AS t1
    WHERE IdCompany = 3026
    AND IsDeletado = 0
    AND Published = 1
    AND PublishedDate IS NOT NULL
    AND CalcDate IS NOT NULL   
),
tb_filters AS (
    SELECT F.IdEnterprisePriceGroups, DF.dbField, F.[Value] AS Affiliate
    FROM Enterprise_Price_Groups_Filter AS F
    JOIN EnterprisePriceGroups_DefaultFilter AS DF
    ON F.IdEnterprisePriceGroups_DefaultFilter = DF.IdEnterprisePriceGroups_DefaultFilter
    WHERE DF.IdCompany = 3026
    AND F.IsDeleted = 0
    AND DF.dbField = 7 -- Affiliate
),
tb_affiliate AS (
    SELECT
        t1.*,
        t2.Affiliate,
        -- FIXME remover coalesce
        DATEADD(day, -30, t1.PublishedDate) AS InitialDateBack,
        t1.PublishedDate AS EndDateBack,
        DATEADD(day, 7, t1.PublishedDate) AS InitialDateFwd,
        DATEADD(
            day,
            0,
            coalesce(lead(t1.PublishedDate) OVER (ORDER BY t1.PublishedDate DESC), GETDATE())
        ) AS EndDateFwd
    FROM tb_groups AS t1
    JOIN tb_filters AS t2
    ON t1.IdEnterprisePriceGroups = t2.IdEnterprisePriceGroups
    WHERE CAST(t2.Affiliate AS nvarchar) = @FILIAL
),
tb_pp AS (
    SELECT
        t2.DataHoraCriacao,
        t2.Affiliate,
        t2.IdEnterprisePriceGroups,
        pp.ProductName AS Description,
        pp.AffiliateName,
        ppwa.[Action],
		t2.EndDateBack,
        CASE
            WHEN vo.identerprisevaluesoverrides IS NOT NULL THEN vo.price
            ELSE pp.saleprice
        END AS SuggestedPrice,
        pp.SalePrice AS IAPrice,
        pp.LastSalePrice AS LastSalePrice
    FROM Enterprise_Prices_Projection AS pp
    JOIN tb_affiliate AS t2
    ON pp.IdEnterprisePriceGroups = t2.IdEnterprisePriceGroups
    LEFT JOIN enterprise_values_overrides vo
    ON vo.projectionsreference = pp.projectionsreference
    JOIN enterprisepriceprojection_workflow ppw
    ON ppw.identerprisepriceprojection = pp.IdEnterprisePricesProjection
    JOIN enterprisepriceprojection_workflowaction ppwa
    ON ppwa.idpriceprojection_workflow = ppw.IdEnterprisePriceProjection_Workflow
),
tb_sales_history_fwd AS (
    SELECT
        t1.[Description],
        t2.InitialDateFwd,
        t2.EndDateFwd,
        t2.IdEnterprisePriceGroups,
        t1.Issuance,
        t1.SalePrice
    FROM Enterprise_Sales_History AS t1
    JOIN tb_affiliate AS t2
    ON t1.Affiliate = t2.Affiliate
    WHERE t1.IdCompany = 3026
    AND t1.IsDeletado = 0
    AND t1.Issuance >= t2.InitialDateFwd
    AND t1.Issuance < t2.EndDateFwd
),
tb_sales_history_fwd_agg AS (
    SELECT
        [Description],
        IdEnterprisePriceGroups,
        avg(SalePrice) AS AvgPriceFwd
    FROM tb_sales_history_fwd
    GROUP BY [Description], IdEnterprisePriceGroups
),
tb_sales_history_back AS (
    SELECT
        t1.[Description],
        t2.IdEnterprisePriceGroups,
        avg(t1.SalePrice) AS AvgPriceBack
    FROM Enterprise_Sales_History AS t1
    JOIN tb_affiliate AS t2
    ON t1.Affiliate = t2.Affiliate
    WHERE t1.IdCompany = 3026
    AND t1.IsDeletado = 0
    AND t1.Issuance >= t2.InitialDateBack
    AND t1.Issuance < t2.EndDateBack
    GROUP BY t1.[Description], t2.IdEnterprisePriceGroups
),
tb_combine AS (
    SELECT
        t1.*,
        t2.AvgPriceFwd,
        t3.AvgPriceBack
    FROM tb_pp AS t1
    LEFT JOIN tb_sales_history_fwd_agg AS t2
    ON t1.IdEnterprisePriceGroups = t2.IdEnterprisePriceGroups
    AND t1.[Description] = t2.[Description]
    LEFT JOIN tb_sales_history_back AS t3
    ON t1.IdEnterprisePriceGroups = t3.IdEnterprisePriceGroups
    AND t1.[Description] = t3.[Description]
)
SELECT
	DATEPART(YEAR, EndDateBack) AS Ano,    
    DATEPART(MONTH, EndDateBack) AS Mes,  
    SUM(CASE WHEN Action = 0 THEN 1 ELSE 0 END)  * 100.0 / Count(1) AS Approved,
    SUM(CASE WHEN Action <> 0 THEN 1 ELSE 0 END)  * 100.0 / Count(1) AS Reproved,
    SUM(
        CASE WHEN AvgPriceFwd IS NOT NULL
        AND ABS(AvgPriceFwd - SuggestedPrice) <= 0.01
        THEN 1 ELSE 0 END
    )  * 100.0 / Count(1) AS AdoptionSuggested,
    SUM(
        CASE WHEN AvgPriceFwd IS NOT NULL
        AND ABS(AvgPriceFwd - SuggestedPrice) > 0.01
        THEN 1 ELSE 0 END
    )  * 100.0 / Count(1) AS RejectionSuggested,
    SUM(
        CASE WHEN AvgPriceFwd IS NOT NULL
        AND AvgPriceBack IS NOT NULL
        AND ABS(AvgPriceBack - SuggestedPrice) > 0.01
        THEN 1 ELSE 0 END
    )  * 100.0 / Count(1) AS NewPriceSuggested,
    SUM(
        CASE WHEN AvgPriceFwd IS NULL
        THEN 1 ELSE 0 END
    ) * 100.0 / Count(1) AS UnknownPrice 
FROM tb_combine
GROUP BY DATEPART(YEAR, EndDateBack), DATEPART(MONTH, EndDateBack);


---------- MARGEM MEDIA --------------


declare @FILIAL as NVARCHAR(100);  
set @FILIAL = '303071';

WITH tb_groups AS (
    SELECT  
        DataHoraCriacao,
        PublishedDate,
        IdEnterprisePriceGroups
    FROM Enterprise_Price_Groups AS t1
    WHERE IdCompany = 3026
    AND IsDeletado = 0
    AND Published = 1
    AND PublishedDate IS NOT NULL
    AND CalcDate IS NOT NULL   
),
tb_filters AS (
    SELECT F.IdEnterprisePriceGroups, DF.dbField, F.[Value] AS Affiliate
    FROM Enterprise_Price_Groups_Filter AS F
    JOIN EnterprisePriceGroups_DefaultFilter AS DF
    ON F.IdEnterprisePriceGroups_DefaultFilter = DF.IdEnterprisePriceGroups_DefaultFilter
    WHERE DF.IdCompany = 3026
    AND F.IsDeleted = 0
    AND DF.dbField = 7 -- Affiliate
),
tb_affiliate AS (
    SELECT
        t1.*,
        t2.Affiliate,
        -- FIXME remover coalesce
        DATEADD(day, -30, t1.PublishedDate) AS InitialDateBack,
        t1.PublishedDate AS EndDateBack,
        DATEADD(day, 7, t1.PublishedDate) AS InitialDateFwd,
        DATEADD(
            day,
            0,
            coalesce(lead(t1.PublishedDate) OVER (ORDER BY t1.PublishedDate DESC), GETDATE())
        ) AS EndDateFwd
    FROM tb_groups AS t1
    JOIN tb_filters AS t2
    ON t1.IdEnterprisePriceGroups = t2.IdEnterprisePriceGroups
    WHERE CAST(t2.Affiliate AS nvarchar) = @FILIAL
),
tb_pp AS (
    SELECT
        t2.DataHoraCriacao,
        t2.Affiliate,
        t2.IdEnterprisePriceGroups,
        pp.ProductName AS Description,
        pp.AffiliateName,
        ppwa.[Action],
		t2.EndDateBack,
        CASE
            WHEN vo.identerprisevaluesoverrides IS NOT NULL THEN vo.price
            ELSE pp.saleprice
        END AS SuggestedPrice,
        pp.SalePrice AS IAPrice,
        pp.LastSalePrice AS LastSalePrice
    FROM Enterprise_Prices_Projection AS pp
    JOIN tb_affiliate AS t2
    ON pp.IdEnterprisePriceGroups = t2.IdEnterprisePriceGroups
    LEFT JOIN enterprise_values_overrides vo
    ON vo.projectionsreference = pp.projectionsreference
    JOIN enterprisepriceprojection_workflow ppw
    ON ppw.identerprisepriceprojection = pp.IdEnterprisePricesProjection
    JOIN enterprisepriceprojection_workflowaction ppwa
    ON ppwa.idpriceprojection_workflow = ppw.IdEnterprisePriceProjection_Workflow
),
tb_sales_history_fwd AS (
    SELECT
        t1.[Description],
        t2.InitialDateFwd,
        t2.EndDateFwd,
        t2.IdEnterprisePriceGroups,
        t1.Issuance,
        t1.SalePrice,
        t1.PbCost
    FROM Enterprise_Sales_History AS t1
    JOIN tb_affiliate AS t2
    ON t1.Affiliate = t2.Affiliate
    WHERE t1.IdCompany = 3026
    AND t1.IsDeletado = 0
    AND t1.Issuance >= t2.InitialDateFwd
    AND t1.Issuance < t2.EndDateFwd
),
tb_sales_history_fwd_agg AS (
    SELECT
        [Description],
        IdEnterprisePriceGroups,
        avg(SalePrice) AS AvgPriceFwd,
        avg(100 * (SalePrice - PbCost) / SalePrice) AS AvgMarginFwd
    FROM tb_sales_history_fwd
    GROUP BY [Description], IdEnterprisePriceGroups
),
tb_sales_history_back AS (
    SELECT
        t1.[Description],
        t2.IdEnterprisePriceGroups,
        avg(t1.SalePrice) AS AvgPriceBack,
        avg(100 * (SalePrice - PbCost) / SalePrice) AS AvgMarginBack
    FROM Enterprise_Sales_History AS t1
    JOIN tb_affiliate AS t2
    ON t1.Affiliate = t2.Affiliate
    WHERE t1.IdCompany = 3026
    AND t1.IsDeletado = 0
    AND t1.Issuance >= t2.InitialDateBack
    AND t1.Issuance < t2.EndDateBack
    GROUP BY t1.[Description], t2.IdEnterprisePriceGroups
),
tb_combine AS (
    SELECT
        t1.*,
        t2.AvgPriceFwd,
        t2.AvgMarginFwd,
        t3.AvgMarginBack,
        t3.AvgPriceBack
    FROM tb_pp AS t1
    LEFT JOIN tb_sales_history_fwd_agg AS t2
    ON t1.IdEnterprisePriceGroups = t2.IdEnterprisePriceGroups
    AND t1.[Description] = t2.[Description]
    LEFT JOIN tb_sales_history_back AS t3
    ON t1.IdEnterprisePriceGroups = t3.IdEnterprisePriceGroups
    AND t1.[Description] = t3.[Description]
)
SELECT
	DATEPART(YEAR, EndDateBack) AS Ano,    
    DATEPART(MONTH, EndDateBack) AS Mes,  
    AVG(
        CASE WHEN AvgPriceFwd IS NOT NULL
        AND ABS(AvgPriceFwd - SuggestedPrice) <= 0.01
        THEN AvgMarginFwd END
    ) AS AvgMarginAdoptionSuggested,
    AVG(
        CASE WHEN AvgPriceFwd IS NOT NULL
        AND ABS(AvgPriceFwd - SuggestedPrice) > 0.01
        THEN AvgMarginFwd END
    ) AS AvgMarginRejectionSuggested,
    SUM(
        CASE WHEN AvgPriceFwd IS NULL
        THEN 1 ELSE 0 END
    ) AS UnknownPrice
FROM tb_combine
GROUP BY DATEPART(YEAR, EndDateBack), DATEPART(MONTH, EndDateBack);


---------- RECEITA ---------------

declare @FILIAL as NVARCHAR(100);  
set @FILIAL = '303071';

WITH tb_groups AS (
    SELECT  
        DataHoraCriacao,
        PublishedDate,
        IdEnterprisePriceGroups
    FROM Enterprise_Price_Groups AS t1
    WHERE IdCompany = 3026
    AND IsDeletado = 0
    AND Published = 1
    AND PublishedDate IS NOT NULL
    AND CalcDate IS NOT NULL   
),
tb_filters AS (
    SELECT F.IdEnterprisePriceGroups, DF.dbField, F.[Value] AS Affiliate
    FROM Enterprise_Price_Groups_Filter AS F
    JOIN EnterprisePriceGroups_DefaultFilter AS DF
    ON F.IdEnterprisePriceGroups_DefaultFilter = DF.IdEnterprisePriceGroups_DefaultFilter
    WHERE DF.IdCompany = 3026
    AND F.IsDeleted = 0
    AND DF.dbField = 7 -- Affiliate
),
tb_affiliate AS (
    SELECT
        t1.*,
        t2.Affiliate,
        -- FIXME remover coalesce
        DATEADD(day, -30, t1.PublishedDate) AS InitialDateBack,
        t1.PublishedDate AS EndDateBack,
        DATEADD(day, 7, t1.PublishedDate) AS InitialDateFwd,
        DATEADD(
            day,
            0,
            coalesce(lead(t1.PublishedDate) OVER (ORDER BY t1.PublishedDate DESC), GETDATE())
        ) AS EndDateFwd
    FROM tb_groups AS t1
    JOIN tb_filters AS t2
    ON t1.IdEnterprisePriceGroups = t2.IdEnterprisePriceGroups
    WHERE CAST(t2.Affiliate AS nvarchar) = @FILIAL
),
tb_pp AS (
    SELECT
        t2.DataHoraCriacao,
        t2.Affiliate,
        t2.IdEnterprisePriceGroups,
        pp.ProductName AS Description,
        pp.AffiliateName,
        ppwa.[Action],
		t2.EndDateBack,
        CASE
            WHEN vo.identerprisevaluesoverrides IS NOT NULL THEN vo.price
            ELSE pp.saleprice
        END AS SuggestedPrice,
        pp.SalePrice AS IAPrice,
        pp.LastSalePrice AS LastSalePrice
    FROM Enterprise_Prices_Projection AS pp
    JOIN tb_affiliate AS t2
    ON pp.IdEnterprisePriceGroups = t2.IdEnterprisePriceGroups
    LEFT JOIN enterprise_values_overrides vo
    ON vo.projectionsreference = pp.projectionsreference
    JOIN enterprisepriceprojection_workflow ppw
    ON ppw.identerprisepriceprojection = pp.IdEnterprisePricesProjection
    JOIN enterprisepriceprojection_workflowaction ppwa
    ON ppwa.idpriceprojection_workflow = ppw.IdEnterprisePriceProjection_Workflow
),
tb_sales_history_fwd AS (
    SELECT
        t1.[Description],
        t2.InitialDateFwd,
        t2.EndDateFwd,
        t2.IdEnterprisePriceGroups,
        t1.Issuance,
        t1.SalePrice,
        t1.Quantity
    FROM Enterprise_Sales_History AS t1
    JOIN tb_affiliate AS t2
    ON t1.Affiliate = t2.Affiliate
    WHERE t1.IdCompany = 3026
    AND t1.IsDeletado = 0
    AND t1.Issuance >= t2.InitialDateFwd
    AND t1.Issuance < t2.EndDateFwd
),
tb_sales_history_fwd_agg AS (
    SELECT
        [Description],
        IdEnterprisePriceGroups,
        avg(SalePrice) AS AvgPriceFwd,
        sum(SalePrice * Quantity) / DATEDIFF(day, min(InitialDateFwd), LEAST(MAX(EndDateFwd), (SELECT MAX(Issuance) FROM tb_sales_history_fwd))) AS RevenueFwd
    FROM tb_sales_history_fwd
    GROUP BY [Description], IdEnterprisePriceGroups
),
tb_sales_history_back AS (
    SELECT
        t1.[Description],
        t2.IdEnterprisePriceGroups,
        avg(t1.SalePrice) AS AvgPriceBack,
        sum(SalePrice * Quantity) / DATEDIFF(day, min(t2.InitialDateBack), max(t2.EndDateBack)) AS RevenueBack
    FROM Enterprise_Sales_History AS t1
    JOIN tb_affiliate AS t2
    ON t1.Affiliate = t2.Affiliate
    WHERE t1.IdCompany = 3026
    AND t1.IsDeletado = 0
    AND t1.Issuance >= t2.InitialDateBack
    AND t1.Issuance < t2.EndDateBack
    GROUP BY t1.[Description], t2.IdEnterprisePriceGroups
),
tb_combine AS (
    SELECT
        t1.*,
        t2.AvgPriceFwd,
        t2.RevenueFwd,
        t3.RevenueBack,
        t3.AvgPriceBack
    FROM tb_pp AS t1
    LEFT JOIN tb_sales_history_fwd_agg AS t2
    ON t1.IdEnterprisePriceGroups = t2.IdEnterprisePriceGroups
    AND t1.[Description] = t2.[Description]
    LEFT JOIN tb_sales_history_back AS t3
    ON t1.IdEnterprisePriceGroups = t3.IdEnterprisePriceGroups
    AND t1.[Description] = t3.[Description]
)
SELECT
	DATEPART(YEAR, EndDateBack) AS Ano,    
    DATEPART(MONTH, EndDateBack) AS Mes,  
    SUM(CASE WHEN Action = 0 THEN 1 ELSE 0 END) AS Approved,
    SUM(CASE WHEN Action <> 0 THEN 1 ELSE 0 END) AS Reproved,
    SUM(
        CASE WHEN AvgPriceFwd IS NOT NULL
        AND ABS(AvgPriceFwd - SuggestedPrice) <= 0.01
        THEN RevenueFwd ELSE 0 END
    ) AS DailyRevenueAdoptionSuggested,
    SUM(
        CASE WHEN AvgPriceFwd IS NOT NULL
        AND ABS(AvgPriceFwd - SuggestedPrice) > 0.01
        THEN RevenueFwd ELSE 0 END
    ) AS DailyRevenueRejectionSuggested,
    SUM(
        CASE WHEN AvgPriceFwd IS NULL
        THEN 1 ELSE 0 END
    ) AS UnknownPrice
FROM tb_combine
GROUP BY DATEPART(YEAR, EndDateBack), DATEPART(MONTH, EndDateBack);
