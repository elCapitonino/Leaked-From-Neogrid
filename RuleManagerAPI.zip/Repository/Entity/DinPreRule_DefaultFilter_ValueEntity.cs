﻿namespace Repository.Entity
{
    public sealed class DinPreRule_DefaultFilter_ValueEntity : BaseEntity
    {
        public long DinPreRule_DefaultFilter_ValueId { get; set; }
        public long IdEnterprisePriceGroups_DefaultFilter { get; set; }
        public EnterprisePriceGroups_DefaultFilterEntity? DefaultFilter { get; set; }

        public long IdRule { get; set; }
        public DinPreRuleEntity? Rule { get; set; }

        public string Value { get; set; }

        public bool IsDeletado {  get; set; }
    }
}
