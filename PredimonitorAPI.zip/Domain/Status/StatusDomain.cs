﻿using AutoMapper;
using Domain.Exceptions;
using Domain.Status.Models;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Repository.Entity;
using Repository.Enums;
using Repository.UnitOfWork;
using System.Threading.Tasks;

namespace Domain.Status
{
    public class StatusDomain : IStatusDomain
    {
        private readonly ILogger<StatusDomain> _logger;
        private readonly IUnitOfWork _uow;
        private readonly IMapper _mapper;
        private readonly IMemoryCache _cache;
        private static object _locker = new object();

        public StatusDomain(ILogger<StatusDomain> logger, IUnitOfWork uow, IMapper mapper, IMemoryCache cache)
        {
            _logger = logger;
            _uow = uow;
            _mapper = mapper;
            _cache = cache;
        }
        public IEnumerable<MonitoringItemResultsStatusResponse> GetTaskRunnings()
        {
            var response = _uow.MonitoringItemResultsStatus
                .GetAll()
                .Where(x => x.Status == Repository.Enums.MonitoringItemResultsStatusType.Running)
                .OrderByDescending(x => x.CreateDate)
                .ToList();

            return _mapper.Map<IEnumerable<MonitoringItemResultsStatusResponse>>(response);
        }
        public MonitoringItemResultsStatusResponse GetByCompanyId(long companyId)
        {
            var entity = _uow.MonitoringItemResultsStatus
                .GetAll()
                .Where(x => x.CompanyId == companyId)
                .OrderByDescending(x => x.CreateDate)
                .FirstOrDefault();

            var response = _mapper.Map<MonitoringItemResultsStatusResponse>(entity) ?? new MonitoringItemResultsStatusResponse() { CompanyId = companyId, Status = MonitoringItemResultsStatusType.None, TaskId = Guid.Empty };

            if (_cache.TryGetValue(response.TaskId.Value, out Dictionary<CrawlerSourceType, StatusCacheModel> taskStatus))
            {

                if (taskStatus.Values.Count > 0)
                {
                    var total = taskStatus.Values.FirstOrDefault()?.Total ?? 0;
                    var indexed = taskStatus.Values.Select(x => x.Indexed).Average();


                    if (response.CurrentStep == MonitoringItemResultStatusSteps.REINDEXING_DATABASE && total > 0)
                    {
                        response.Percent = (indexed / (double)total) * 100;
                        response.Total = total;
                        response.Indexed = (int)indexed;
                    }
                }
            }

            return response;
        }

        public MonitoringItemResultsStatusResponse AddOrUpdate(MonitoringItemResultsStatusRequest request)
        {
            request.TaskId ??= Guid.NewGuid();
            var newEntity = _mapper.Map<MonitoringItemResultsStatusEntity>(request);
            newEntity.Status = request.Status;

            using var transaction = _uow.CreateTransactionScope(System.Transactions.TransactionScopeAsyncFlowOption.Enabled);

            try
            {
                var oldEntity = _uow.MonitoringItemResultsStatus.GetAll().FirstOrDefault(x => x.TaskId == request.TaskId);

                newEntity.UpdateDate = DateTime.Now;
                if (oldEntity == null)
                {
                    newEntity.CreateDate = DateTime.Now;
                    _uow.MonitoringItemResultsStatus.Create(newEntity);
                    transaction.Complete();
                    return _mapper.Map<MonitoringItemResultsStatusResponse>(newEntity);
                }
                else
                {
                    _mapper.Map(request, oldEntity);

                    if (request.Status != MonitoringItemResultsStatusType.None)
                        oldEntity.Status = request.Status;

                    _logger.LogInformation("Atualizando status: Status:{Status} - Step:{Step} - Message: {Message}", oldEntity.Status.ToString(), oldEntity.CurrentStep, oldEntity.Message);
                    _uow.MonitoringItemResults.SaveChanges();
                    transaction.Complete();
                    return _mapper.Map<MonitoringItemResultsStatusResponse>(oldEntity);
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao atualizar status");
                transaction.Dispose();
                throw;
            }



        }
        public void AddToCache(Guid? taskId)
        {
            if (taskId.HasValue)
            {
                if (_cache.TryGetValue(taskId, out Dictionary<CrawlerSourceType, StatusCacheModel> cacheModel))
                {
                    _cache.Remove(taskId);

                }

                _cache.Set(taskId, new Dictionary<CrawlerSourceType, StatusCacheModel>());
            }
        }

        public void UpdateCache(StatusCacheModel model)
        {
            if (model.TaskId.HasValue)
            {

                if (_cache.TryGetValue(model.TaskId, out Dictionary<CrawlerSourceType, StatusCacheModel> cacheModel))
                {
                    lock (_locker)
                    {
                        if (cacheModel.ContainsKey(model.SourceType))
                        {
                            var entity = cacheModel[model.SourceType];
                            entity.Status = model.Status;
                            entity.Message = model.Message;
                            entity.Total = model.Total;
                            entity.Indexed = model.Indexed;

                        }
                        else
                            cacheModel.Add(model.SourceType, model);
                    }

                }
                else
                {
                    throw new NotFoundException("TaskId não encontrado no cache");
                }
            }
        }

        public void RemoveCache(Guid taskId)
        {
            if (_cache.TryGetValue(taskId, out Dictionary<CrawlerSourceType, StatusCacheModel> cacheModel))
            {
                _cache.Remove(taskId);
            }
            else
            {
                throw new NotFoundException("TaskId não encontrado no cache");
            }
        }

        public Dictionary<CrawlerSourceType, StatusCacheModel> GetTaskStatus(Guid taskId)
        {
            if (_cache.TryGetValue(taskId, out Dictionary<CrawlerSourceType, StatusCacheModel> cacheModel))
            {
                return cacheModel;
            }
            else
            {
                throw new NotFoundException("TaskId não encontrado no cache");
            }
        }


    }
}
