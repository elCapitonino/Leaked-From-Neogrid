﻿using Repository.Enums;

namespace Repository.Entity
{
    public class CompanyMonitoringCrawlerEntity : BaseEntity
    {
        public long CompanyId { get; set; }

        public int MonitoringCrawlerId { get; set; }
        public MonitoringCrawlerEntity MonitoringCrawler { get; set; }

        public PreSegmentoSource? Source { get; set; }

        public CrawlersTypes? CrawlerType { get; set; }

        public string? Store { get; set; }

        public string? StoreType { get; set; }

        public string? City { get; set; }

        public string? State { get; set; }

        public string? Networks { get; set; }

        public string? Cnpj { get; set; }

        public bool ExactVector { get; set; } = true;

        public bool UseInPricing { get; set; } = true;

        public bool IsSale { get; set; }

        public bool IsCost { get; set; }

        public bool IsDeleted { get; set; }

        public bool IsNewPredimonitorTemp { get; set; }

        public ICollection<CompanyMonitoringCrawlerFiltersEntity>? CompanyMonitoringCrawlerFilters { get; set; }
    }
}
