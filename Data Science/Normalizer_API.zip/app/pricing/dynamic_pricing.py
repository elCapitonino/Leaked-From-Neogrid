import threading
from datetime import datetime
from time import sleep
from norm.conect_mongo import MongoConnect
import requests
from fastapi.encoders import jsonable_encoder


class DynamicPricing(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)
        self.dbMongo = MongoConnect()
        self.start()
        self.status = True
        self.url_precificacao = 'https://web-service.predify.me/api/V2/Monitoring/CalculateMarketResult'
        self.url_token = 'https://web-service.predify.me/token'
        self._event = threading.Event()

    def set_status(self, status):
        self.status = status
        print("status: ", self.status)

    def pause(self):
        self.status = True

        print("precificação dinamica Pausa --- ",
              datetime.now().strftime('%d-%m-%Y %H:%M:%S.%f'))
        # self._event.clear()
        self._event.wait()

    def resume(self, status):
        self.status = status

        print("precificação dinamica iniciada --- ",
              datetime.now().strftime('%d-%m-%Y %H:%M:%S.%f'))
        self._event.set()

    def run(self):

        while True:
            print("precificação dinamica iniciada --- ",
                  datetime.now().strftime('%d-%m-%Y %H:%M:%S.%f'))
            self.pause()

            data = {'grant_type': 'password', 'username': 'usuariopython@predify.me',
                    'password': 'bEQumLSP0tr14efugAqe', 'client_id': 'multiverso-emp-angularjs-app'}
            auth_token = requests.get(url=self.url_token,
                                      data=data)
            hed = {'Authorization': 'Bearer ' +
                   auth_token.json()['access_token']}

            dict_company = {}
            calculated_status = self.dbMongo.get_calculated_status()
            calculated_status_list = list(calculated_status)
            for i in calculated_status_list:
                if i['id_company'] in dict_company:
                    dict_company[i['id_company']].append(i['id_task'])
                else:
                    dict_company[i['id_company']] = [i['id_task']]
            for j in dict_company:
                notificar_precificacao = True
                for task_id in dict_company[j]:
                    id_task_to_norm = self.dbMongo.get_id_task_to_norm(
                        task_id)
                    id_task_to_norm_list = list(id_task_to_norm)
                    if len(id_task_to_norm_list) > 0:
                        notificar_precificacao = False
                        break
                    if len(id_task_to_norm_list) == 0:
                        notificar_precificacao = True

                if notificar_precificacao == True:
                    resp = requests.get(url=self.url_precificacao, params=(
                        {'idCompany': j}), headers=hed)
                    print("resp ", resp.json())
                    if resp.json()['success'] == True:
                        print("notificar_precificacao ", j)
                        for task_id in dict_company[j]:
                            self.dbMongo.update_id_task_to_norm(task_id)
            print("precificação dinamica pausa --- ",
                  datetime.now().strftime('%d-%m-%Y %H:%M:%S.%f'))

            sleep(7200)
