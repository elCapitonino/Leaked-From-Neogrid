﻿using PH.Domain.DTO;

namespace PH.Domain.Interfaces.Repositories
{
    public interface IGraficoRepository
    {
        Task<List<GraficoDTO>> Get(string? loja, string? curva, string? categoria);
        Task<List<GraficoReceitaDTO>> GetGraficoReceita(long idCompany, string? loja);
    }
}
