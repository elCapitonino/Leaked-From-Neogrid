﻿using PredifyClientAPI.Services.PredifyAPI.Access.Models;

namespace PredifyClientAPI.Services.PredifyAPI.Access
{
    public interface IAccessService
    {
        Task<AccessTokenResponse> Login(LoginRequest request);

        Task<bool> UserHasAccess(long companyId);
    }
}
