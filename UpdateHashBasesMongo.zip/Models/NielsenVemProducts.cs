﻿using MongoDB.Bson;

namespace UpdateHash.Models
{
    public class NielsenVemProducts
    {
        public ObjectId _id { get; set; }
        public int? WEEK_ID { get; set; }
        public int? STORE_ID { get; set; }
        public string STORE { get; set; }
        public string STORE_ADDRESS { get; set; }
        public string STATE { get; set; }
        public string RETAILER { get; set; }
        public string BANNER { get; set; }
        public string FORMAT_MARKET { get; set; }
        public string CATEGORY { get; set; }
        public string MANUFACTURER { get; set; }
        public string BRAND { get; set; }
        public string PRODUCT_DESCRIPTION { get; set; }
        public string EAN { get; set; }
        public double? WEEKLY_PRICE { get; set; }
        public string STORE_NAME { get; set; }
        public string STATE_UF { get; set; }
        public DateTime? DATE { get; set; }
        public string CITY { get; set; }
        public string ZONE { get; set; }
    }
}
