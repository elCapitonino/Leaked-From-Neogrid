﻿using MongoDB.Driver;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UpdateHash.Models;
using UpdateHashHorus;

namespace UpdateHash.Handlers
{
    public class IndiretaHandler
    {
        private readonly MongoClient _client;

        public IndiretaHandler(MongoClient client)
        {
            _client = client;
        }

        public async Task ExecuteAsync(string baseName, string collectionName, DateTime startDate, DateTime endDate, int batchSize, bool dryRun = false)
        {
            var database = _client.GetDatabase(baseName);
            var collection = database.GetCollection<IndiretaProducts>(collectionName);

            var filter = Builders<IndiretaProducts>.Filter.And(
                Builders<IndiretaProducts>.Filter.Gte(doc => doc.ULTIMAVENDA, startDate),
                Builders<IndiretaProducts>.Filter.Lte(doc => doc.ULTIMAVENDA, endDate)
            );

            var projection = Builders<IndiretaProducts>.Projection
                .Include(doc => doc.DESCRICAOOPRODUTO)
                .Include(doc => doc.EANPRODUTO)
                .Include(doc => doc.NOMEDISTRIBUIDOR);

            int take = batchSize;
            int skip = 0;

            while (true)
            {
                Log.Information("Buscando Produtos");

                var documents = await collection.Find(filter)
                                                 .Sort(Builders<IndiretaProducts>.Sort.Descending(doc => doc.ULTIMAVENDA))
                                                 .Skip(skip)
                                                 .Limit(take)
                                                 .Project<IndiretaProducts>(projection)
                                                 .ToListAsync();

                if (documents.Count == 0)
                {
                    break;
                }

                Log.Information("Atualizando Produtos");

                var updates = new List<WriteModel<IndiretaProducts>>();

                foreach (var doc in documents)
                {
                    var ean = doc.EANPRODUTO;
                    var store = doc.NOMEDISTRIBUIDOR;

                    var concatenatedString = $"{ean}|{store}";

                    var hashValue = Utils.CalculateSHA256(concatenatedString);

                    var filterDoc = Builders<IndiretaProducts>.Filter.Eq("_id", doc._id);
                    var update = Builders<IndiretaProducts>.Update.Set("HASH", hashValue);
                    updates.Add(new UpdateOneModel<IndiretaProducts>(filterDoc, update));
                }

                if (!dryRun)
                    await collection.BulkWriteAsync(updates);

                Log.Information($"Atualizados {skip + take} documentos");

                skip += take;
            }
        }
    }
}
