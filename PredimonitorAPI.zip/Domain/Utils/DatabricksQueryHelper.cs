﻿using Azure.Core;
using Domain.CompanyMonitoringCrawler;
using Domain.Filter.Models;
using Domain.Product.Models;
using Repository.Entity;
using Repository.Models.Databricks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Utils
{
    public class DatabricksQueryHelper
    {
        private static readonly List<string> _validOperatorsComparison = ["=", "<>", "!=", "<", ">", "<=", ">="];
        private static readonly List<string> _validOperatorsList = ["IN", "NOT IN"];
        private static readonly List<string> _validOperatorsLike = ["LIKE", "NOT LIKE"];

        public static List<QueryFilter> CreateFilterBaseFilters(FilterRequest request, List<CompanyMonitoringCrawlerEntity> companyCrawlers, QueryIgnore? ignore = null)
        {
            var filters = new List<QueryFilter>();

            var crawlerIds = GetCrawlerIds(ignore != QueryIgnore.Crawler ? request.Origins : null, companyCrawlers);

            filters.Add(new() { Column = "CrawlerId", Operator = "IN", Value = crawlerIds });

            if (ignore != QueryIgnore.Name)
            {
                filters.Add(new() { Column = "Name", Operator = "IN", Value = request.ProductNames });
            }

            if (ignore != QueryIgnore.Category)
            {
                filters.Add(new() { Column = "Category", Operator = "IN", Value = request.Categories });
            }

            if (ignore != QueryIgnore.Seller)
            {
                filters.Add(new() { Column = "Seller", Operator = "IN", Value = request.Sellers });
            }

            if (ignore != QueryIgnore.Brand)
            {
                filters.Add(new() { Column = "Brand", Operator = "IN", Value = request.Brands });
            }

            if (ignore != QueryIgnore.UF)
            {
                filters.Add(new() { Column = "UF", Operator = "IN", Value = request.States });
            }

            if (ignore != QueryIgnore.Year)
            {
                filters.Add(new() { Column = "Year", Operator = "IN", Value = request.Years });
            }

            if (ignore != QueryIgnore.Region)
            {
                filters.Add(new() { Column = "Region", Operator = "IN", Value = request.Regions });
            }

            if (ignore != QueryIgnore.Segment)
            {
                filters.Add(new() { Column = "Segment", Operator = "IN", Value = request.Segments });
            }

            return filters;
        }

        public static List<QueryFilter> CreateResultBaseFilters(FiltersRequest request, List<CompanyMonitoringCrawlerEntity> companyCrawlers)
        {
            var crawlerIds = GetCrawlerIds(request.Origins, companyCrawlers);

            var filters = new List<QueryFilter>
            {
                new(){ Column = "CrawlerId", Operator = "IN", Value = crawlerIds },
                new(){ Column = "p.Id", Operator = "IN", Value = request.ProductIds },
                new(){ Column = "Name", Operator = "IN", Value = request.ProductNames },
                new(){ Column = "Category", Operator = "IN", Value = request.Categories },
                new(){ Column = "Seller", Operator = "IN", Value = request.Sellers },
                new(){ Column = "Brand", Operator = "IN", Value = request.Brands },
                new(){ Column = "UF", Operator = "IN", Value = request.States },
                new(){ Column = "Year", Operator = "IN", Value = request.Years },
                new(){ Column = "Segment", Operator = "IN", Value = request.Segments },
                new(){ Column = "CAST(pp.CollectedDate AS DATE)", Operator = ">=", Value = request.StartDate.ToString("yyyy-MM-dd") },
                new(){ Column = "CAST(pp.CollectedDate AS DATE)", Operator = "<=", Value = request.EndDate.ToString("yyyy-MM-dd") },
                new(){ Column = "Region", Operator = "IN", Value = request.Regions},
                new(){ Column = "Mileage", Operator = ">=", Value = request.Kilometers?.Min ?? null},
                new(){ Column = "Mileage", Operator = "<=", Value = request.Kilometers?.Max ?? null},
                new(){ Column = "Model", Operator = "IN", Value = request.Models},
                new(){ Column = "ip.ProductPriceId", Operator = "IS", Value = "NULL" } //remove os ignorados
            };

            return filters;
        }

        private static List<int> GetCrawlerIds(List<string> crawlerNames, List<CompanyMonitoringCrawlerEntity> companyCrawlers)
        {
            var crawlerIds = CompanyMonitoringCrawlerDomain.GetCrawlerIdsByNames(crawlerNames, companyCrawlers, true);

            if (crawlerIds == null || crawlerIds.Count <= 0)
            {
                throw new ArgumentException($"It is necessary to filter by one crawler id at least");
            }

            return crawlerIds;
        }

        public static IEnumerable<QuerySQL> CreateCompanyMandatoryFilters(List<CompanyMonitoringCrawlerEntity> companyCrawlers)
        {
            var response = new List<QuerySQL>();

            foreach (var companyCrawler in companyCrawlers)
            {
                var filters = companyCrawler.CompanyMonitoringCrawlerFilters?.Where(x => !x.IsDeleted).ToList();

                if (filters == null || filters.Count <= 0)
                    continue;

                string sqlClause = $"(CrawlerId = {companyCrawler.MonitoringCrawlerId}";

                foreach (var filter in companyCrawler.CompanyMonitoringCrawlerFilters)
                {
                    var filterValues = filter.CompanyMonitoringCrawlerFiltersValues?
                                            .Where(x => !x.IsDeleted)
                                            .Select(x => x.Values.Replace("'", "''"))
                                            .ToList();

                    var typeOperator = ValidateSqlOperator(filter.Operator);

                    string formattedValues = string.Join(", ", filterValues.Select(v => $"'{v}'"));

                    switch (typeOperator)
                    {
                        case "List":
                            sqlClause += $" AND {filter.Field} {filter.Operator} ({formattedValues})";
                            break;

                        case "Like":
                            sqlClause += $" AND {filter.Field} {filter.Operator} '%{filterValues.First()}%'";
                            break;

                        case "Standard":
                            sqlClause += $" AND {filter.Field} {filter.Operator} '{filterValues.First()}'";
                            break;
                    }

                }

                sqlClause += ")";

                if (!string.IsNullOrEmpty(sqlClause))
                {
                    response.Add(new QuerySQL() { SQL = sqlClause });
                }
            }

            return response;
        }

        public static string ValidateSqlOperator(string sqlOperator)
        {
            string normalizedOperator = sqlOperator.ToUpper().Trim();

            if (_validOperatorsComparison.Contains(normalizedOperator))
            {
                return "Standard";
            }
            else if (_validOperatorsList.Contains(normalizedOperator))
            {
                return "List";
            }
            else if (_validOperatorsLike.Contains(normalizedOperator))
            {
                return "Like";
            }

            throw new ArgumentException($"Invalid operator {sqlOperator}");
        }
    }
}