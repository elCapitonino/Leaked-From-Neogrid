﻿namespace DI.Repository.Entities
{
    public sealed class MonthlySaleHistoryDataEntity : BaseEntity
    {
        public required long CompanyId { get; set; }
        public Guid GranularityGroupId { get; set; }
        public GranularityGroupEntity? GranularityGroup { get; set; }
        public string? ProductId { get; set; }
        public required int YearMonth { get; set; }
        public string? MajorGranularity { get; set; }
        public string? ConsolidateGroupBy { get; set; }

        public decimal Revenue { get; set; }
        public decimal Profit { get; set; }
        public decimal TotalQuantity { get; set; }
        public decimal AveragePrice { get; set; }
        public decimal AverageCost { get; set; }
        public decimal Margin { get; set; }
        public decimal TotalCost { get; set; }
        public decimal RoyaltyPercentage { get; set; }
        public decimal RoyaltyReal { get; set; }

        public DateTime FirstSale { get; set; }
        public DateTime LastSale { get; set; }
    }
}
