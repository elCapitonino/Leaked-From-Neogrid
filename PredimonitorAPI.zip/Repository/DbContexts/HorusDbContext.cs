﻿using Microsoft.EntityFrameworkCore;
using MongoDB.Driver;
using Repository.DbContexts.Bases;

namespace Repository.DbContexts
{
    public class HorusDbContext : MongoDbContextBase
    {

        public HorusDbContext(DbContextOptions<HorusDbContext> options, IMongoClient mongoClient) : base(options, mongoClient)
        {

        }
        public override string DbContextName => nameof(HorusDbContext);
    }
}
