import re
from predimonitor_type import *
from async_mongo import AsyncMongoConnect
from logger import logger


class Search_neogrid():

    def __init__(self):
        self.dbMongo = AsyncMongoConnect()

    #obsoleto
    def search_get(self, id_crawlers_offline, data_source, products, start_date, end_date):

        result_list = []

        return result_list

    #obsoleto
    async def search_get_V1(self, id_crawlers_offline, data_source, products, start_date, end_date):

        result_list = []

        ean = None
        if (products != None):
            if ((products[0].ean != None) and (len(products[0].ean) > 1)):
                ean = products[0].ean

        for crawler in id_crawlers_offline:
            if crawler.idcrawlers != 172:
                continue

        try:
            result_neogrid = await self.dbMongo.get_product_search_neogrid_ecoa_by_date(start_date, end_date, ean)

            for documento in result_neogrid:
                
                item = documento['documento']
                if 'url' not in item:
                    item['url'] = item['_id']

                name = item['product_name']
                    
                result_list.append({'id': str(item['_id']),
                                            'id_crawler': 172,
                                            "product_name": name,
                                            "product_link": str(item['url']),
                                            "product_ean": item['product_ean'],
                                            "site_sku": 0,
                                            "source": "Neogrid",
                                            "language": "pt-br",
                                            "product_brand": None,
                                            "id_product_normalized": None,
                                            "trash_score": 0,
                                            "crawler_date": item["crawler_date"],
                                            "sellers": [
                    {"seller_name": item["sellers"][0]['seller_name'],
                        "prices":[{'price': float(str(item["sellers"][0]['prices'][0]['price'])),
                                "price_currency": "BRL"}]
                        }],
                     "product_local":
                     {'state': item['product_local']["state"],
                         'city': item['product_local']["city"]},
                    # "product_manufacture_year": None,
                    # "product_used_hours": None
                })
        except Exception as ex:
            print(" ------ Erro dados neogrid  ------")
            print(str(ex))
                    
        return result_list
    
    #obsoleto
    async def search_get_v2(self, products):
        full_result = []
        ean_where = []
        start_date = ""
        end_date = ""

        lista_result = []
        result_list = []
        
        if (products.filters.eans != None and len(products.filters.eans) != 0):
            filtered_eans = []
            if(len(products.filters.products) > 0):
                for ean_obj in products.filters.eans:
                    if ean_obj.description is not None:
                        for product in products.filters.products:
                            if re.match(ean_obj.description, product):
                                    filtered_eans.append(ean_obj.ean)
                ean_where.extend(filtered_eans)
            else:
                logger.debug("Error: Produto não encontrado no momento da verificação dos eans.")


        if (products.start_date != None and products.end_date != None):
            start_date = products.start_date
            end_date = products.end_date

        # data=2022-09-11 23:59:56,

        try:
            if (ean_where != None and ean_where.count != 0 and start_date != "" and end_date != ""):
                for ean in ean_where:
                    result_ean = await self.dbMongo.get_product_search_neogrid_ecoa_by_date_v2(start_date, end_date, ean)
                    if (result_ean != None):
                        lista_result.append(result_ean)

            for documento in lista_result[0]:
                
                try:
                    item = documento
                    if 'url' not in item:
                        item['url'] = item['_id']

                    name = item['product_name']
                    # if result_produto != None:
                    #     name = result_produto['product_name']    
                    
                    result_list.append({'id': str(item['_id']),
                                            'id_crawler': 172,
                                            "product_name": name,
                                            "product_link": str(item['url']),
                                            "product_ean": item['product_ean'],
                                            "site_sku": 0,
                                            "source": "Neogrid",
                                            "language": "pt-br",
                                            "product_brand": None,
                                            "id_product_normalized": None,
                                            "trash_score": 0,
                                            "crawler_date": item["crawler_date"],
                                            'seller_name': item["sellers"][0]['seller_name'],
                                            'sellercpf_cnpj': item["sellers"][0]['cnpj_seller'] if item["sellers"][0]['cnpj_seller'] is not None else None,
                                            "prices": [{
                                                        'price': float(str(item["sellers"][0]['prices'][0]['price'])),
                                                        'price_unit': None,
                                                        'total_price_value': float(str(item["sellers"][0]["prices"][0]["total_price_value"])) if "total_price_value" in item["sellers"][0]["prices"][0] and item["sellers"][0]["prices"][0]["total_price_value"] else float(str(item["sellers"][0]['prices'][0]['price'])) * float(str(item["sellers"][0]["prices"][0]["total_quantity_sold"])),
                                                        'total_quantity_sold': float(str(item["sellers"][0]["prices"][0]["total_quantity_sold"])) if item["sellers"][0]["prices"][0]["total_quantity_sold"] is not None else None
                                                      }],
                                            "product_local":
                                                      {
                                                       'state': item['product_local']["state"],
                                                       'city': item['product_local']["city"]
                                                      },
                                            "product_manufacture_year": None,
                                            "product_used_hours": None, 
                                            "product_segment": None
                    })

                except Exception as ex:
                    print(" ------ Erro dados neogrid V2  ------")
                    print(str(ex))

            full_result.append({
                "product": products.filters.products[0],
                "result": result_list
            })

        except Exception as ex:
            print(" ------ Erro dados neogrid V2  ------")
            print(str(ex))

        return full_result
    
    #obsoleto
    async def search_get_Ecoa_v3v2(self, products):
        ean_where = []
        start_date = ""
        end_date = ""
        full_result = []
        result_list = []

        if (products.filters.eans is not None and len(products.filters.eans) != 0):
            for i in products.filters.eans:
                ean_where.append(i.ean)

        if (products.start_date is not None and products.end_date is not None):
            start_date = products.start_date
            end_date = products.end_date

        states = None
        if (products.idcrawlers_offline is not None):
            states = [obj.state for obj in products.idcrawlers_offline]
            states = list(filter(lambda x: x is not None and x !=
                                 '' and x.strip() != '', states))

        if (len(ean_where) > 0 and start_date != "" and end_date != ""):
            try:
                for ean in ean_where:
                    result_ean = await self.dbMongo.get_product_search_neogrid_ecoa_v3_v2(start_date, end_date, ean, states)
                    if (result_ean is None):
                        continue
                    result_list = []
                    for documento in result_ean:
                        try:
                            item = documento
                            name = item['product_name']
                            result_list.append({'id': str(item['_id']),
                                                    'id_crawler': 172,
                                                    "product_name": name,
                                                    "product_link": item['product_ean'] + '-' + item["sellers"][0]['cnpj_seller'] if item["sellers"][0]['cnpj_seller'] is not None else '',
                                                    "product_ean": item['product_ean'],
                                                    "site_sku": 0,
                                                    "source": "Neogrid",
                                                    "language": "pt-br",
                                                    "product_brand": None,
                                                    "id_product_normalized": None,
                                                    "trash_score": 0,
                                                    "crawler_date": item["crawler_date"],
                                                    'seller_name': item["sellers"][0]['seller_name'],
                                                    'sellercpf_cnpj': item["sellers"][0]['cnpj_seller'] if item["sellers"][0]['cnpj_seller'] is not None else None,
                                                    "prices": [{
                                                                'price': item["sellers"][0]['prices'][0]['price_unit'],
                                                                'price_unit': item["sellers"][0]['prices'][0]['price_unit'],
                                                                'total_price_value': item["sellers"][0]["prices"][0]["total_price_value"],
                                                                'total_quantity_sold': item["sellers"][0]["prices"][0]["total_quantity_sold"]
                                                            }],
                                                    "product_local":
                                                            {
                                                            'state': item['product_local']["state"],
                                                            'city': item['product_local']["city"]
                                                            },
                                                    "product_manufacture_year": None,
                                                    "product_used_hours": None,
                                                    "product_segment": None
                                })
                            
                        except Exception as ex:
                            print(" ------ Erro dados Neogrid V3 V2 ITEM  ------")
                            print(str(ex))

                    full_result.append({
                        "product": ean,
                        "result": result_list
                    })
            
            except Exception as ex:
                print(" ------ Erro dados Neogrid V3 V2  ------")
                print(str(ex))
        print(" ------ Fim dados Neogrid V3 V2  ------")
        return full_result
    
    async def search_get_indireta_v3_v2(self, products):
        ean_where = []
        start_date = ""
        end_date = ""
        full_result = []
        result_list = []

        if (products.filters.eans is not None and len(products.filters.eans) != 0):
            for i in products.filters.eans:
                ean_where.append(i.ean)

        if (products.start_date is not None and products.end_date is not None):
            start_date = products.start_date
            end_date = products.end_date

        states = None
        if (products.idcrawlers_offline is not None):
            states = [obj.state for obj in products.idcrawlers_offline]
            states = list(filter(lambda x: x is not None and x !=
                                 '' and x.strip() != '', states))

        if (len(ean_where) > 0 and start_date != "" and end_date != ""):
            try:
                for ean in ean_where:
                    result_ean = await self.dbMongo.get_product_search_neogrid_indireta_v3_v2(start_date, end_date, ean, states)
                    if (result_ean is None):
                        continue
                    result_list = []
                    for documento in result_ean:
                        try:
                            item = documento
                            name = item['DESCRICAOO PRODUTO']
                            result_list.append(
                                {
                                    'id': str(item['_id']),
                                    'id_crawler': 172,
                                    "product_name": name,
                                    "product_link": item['EAN PRODUTO'] + '-' + item.get("NOME DISTRIBUIDOR"),
                                    "product_ean": item['EAN PRODUTO'],
                                    "site_sku": 0,
                                    "source": "Neogrid",
                                    "language": "pt-br",
                                    "product_brand": None,
                                    "id_product_normalized": None,
                                    "trash_score": 0,
                                    "crawler_date": item["ULTIMA VENDA"],
                                    'seller_name': item["NOME DISTRIBUIDOR"],
                                    'sellercpf_cnpj': item["CNPJ DISTRIBUIDOR"],
                                    "format_market": item.get("format_market"),
                                    "coordinates": {
                                        "longitude": item['coordinates']['coordinates'][0],
                                        "latitude": item['coordinates']['coordinates'][1],
                                    } if 'coordinates' in item and 'coordinates' in item['coordinates'] and len(item['coordinates']['coordinates']) == 2 else None,
                                    "prices": [
                                        {
                                            'price': item["VALOR VENDA"],
                                            'total_quantity_sold': item["QTD VENDA"]
                                        }
                                    ],
                                    "product_local": {
                                        'state': item['UF2'],
                                        'city': item['CIDADE']
                                    },
                                    "product_manufacture_year": None,
                                    "product_used_hours": None,
                                    "product_segment": None
                                })
                            
                        except Exception as ex:
                            print(" ------ Erro dados Neogrid Indireta V3 V2 ITEM  ------")
                            print(str(ex))

                    full_result.append({
                        "product": ean,
                        "result": result_list
                    })
            
            except Exception as ex:
                print(" ------ Erro dados Neogrid Indireta V3 V2  ------")
                print(str(ex))

        print(" ------ Fim dados Neogrid Indireta V3 V2  ------")
        return full_result



