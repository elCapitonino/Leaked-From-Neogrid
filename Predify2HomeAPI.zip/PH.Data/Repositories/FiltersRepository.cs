﻿using Dapper;
using Microsoft.Extensions.Configuration;
using PH.Domain.DTO;
using PH.Domain.Interfaces.Repositories;
using System.Data;
using System.Data.SqlClient;

namespace PH.Data.Repositories
{
    public class FiltersRepository : IFiltersRepository
    {
        private string _sQLConnectionString;
        private readonly IConfiguration _configuration;

        public FiltersRepository(IConfiguration configuration)
        {
            _configuration = configuration;
            _sQLConnectionString = _configuration.GetConnectionString("SQLConnectionString");
        }

        public async Task<FiltersMainDTO> Get()
        {
            FiltersMainDTO mainDTO = new FiltersMainDTO();
            mainDTO.Loja = new FiltersDTO();
            mainDTO.Curva = CriarFiltersCurva();
            mainDTO.Categoria = await GetFiltersCategoria();
            return mainDTO;
        }

        private FiltersDTO CriarFiltersCurva()
        {
            FiltersDTO filter = new FiltersDTO();
            filter.Items.Add(new FiltersItemsDTO()
            {
                Text = "Curva A",
                Value = "A"
            });
            filter.Items.Add(new FiltersItemsDTO()
            {
                Text = "Curva B",
                Value = "B"
            });
            filter.Items.Add(new FiltersItemsDTO()
            {
                Text = "Curva C",
                Value = "C"
            });
            return filter;
        }

        private async Task<FiltersDTO> GetFiltersCategoria()
        {
            FiltersDTO filter = new FiltersDTO();

            try
            {
                IDbConnection connection = CreateSqlConnection();
                var result = connection.Query<string>("VEM_Categoria", commandType: CommandType.StoredProcedure);

                foreach (string categoria in result)
                {
                    filter.Items.Add(new FiltersItemsDTO()
                    {
                        Text = categoria,
                        Value = categoria
                    });
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return filter;
        }

        private IDbConnection CreateSqlConnection() => new SqlConnection(_sQLConnectionString);
    }
}