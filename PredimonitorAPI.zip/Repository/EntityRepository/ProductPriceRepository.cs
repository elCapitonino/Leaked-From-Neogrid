using Repository.DbContexts;
using Repository.Entity.Databricks;
using Repository.EntityRepository.Bases;

namespace Repository.EntityRepository;

public class ProductPriceRepository : GenericDatabricksRepository<ProductPriceEntity>, IProductPriceRepository
{
    public ProductPriceRepository(DatabricsDbContext dbContext) : base(dbContext, "product_prices")
    {
    }
}