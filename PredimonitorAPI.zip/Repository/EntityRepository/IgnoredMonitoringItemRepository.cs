﻿using Repository.DbContexts;
using Repository.Entity;
using Repository.EntityRepository.Bases;

namespace Repository.EntityRepository
{
    public class IgnoredMonitoringItemRepository : GenericRepository<IgnoredMonitoringItemEntity, long>, IIgnoredMonitoringItemRepository
    {
        public IgnoredMonitoringItemRepository(ApplicationDbContext dbContext) : base(dbContext)
        {
        }
        public static string DbContextName => nameof(ApplicationDbContext);
    }
}
