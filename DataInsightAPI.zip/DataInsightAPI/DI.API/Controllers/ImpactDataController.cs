﻿using DI.API.Utils.Cache;
using DI.Domain.ImpactData;
using DI.Domain.ImpactData.Models;
using DI.Domain.Utils;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;

namespace DI.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class ImpactDataController : ControllerBase
    {
        private readonly ILogger<ImpactDataController> _logger;
        private readonly IImpactDataDomain _domainImpactData;
        private readonly ICacheService _cacheService;

        public ImpactDataController(ILogger<ImpactDataController> logger, IImpactDataDomain domainImpactData, ICacheService cacheService)
        {
            _logger = logger;
            _domainImpactData = domainImpactData;
            _cacheService = cacheService;
        }

        [HttpGet]
        [Route("Granularities")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<GranularityGroupResponse>))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [SwaggerOperation(Summary = "Get Granularity of a Company", Description = "Get Granularity of a Company")]
        public IActionResult GetGranularities(long companyId)
        {
            try
            {
                var cacheKey = $"{companyId}";

                var cachedData = _cacheService.Get<IEnumerable<GranularityGroupResponse>>(cacheKey);

                if (cachedData != null) return Ok(cachedData);

                var result = _domainImpactData.GetGranularities(companyId);

                _cacheService.Set(cacheKey, result);

                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error Getting Granularities");
                return StatusCode(500, "An error occurred.");
            }
        }

        [HttpGet]
        [Route("MonthlyImpactData")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<MonthlyImpactDataResponse>))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [SwaggerOperation(Summary = "Get MonthlyImpactData of a Company", Description = "Get MonthlyImpactData of a Company")]
        public IActionResult GetMonthlyImpactData(long companyId, int startDate, int endDate)
        {
            try
            {
                var cacheKey = $"{companyId}-{startDate.ToString()}-{endDate.ToString()}";

                var cachedData = _cacheService.Get<IEnumerable<MonthlyImpactDataResponse>>(cacheKey);
                if (cachedData != null) return Ok(cachedData);

                var result = _domainImpactData.GetMonthlyImpactData(companyId, new YearMonth(startDate), new YearMonth(endDate));

                _cacheService.Set(cacheKey, result);

                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Getting MonthlyImpactData");
                return StatusCode(500, "An error occurred.");
            }
        }

        [HttpGet]
        [Route("ProjectionImpactData")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<ProjectionImpactDataResponse>))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [SwaggerOperation(Summary = "Get ProjectionImpactData of a Company", Description = "Get ProjectionImpactData of a Company")]
        public IActionResult GetProjectionImpactData(long companyId, long priceGroupId)
        {
            try
            {
                var cacheKey = $"{companyId}-{priceGroupId}";

                var cachedData = _cacheService.Get<IEnumerable<ProjectionImpactDataResponse>>(cacheKey);

                if (cachedData != null) return Ok(cachedData);

                var result = _domainImpactData.GetProjectionImpactData(companyId, priceGroupId);

                _cacheService.Set(cacheKey, result);

                return Ok(result);
            }
            catch (UnauthorizedAccessException ex)
            {
                _logger.LogError(ex, "UnauthorizedAccessException company: {companyId}, priceGroupId: {priceGroupId}", companyId, priceGroupId);
                return Unauthorized(ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error Getting ProjectionImpactData");
                return StatusCode(500, "An error occurred.");
            }
        }
    }
}
