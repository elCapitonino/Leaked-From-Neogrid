﻿using Domain.Copilot;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Logging;

namespace Domain.Socket
{
    [Authorize]
    public class CopilotChathub : Hub
    {
        private readonly ILogger<CopilotChathub> log;
        private readonly ICopilotDomain copilotDomain;

        public CopilotChathub(ILogger<CopilotChathub> log, ICopilotDomain copilotDomain)
        {
            this.log = log;
            this.copilotDomain = copilotDomain;
        }
        public override Task OnConnectedAsync()
        {
            log.LogInformation($"{this.Context.ConnectionId} - {this.Context.User.Identity.Name} - Connected");
            return base.OnConnectedAsync();
        }
        public override Task OnDisconnectedAsync(Exception exception)
        {
            log.LogInformation($"{this.Context.ConnectionId} - {this.Context.User.Identity.Name} - Disconnected");
            return base.OnDisconnectedAsync(exception);
        }

        public async Task SendMessage(string companyId, string message)
        {
            try
            {
                log.LogInformation($"{this.Context.ConnectionId} - {this.Context.User.Identity.Name} - SendMessage");

                var token = Context.User.FindFirst("access_token")?.Value;
                copilotDomain.SetToken(token);
                var response = await copilotDomain.SendMessageAsync(int.Parse(companyId), message);
                await Clients.Client(this.Context.ConnectionId).SendAsync("ReceiveMessage", "Copilot", response);
            }
            catch (Exception ex)
            {
                log.LogError($"{this.Context.ConnectionId} - {this.Context.User.Identity.Name} - SendMessage", ex);
            }
        }
    }
}
