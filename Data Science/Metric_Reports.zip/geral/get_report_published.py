"""
Código para gerar um excel a partir das precificações publicadas.
"""
import warnings
warnings.filterwarnings("ignore", category=UserWarning)

import json
import time
from typing import Any

import pandas as pd
import yaml
from pyodbc import Connection

import config
from db import query_published_price_groups
from excel import to_excel
from generator import generate_reports, get_base_parser


def main(conn_obj: Connection, params: dict[str, Any]) -> pd.DataFrame:
    """Função para gerar os dados da planilha excel."""
    price_groups = query_published_price_groups(
        conn_obj,
        params["idcompany"],
        params["group_lookback"],
        group_granularity=params["group_gran"],
        group_info=params["group_info"],
        days_lookback=params["lookback"],
        days_interval=params["interval"],
        days_lookforward=params["lookforward"],
    )
    resultados = generate_reports(price_groups, conn_obj, params)
    resultado = pd.concat([res.get_report() for res in resultados], ignore_index=True)
    company_col_map = params["col_map"].get(int(params["idcompany"]), {})
    # renomeando as colunas
    resultado.rename(columns=company_col_map, inplace=True)
    print(resultado.shape, "\n\n", resultado.head())
    return resultado


if __name__ == "__main__":
    parser = get_base_parser()
    parser.add_argument(
        "--group-lookback",
        type=int,
        default=30,
        help="número de dias retroativos nos quais serão buscadas precificações",
    )
    args = parser.parse_args()

    filtros = {}
    if args.filters_json is not None:
        with open(args.filters_json, "r", encoding="utf-8") as f:
            filtros = json.load(f)

    print(f"Filtros:\n{filtros = }")

    with open("company_col_map.yaml", "r", encoding="utf-8") as f:
        col_map = yaml.safe_load(f)
    print(col_map)

    params = {
        "idcompany": args.id_company,
        "gran": args.granularity,
        "group_gran": args.group_granularity,
        "filtros": filtros,
        "clean_data": args.clean_data,
        "col_map": col_map,
        "group_lookback": args.group_lookback,
        "lookback": args.lookback,
        "interval": args.interval,
        "lookforward": args.lookforward,
        "last_price_lookback": args.last_price_lookback,
        "keep_quantity_na": args.keep_quantity_na,
        "only_date": args.only_date,
        "preco": args.preco,
        "product_info": args.product_info,
        "group_info": args.group_info,
    }

    t = time.time()
    with config.getDadosAWSSession(args.env) as aws:
        print("\nConexao estabelecida com sucesso.\n")
        aux = main(aws, params)
        # aux.to_parquet('temp.parquet')

    # aux = pd.read_parquet('temp.parquet')
    to_excel(aux, params)
    print(f"Levaram {(time.time() - t)/60:.2f} mins para executar tudo.")
