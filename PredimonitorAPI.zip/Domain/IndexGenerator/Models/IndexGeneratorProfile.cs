﻿using AutoMapper;
using Domain.Status.Models;
using Repository.Entity;
using Services.SearchAPI.Models;

namespace Domain.IndexGenerator.Models
{
    public class IndexGeneratorProfile:Profile
    {
        public IndexGeneratorProfile()
        {
            CreateMap<MonitoringItemResultsEntity, SearchAPIResponse>().ReverseMap();
            CreateMap<MonitoringItemEntity, MonitoringItemTags>()
                .ForMember(dest => dest.MonitoringItemId, opt => opt.MapFrom(src => src.Id))
                .ForMember(dest => dest.Tags, opt => opt.MapFrom(src => src.Configs.Select(x=>x.Description)))
                .ForMember(dest => dest.Eans, opt => opt.MapFrom(src =>
                    (src.EanGtin ?? string.Empty).Split(';', StringSplitOptions.RemoveEmptyEntries).ToList()))
                .ForMember(dest => dest.RequiredWords, opt => opt.MapFrom(src => src.RequiredWords))
                .ForMember(dest => dest.RestrictedWords, opt => opt.MapFrom(src => src.RestrictedWords))                
                .ReverseMap();

        }
    }
}
