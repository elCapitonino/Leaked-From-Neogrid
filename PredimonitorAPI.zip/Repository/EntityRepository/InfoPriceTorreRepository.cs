﻿using Repository.DbContexts;
using Repository.Entity;
using Repository.EntityRepository.Bases;

namespace Repository.EntityRepository
{
    public class InfoPriceTorreRepository : GenericMongoRepository<InfoPriceTorreEntity>, IInfoPriceTorreRepository
    {
        public InfoPriceTorreRepository(InfoPriceSaoJoaoDbContext dbContext) : base(dbContext)
        {
        }
        public static string DbContextName => nameof(InfoPriceSaoJoaoDbContext);
    }
}
