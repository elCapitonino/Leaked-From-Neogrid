"""
Script para gerar relatório com preços sugeridos para filiais novas da VEM
com sortimento ideal.

Os preços sugeridos são a mediana das modas dos preços das filiais da região.
A região é definida como a própria cidade, caso haja filiais nela, ou então
cidades próximas com filiais em um raio progressivamente maior. O raio de busca
é expandido até encontrar todos os produtos do sortimento ideal ou exaurir todas
as filiais cadastradas na plataforma.

Exemplo de uso:
PYTHONPATH=. python scripts/synthetic_prices_sortimento.py --env producao --affiliate-info ./scripts/affiliate_info.xlsx --new-affiliates ./data/new_affiliates_2024-03-26.xlsx
"""

import argparse
from collections import defaultdict
from datetime import datetime, timedelta
from typing import Optional

import numpy as np
import pandas as pd
from openpyxl.worksheet.worksheet import Worksheet
from synthetic_prices import (
    ID_COMPANY,
    City,
    Report,
    Task,
    _adjust_cell_width,
    _format_float_cols,
    _format_pct_cols,
    agg_histogram,
    clean_string,
    float_columns,
    mean_mode,
    median_mode,
    nearest_cities,
    pct_columns,
)

from geral import config


def find_near_cities(
    aff_city: City,
    av_cities: list[City],
    city_coords: dict[City, tuple[float, float]],
):
    yield [aff_city], 0
    max_dist = 50
    while True:
        near_cities = nearest_cities(aff_city, 10_000, max_dist, av_cities, city_coords)
        if near_cities:
            yield near_cities, max_dist
        max_dist = int(1.2 * max_dist)


def generate_report_sortimento(
    conn,
    task: Task,
    city_aff: dict[City, list[str]],
    av_cities: list[City],
    city_coords: dict[City, tuple[float, float]],
    df_sortimento: pd.DataFrame,
    lookback: int = 10,
) -> Optional[Report]:
    city = clean_string(task.city)
    uf = clean_string(task.uf)
    aff_city = City(city, uf)
    min_date = datetime.today() - timedelta(days=lookback)

    df_sortimento_aff = df_sortimento[df_sortimento["Affiliate"] == task.zbrm]

    max_pg_count = conn.execute(
        """
        SELECT COUNT(DISTINCT F.Value)
        FROM Enterprise_Price_Groups AS pg
        JOIN Enterprise_Price_Groups_Filter F
        ON pg.IdEnterprisePriceGroups = F.IdEnterprisePriceGroups
        JOIN EnterprisePriceGroups_DefaultFilter DF
        ON F.IdEnterprisePriceGroups_DefaultFilter = DF.IdEnterprisePriceGroups_DefaultFilter
        WHERE pg.IdCompany = ?
        AND pg.Automatic = 1
        AND pg.DataHoraCriacao >= ?
        AND F.IsDeleted = 0
        AND pg.IsDeletado = 0
        AND DF.dbField = 7 -- Affiliate
        """,
        ID_COMPANY,
        min_date.date(),
    ).fetchone()[0]

    seen_aff = set()
    dfs_out = []
    cities = [aff_city]
    max_dist = 0
    for cities, max_dist in find_near_cities(aff_city, av_cities, city_coords):

        affiliates = [
            zbrm for city in cities for zbrm in city_aff[city] if zbrm not in seen_aff
        ]
        seen_aff.update(affiliates)
        print(
            f"zbrm: {task.zbrm} | near affiliates: {affiliates} | max dist: {max_dist}"
        )
        print(f"-> {len(seen_aff) = } {max_pg_count = }")

        if max_dist > 1e6:
            print(f"WARNING: todas as filiais buscadas para {task.zbrm}")
            break

        if not affiliates:
            continue

        placeholder = ",".join("?" for _ in range(len(affiliates)))

        # NOTE filtro dbField 7 = Affiliate
        df_price_groups = pd.read_sql_query(
            f"""
            SELECT pg.*, F.Value AS Affiliate FROM Enterprise_Price_Groups AS pg
            JOIN Enterprise_Price_Groups_Filter F
            ON pg.IdEnterprisePriceGroups = F.IdEnterprisePriceGroups
            JOIN EnterprisePriceGroups_DefaultFilter DF
            ON F.IdEnterprisePriceGroups_DefaultFilter = DF.IdEnterprisePriceGroups_DefaultFilter
            WHERE pg.IdCompany = ?
            AND pg.Automatic = 1
            AND pg.DataHoraCriacao >= ?
            AND F.IsDeleted = 0
            AND pg.IsDeletado = 0
            AND DF.dbField = 7
            AND F.Value IN ({placeholder})
            """,
            conn,
            params=[ID_COMPANY, min_date.date(), *affiliates],
        )

        price_groups = (
            df_price_groups.sort_values("DataHoraCriacao", ascending=False)
            .groupby("Affiliate")
            .head(1)["IdEnterprisePriceGroups"]
            .tolist()
        )

        placeholder = ",".join("?" for _ in range(len(price_groups)))

        df_pp = pd.read_sql_query(
            f"""
            SELECT
                pp.PackageDescription AS EAN,
                pp.Affiliate,
                CASE
                    WHEN ppwa.Action = 0 THEN coalesce(vo.price, pp.SalePrice)
                    ELSE pp.LastSalePrice
                END AS SuggestedPrice,
                pp.SalePrice AS IAPrice,
                coalesce(vo.price, pp.SalePrice) AS RulesPrice, 
                pp.LastSalePrice AS LastPrice,
                pp.PbCost,
                pp.Category3,
                pp.Category4,
                pp.Category5
            FROM Enterprise_Prices_Projection AS pp
            LEFT JOIN enterprise_values_overrides vo
            ON vo.projectionsreference = pp.projectionsreference
            JOIN enterprisepriceprojection_workflow ppw
            ON ppw.identerprisepriceprojection = pp.IdEnterprisePricesProjection
            JOIN enterprisepriceprojection_workflowaction ppwa
            ON ppwa.idpriceprojection_workflow = ppw.IdEnterprisePriceProjection_Workflow
            WHERE pp.IdEnterprisePriceGroups IN ({placeholder})
            """,
            conn,
            params=price_groups,
        )

        df_pp["margin"] = (df_pp["SuggestedPrice"] - df_pp["PbCost"]) / df_pp[
            "SuggestedPrice"
        ]

        df_agg = (
            df_pp.groupby(["EAN"])["SuggestedPrice"]
            .agg(
                [
                    np.mean,
                    np.median,
                    np.histogram,
                    agg_histogram,
                    np.max,
                    median_mode,
                    mean_mode,
                ]
            )
            .reset_index()
        )
        df_agg["diff"] = np.abs(df_agg["median"] - df_agg["agg_histogram"])
        df_agg["diff_pct"] = df_agg["diff"] / df_agg["median"]

        df_cost = df_pp.groupby(["EAN"])["PbCost"].agg(median_mode).reset_index()

        df_cat = df_pp.groupby("EAN").first().reset_index()
        df_out = pd.merge(
            df_agg,
            df_cat[["EAN", "Category3", "Category4", "Category5"]],
            on="EAN",
            how="inner",
        )

        df_out = pd.merge(df_out, df_cost, on="EAN", how="inner")
        df_out["margin"] = (df_out["median_mode"] - df_out["PbCost"]) / df_out[
            "median_mode"
        ]

        df_out_sortimento = pd.merge(df_out, df_sortimento_aff, "inner", on=["EAN"])
        df_out = df_out_sortimento

        df_out_filtered = df_out[df_out["margin"] > 0]
        if df_out_filtered.shape != df_out.shape:
            removed_lines = df_out.shape[0] - df_out_filtered.shape[0]
            all_lines = df_out.shape[0]
            print(
                f"--> WARNING: removing {removed_lines} lines ({removed_lines / all_lines:.2%}) with negative margin"
            )
            print(df_out[df_out["margin"] <= 0]["EAN"])
            df_out = df_out_filtered

        print()
        df_out = df_out[
            [
                "Nome",
                "EAN",
                "median_mode",
                "PbCost",
                "margin",
                "Category3",
                "Category4",
                "Category5",
            ]
        ].rename(
            columns={
                "Nome": "Descrição",
                "median_mode": "Preço Sugerido",
                "margin": "Margem do micromercado (%)",
                "PbCost": "Custo do micromercado",
                "Category3": "Categoria",
                "Category4": "Subcategoria",
                "Category5": "Grupo",
            }
        )

        dfs_out.append(df_out)

        print(f"before removal: {df_sortimento_aff.shape = }")
        df_sortimento_aff = df_sortimento_aff[
            ~df_sortimento_aff["EAN"].isin(df_out["EAN"])
        ]
        print(f"after removal: {df_sortimento_aff.shape = }")
        if df_sortimento_aff.empty:
            break

        if len(seen_aff) >= max_pg_count:
            print(f"WARNING: todas as filiais buscadas para {task.zbrm}")
            break

    df_out = pd.concat(dfs_out)
    df_out = df_out.sort_values("Descrição")
    return Report(task.zbrm, task.city, task.uf, df_out, cities, max_dist)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--env", required=True, type=str, choices=["producao", "preproducao"]
    )
    parser.add_argument(
        "--new-affiliates",
        required=True,
        type=str,
        help="caminho para planilha (XLSX) com informações sobre novas filiais",
    )
    parser.add_argument(
        "--affiliate-info",
        required=True,
        type=str,
        help="caminho para planilha (XLSX) com informações sobre filiais existentes",
    )
    parser.add_argument("--lookback", type=int, default=15)
    args = parser.parse_args()

    df_new_affiliates = pd.read_excel(args.new_affiliates).rename(
        columns={"ZBRM": "Affiliate"}
    )
    df_new_affiliates["Affiliate"] = (
        df_new_affiliates["Affiliate"].astype(str).str.strip()
    )

    df_sortimento = []
    # NOTE valores fixos. Mudar conforme necessário e de acordo com formato recebido.
    for file, affiliates in (
        (
            "./scripts/Sortimento Indicado_308201_308633_308831.xlsx",
            ("308201", "308633", "308831"),
        ),
        ("./scripts/Sortimento Indicado_308520.xlsx", ("308520",)),
        ("./scripts/Sortimento Indicado_308903.xlsx", ("308903",)),
        (
            "./scripts/Sortimento Indicado_308908_308928_308978.xlsx",
            ("308908", "308928", "308978"),
        ),
        ("./scripts/Sortimento Indicado_308920.xlsx", ("308920",)),
    ):
        df = pd.read_excel(file)
        for aff in affiliates:
            df_aff = df[["EAN", "Nome"]].copy()
            df_aff["EAN"] = df_aff["EAN"].astype(str)
            df_aff["Affiliate"] = aff
            df_aff = pd.merge(df_aff, df_new_affiliates, on="Affiliate")
            if df_aff.empty:
                raise RuntimeError(f"sem linhas para filial {aff}")
            df_sortimento.append(df_aff)

    df_sortimento = pd.concat(df_sortimento)

    conn = config.getDadosAWSSession(args.env)

    ibge_cidades = pd.read_csv("./data/ibge_cidades.csv")
    codigo_uf = pd.read_csv("./data/codigo_uf.csv")
    ibge_cidades = pd.merge(
        ibge_cidades, codigo_uf[["codigo_uf", "uf"]], on="codigo_uf"
    )
    ibge_cidades = ibge_cidades.drop(columns=["codigo_uf", "siafi_id", "ddd"])
    ibge_cidades.head()

    city_coords = {
        City(clean_string(row.nome), clean_string(row.uf)): (
            row.latitude,
            row.longitude,
        )
        for row in ibge_cidades.itertuples()
    }

    df_aff = pd.read_excel(args.affiliate_info)
    df_aff["FINALIZADA"] = df_aff["FINALIZADA"].astype(bool)
    df_aff["SUCEDIDA"] = df_aff["SUCEDIDA"].astype(bool)
    df_aff["PARALISADA"] = df_aff["PARALISADA"].astype(bool)
    df_aff = df_aff[~df_aff["FINALIZADA"] & ~df_aff["PARALISADA"] & ~df_aff["SUCEDIDA"]]
    de_para = {"armacao de buzios": "armacao dos buzios"}
    av_cities = set()
    city_aff = defaultdict(list)
    for _, row in df_aff.iterrows():
        mun = clean_string(row["MUNICÍPIO"])
        mun = de_para.get(mun, mun)
        city = City(mun, clean_string(row["UF"]))
        if city not in city_coords:
            print(f"WARNING: unknown city {city}")
            continue
        av_cities.add(city)
        city_aff[city].append(str(row["ZBRM"]))

    av_cities = sorted(av_cities)

    tasks = set()
    num_na = 0
    for _, row in df_sortimento.iterrows():
        zbrm = str(row["Affiliate"]).split(".", maxsplit=1)[0].strip()
        if zbrm == "NA":
            num_na += 1
            zbrm = f"NA {num_na}"
        task = Task(zbrm, row["MUNICÍPIO"], row["UF"])
        tasks.add(task)

    tasks = sorted(tasks)
    reports = []
    for task in tasks:
        print("------------------------------------------")
        print(f"iniciando tarefa: {task}")
        report = generate_report_sortimento(
            conn,
            task,
            city_aff,
            av_cities,
            city_coords,
            df_sortimento,
            lookback=args.lookback,
        )
        reports.append(report)

    fpath = "./data/new_affiliate_sortimento_report.xlsx"
    with pd.ExcelWriter(fpath, engine="openpyxl") as writer:
        workbook = writer.book
        reports = sorted(reports, key=lambda x: x.zbrm)

        for report in reports:
            df_report = report.data
            zbrm = str(report[0]).split(".", maxsplit=1)[0]
            print(zbrm)
            df_report.to_excel(
                writer, sheet_name=zbrm, index=False, float_format="%.2f"
            )

            sheets = workbook.sheetnames
            for sheet in sheets:
                ws = workbook[sheet]
                _adjust_cell_width(ws)  # NOTE precisa ser feito antes de usar fórmulas

            for sheet in sheets:
                ws: Worksheet = workbook[sheet]
                _format_float_cols(ws, float_columns(df_report))
                _format_pct_cols(ws, pct_columns(df_report))

    print(f"arquivo salvo em {fpath}")


if __name__ == "__main__":
    main()
