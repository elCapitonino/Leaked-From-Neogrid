"""
Script para calcular dados de impacto de forma retroativa.
Necessário pois cada cálculo depende dos anteriores, então
deve ser feito na ordem cronológica.
"""

import argparse
import time

import requests
from sqlalchemy import Table, select

from src.db import create_sql_server_engine

LOCAL_URL = "http://localhost:8000"


def get_price_groups(conn, metadata, id_company: int):
    table = Table("Enterprise_Price_Groups", metadata, autoload_with=conn)
    stmt = (
        select(table.c.IdEnterprisePriceGroups, table.c.PublishedDate)
        .where(table.c.IdCompany == id_company, table.c.Published == 1)
        .order_by(table.c.PublishedDate)
    )
    return conn.execute(stmt).fetchall()


def _get_price_group_task_status(uuid: str, api_url: str) -> str:
    res = requests.get(api_url + f"/get_price_group_task_status?import_id={uuid}")
    res_json = res.json()
    return res_json["status"]


def _get_date_task_status(uuid: str, api_url: str) -> str:
    res = requests.get(api_url + f"/get_date_range_task_status?import_id={uuid}")
    res_json = res.json()
    return res_json["status"]


def calculate(id_company: int, price_group: int, published_date, api_url: str) -> None:
    print(
        f"-> requesting price_group {price_group} with published_date {published_date}"
    )
    res = requests.post(
        api_url
        + f"/calculate_projection_metrics/{id_company}/price_group?id_price_group={price_group}"
    )
    if res.status_code != 200:
        if res.status_code == 400:
            error = res.json()["detail"]
            if error == f"no projections found in price_group {price_group}":
                print(f"{error} -> skipping...")
                return
        raise RuntimeError(f"error when requesting: {res.text}")

    res_json = res.json()
    print(res_json)
    date_task_id = res_json["date_task_id"]
    pg_task_ids = res_json["pg_task_ids"]

    while True:
        time.sleep(10)
        date_status = _get_date_task_status(date_task_id, api_url)
        pg_status = [
            _get_price_group_task_status(uuid, api_url) for uuid in pg_task_ids
        ]
        if date_status == "success" and all(s == "success" for s in pg_status):
            print(f"-> price_group {price_group} finished successfully")
            break

        if date_status not in ("running", "success"):
            raise RuntimeError(f"date task failed for price_group {price_group}")

        if any(s not in ("running", "success") for s in pg_status):
            raise RuntimeError(
                f"at least one pg task failed for price_group {price_group}"
            )

        print("continue...")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--id-company", type=int, required=True)
    parser.add_argument("--api-url", type=str, default=LOCAL_URL)
    args = parser.parse_args()

    engine, metadata = create_sql_server_engine()
    with engine.connect() as conn:
        price_groups = get_price_groups(conn, metadata, args.id_company)

    print(price_groups)

    for price_group, published_date in price_groups:
        calculate(args.id_company, price_group, published_date, args.api_url)


if __name__ == "__main__":
    main()
