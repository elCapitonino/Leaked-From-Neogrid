using Domain.CompanyMonitoringCrawler;
using Domain.MonitoringResult;
using Domain.Product;
using Domain.Product.Models;
using Domain.Status;
using DomainTests.DynamicFilter.Seed;
using DomainTests.Extensions;
using DomainTests.Product.Seed;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.DependencyInjection;
using MongoDB.Driver;
using Moq;
using Repository.DbContexts;
using Repository.Entity;
using Repository.UnitOfWork;

namespace DomainTests.Product
{
    //[TestClass()]
    public class GroupedProductsDataTests
    {
        private IServiceCollection _services;
        private ServiceProvider _serviceProvider;

        //[TestInitialize]
        public void Initialize()
        {
            _services = new ServiceCollection();
            var mongo = new Mock<MongoClient>().Object;

            _services.AddTransient<IMongoClient>(provider => mongo);
            _services.SetAutoMapper();

            _services.AddDbContext<ApplicationDbContext>(options => options.UseSqlite("Filename=:memory:").ConfigureWarnings(opt => opt.Ignore(RelationalEventId.AmbientTransactionWarning)));

            _services.AddDbContext<HorusDbContext>(options => options.UseMongoDB(mongo, "Horus").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            _services.AddDbContext<InfoPriceSaoJoaoDbContext>(options => options.UseMongoDB(mongo, "InfroPriceSaoJoao").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            _services.AddDbContext<NormalizerDbContext>(options => options.UseMongoDB(mongo, "Normalizer").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            _services.AddDbContext<LinxDbContext>(options => options.UseMongoDB(mongo, "Linx").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            _services.AddDbContext<NeogridDbContext>(options => options.UseMongoDB(mongo, "Neogrid").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            _services.AddDbContext<NielsenDbContext>(options => options.UseMongoDB(mongo, "Nielsen").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            _services.AddDbContext<SmarketCompetitorDbContext>(options => options.UseMongoDB(mongo, "SmarketCompetitor").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
            _services.AddDbContext<OfflineDbContext>(options => options.UseMongoDB(mongo, "Offline").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);

            _services.AddTransient(provider => new DatabricsDbContext("Driver=Simba Spark ODBC Driver;Host=adb-1165720697464401.1.azuredatabricks.net;Port=443;HTTPPath=/sql/1.0/warehouses/bb3e5168ee7e6ca6;SSL=1;ThriftTransport=2;AuthMech=3;UID=token;PWD=dapib21631ae7a26d105f43b29d37237aa34;Timeout=30", "predimonitor_test"));

            _services.AddScoped<IMonitoringResultDomain, MonitoringResultDomain>();
            _services.AddScoped<ICompanyMonitoringCrawlerDomain, CompanyMonitoringCrawlerDomain>();
            _services.AddScoped<IStatusDomain, StatusDomain>();
            _services.AddScoped<IProductDomain, ProductDomain>();
            _services.AddMemoryCache();

            _services.AddScoped<IUnitOfWork, UnitOfWork>();
            _services.AddLogging();

            _serviceProvider = _services.BuildServiceProvider();

            var context = _serviceProvider.GetRequiredService<ApplicationDbContext>();
            context.Database.OpenConnection();
            context.Database.EnsureCreated();

            RemoveOldTestData(_serviceProvider.GetService<IUnitOfWork>()!);

        }

        private void RemoveOldTestData(IUnitOfWork uow)
        {
            uow.ProductRepository.ExecuteSQL("DELETE FROM predimonitor_test.products");
            uow.ProductSellerRepository.ExecuteSQL("DELETE FROM predimonitor_test.product_sellers");
            uow.ProductPriceRepository.ExecuteSQL("DELETE FROM predimonitor_test.product_prices");
            uow.IgnoredPriceRepository.ExecuteSQL("DELETE FROM predimonitor_test.ignored_prices");
        }

        private ProductTestData GenerateTestData(IUnitOfWork uow, int crawlerId, bool generateIgnored = false)
        {
            uow.Company.AddRange(CompanySeed.GetTestData(), autosave: true);

            uow.MonitoringCrawler.Create(new MonitoringCrawlerEntity { Id = crawlerId, Description = "Teste" }, autosave: true);

            var companyCrawlers = new List<CompanyMonitoringCrawlerEntity>()
            {
                new CompanyMonitoringCrawlerEntity{
                    Id = 1,
                    MonitoringCrawlerId = crawlerId,
                    CompanyId = 1,
                    IsDeleted = false,
                    IsCost = true,
                    IsSale = true
                }
            };

            uow.CompanyMonitoringCrawler.AddRange(companyCrawlers, autosave: true);

            var testData = ProductSeed.GetProductTestData(crawlerId);

            uow.ProductRepository.Insert(testData.Products);
            uow.ProductSellerRepository.Insert(testData.Sellers);
            uow.ProductPriceRepository.Insert(testData.Prices);

            if (generateIgnored)
            {
                uow.IgnoredPriceRepository.Insert(testData.IgnoredPrices);
            }

            return testData;
        }

        //[TestMethod()]
        public void GetGroupedProductsShouldReturnFilteredByProductNameAndPricesCorrectly()
        {
            var uow = _serviceProvider.GetService<IUnitOfWork>()!;
            var domain = _serviceProvider.GetService<IProductDomain>()!;

            var testData = GenerateTestData(uow, 9001);

            var request = new FiltersRequest()
            {
                CompanyId = 1,
                ProductNames = new List<string?>() { "Maçã" },
                StartDate = DateTime.Now.AddDays(-1),
                EndDate = DateTime.Now,
                Take = 10
            };

            var result = domain.GetGroupedProducts(request).Result;

            var macaData = testData.Products.Where(x => x.Name == "Maçã").ToList();
            var macaSellers = testData.Sellers.Where(x => macaData.Select(m => m.Id).Contains(x.ProductId)).ToList();
            var macaPrices = testData.Prices.Where(x => macaSellers.Select(m => m.Id).Contains(x.ProductSellerId)).ToList();

            var macaCount = macaData.Select(x => x.Name).Distinct().Count();
            var macaMinPrice = macaPrices.Min(x => x.Price);
            var macaMaxPrice = macaPrices.Max(x => x.Price);
            var macaAvgPrice = macaPrices.Average(x => x.Price);

            var tolerance = 0.0001m;


            Assert.AreEqual(result.Products.Count(), macaCount, "Produtos com o mesmo nome devem ser agrupados");
            Assert.AreEqual(result.Products.FirstOrDefault().MinPrice, macaMinPrice, "Preço mínimo não está correto");
            Assert.AreEqual(result.Products.FirstOrDefault().MaxPrice, macaMaxPrice, "Preço máximo não está correto");
            Assert.AreEqual(result.Products.FirstOrDefault().AvgPrice, macaAvgPrice, tolerance, "Preço médio não está correto");
        }

        //[TestMethod()]
        public void GetGroupedProductsShouldReturnFilteredByProductNamesAndPricesCorrectly()
        {
            var uow = _serviceProvider.GetService<IUnitOfWork>()!;
            var domain = _serviceProvider.GetService<IProductDomain>()!;

            var testData = GenerateTestData(uow, 9002);

            var request = new FiltersRequest()
            {
                CompanyId = 1,
                ProductNames = new List<string?>() { "Maçã", "Laranja" },
                StartDate = DateTime.Now.AddDays(-1),
                EndDate = DateTime.Now,
                Take = 10
            };

            var result = domain.GetGroupedProducts(request).Result;

            var macaData = testData.Products.Where(x => x.Name == "Maçã").ToList();
            var macaSellers = testData.Sellers.Where(x => macaData.Select(m => m.Id).Contains(x.ProductId)).ToList();
            var macaPrices = testData.Prices.Where(x => macaSellers.Select(m => m.Id).Contains(x.ProductSellerId)).ToList();

            var macaCount = macaData.Select(x => x.Name).Distinct().Count();
            var macaMinPrice = macaPrices.Min(x => x.Price);
            var macaMaxPrice = macaPrices.Max(x => x.Price);
            var macaAvgPrice = macaPrices.Average(x => x.Price);

            var laranjaData = testData.Products.Where(x => x.Name == "Laranja").ToList();
            var laranjaSellers = testData.Sellers.Where(x => laranjaData.Select(m => m.Id).Contains(x.ProductId)).ToList();
            var laranjaPrices = testData.Prices.Where(x => laranjaSellers.Select(m => m.Id).Contains(x.ProductSellerId)).ToList();

            var laranjaCount = laranjaData.Select(x => x.Name).Distinct().Count();
            var laranjaMinPrice = laranjaPrices.Min(x => x.Price);
            var laranjaMaxPrice = laranjaPrices.Max(x => x.Price);
            var laranjaAvgPrice = laranjaPrices.Average(x => x.Price);

            var tolerance = 0.0001m;

            Assert.AreEqual(result.Products.Count(), macaCount + laranjaCount, "Produtos com o mesmo nome devem ser agrupados");

            Assert.AreEqual(result.Products.FirstOrDefault(x => x.Name == "Maçã").MinPrice, macaMinPrice, "Preço mínimo não está correto");
            Assert.AreEqual(result.Products.FirstOrDefault(x => x.Name == "Maçã").MaxPrice, macaMaxPrice, "Preço máximo não está correto");
            Assert.AreEqual(result.Products.FirstOrDefault(x => x.Name == "Maçã").AvgPrice, tolerance, macaAvgPrice, "Preço médio não está correto");

            Assert.AreEqual(result.Products.FirstOrDefault(x => x.Name == "Laranja").MinPrice, laranjaMinPrice, "Preço mínimo não está correto");
            Assert.AreEqual(result.Products.FirstOrDefault(x => x.Name == "Laranja").MaxPrice, laranjaMaxPrice, "Preço máximo não está correto");
            Assert.AreEqual(result.Products.FirstOrDefault(x => x.Name == "Laranja").AvgPrice, tolerance, laranjaAvgPrice, "Preço médio não está correto");
        }

        //[TestMethod()]
        public void GetGroupedProductsShouldReturnFilteredByCategoryAndPricesCorrectly()
        {
            var uow = _serviceProvider.GetService<IUnitOfWork>()!;
            var domain = _serviceProvider.GetService<IProductDomain>()!;

            var testData = GenerateTestData(uow, 9003);

            var request = new FiltersRequest()
            {
                CompanyId = 1,
                Categories = new List<string?> { "Frutas" },
                StartDate = DateTime.Now.AddDays(-1),
                EndDate = DateTime.Now,
                Take = 10
            };

            var result = domain.GetGroupedProducts(request).Result;

            var sellers = testData.Sellers.Where(x => x.Category == "Frutas").ToList();
            var products = testData.Products.Where(x => sellers.Select(x => x.ProductId).Contains(x.Id)).ToList();
            var prices = testData.Prices.Where(x => sellers.Select(x => x.Id).Contains(x.ProductSellerId)).ToList();

            var productsGroup = products.Select(x => x.Name).Distinct().ToList();

            Assert.AreEqual(result.Products.Count(), productsGroup.Count(), "Resultado do filtro não está de acordo com os dados");

            var tolerance = 0.0001m;

            foreach (var product in productsGroup)
            {
                Assert.IsTrue(result.Products.Any(x => x.Name == product), "Resultado do filtro não trouxe dados esperados");

                var productData = testData.Products.Where(x => x.Name == product).ToList();
                var productSellers = testData.Sellers.Where(x => productData.Select(m => m.Id).Contains(x.ProductId)).ToList();
                var productPrices = testData.Prices.Where(x => productSellers.Select(m => m.Id).Contains(x.ProductSellerId)).ToList();

                var productMinPrice = productPrices.Min(x => x.Price);
                var productMaxPrice = productPrices.Max(x => x.Price);
                var productAvgPrice = productPrices.Average(x => x.Price);


                Assert.AreEqual(result.Products.FirstOrDefault(x => x.Name == product).MinPrice, productMinPrice, "Preço mínimo não está correto");
                Assert.AreEqual(result.Products.FirstOrDefault(x => x.Name == product).MaxPrice, productMaxPrice, "Preço máximo não está correto");
                Assert.AreEqual(result.Products.FirstOrDefault(x => x.Name == product).AvgPrice, tolerance, productAvgPrice, "Preço médio não está correto");
            }
        }

        //[TestMethod()]
        public void GetGroupedProductsShouldReturnFilteredByCategoriesAndPricesCorrectly()
        {
            var uow = _serviceProvider.GetService<IUnitOfWork>()!;
            var domain = _serviceProvider.GetService<IProductDomain>()!;

            var testData = GenerateTestData(uow, 9004);

            var request = new FiltersRequest()
            {
                CompanyId = 1,
                Categories = new List<string?> { "Frutas", "Bebidas" },
                StartDate = DateTime.Now.AddDays(-1),
                EndDate = DateTime.Now,
                Take = 10
            };

            var result = domain.GetGroupedProducts(request).Result;

            var sellers = testData.Sellers.Where(x => x.Category == "Frutas" || x.Category == "Bebidas").ToList();
            var products = testData.Products.Where(x => sellers.Select(x => x.ProductId).Contains(x.Id)).ToList();
            var prices = testData.Prices.Where(x => sellers.Select(x => x.Id).Contains(x.ProductSellerId)).ToList();

            var productsGroup = products.Select(x => x.Name).Distinct().ToList();

            Assert.AreEqual(result.Products.Count(), productsGroup.Count(), "Resultado do filtro não está de acordo com os dados");

            var tolerance = 0.0001m;

            foreach (var product in productsGroup)
            {
                Assert.IsTrue(result.Products.Any(x => x.Name == product), "Resultado do filtro não trouxe dados esperados");

                var productData = testData.Products.Where(x => x.Name == product).ToList();
                var productSellers = testData.Sellers.Where(x => productData.Select(m => m.Id).Contains(x.ProductId)).ToList();
                var productPrices = testData.Prices.Where(x => productSellers.Select(m => m.Id).Contains(x.ProductSellerId)).ToList();

                var productMinPrice = productPrices.Min(x => x.Price);
                var productMaxPrice = productPrices.Max(x => x.Price);
                var productAvgPrice = productPrices.Average(x => x.Price);

                Assert.AreEqual(result.Products.FirstOrDefault(x => x.Name == product).MinPrice, productMinPrice, "Preço mínimo não está correto");
                Assert.AreEqual(result.Products.FirstOrDefault(x => x.Name == product).MaxPrice, productMaxPrice, "Preço máximo não está correto");
                Assert.AreEqual(result.Products.FirstOrDefault(x => x.Name == product).AvgPrice, productAvgPrice, tolerance, "Preço médio não está correto");
            }
        }

        //[TestMethod()]
        public void GetGroupedProductsShouldCalculatePricesFromAllDataNoMatterPagination()
        {
            var uow = _serviceProvider.GetService<IUnitOfWork>()!;
            var domain = _serviceProvider.GetService<IProductDomain>()!;

            var testData = GenerateTestData(uow, 9005);

            var request = new FiltersRequest()
            {
                CompanyId = 1,
                ProductNames = new List<string?>() { "Suco de Uva" },
                StartDate = DateTime.Now.AddDays(-1),
                EndDate = DateTime.Now,
                Take = 2
            };

            var result = domain.GetGroupedProducts(request).Result;

            var sucoData = testData.Products.Where(x => x.Name == "Suco de Uva").ToList();
            var sucoSellers = testData.Sellers.Where(x => sucoData.Select(m => m.Id).Contains(x.ProductId)).ToList();
            var sucoPrices = testData.Prices.Where(x => sucoSellers.Select(m => m.Id).Contains(x.ProductSellerId)).ToList();

            var sucoCount = sucoData.Select(x => x.Name).Distinct().Count();
            var sucoMinPrice = sucoPrices.Min(x => x.Price);
            var sucoMaxPrice = sucoPrices.Max(x => x.Price);
            var sucoAvgPrice = sucoPrices.Average(x => x.Price);

            var tolerance = 0.0001m;

            Assert.AreEqual(result.Products.Count(), sucoCount, "Produtos com o mesmo nome devem ser agrupados");
            Assert.AreEqual(result.Products.FirstOrDefault().MinPrice, sucoMinPrice, "Preço mínimo não está correto");
            Assert.AreEqual(result.Products.FirstOrDefault().MaxPrice, sucoMaxPrice, "Preço máximo não está correto");
            Assert.AreEqual(result.Products.FirstOrDefault().AvgPrice, sucoAvgPrice, tolerance, "Preço médio não está correto");
        }

        //[TestMethod()]
        public void GetProductSellersWithPricesShouldReturnOnlyPricesNotIgnored()
        {
            var uow = _serviceProvider.GetService<IUnitOfWork>()!;
            var domain = _serviceProvider.GetService<IProductDomain>()!;

            var testData = GenerateTestData(uow, 9006);

            var request = new FiltersRequest()
            {
                CompanyId = 1,
                ProductNames = new List<string?>() { "Maçã" },
                StartDate = DateTime.Now.AddDays(-1),
                EndDate = DateTime.Now,
                Take = 10
            };

            var result = domain.GetGroupedProducts(request).Result;

            var macaData = testData.Products.Where(x => x.Name == "Maçã").ToList();
            var macaSellers = testData.Sellers.Where(x => macaData.Select(m => m.Id).Contains(x.ProductId)).ToList();
            var macaPrices = testData.Prices.Where(x => macaSellers.Select(m => m.Id).Contains(x.ProductSellerId) && x.Id != "102").ToList();

            var macaCount = macaData.Select(x => x.Name).Distinct().Count();
            var macaMinPrice = macaPrices.Min(x => x.Price);
            var macaMaxPrice = macaPrices.Max(x => x.Price);
            var macaAvgPrice = macaPrices.Average(x => x.Price);

            var tolerance = 0.0001m;

            Assert.AreEqual(result.Products.Count(), macaCount, "Produtos com o mesmo nome devem ser agrupados");
            Assert.AreEqual(result.Products.FirstOrDefault().MinPrice, macaMinPrice, "Preço mínimo não está correto");
            Assert.AreEqual(result.Products.FirstOrDefault().MaxPrice, macaMaxPrice, "Preço máximo não está correto");
            Assert.AreEqual(result.Products.FirstOrDefault().AvgPrice, macaAvgPrice, tolerance, "Preço médio não está correto");
        }
    }
}