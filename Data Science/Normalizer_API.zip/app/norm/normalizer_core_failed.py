from concurrent.futures import process
import threading
import time
from datetime import datetime
from norm.memorycache import MemoryCache
from norm.processing import Processing
from norm.extraction import Extraction
from norm.validate_products import ValidateProducts
from norm.conect_mongo import MongoConnect
from norm.NormalizerExtraction import NormalizerExtraction
from norm.log_normalizador import LogNormalizador


class Normalizer_core_failed(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)
        self.prep = Processing()
        self.extr = Extraction()
        self.Validate_P = ValidateProducts()
        self.memory = MemoryCache()
        self.dbMongo = MongoConnect()
        self.norm_extraction = NormalizerExtraction()
        self.log_norm = LogNormalizador()
        self._event = threading.Event()

        self.status_failed = True
        self.status_real_failed = True

    def set_status(self, status):
        self.status_failed = status
        print("status_failed: ", self.status_failed)

    def pause(self):
        self.status_real_failed = True
        self.status_failed = True
        print("Normalizador falha Pausado --- ",
              datetime.now().strftime('%d-%m-%Y %H:%M:%S.%f'))
        self._event.clear()
        self._event.wait()

    def resume(self, status_failed):
        self.status_failed = status_failed
        self.status_real_failed = False
        print("Normalizador falha iniciado --- ",
              datetime.now().strftime('%d-%m-%Y %H:%M:%S.%f'))
        self._event.set()

    def run(self):

        while True:

            ean = ''
            ncm = ''
            product_model = ''
            shipping = ''
            stock_quantity = ''
            product_link = ''
            site_sku = ''

            if self.status_failed == True:
                # print("Normalizador falha Pausado")
                self.pause()

            list_crawlers = [16, 17, 18, 19, 20, 21, 22, 23, 69, 29, 48, 0]

            for crawler in list_crawlers:

                if crawler == 0:
                    print("renormalizador falha concluida ---------------------")
                    # time.sleep(5)
                    self.status_failed = True
                    self.pause()
                    break
                if self.status_failed == True:
                    # print("Renormalizador falha em pausa")
                    # self.comleted_renorm = True
                    self.pause()

                data = self.dbMongo.get_products_failed(crawler)

                results = list(data)
                # print("results: ", len(results))

                for i in results:

                    if self.status_failed == True:
                        # print("Renormalizador falha em pausa")
                        # self.comleted_renorm = True
                        self.pause()

                    # print("ID 1", i['_id'])

                    # variavaies
                    ListNorm = None
                    product = None
                    produto_valido = None
                    insert = None

                    # print("----------------------------------")
                    # process_product = self.norm_extraction.normalize_preprocessing(
                    #     i["product_name"])
                    ##############################################################
                    product_brand = ''
                    product_model = ''
                    if "product_model" in i:
                        product_model = i["product_model"]
                    if "product_brand" in i:
                        product_brand = i["product_brand"]

                    product_concat = (
                        i["product_name"] + " " + product_model + " " + product_brand)

                    #print("product_concat: ", product_concat)

                    ##############################################################

                    product = self.norm_extraction.normalizer_extraction(
                        product_concat, i["language"])

                    # print("----------------------------------")
                    # print("Produto: ", i["product_name"])
                    # print("products  : ", product)

                    produto_valido, log = self.Validate_P.validate_products(
                        product)

                    #########################################################################
                    if "product_ean" in i:
                        ean = i["product_ean"]
                    if "product_ncm" in i:
                        ncm = i["product_ncm"]
                    if "product_model" in i:
                        product_model = i["product_model"]
                    if "shipping" in i:
                        shipping = i["shipping"]
                    # if "stock_quantity" in i:
                    #    stock_quantity = i["stock_quantity"]
                    if "product_link" in i:
                        # print("------- ", i["product_link"])
                        product_link = i["product_link"]
                    if "site_sku" in i:
                        # print("------- ", i["site_sku"])
                        site_sku = i["site_sku"]

                    ########################################################################

                    if produto_valido == True:

                        product.update({"model": product_model, "ean": ean,
                                        "ncm": ncm, "idcrawlers": i["id_crawler"]})

                        # print("product: ", product)

                        ListNorm = self.Validate_P.checks_products_register(
                            self.memory.get_products_normalized(i["language"]), product)
                        # print("ListNorm: ", ListNorm)

                    ################################################################################

                    if (produto_valido == True and ListNorm == None):

                        # print(i["_id"], product, brands, categories, materials, voltage, metric_units, power, leftover,

                        #      product_model, ean, ncm, i["id_crawler"])
                        ListNorm, insert = self.dbMongo.register_renorm(
                            product)

                        ListNorm = ListNorm.inserted_id

                        # print("ListNorm: ", ListNorm, "insert: ", insert)

                        # atualizar lista de produtos normalizados em memoria
                        # print("insert ", insert)
                        if(insert != None):
                            # print(insert)
                            self.memory.update_products_nomal(insert)
                        ################################################################################
                        if produto_valido == True and ListNorm != None:
                            # print("ID 2 ", i['_id'])
                            id_price = self.dbMongo.insert_price_failed(
                                ListNorm, i)

                            self.log_norm.log_normalization(
                                id_price, ListNorm, product["product"], 2)
