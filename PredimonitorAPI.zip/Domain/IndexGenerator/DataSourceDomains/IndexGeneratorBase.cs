﻿using Domain.IndexGenerator.Models;
using Domain.Status;
using Repository.Enums;
using System.Security.Cryptography;
using System.Text;

namespace Domain.IndexGenerator.DataSourceDomains
{
    public abstract class IndexGeneratorBase
    {
        private readonly IStatusDomain _statusDomain;

        protected IndexGeneratorBase(IStatusDomain statusDomain)
        {
            _statusDomain = statusDomain;
        }
        protected virtual void UpdateStatus(Guid? taskId, CrawlerSourceType crawlerSourceType,MonitoringItemResultsStatusType status, int total, int processed)
        {
            if (taskId.HasValue)
            {
                _statusDomain.UpdateCache(new Status.Models.StatusCacheModel()
                {
                    TaskId = taskId,
                    SourceType = crawlerSourceType,
                    Status = status,
                    Message = $"Total: {total} Processed: {processed}",
                    Total = total,
                    Indexed = processed
                });
            }
        }

        protected string CalculateSHA256(string input)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = sha256.ComputeHash(bytes);
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < hashBytes.Length; i++)
                {
                    builder.Append(hashBytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }

        protected string GetOrGenerateHash(string? hash, string concatenatedString)
        {
            if (string.IsNullOrEmpty(hash))
                return CalculateSHA256(concatenatedString);

            return hash;
        }

        protected void EnsureAllMonitoringItemId(IEnumerable<MonitoringItemTags> monitoringItems)
        {
            if (monitoringItems.Any(x => x.MonitoringItemId == 0))
            {
                throw new Exception("Existe monitoring item sem id");
            }
        }
    }
}
