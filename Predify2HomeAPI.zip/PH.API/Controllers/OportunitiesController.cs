﻿using Microsoft.AspNetCore.Mvc;
using PH.Domain.Interfaces.Services;

namespace PH.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OportunitiesController : ControllerBase
    {
        private readonly ILogger<OportunitiesController> _logger;
        private readonly IOportunitiesServices _service;

        public OportunitiesController(ILogger<OportunitiesController> logger,
                                IOportunitiesServices service)
        {
            _logger = logger;
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> Get(long? idCompany, long? idPriceGroup)
        {
            _logger.LogInformation($"Controller: Buscando todos os Oportunitiess idCompany:{idCompany} - idPriceGroup: {idPriceGroup}");

            try
            {
                if (idCompany == null || idCompany == 0 || idPriceGroup == null || idPriceGroup == 0)
                    throw new Exception("Id da Compania ou Id do grupo não podem ser nulo ou 0");

                var recipes = await _service.Get(idCompany.Value, idPriceGroup.Value);
                return Ok(recipes);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Controller: Erro ao buscar todos os Oportunitiess. {ex.Message}");
                return StatusCode(500, "Erro ao buscar todos os Oportunitiess");
            }
        }
    }

    public class FiltersValues
    {
        public string Key { get; set; }
        public string Value { get; set; }
    }
}
