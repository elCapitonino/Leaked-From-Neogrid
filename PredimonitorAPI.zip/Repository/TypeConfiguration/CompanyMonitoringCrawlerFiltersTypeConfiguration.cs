﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Repository.Attributes;
using Repository.DbContexts;
using Repository.Entity;

namespace Repository.TypeConfiguration
{
    [DbContextTypeConfiguration(typeof(ApplicationDbContext))]
    public class CompanyMonitoringCrawlerFiltersTypeConfiguration : TypeConfigurationBase<CompanyMonitoringCrawlerFiltersEntity>, IEntityTypeConfiguration<CompanyMonitoringCrawlerFiltersEntity>
    {
        public override void Configure(EntityTypeBuilder<CompanyMonitoringCrawlerFiltersEntity> builder)
        {
            builder.ToTable("Company_MonitoringCrawlerFilters");
            builder.Property(x => x.Id).HasColumnName("IdCompany_MonitoringCrawlerFilters");
            builder.Property(x => x.CompanyMonitoringCrawlerId).HasColumnName("IdCompany_MonitoringCrawler");
            builder.HasOne(x => x.CompanyMonitoringCrawler);
            builder.Property(x => x.Operator).HasMaxLength(8);
            builder.Property(x => x.Field).HasMaxLength(32);
            builder.HasOne(w => w.CompanyMonitoringCrawler).WithMany(b => b.CompanyMonitoringCrawlerFilters).HasForeignKey(w => w.CompanyMonitoringCrawlerId);
        }
    }
}
