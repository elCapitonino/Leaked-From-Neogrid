﻿namespace Repository.Entity
{
    public class CompanyConfigurationEntity : BaseEntity
    {
        public long CompanyId { get; set; }
     
        public long? RedirectDataBaseSaleHistory { get; set; }

        public bool? UseAltListElasticity { get; set; }

        public bool? DisableCalculateMarketResult { get; set; }

        public string? CurrencySymbol { get; set; }

        public decimal? SearchThresholdRelative { get; set; }

        public decimal? SearchThresholdFuzzy { get; set; }

        public bool? SearchUseCosine { get; set; }

        public bool? SearchUseTopWord { get; set; }

        public bool? RemoveOldsMarketResult { get; set; }

        public bool? RemoveOutliersOnMarketResult { get; set; }

        public string? NumericalExpressionMargin { get; set; }

        public string? NumericalExpressionPrice { get; set; }

        public DateTime? SearchAPIMonitoringItemDateFilter { get; set; }

        public bool IsDeleted { get; set; }

        public int? RangeDateMarketResult { get; set; }

    }
}
