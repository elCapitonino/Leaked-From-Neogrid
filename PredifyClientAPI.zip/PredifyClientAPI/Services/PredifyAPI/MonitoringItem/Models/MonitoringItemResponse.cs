﻿namespace PredifyClientAPI.Services.PredifyAPI.MonitoringItem.Models
{
    public class MonitoringItemResponse
    {
        /// <summary>
        /// Id do item de monitoramento
        /// </summary>
        public long IdMonitoringItem { get; set; }

        /// <summary>
        /// Id do produto predify atrelado
        /// </summary>
        public long? IdProduct { get; set; }

        ///// <summary>
        ///// Id do lote
        ///// </summary>
        //public long? IdMonitoringBatch { get; set; }

        /// <summary>
        /// Código do produto
        /// </summary>
        public string ProductCode { get; set; }

        /// <summary>
        /// Categorias
        /// </summary>
        public List<MonitoringItem_ProductCategoryResponse> Categories { get; set; }

        /// <summary>
        /// id de importação atrelado ao produto predify ou idmonitoring
        /// </summary>
        public string IdImport { get; set; }

        /// <summary>
        /// Descrição do produto atrelado ao item de monitoramento
        /// </summary>
        public string ProductDescription { get; set; }

        /// <summary>
        /// Descrição do monitoring item ou do produto predify caso tenha um atrelado
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Descrição utilizada para pesquisa interna na nossa base
        /// </summary>
        public string InternalSearch { get; set; }

        /// <summary>
        /// Descrição utilizada para pesquisa nos crawlers
        /// </summary>
        public string ExternalSearch { get; set; }

        /// <summary>
        /// tempo de vida relacionado a quantidades de monitoramento
        /// </summary>
        public int? LifeTimeMonitoring { get; set; }

        /// <summary>
        /// Indica se é para desativar o Item de monitoramento ou não
        /// </summary>
        public bool? IsDeleted { get; set; }

        /// <summary>
        /// Data de Criação do item
        /// </summary>
        public DateTime CreateDate { get; set; }

        /// <summary>
        /// Ean do produto quando existir.
        /// </summary>
        public string ProductEan { get; set; }

        /// <summary>
        /// Indice deflator informado para fazer o calculo
        /// </summary>
        public decimal? PortionDeflatorIndex { get; set; }

        /// <summary>
        /// Coluna para checar se deve usar limitador de preço.
        /// Padrão como true.
        /// </summary>
        public bool UsePriceRange { get; set; } = true;

        /// <summary>
        /// Limitador de preço minimo para coleta/pesquisa
        /// </summary>
        public decimal? LowerPriceRange { get; set; }

        /// <summary>
        /// Limitador de preço maximo para coleta/pesquisa
        /// </summary>
        public decimal? UpperPriceRange { get; set; }

        /// <summary>
        /// Tags obrigatórias no retorno (test1;test2)
        /// </summary>
        public string MandatoryTagModel { get; set; }

        /// <summary>
        /// Retorno de brands (test1;test2)
        /// </summary>
        public string MandatoryTagBrand { get; set; }

        /// <summary>
        /// EAN ou GTIN do produto
        /// </summary>
        public string Ean_Gtin { get; set; }

        /// <summary>
        /// Palavras que deve ter na busca
        /// </summary>
        public string RequiredWords { get; set; }

        /// <summary>
        /// Palavras que nao deve ter na busca 
        /// </summary>
        public string RestrictedWords { get; set; }

        public List<MonitoringItem_LeadResponse> Leads { get; set; }

        public List<MonitoringItem_ConfigResponse> Configs { get; set; }

        public List<MonitoringGroups_Response> Groups { get; set; }

        public string GetCode
        {
            get
            {
                if (!string.IsNullOrWhiteSpace(IdImport))
                    return IdImport;

                return ProductCode;
            }
        }

        public string GetDescription
        {
            get
            {
                if (!string.IsNullOrWhiteSpace(Description))
                    return Description;

                return ProductDescription;
            }
        }

        public string GetEan
        {
            get
            {
                if (!string.IsNullOrWhiteSpace(Ean_Gtin))
                    return Ean_Gtin;

                return ProductEan;
            }
        }
    }

    public class MonitoringItem_LeadResponse
    {
        public long IdMonitoringItem_Lead { get; set; }

        public string Name { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public bool? IsDeleted { get; set; }

        public decimal? MonitoringResultPriceMin { get; set; }
        public decimal? MonitoringResultPriceAvg { get; set; }
        public decimal? MonitoringResultPriceMax { get; set; }

        public decimal? MonitoringResultPriceMinOverride { get; set; }
        public decimal? MonitoringResultPriceAvgOverride { get; set; }
        public decimal? MonitoringResultPriceMaxOverride { get; set; }

        public DateTime CreateDate { get; set; }

    }

    /// <summary>
    /// Modelo contando configurações do Item de monitoramento atrelado
    /// </summary>
    public class MonitoringItem_ConfigResponse
    {
        /// <summary>
        /// id do da configuração do item de monitoramneto
        /// </summary>
        public long? IdMonitoringItem_Config { get; set; }

        /// <summary>
        /// Descrição do item de configuração
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// especifica se o item será utilizado para consulta no crawlers ou na pesquisa interna
        /// </summary>
        public bool? IsExternalSearch { get; set; }

        /// <summary>
        /// tempo de vida relacionado a quantidades de monitoramento
        /// </summary>
        public int? LifeTimeMonitoring { get; set; }

        /// <summary>
        /// Indica se é para desativar o Config ou não
        /// </summary>
        public bool? IsDeleted { get; set; }

        /// <summary>
        /// Limitador de preço minimo para coleta/pesquisa
        /// </summary>
        public decimal? LowerPriceRange { get; set; }

        /// <summary>
        /// Limitador de preço maximo para coleta/pesquisa
        /// </summary>
        public decimal? UpperPriceRange { get; set; }

        /// <summary>
        /// Lista de Crawlers para serem configuradas
        /// </summary>
        public List<MonitoringItemConfig_CrawlerResponse> Crawlers { get; set; }
    }

    public class MonitoringItemConfig_CrawlerResponse
    {
        /// <summary>
        /// Identificador do CompanyMonitoringCrawler
        /// </summary>
        public int IdCrawler { get; set; }
    }

    public class MonitoringItem_ProductCategoryResponse
    {
        public long IdProductCategory { get; set; }
        public string Description { get; set; }
    }

    public class MonitoringGroups_Response
    {
        public long IdMonitoringGroup { get; set; }

        public long IdCompany { get; set; }

        public string Description { get; set; }
    }
}
