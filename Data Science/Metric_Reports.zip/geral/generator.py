"""
Módulo para criar relatório de um grupo de precificação.
"""

import argparse
from typing import Any, Optional, Union
from datetime import datetime

import numpy as np
import pandas as pd
from pandas.api.types import is_datetime64_any_dtype as is_datetime
from pyodbc import Connection

from db import query_history, query_projections
from report import Report

# Funcoes auxiliares
map_funcoes_filtro = {
    "in": lambda df, col, vals: df[df[col].isin(vals)],
    "nin": lambda df, col, vals: df[~df[col].isin(vals)],
    "gt": lambda df, col, val: df[df[col] > val],
    "geq": lambda df, col, val: df[df[col] >= val],
    "lt": lambda df, col, val: df[df[col] < val],
    "leq": lambda df, col, val: df[df[col] <= val],
    "eq": lambda df, col, val: df[df[col] == val],
    "neq": lambda df, col, val: df[df[col] != val],
}

# NOTE adicionar % para coluna ser formatada como porcentagem
COL_MAPPING = {
    "Product": "Id do Produto",
    "Description": "Descrição do Produto",
    "Data_Precificação": "Data de Precificação",
    "Aproval": "Preço Ajustado Aprovado?",
    "custo_projecao": "Preço de Custo (Precificação)",
    "custo_anterior": "Preço de Custo (Período Anterior)\n{lookback_start_date} - {lookback_end_date}",
    "custo_posterior": "Preço de Custo (Período Seguinte)\n{lookforward_start_date} - {lookforward_end_date}",
    "custo_ano_passado": "Preço de Custo (Ano Passado)",
    "p_sem_regra_projecao": "Preço Sugerido Sem Regras",
    "p_projecao": "Preço Ajustado",
    "p_anterior": "Preço Médio Praticado (Período Anterior)\n{lookback_start_date} - {lookback_end_date}",
    "p_posterior": "Preço Médio Praticado (Período Seguinte)\n{lookforward_start_date} - {lookforward_end_date}",
    "p_ano_passado": "Preço Médio Praticado (Ano Passado)\n{lookforward_start_date} - {lookforward_end_date}",
    "d_projecao": "Demanda Projetada",
    "q_anterior": "Vendas Totais (Período Anterior)\n{lookback_start_date} - {lookback_end_date}",
    "q_posterior": "Vendas Totais (Período Seguinte)\n{lookforward_start_date} - {lookforward_end_date}",
    "q_ano_passado": "Vendas Totais (Ano Passado)",
    "m_projecao": "Margem Projetada - %",
    "m_anterior": "Margem (Período Anterior) - %\n{lookback_start_date} - {lookback_end_date}",
    "m_posterior": "Margem (Período Seguinte) - %\n{lookforward_start_date} - {lookforward_end_date}",
    "m_ano_passado": "Margem (Ano Passado) - %",
    "r_projecao": "Receita Projetada",
    "r_anterior": "Receita (Período Anterior)\n{lookback_start_date} - {lookback_end_date}",
    "r_posterior": "Receita (Período Seguinte)\n{lookforward_start_date} - {lookforward_end_date}",
    "r_ano_passado": "Receita (Ano Passado)",
    "l_projecao": "Lucro Projetado",
    "l_anterior": "Lucro (Período Anterior)\n{lookback_start_date} - {lookback_end_date}",
    "l_posterior": "Lucro (Período Seguinte)\n{lookforward_start_date} - {lookforward_end_date}",
    "l_ano_passado": "Lucro (Ano Passado)",
    "alt m (Semanal)": "Alteração de Margem (Semanal) - %",
    "alt q (Semanal)": "Alteração de Volume (Semanal)",
    "alt r (Semanal)": "Alteração de Receita (Semanal)",
    "alt l (Semanal)": "Alteração de Lucro (Semanal)",
    "erro p": "Erro de Projeção de Preço",
    "erro q": "Erro de Projeção de Demanda",
    "erro r": "Erro de Projeção de Receita",
    "erro l": "Erro de Projeção de Lucro",
}

def _format_date(d: datetime) -> str:
    return d.strftime("%d/%m/%y")


def _rename_columns(
    df: pd.DataFrame,
    lookback_start_date: datetime,
    lookback_end_date: datetime,
    lookforward_start_date: datetime,
    lookforward_end_date: datetime
) -> pd.DataFrame:
    col_map = {
        k: v.format(
            lookback_start_date=_format_date(lookback_start_date),
            lookback_end_date=_format_date(lookback_end_date),
            lookforward_start_date=_format_date(lookforward_start_date),
            lookforward_end_date=_format_date(lookforward_end_date)
        ) for k, v in COL_MAPPING.items()
    }
    return df.rename(columns=col_map) 

def generate_reports(price_groups: pd.DataFrame, conn_obj: Connection, params: dict[str, Any]) -> list[Report]:
    """Puxa as projeções e os hitóricos de vendas; e junta todas as informações de acordo com as datas dos `ids_Price_Groups`."""
    print("Ids Price Groups - ok")

    if params["only_date"]:
        for col in price_groups.columns:
            if not is_datetime(price_groups[col]):
                continue
            price_groups[col] = price_groups[col].dt.date

    print(price_groups[["IdEnterprisePriceGroups", "Data_Precificação"]], "\n")
    print(price_groups.head())

    if price_groups.empty:
        print("WARNING: nenhum grupo de precificação se enquadra nas regras. Verifique as datas")
        return []

    price_groups_filters = _get_sales_history_filter(
        price_groups, params["group_gran"] + params["group_info"]
    )

    resultados = []
    list_merge = sorted(set([*params["gran"], *params["group_gran"], "IdEnterprisePriceGroups", "Data_Precificação"]))

    for id_ in price_groups.index:
        price_group = price_groups.loc[id_]
        id_pg = price_group["IdEnterprisePriceGroups"]
        data = price_group["Data_Precificação"]
        filters = price_groups_filters.get(id_pg) or []
        sales_history_filters = [(col, value) for (col, value) in filters if col in params["gran"]]
        metadata = dict(filters)
        extra_gran = _get_extra_granularity(price_group, params["gran"], params["group_info"])
        dias_fwd = abs((price_group["EndDateFwd"] - price_group["InitialDateFwd"]).days)

        #####################################################################################
        # projecoes para essa semana
        atual = query_projections(
            conn_obj,
            id_pg,
            params["gran"],
            params["product_info"],
            params["filtros"],
        )
        atual = _add_extra_granularity(atual, extra_gran)
        atual["d_projecao"] = atual["d_projecao"] * dias_fwd
        atual["r_projecao"] = atual["r_projecao"] * dias_fwd
        atual["l_projecao"] = atual["l_projecao"] * dias_fwd
        atual["Data_Precificação"] = data
        atual = _aplicar_filtros(atual, params["filtros"])
        print("Precificações ok - id", id_)

        #####################################################################################
        # vendas na semana anterior
        anterior = query_history(
            conn_obj,
            price_group["InitialDateBack"],
            price_group["EndDateBack"],
            params["gran"],
            params["idcompany"],
            "anterior",
            params["filtros"],
            sales_history_filters,
            period_last_price=params["last_price_lookback"],
            keep_na=params["keep_quantity_na"],
            preco=params["preco"],
        )
        anterior["IdEnterprisePriceGroups"] = id_pg
        anterior["Data_Precificação"] = data
        anterior = _aplicar_filtros(anterior, params["filtros"])
        print("Semana Anterior ok - id", id_)

        #####################################################################################
        # vendas nessa semana
        posterior = query_history(
            conn_obj,
            price_group["InitialDateFwd"],
            price_group["EndDateFwd"],
            params["gran"],
            params["idcompany"],
            "posterior",
            params["filtros"],
            sales_history_filters,
            period_last_price=params["last_price_lookback"],
            keep_na=params["keep_quantity_na"],
            preco=params["preco"],
        )
        posterior["IdEnterprisePriceGroups"] = id_pg
        posterior["Data_Precificação"] = data
        posterior = _aplicar_filtros(posterior, params["filtros"])
        print("Semana Seguinte ok - id", id_)

        resultado = atual.merge(anterior, on=list_merge, how="left").merge(posterior, on=list_merge, how="left")
        resultado = _prepare_result(resultado, params=params)
        resultado = _rename_columns(
            resultado,
            price_group["InitialDateBack"],
            price_group["EndDateBack"],
            price_group["InitialDateFwd"],
            price_group["EndDateFwd"]
        )
        resultados.append(Report(resultado, metadata, raw=True))

    return resultados


def _get_extra_granularity(
    price_group: pd.DataFrame, granularity: list[str], group_granularity: list[str]
) -> dict[str, Any]:
    """Extrai colunas que não estão na granularidade de preços."""
    extra = set(group_granularity) - set(granularity)
    return {col: price_group[col] for col in extra}


def _add_extra_granularity(df: pd.DataFrame, extra_values: dict[str, Any]) -> pd.DataFrame:
    """Insere colunas que não estão na granularidade de preços."""
    for col, value in extra_values.items():
        df[col] = value
    return df


def get_base_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--env",
        type=str,
        choices=["producao", "preproducao", "homologacao"],
        help="ambiente do banco de dados",
        required=True,
    )
    parser.add_argument("--id-company", type=int, required=True, help="id da empresa")
    parser.add_argument("--granularity", type=str, nargs="+", required=True, help="granularidade dos preços")
    parser.add_argument(
        "--group-granularity",
        type=str,
        default=[],
        nargs="+",
        help="granularidade para comparar grupos de precificação",
    )
    parser.add_argument(
        "--product-info",
        type=str,
        nargs="+",
        default=[],
        help=(
            "colunas com informações do produto para incluir no relatório, "
            "mas não na granularidade. ATENÇÃO: não há garantia de que as "
            "informações sejam as mesmas para todos os registros daquele produto "
            "no banco de dados, mas apenas o valor mais recente será exibido"
        )
    )
    parser.add_argument(
        "--group-info",
        type=str,
        nargs="+",
        default=[],
        help=(
            "colunas com informações do grupo de precificação para incluir no relatório, "
            "mas não na granularidade do grupo. ATENÇÃO: não há garantia de que as "
            "informações sejam as mesmas para todos os registros daquele grupo "
            "no banco de dados, mas apenas o valor mais recente será exibido"
        )
    )
    parser.add_argument(
        "--lookback", type=int, default=7, help="número de dias anteriores à precificação a serem agregados"
    )
    parser.add_argument(
        "--interval", type=int, default=0, help="número de dias posteriores à precificação a serem descartados"
    )
    parser.add_argument(
        "--lookforward",
        type=int,
        default=7,
        help="número de dias posteriores à precificação + interval a serem agregados",
    )
    parser.add_argument(
        "--last-price-lookback",
        type=int,
        default=180,
        help="número de dias retroativos para buscar último preço (caso não exista no período de lookback)",
    )
    parser.add_argument("--filters-json", type=str, default=None, help="opções de filtro para cada coluna")
    parser.add_argument("--clean-data", action="store_true", help="remover dados com venda zero")
    parser.add_argument("--keep-quantity-na", action="store_true", help="não preencher quantidades vazias com 0")
    parser.add_argument(
        "--col-blocklist",
        type=str,
        default=None,
        help="YAML com lista de colunas que serão removidas dos relatórios finais",
    )
    parser.add_argument(
        "--only-date", action="store_true", help="extrair apenas data dos valores de data-hora das precificações"
    )
    parser.add_argument(
        "--preco", type=str, choices=["SalePrice", "ClientSalesPrice"], default="SalePrice",
        help="qual coluna da Sales History deve ser puxada como o preço praticado pelo cliente."
    )
    return parser


def _get_sales_history_filter(
    df_price_groups: pd.DataFrame, group_info: Optional[list[str]] = None
) -> dict[int, list[tuple[str, Any]]]:
    if not group_info:
        return {}
    filters = {
        row["IdEnterprisePriceGroups"]: [(col, row[col]) for col in group_info]
        for _, row in df_price_groups.iterrows()
    }
    for key, values in filters.items():
        values = list(
            map(lambda item: (item[0], item[1].strip()) if isinstance(item[1], str) else (item[0], item[1]), values)
        )
        filters[key] = values
    return filters


def _deduplicate(seq):
    # https://stackoverflow.com/questions/480214/how-do-i-remove-duplicates-from-a-list-while-preserving-order
    seen = set()
    seen_add = seen.add
    return [x for x in seq if not (x in seen or seen_add(x))]


def _prepare_result(resultado: pd.DataFrame, params: dict[str, Any]) -> pd.DataFrame:
    """Função auxiliar para incluir os erros de projeção, as regras de adoção e as comparações
    entre os períodos de vendas, enquanto também já organiza a posição de cada coluna.
    """
    # organizando quanto a anterior/precificação/posterior:
    ant = [i for i in resultado.columns if "_anterior" in i]
    prj = [i for i in resultado.columns if "_projecao" in i]
    pst = [i for i in resultado.columns if "_posterior" in i]

    combined_cols = sorted(
        set(params["gran"]) | set(params["group_gran"]) | set(params["product_info"]) | set(params["group_info"])
    )
    cols = _deduplicate(
        ["Data_Precificação", *combined_cols, "Description", "AffiliateName", *ant, *prj, *pst, "Aproval"]
    )
    resultado = resultado[cols].copy()

    # deve-se limpar as vendas "estranhas":
    if params["clean_data"]:
        resultado.dropna(axis=0, inplace=True)
        resultado = resultado[resultado["q_anterior"] > 0.1]
        resultado = resultado[resultado["q_posterior"] > 0.1]
        resultado = resultado[resultado["p_anterior"] > 0.1]
        resultado = resultado[resultado["p_posterior"] > 0.1]
        resultado.reset_index(drop=True, inplace=True)

    if params["idcompany"] == 2550:
        resultado = _prepare_result_bobs(resultado)
    else:
        # variação de preço e demanda:
        resultado = _add_erros(resultado)
        resultado = _aplicar_regras_adocao(resultado)

    # variação em relação à semana anterior a precificação:
    resultado = _add_alteracoes(resultado, "anterior")
    # print(resultado.head())

    # padronizando o lugar das colunas:
    resultado = _reorder_cols(resultado, combined_cols)
    return resultado


def _prepare_result_bobs(resultado: pd.DataFrame) -> pd.DataFrame:
    # com base no tipo do produto (sand, gelado ou trio),
    # serão consideradas outras margens para a adoção de preço
    gelados = ["1079", "10816", "10903", "3536", "452"]
    trios = [
        "Sand Bobs Premium Bov (Trio)",
        "Sand Bobs Costela Bov (Trio)",
        "Sand Tentador Carne Bov (Trio)",
        "Sand Tentador Veggie Carne (Trio)",
    ]
    resultado["Categoria do Produto"] = "Sanduiches"
    resultado.loc[resultado["Product"].isin(gelados), "Categoria do Produto"] = "Gelados"
    resultado.loc[resultado["Description"].isin(trios), "Categoria do Produto"] = "Trios"

    # variação de preço e demanda:
    resultado = _add_erros(resultado)
    resultado = _aplicar_regras_adocao(resultado)

    # regras especiais:
    # gelados:15%, sand:10%, trios:5%
    resultado["Influência Por Categoria"] = "FALSO"
    t = resultado["Categoria do Produto"] == "Trios"
    g = resultado["Categoria do Produto"] == "Gelados"
    s = resultado["Categoria do Produto"] == "Sanduiches"

    rows_t = abs(resultado["p_posterior"] - resultado["p_projecao"]) / resultado["p_projecao"] <= 0.05
    rows_g = abs(resultado["p_posterior"] - resultado["p_projecao"]) / resultado["p_projecao"] <= 0.10
    rows_s = abs(resultado["p_posterior"] - resultado["p_projecao"]) / resultado["p_projecao"] <= 0.15
    resultado.loc[(t) & (rows_t), "Influência Por Categoria"] = "VERDADEIRO"
    resultado.loc[(g) & (rows_g), "Influência Por Categoria"] = "VERDADEIRO"
    resultado.loc[(s) & (rows_s), "Influência Por Categoria"] = "VERDADEIRO"
    return resultado


def _aplicar_filtros(df: pd.DataFrame, filtros: dict) -> pd.DataFrame:
    """Função para aplicar em `df` os filtros especificados."""
    filtro = df.copy()

    for col in filtros.keys():
        if col not in df.columns:
            print(f"{col} nao faz parte de {df.columns}", "(por enquanto, este filtro esta sendo ignorado)")
            continue

        func = filtros[col][0]
        valores = filtros[col][1]
        filtro = map_funcoes_filtro[func](filtro, col, valores)

    return filtro.copy()


def _add_erros(df: pd.DataFrame) -> pd.DataFrame:
    """Função para incluir as seguinte colunas em `df`:
    - Erro de Projeção de Preço: Preço_projetada menos Preço_posterior
    - Erro de Projeção de Volume: Demanda_projetada menos Vendas_posterior
    - Erro de Projeção de Receita: Receita_projetada menos Receita_posterior
    - Erro de Projeção de Lucro: Lucro_projetado menos Lucro_posterior
    """
    for pcol in ["p", "q", "r", "l"]:
        df[f"erro {pcol}"] = df[f"{pcol if pcol != 'q' else 'd'}_projecao"] - df[f"{pcol}_posterior"]
    return df


def _add_alteracoes(df: pd.DataFrame, nome: str = "anterior") -> pd.DataFrame:
    """Função para incluir as seguinte colunas em `df`:
    - Alteração de Margem: Marge_atual menos Margem_{nome}
    - Alteração de Volume: Demanda_atual menos Vendas_{nome}
    - Alteração de Receita: Receita_atual menos Receita_{nome}
    - Alteração de Lucro: Lucro_atual menos Lucro_{nome}
    """
    for pcol in ["m", "q", "r", "l"]:
        if nome == "anterior":
            df[f"alt {pcol} (Semanal)"] = df[f"{pcol}_posterior"] - df[f"{pcol}_{nome}"]
        else:
            df[f"Alteração de {pcol.capitalize()} ({nome.capitalize()})"] = (
                df[f"{pcol}_posterior"] - df[f"{pcol}_{nome}"]
            )

    return df


def _aplicar_regras_adocao(df: pd.DataFrame) -> pd.DataFrame:
    """Função auxiliar para incluir em `df` a(s) coluna(s) com a(s) regra(s) de adoção."""
    ret = df.copy()
    _create_adoption_cols(ret, True)
    _create_adoption_cols(ret, False)
    return ret


def _create_adoption_cols(df: pd.DataFrame, adjusted: bool) -> None:
    na_rows = df["p_posterior"].isna()
    # ant_na_rows = df["p_anterior"].isna()

    df["Influência da IA"] = df.apply(_new_adoption_rule_1_pct, axis=1)
    print(df.sample(1).iloc[0])

    df.loc[na_rows, "Influência da IA"] = None


def _new_adoption_rule_1_pct(row: pd.Series):
    if row["q_posterior"] == 0 or row.isna()["q_posterior"]:
        return "SEM VENDAS"

    adoption = (row["p_projecao"] - row["p_posterior"]) / row["p_posterior"] <= 0.01
    new_price = (row["p_projecao"] - row["p_anterior"]) / row["p_anterior"] > 0.01

    if adoption and new_price:
        return "REMARCADO"
    if adoption:
        return "MANTIDO"

    return "NÃO REMARCADO"


def _adoption_rule_1_pct(df: pd.DataFrame, price_col: str, new_price_col: str) -> pd.Series:
    return abs(df[price_col] - df[new_price_col]) / df[new_price_col] <= 0.01


def _new_price_rule_1_pct(df: pd.DataFrame, price_col: str, new_price_col: str) -> pd.Series:
    return abs(df[price_col] - df[new_price_col]) / df[new_price_col] > 0.01


def _bool_to_str(x) -> str:
    return "VERDADEIRO" if x else "FALSO"


def _reorder_cols(df: pd.DataFrame, base_cols: Union[list, set], debug: bool = False) -> pd.DataFrame:
    """Função auxiliar para organizar a ordem das colunas.

    ---
    `df` precisa conter as seguintes colunas:
    - Data_Precificação, Description, AffiliateName
    - colunas da granularidade: `base_cols`
    - custo_*
    - m_*
    - p_*, p_sem_regra_projecao
    - q_anterior e q_posterior, d_projecao
    - r_*
    - l_*
    - Aproval
    - Erro de Projeção de **
    - Influência da IA (***) e Influência da IA - Preços Novos (***)
    - Preços Novos (***)
    - Alteração de **** (Semanal)

    em que
    - * vale: anterior, projecao, posterior
    - ** vale: Preço, Demanda, Receita, Lucro
    - *** vale: Preço Ajustado, Preço Sem Regras
    - **** vale: Margem, Volume, Receita, Lucro
    """
    base_infos = ["Data_Precificação", *base_cols, "AffiliateName", "Description"]

    # referencias de cada "grupo" de colunas
    custo = list()
    precos = list()
    regras = list()
    margens = list()
    volumes = list()
    receitas = list()
    lucros = list()
    erros = list()
    for i in df.columns:
        if "custo_" in i:
            custo.append(i)
        elif "p_" in i:
            precos.append(i)
        elif "Ajustado" in i or "Sem Regra" in i or "Influência" in i:
            regras.append(i)
        elif "m_" in i or "alt m" in i:
            margens.append(i)
        elif "q_" in i or "d_" in i or "alt q" in i:
            volumes.append(i)
        elif "r_" in i or "alt r" in i:
            receitas.append(i)
        elif "l_" in i or "alt l" in i:
            lucros.append(i)
        elif "erro " in i:
            erros.append(i)
        else:
            if i not in base_infos and not i in ["IdEnterprisePriceGroups", "Aproval"]:
                print("Coluna não referenciada:", i)

    cols = [*base_infos, *custo, *precos, "Aproval", *regras, *margens, *volumes, *receitas, *lucros, *erros]
    cols = _deduplicate(cols)

    if debug:
        print("\n[COLUNAS ANT]\n", df.columns, "\n")
        print(f"\n {base_infos = }")
        print(f"\n {custo = }")
        print(f"\n {precos = }")
        print(f"\n {regras = }")
        print(f"\n {margens = }")
        print(f"\n {volumes = }")
        print(f"\n {receitas = }")
        print(f"\n {lucros = }")
        print(f"\n {erros = }")
        print("\n[COLUNAS DPS]\n", cols, "\n")

    return df[cols]
