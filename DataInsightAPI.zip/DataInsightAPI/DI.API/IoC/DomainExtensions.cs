﻿using DI.Domain.ImpactData;
using DI.Domain.ImpactGraph;
using DI.Domain.ImpactReport;
using DI.Domain.ImpactReportConfiguration;

namespace DI.API.IoC
{
    public static class DomainExtensions
    {
        public static void AddDomain(this IServiceCollection services)
        {
            services.AddScoped<IImpactDataDomain, ImpactDataDomain>();
            services.AddScoped<IImpactGraphDomain, ImpactGraphDomain>();
            services.AddScoped<IImpactReportDomain, ImpactReportDomain>();
            services.AddScoped<IImpactReportConfigurationDomain, ImpactReportConfigurationDomain>();
        }
    }
}
