﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DI.Repository.Migrations.PostgreMigrations
{
    /// <inheritdoc />
    public partial class AddNewCollumnsMaxMinStatus : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<DateTime>(
                name: "MaxIssuance",
                table: "MonthlySaleHistoryImportStatus",
                type: "timestamp with time zone",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "MinIssuance",
                table: "MonthlySaleHistoryImportStatus",
                type: "timestamp with time zone",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "MaxIssuance",
                table: "MonthlySaleHistoryImportStatus");

            migrationBuilder.DropColumn(
                name: "MinIssuance",
                table: "MonthlySaleHistoryImportStatus");
        }
    }
}
