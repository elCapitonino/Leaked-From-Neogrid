﻿using Repository.EntityRepository;
using System.Transactions;

namespace Repository.UnitOfWork
{
    public class UnitOfWork : IUnitOfWork
    {
        private bool disposed = false;
        private readonly ApplicationDbContext dbContext;
        private readonly ChatDbContext chatDbContext;

        public UnitOfWork(ApplicationDbContext dbContext,ChatDbContext chatDbContext)
        {
            this.dbContext = dbContext;
            this.chatDbContext = chatDbContext;
            this.InitializeRepository(dbContext, chatDbContext);
        }

        public IRuleGroupRepository RuleGroupRepository { get; }
        public IRuleRepository RuleRepository { get; }
        public IDefaultFilterRepository DefaultFilterRepository { get; }
        public IProductMarketResultSellerRepository ProductMarketResultSellerRepository { get; }

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    dbContext.Dispose();
                    chatDbContext.Dispose();
                }
            }
            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            System.GC.SuppressFinalize(this);
        }

        public TransactionScope CreateTransactionScope() => new TransactionScope();
        public TransactionScope CreateTransactionScope(TransactionScopeAsyncFlowOption asyncFlowOption) => new TransactionScope(TransactionScopeOption.Required, TimeSpan.FromMinutes(60), asyncFlowOption);
    }
}
