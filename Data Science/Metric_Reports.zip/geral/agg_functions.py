"""
Funções para agregar colunas do relatório.
"""

import pandas as pd
import numpy as np


def count_remarcado(data: pd.Series) -> int:
    # agg_operation: np.sum
    return np.sum(data.apply(lambda xx: int(xx == "REMARCADO")))


def count_adoption(data: pd.Series) -> int:
    # agg_operation: np.sum
    return np.sum(data.apply(lambda xx: int(xx in ("REMARCADO", "MANTIDO"))))


def pct_remarcado(data: pd.Series) -> int:
    # agg_operation: np.mean
    return np.sum(data.apply(lambda xx: int(xx == "REMARCADO"))) / np.sum(
        data.apply(lambda xx: int(xx in ("REMARCADO", "NÃO REMARCADO")))
    )


def pct_adoption(data: pd.Series) -> int:
    # agg_operation: np.mean
    return np.sum(data.apply(lambda xx: int(xx in ("REMARCADO", "MANTIDO")))) / np.sum(
        data.apply(lambda xx: int(xx in ("REMARCADO", "NÃO REMARCADO", "MANTIDO")))
    )
