﻿using DI.Repository.Entities;

namespace DI.Repository.Interfaces.Repositories
{
    public interface IProjectionImpactDataRepository
    {
        IEnumerable<ProjectionImpactDataEntity> GetAllByPriceGroupId(long priceGroupId);
        IEnumerable<ProjectionImpactDataEntity> GetAllByPriceGroupId(List<long> priceGroupId);
    }
}