namespace Domain.Filter.Models;

public class FilterResponse
{
    public List<string?>? Products { get; set; }
    public List<string?>? Categories { get; set; }
    public List<string?>? Origins { get; set; }
    public List<string?>? Sellers { get; set; }
    public List<string?>? Brands { get; set; }
    public List<string?>? States { get; set; }
    public List<string?>? Regions { get; set; }
    public List<string?>? Segments { get; set; }
    public List<string?>? Years { get; set; }
    public List<string?>? Models { get; set; }
}

public class ProductFilterResponse
{
    public string? Name { get; set; }
}

public class CategoryFilterResponse
{
    public string? Category { get; set; }
}

public class OriginFilterResponse
{
    public int CrawlerId { get; set; }
}

public class SellerFilterResponse
{
    public string? Seller { get; set; }
}

public class BrandFilterResponse
{
    public string? Brand { get; set; }
}

public class RegionFilterResponse
{
    public string? Region { get; set; }
}

public class StateFilterResponse
{
    public string? UF { get; set; }
}

public class SegmentFilterResponse
{
    public string? Segment { get; set; }
}

public class YearFilterResponse
{
    public string? Year { get; set; }
}

public class ModelFilterResponse
{
    public string? Model { get; set; }
}