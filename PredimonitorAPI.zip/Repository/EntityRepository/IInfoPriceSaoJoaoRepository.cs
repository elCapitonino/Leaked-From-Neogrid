﻿using MongoDB.Bson;
using Repository.Entity;
using Repository.EntityRepository.Bases;

namespace Repository.EntityRepository
{
    public interface IInfoPriceSaoJoaoRepository : IGenericRepository<InfoPriceSaoJoaoEntity, ObjectId>, IMongoRepository
    {
    }
}