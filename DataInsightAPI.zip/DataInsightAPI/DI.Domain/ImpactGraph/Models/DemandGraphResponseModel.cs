﻿namespace DI.Domain.ImpactGraph.Models
{
    public class DemandGraphResponseModel
    {
        public DemandGraphResponseModel()
        {
            Categories = [];
            PreviousDemand = new GraphDataModel();
            ProjectedDemand = new GraphDataModel();
            RealizedDemand = new GraphDataModel();
            Royalties = new GraphDataModel();
            Goal = new GraphDataModel();
        }
        public List<GraphCategoryModel> Categories { get; set; }
        public GraphDataModel PreviousDemand { get; set; }
        public GraphDataModel ProjectedDemand { get; set; }
        public GraphDataModel RealizedDemand { get; set; }
        public GraphDataModel Royalties { get; set; }
        public GraphDataModel Goal { get; set; }
    }
}
