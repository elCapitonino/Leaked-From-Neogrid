﻿using PredifyClientAPI.Models;
using PredifyClientAPI.Services.DataInsightAPI.Models;
using PredifyClientAPI.Services.PredifyAPI.Models;
using PredifyClientAPI.Services.PredimonitorAPI.Models;

namespace PredifyClientAPI.Extensions
{
    public static class OptionsExtensions
    {
        public static IServiceCollection AddCustomOptions(this IServiceCollection services, IConfiguration configuration)
        {
            services.Configure<AppsettingsOptions>(configuration);
            services.Configure<PredifyAPIOptions>(configuration.GetSection("Services").GetSection("PredifyAPI"));
            services.Configure<PredimonitorAPIOptions>(configuration.GetSection("Services").GetSection("PredimonitorAPI"));
            services.Configure<DataInsightAPIOptions>(configuration.GetSection("Services").GetSection("DataInsightAPI"));
            return services;
        }
    }
}
