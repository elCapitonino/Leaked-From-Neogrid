﻿using PredifyClientAPI.Services.PredifyAPI.Empresa.Models;

namespace PredifyClientAPI.Services.PredifyAPI.Empresa
{
    public interface IEmpresaService
    {
        Task<IEnumerable<EmpresaSelecionarResponse>> GetEmpresaAsync();
    }
}
