﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Repository.Entity;

namespace Repository.TypeConfiguration
{
    public sealed class ProductMarketResultSellerTypeConfiguration : TypeConfigurationBase<ProductMarketResultSellerEntity>, IEntityTypeConfiguration<ProductMarketResultSellerEntity>
    {
        public override void Configure(EntityTypeBuilder<ProductMarketResultSellerEntity> builder)
        {
            ConfigureTableName(builder, "ProductMarketResultSeller");
            builder.ToTable("ProductMarketResultSeller", table => table.ExcludeFromMigrations());
            builder.Ignore(x => x.Id);
            builder.HasKey(x => x.ProductMarketResultSellerId);
            builder.Property(x => x.ProductMarketResultSellerId).HasColumnName("IdProductMarketResultSeller");
            builder.Property(x => x.CompanyId).HasColumnName("IdCompany");
            builder.Property(x => x.SellerName).HasMaxLength(256);
            builder.Property(x => x.CreatedDate).HasColumnName("CreateDate");
            builder.Ignore(x => x.UpdatedDate);
        }
    }
}
