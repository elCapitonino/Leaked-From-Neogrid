﻿using Newtonsoft.Json;
using PredifyClientAPI.Services.PredifyAPI.Models;
using PredifyClientAPI.Services.PredifyAPI.SaleHistory.Models;
using System.Text;

namespace PredifyClientAPI.Services.PredifyAPI.SaleHistory
{
    public class SaleHistoryService : ISaleHistoryService
    {
        private readonly HttpClient _client;

        public SaleHistoryService(HttpClient client)
        {
            _client = client;
        }

        public async Task<AnswerModel<string>> PostSaleHistory(EnterpriseSalesHistoryAddRequest request)
        {
            string jsonPayload = JsonConvert.SerializeObject(request);

            StringContent payload = new StringContent(jsonPayload, Encoding.UTF8, "application/json");

            var response = await _client.PostAsync($"/api/v2/Enterprise/SalesHistory", payload);
            var content = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
                return JsonConvert.DeserializeObject<AnswerModel<string>>(content);
            else if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                throw new UnauthorizedAccessException();

            throw new Exception(content);
        }
    }
}
