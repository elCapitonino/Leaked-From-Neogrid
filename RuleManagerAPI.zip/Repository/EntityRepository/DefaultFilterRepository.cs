﻿using Repository.Entity;

namespace Repository.EntityRepository
{
    public sealed class DefaultFilterRepository : GenericRepository<EnterprisePriceGroups_DefaultFilterEntity>, IDefaultFilterRepository
    {
        public new static string DbContextName => nameof(ApplicationDbContext);
        public DefaultFilterRepository(ApplicationDbContext dbContext) : base(dbContext)
        {
        }
    }
}
