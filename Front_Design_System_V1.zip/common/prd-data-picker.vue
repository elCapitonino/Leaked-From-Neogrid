<template>
    <div>
        <v-menu ref="menu" v-model="menu" :close-on-content-click="false" :return-value.sync="date"
            transition="scale-transition" offset-y min-width="auto">
            <template v-slot:activator="{ on, attrs }">
                <v-row no-gutters>
                    <v-col cols="auto">
                        <v-text-field v-model="dateFormatted"
                         readonly v-bind="attrs" v-on="on" outlined 
                         hint="DD/MM/YYYY format" persistent-hint dense 
                         hide-details>
                        </v-text-field>
                    </v-col>
                    <v-col>
                        <v-icon class="icon-calendar" color="white">$calendar</v-icon>
                    </v-col>
                </v-row>
            </template>
            <v-date-picker v-model="date" no-title scrollable>
                <v-spacer></v-spacer>
                <v-btn text color="primary" @click="menu = false">
                    Cancel
                </v-btn>
                <v-btn text color="primary" @click="$refs.menu.save(date)">
                    OK
                </v-btn>
            </v-date-picker>
        </v-menu>
    </div>
</template>

<script>
export default {
    name: 'dataPicker',
    data() {
        return {
            date: (new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10),
            dateFormatted: (new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10),
            menu: false,
        }
    },
    methods: {
        formatDate(date) {
            if (!date) return null
            const [year, month, day] = date.split('-')
            return `${day}/${month}/${year}`
        },
    },
    watch: {
      date () {
        this.dateFormatted = this.formatDate(this.date)
      },
    },
}
</script>

<style scoped>
.icon-calendar {
    align-items: center;
    background-color: #3C5CA7;
    border-top-right-radius: 5px;
    border-bottom-right-radius: 5px;
    border-top-left-radius: 3px;
    border-bottom-left-radius: 3px;
    width: 30px;
    height: 40px;
}

.flex {
    display: flex;
    flex-wrap: nowrap;
}
</style>