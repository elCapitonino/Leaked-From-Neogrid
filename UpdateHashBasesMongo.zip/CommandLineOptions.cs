﻿using CommandLine;

namespace UpdateHashHorus
{
    public class CommandLineOptions
    {
        [Option('s', "star-date", Required = true, HelpText = "Digite a data de início (formato: AAAA-MM-DD) ")]
        public DateTime StartDate { get; set; }

        [Option('e', "end-date", Required = true, HelpText = "Digite a data de fim (formato: AAAA-MM-DD) ")]
        public DateTime EndDate { get; set; }

        [Option('c', "connection-string", Required = true, HelpText = "Coloque a string de conexão do Mongo ")]

        public string ConnectionString { get; set; }

        [Option('b', "base", Required = true, HelpText = "Coloque a Base do Mongo que deseja acessar ")]

        public string Base { get; set; }

        [Option("collection", Required = true, HelpText = "Coloque a Collection da base para consultar valores ")]

        public string Collection { get; set; }

        [Option("batch-size", Required = false, Default = 1_000_000, HelpText = "Coloque a quantidade de produtos que deseja atualizar em lote ")]

        public int BatchSize { get; set; }

        [Option("dry-run", Required = false, Default = false, HelpText = "Executar o comando em modo de simulação. Nenhuma alteração será feita ")]

        public bool DryRun { get; set; }

        [Option("base-type", Required = true, HelpText = "Coloque qual base deseja atualizar ")]

        public BaseType BaseType { get; set; }
    }
}
