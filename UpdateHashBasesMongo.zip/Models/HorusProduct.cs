﻿using MongoDB.Bson;

public class HorusProduct
{
    public ObjectId _id { get; set; }
    public string cnpj { get; set; }
    public string brand { get; set; }
    public string brand_group { get; set; }
    public string uf { get; set; }
    public string city { get; set; }
    public string ean { get; set; }
    public string description { get; set; }
    public string category { get; set; }
    public DateTime? date { get; set; }
    public decimal? price { get; set; }
    public string format_market { get; set; }
    public string zipcode { get; set; }
    public string address { get; set; }
    public Coordinates? coordinates { get; set; }
    public DateTime? import_date { get; set; }
}

