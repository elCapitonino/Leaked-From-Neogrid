import pandas as pd
from sqlalchemy import MetaData, Table, bindparam, delete

from src.db import PostgreSQLConnection
from src.logger import logger


def insert_data_into_postgresql(
    pg_conn: PostgreSQLConnection,
    pg_metadata: MetaData,
    df: pd.DataFrame,
    id_company: int,
    price_group: int,
):
    table = Table("ProjectionImpactData", pg_metadata, autoload_with=pg_conn)

    delete_stmt = delete(table).where(
        table.c.CompanyId == id_company, table.c.PriceGroupId == price_group
    )
    res = pg_conn.execute(delete_stmt)
    logger.info(
        "Deleted old data (%d lines) for CompanyId: %s and PriceGroupId: %s",
        res.rowcount,
        id_company,
        price_group,
    )

    df["Adopted"] = df["Adopted"].astype(bool)
    df["HasSuggestion"] = df["HasSuggestion"].astype(bool)
    df = df[
        [
            "PriceGroupId",
            "PriceProjectionId",
            "GranularityGroupId",
            "ProductId",
            "PriorCost",
            "ProjectionCost",
            "RealCost",
            "PriorPrice",
            "ProjectionPrice",
            "RealPrice",
            "PriorDemand",
            "ProjectionDemand",
            "RealDemand",
            "PriorRevenue",
            "ProjectionRevenue",
            "RealRevenue",
            "PriorProfit",
            "ProjectionProfit",
            "RealProfit",
            "PriorMargin",
            "ProjectionMargin",
            "RealMargin",
            "Adopted",
            "CreatedDate",
            "UpdatedDate",
            "YearMonth",
            "CompanyId",
            "HasSuggestion",
            "Affiliate",
        ]
    ]
    rows = df.to_dict("records")
    stmt = table.insert().values({col: bindparam(col) for col in df.columns})
    logger.info(
        "inserting %d rows for id_company %d and price_group %d into ProjectionImpactData",
        len(rows),
        id_company,
        price_group,
    )
    pg_conn.execute(stmt, rows)
