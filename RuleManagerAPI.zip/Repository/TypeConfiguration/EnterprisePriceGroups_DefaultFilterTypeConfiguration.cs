﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Repository.Entity;

namespace Repository.TypeConfiguration
{
    public sealed class EnterprisePriceGroups_DefaultFilterTypeConfiguration : TypeConfigurationBase<EnterprisePriceGroups_DefaultFilterEntity>, IEntityTypeConfiguration<EnterprisePriceGroups_DefaultFilterEntity>
    {
        public override void Configure(EntityTypeBuilder<EnterprisePriceGroups_DefaultFilterEntity> builder)
        {
            ConfigureTableName(builder, "EnterprisePriceGroups_DefaultFilter");
            builder.ToTable("EnterprisePriceGroups_DefaultFilter", table => table.ExcludeFromMigrations());
            builder.Ignore(x => x.Id);
            builder.HasKey(x => x.EnterprisePriceGroups_DefaultFilterId);
            builder.Property(x => x.FieldName).HasMaxLength(50);
            builder.Property(x => x.GroupTag).HasMaxLength(63);
            builder.Property(x => x.Tooltip).HasMaxLength(255);
            builder.Property(x => x.EnterprisePriceGroups_DefaultFilterId).HasColumnName("IdEnterprisePriceGroups_DefaultFilter");
            builder.Property(x => x.CreatedDate).HasColumnName("CreateDate");
            builder.Ignore(x => x.UpdatedDate);

            builder.HasOne(x => x.Parent).WithMany().HasForeignKey(x => x.IdParent);
        }
    }
}
