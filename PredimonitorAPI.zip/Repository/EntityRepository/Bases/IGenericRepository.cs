﻿using Repository.Entity;

namespace Repository.EntityRepository.Bases
{
    public interface IGenericRepository<TEntity, TPKType> where TEntity : class, IEntityBase<TPKType>
    {
        static string DbContextName { get; }
        string? TableName { get; }

        TEntity Create(TEntity entity, bool autosave = true);
        IQueryable<TEntity> GetAll();
        TEntity? GetById(TPKType id);
        void Update(TEntity entity, bool autosave = true);
        void Update(IEnumerable<TEntity> entity, bool autosave = true);
        void SaveChanges();
        void Delete(TPKType id);
        void Delete(TEntity entity, bool autosave = true);
        void AddRange(IEnumerable<TEntity> entities, bool autosave = false);
        IQueryable<TEntity> ExecuteRawSQL(string sql);
        Task ExecuteRawSQLAsync(string sql);
        void DeleteAll(IEnumerable<TPKType> ids);
    }
}
