import calendar
from datetime import date, datetime, timedelta, timezone
from enum import Enum
from typing import Callable, NamedTuple, Optional

import pandas as pd
from dateutil.relativedelta import relativedelta
from sqlalchemy import MetaData, Subquery, Table, bindparam, delete, func, select

from src.db import (
    PostgreSQLConnection,
    PostgreSQLEngine,
    SQLServerConnection,
    SQLServerEngine,
)
from src.exceptions import ConfigError
from src.granularity import GranularityGroup, GranularityType, load_granularity
from src.logger import logger
from src.projections import (
    calculate_adoption,
    fetch_projections,
    find_last_price_projection,
    get_published_date,
    read_price_groups,
)
from src.utils import build_product_id, check_product_id_uniqueness


def get_consolidate_group_by(
    pg_conn: PostgreSQLConnection,
    metadata: MetaData,
    id_company: int,
    granularity: list[str],
) -> Optional[str]:
    table = Table("ImpactReportConfiguration", metadata, autoload_with=pg_conn)
    stmt = (
        select(table.c.ConsolidateFieldGroupBy)
        .where(table.c.CompanyId == id_company)
        .order_by(func.coalesce(table.c.UpdatedDate, table.c.CreatedDate).desc())
        .limit(1)
    )
    row = pg_conn.execute(stmt).fetchone()
    consolidate_group_by = row[0] if row else None
    consolidate_group_by = (
        consolidate_group_by if consolidate_group_by else granularity[0]
    )
    return consolidate_group_by


def count_adoptions(df_adoption: pd.DataFrame, granularity: list[str]) -> pd.DataFrame:
    major_granularity = granularity[0]

    df_adoption["ProductId"] = build_product_id(df_adoption, granularity)
    all_adoptions = (
        df_adoption.groupby(
            ["ProductId", major_granularity, "IdEnterprisePriceGroups"], dropna=False
        )["AdoptionIssuance"]
        .max()
        .reset_index()
    )
    valid_adoptions = (
        df_adoption.loc[df_adoption["Approved"], :]
        .groupby(
            ["ProductId", major_granularity, "IdEnterprisePriceGroups"], dropna=False
        )["AdoptionIssuance"]
        .max()
        .reset_index()
    )

    num_adoptions = (
        valid_adoptions["AdoptionIssuance"]
        .notna()
        .groupby(
            [valid_adoptions["ProductId"], valid_adoptions[major_granularity]],
            dropna=False,
        )
        .sum()
        .reset_index()
        .rename(columns={"AdoptionIssuance": "adoption_count"})
    )
    num_approved = (
        df_adoption.loc[df_adoption["Approved"], :]
        .groupby(["ProductId", major_granularity], dropna=False)[
            "IdEnterprisePriceGroups"
        ]
        .nunique()
        .reset_index()
        .rename(columns={"IdEnterprisePriceGroups": "approved_count"})
    )
    total_suggestions = (
        all_adoptions.groupby(["ProductId", major_granularity], dropna=False)[
            "IdEnterprisePriceGroups"
        ]
        .count()
        .reset_index()
        .rename(columns={"IdEnterprisePriceGroups": "suggestion_count"})
    )
    out = pd.merge(
        num_adoptions,
        total_suggestions,
        on=["ProductId", major_granularity],
        how="outer",
    )
    out = pd.merge(out, num_approved, on=["ProductId", major_granularity], how="outer")
    out = out.fillna(0)
    out["not_adoption_count"] = out["approved_count"] - out["adoption_count"]
    if (out["not_adoption_count"] < 0).any():
        raise ValueError("unexpected negative value in not_adoption_count")

    return out


def calculate_projected_metrics(
    *,
    conn: SQLServerConnection,
    metadata: MetaData,
    df_adoption: pd.DataFrame,
    df_projections: pd.DataFrame,
    id_company: int,
    granularity: list[str],
    initial_date: date,
    final_date: date,
):
    table_sales_history = Table(
        "Enterprise_Sales_History", metadata, autoload_with=conn
    )

    stmt_latest_date = select(func.max(table_sales_history.c.Issuance)).where(
        table_sales_history.c.IdCompany == id_company,
        table_sales_history.c.IsDeletado == 0,
    )
    latest_date = conn.execute(stmt_latest_date).fetchone()[0].date()
    final_date = min(latest_date + timedelta(days=1), final_date)

    gran_values = df_adoption[granularity].drop_duplicates()
    gran_values["PublishedDate"] = pd.Timestamp(final_date)
    gran_values["IdEnterprisePriceGroups"] = pd.NA

    df_adoption = pd.concat((df_adoption, gran_values)).reset_index(drop=True)

    df_suggestions = (
        df_adoption[
            [
                *granularity,
                "ConsolidateGroupBy",
                "IdEnterprisePriceGroups",
                "SuggestedPrice",
                "PublishedDate",
            ]
        ]
        .drop_duplicates()
        .rename(columns={"PublishedDate": "projection_datetime"})
    )
    df_adopted_suggestions = (
        df_adoption.loc[df_adoption["AdoptionIssuance"].notna(), :]
        .rename(columns={"AdoptionIssuance": "projection_datetime"})
        .drop(columns=["SalePrice", "PublishedDate"])
    )

    # NOTE adoções têm preferência sobre sugestões
    df_suggestions["sort_dummy"] = 0
    df_adopted_suggestions["sort_dummy"] = 1

    df_suggestions = pd.concat(
        (df_suggestions, df_adopted_suggestions), ignore_index=True, axis=0
    )
    df_suggestions = df_suggestions.sort_values(["projection_datetime", "sort_dummy"])

    df_suggestions["projection_datetime"] = pd.to_datetime(
        df_suggestions["projection_datetime"], errors="coerce"
    )
    df_suggestions["projection_date"] = df_suggestions["projection_datetime"].dt.floor(
        "D"
    )
    if df_suggestions["projection_date"].isna().any():
        logger.warning("null values in projection_date, removing rows")
        df_suggestions = df_suggestions.loc[
            df_suggestions["projection_date"].notna(), :
        ]

    # NOTE trazer projeções de meses anteriores para data inicial
    df_suggestions["projection_date"] = df_suggestions["projection_date"].clip(
        lower=pd.Timestamp(initial_date)
    )
    df_suggestions = (
        df_suggestions.groupby([*granularity, "projection_date"]).last().reset_index()
    )

    df_suggestions["next_projection_date"] = (
        df_suggestions.sort_values("projection_date")
        .groupby([*granularity])["projection_date"]
        .shift(-1)
    )

    df_suggestions = df_suggestions.loc[
        df_suggestions["IdEnterprisePriceGroups"].notna(), :
    ]
    df_suggestions["projected_days"] = (
        df_suggestions["next_projection_date"] - df_suggestions["projection_date"]
    )

    df_proj_metrics = df_projections[
        [*granularity, "IdEnterprisePriceGroups", "cost", "price", "demand"]
    ]
    logger.debug("df_suggestions shape: %s", df_suggestions.shape)

    df_metrics = pd.merge(
        df_suggestions,
        df_proj_metrics,
        how="inner",
        on=[*granularity, "IdEnterprisePriceGroups"],
    )

    df_metrics["total_demand"] = (
        df_metrics["demand"] * df_metrics["projected_days"].dt.days
    )
    df_metrics["total_revenue"] = df_metrics["total_demand"] * df_metrics["price"]
    df_metrics["total_cost"] = df_metrics["total_demand"] * df_metrics["cost"]
    df_metrics["total_profit"] = df_metrics["total_revenue"] - df_metrics["total_cost"]
    df_metrics["margin"] = df_metrics["total_profit"] / df_metrics["total_revenue"]
    logger.debug("df_metrics shape: %s", df_metrics.shape)

    return df_metrics


def get_history_data(
    pg_conn: PostgreSQLConnection,
    metadata: MetaData,
    id_company: int,
    year_month: int,
    granularity_group: GranularityGroup,
) -> pd.DataFrame:
    table_monthly_history = Table(
        "MonthlySaleHistoryData", metadata, autoload_with=pg_conn
    )
    stmt = select(
        table_monthly_history.c.ProductId,
        table_monthly_history.c.MajorGranularity,
        table_monthly_history.c.ConsolidateGroupBy,
        table_monthly_history.c.TotalQuantity.label("DemandNotProjected"),
        table_monthly_history.c.Profit.label("ProfitNotProjected"),
        table_monthly_history.c.Revenue.label("RevenueNotProjected"),
    ).where(
        table_monthly_history.c.CompanyId == id_company,
        table_monthly_history.c.GranularityGroupId == granularity_group.group_id,
        table_monthly_history.c.YearMonth == year_month,
    )
    df = pd.read_sql(stmt, pg_conn)

    check_product_id_uniqueness(df)

    return df


def prepare_monthly_projections(
    *,
    year_month: int,
    df_history: pd.DataFrame,
    df_projections: pd.DataFrame,
    df_agg_projections: pd.DataFrame,
    df_adoption_count: pd.DataFrame,
    granularity_group: GranularityGroup,
    consolidate_group_by_col: str,
) -> pd.DataFrame:

    granularity = granularity_group.to_columns()
    df_agg_projections["ProductId"] = build_product_id(df_agg_projections, granularity)

    minor_granularity = granularity[1:] if len(granularity) > 1 else []
    major_granularity = granularity[0]
    # TODO abstrair produto
    if minor_granularity:
        df_agg_projections = df_agg_projections.drop(columns=minor_granularity)

    df_agg_projections = (
        df_agg_projections.groupby("ProductId", dropna=False)
        .agg(
            {
                "total_revenue": "sum",
                "total_demand": "sum",
                "total_profit": "sum",
                major_granularity: "max",
                "ConsolidateGroupBy": "max",
            }
        )
        .reset_index()
    )

    map_cols = sorted({major_granularity, consolidate_group_by_col})
    df_consolidate_map = (
        df_projections.sort_values("PublishedDate", ascending=False)
        .groupby("ProductId")[map_cols]
        .first()
        .reset_index()
        .drop_duplicates()
    )

    rename_major_gran = major_granularity
    if major_granularity == consolidate_group_by_col:
        df_consolidate_map["dummy_major"] = df_consolidate_map[major_granularity]
        rename_major_gran = "dummy_major"

    df_consolidate_map = df_consolidate_map.rename(
        columns={
            rename_major_gran: "MajorGranularity",
            consolidate_group_by_col: "ConsolidateGroupBy",
        }
    )

    df_agg_projections = df_agg_projections.drop(
        columns=[major_granularity, "ConsolidateGroupBy"]
    )
    df_agg_projections = pd.merge(
        df_consolidate_map, df_agg_projections, on="ProductId", how="left"
    )

    df_adoption_count = df_adoption_count.rename(
        columns={major_granularity: "MajorGranularity"}
    )
    df_agg_projections = pd.merge(
        df_agg_projections,
        df_adoption_count,
        on=["ProductId", "MajorGranularity"],
        how="left",
    )

    df_history = df_history.rename(
        columns={
            "MajorGranularity": "MajorGranularity_hist",
            "ConsolidateGroupBy": "ConsolidateGroupBy_hist",
        }
    )
    df_agg_projections = pd.merge(
        df_agg_projections,
        df_history,
        on=["ProductId"],
        how="outer",
    )
    df_agg_projections["MajorGranularity"] = df_agg_projections[
        "MajorGranularity"
    ].fillna(df_agg_projections["MajorGranularity_hist"])
    df_agg_projections["ConsolidateGroupBy"] = df_agg_projections[
        "ConsolidateGroupBy"
    ].fillna(df_agg_projections["ConsolidateGroupBy_hist"])
    df_agg_projections = df_agg_projections.drop(
        columns=["MajorGranularity_hist", "ConsolidateGroupBy_hist"]
    )

    df_agg_projections["RevenueNotProjected"] = df_agg_projections[
        "RevenueNotProjected"
    ].where(df_agg_projections["total_demand"].isna(), 0)
    df_agg_projections["DemandNotProjected"] = df_agg_projections[
        "DemandNotProjected"
    ].where(df_agg_projections["total_demand"].isna(), 0)
    df_agg_projections["ProfitNotProjected"] = df_agg_projections[
        "ProfitNotProjected"
    ].where(df_agg_projections["total_demand"].isna(), 0)

    df_agg_projections["RevenueNotProjected"] = df_agg_projections[
        "RevenueNotProjected"
    ].fillna(0)
    df_agg_projections["DemandNotProjected"] = df_agg_projections[
        "DemandNotProjected"
    ].fillna(0)
    df_agg_projections["ProfitNotProjected"] = df_agg_projections[
        "ProfitNotProjected"
    ].fillna(0)

    df_agg_projections["suggestion_count"] = df_agg_projections[
        "suggestion_count"
    ].fillna(0)
    df_agg_projections["adoption_count"] = df_agg_projections["adoption_count"].fillna(
        0
    )
    df_agg_projections["approved_count"] = df_agg_projections["approved_count"].fillna(
        0
    )
    df_agg_projections["not_adoption_count"] = df_agg_projections[
        "not_adoption_count"
    ].fillna(0)

    df_agg_projections["total_revenue"] = df_agg_projections["total_revenue"].fillna(0)
    df_agg_projections["total_demand"] = df_agg_projections["total_demand"].fillna(0)
    df_agg_projections["total_profit"] = df_agg_projections["total_profit"].fillna(0)

    df_agg_projections = df_agg_projections.rename(
        columns={
            "total_revenue": "Revenue",
            "total_demand": "Demand",
            "total_profit": "Profit",
            "adoption_count": "AdoptionCount",
            "suggestion_count": "PricingCount",
            "not_adoption_count": "NotAdoptionCount",
            "approved_count": "ApprovedCount",
        }
    )

    df_agg_projections["GranularityGroupId"] = granularity_group.group_id
    df_agg_projections["YearMonth"] = year_month

    check_product_id_uniqueness(df_agg_projections)

    return df_agg_projections


def aggregate_projections(df_metrics, granularity, initial_date):
    df_agg_metrics = (
        df_metrics.groupby(granularity)
        .agg(
            {
                "total_demand": "sum",
                "total_revenue": "sum",
                "total_cost": "sum",
                "total_profit": "sum",
                "projected_days": "sum",
                "ConsolidateGroupBy": "max",
            }
        )
        .reset_index()
    )

    # NOTE correção para que todos os produtos com pelo menos 1 sugestão
    # tenham projeção em todos dias do mês
    _, num_days = calendar.monthrange(initial_date.year, initial_date.month)
    df_agg_metrics["multiplier"] = num_days / df_agg_metrics["projected_days"].dt.days
    for col in (
        "total_demand",
        "total_revenue",
        "total_cost",
        "total_profit",
        "projected_days",
    ):
        df_agg_metrics[col] = df_agg_metrics[col] * df_agg_metrics["multiplier"]
    return df_agg_metrics


def sum_projections(
    conn: PostgreSQLConnection,
    metadata: MetaData,
    df_projections: pd.DataFrame,
    id_company: int,
    year_month: int,
) -> tuple[pd.DataFrame, GranularityGroup]:

    granularity_group = load_granularity(
        pg_conn=conn,
        metadata=metadata,
        id_company=id_company,
        granularity_type=GranularityType.NONE,
    )

    projections = df_projections.agg(
        {
            "AdoptionCount": "sum",
            "NotAdoptionCount": "sum",
            "PricingCount": "sum",
            "ApprovedCount": "sum",
            "Demand": "sum",
            "Revenue": "sum",
            "Profit": "sum",
            "DemandNotProjected": "sum",
            "ProfitNotProjected": "sum",
            "RevenueNotProjected": "sum",
        }
    )
    projections["YearMonth"] = year_month
    projections["CompanyId"] = id_company
    projections["GranularityGroupId"] = granularity_group.group_id
    return pd.DataFrame(projections).T, granularity_group


def _delete_monthly_projections(
    *,
    conn: PostgreSQLConnection,
    metadata: MetaData,
    id_company: int,
    year_month: int,
    granularity_group: GranularityGroup,
) -> None:
    table_monthly_projection_data = Table(
        "MonthlyProjectionData", metadata, autoload_with=conn
    )

    stmt = delete(table_monthly_projection_data).where(
        table_monthly_projection_data.c.CompanyId == id_company,
        table_monthly_projection_data.c.YearMonth == year_month,
        table_monthly_projection_data.c.GranularityGroupId
        == granularity_group.group_id,
    )
    result = conn.execute(stmt)
    logger.info(
        "deleted %d rows with filter id_company = %d, year_month = %d and granularity group ID %s",
        result.rowcount,
        id_company,
        year_month,
        granularity_group.group_id,
    )


def _insert_monthly_projections(
    *,
    conn: PostgreSQLConnection,
    metadata: MetaData,
    id_company: int,
    year_month: int,
    df_projections: pd.DataFrame,
) -> None:
    if df_projections.empty:
        logger.info(
            "empty dataframe, skipping insertion of id_company %s and year_month %s",
            id_company,
            year_month,
        )
        return

    table_monthly_sale_history_data = Table(
        "MonthlyProjectionData", metadata, autoload_with=conn
    )

    now = datetime.now(timezone.utc)
    df_projections["CreatedDate"] = now
    df_projections["CompanyId"] = id_company
    df_projections[["Demand", "Revenue", "Profit"]] = (
        df_projections[["Demand", "Revenue", "Profit"]].astype(float).round(2)
    )

    metric_rows = df_projections.to_dict("records")
    stmt = table_monthly_sale_history_data.insert().values(
        {col: bindparam(col) for col in df_projections.columns}
    )
    logger.info(
        "inserting %d rows for id_company %d and year_month %d into MonthlyProjectionData",
        len(metric_rows),
        id_company,
        year_month,
    )
    conn.execute(stmt, metric_rows)


def upsert_monthly_projections(
    conn: PostgreSQLConnection,
    metadata: MetaData,
    df_projections: pd.DataFrame,
    id_company: int,
    year_month: int,
    granularity_group: GranularityGroup,
) -> None:
    _delete_monthly_projections(
        conn=conn,
        metadata=metadata,
        id_company=id_company,
        year_month=year_month,
        granularity_group=granularity_group,
    )
    _insert_monthly_projections(
        conn=conn,
        metadata=metadata,
        id_company=id_company,
        year_month=year_month,
        df_projections=df_projections,
    )


def _add_last_price_group(
    df_proj: pd.DataFrame, df_last_pg: pd.DataFrame, granularity: list[str]
) -> pd.DataFrame:
    df_last_pg["previous_month"] = True
    df_proj = pd.merge(
        df_proj,
        df_last_pg,
        on=[*granularity, "IdEnterprisePriceGroups"],
        how="left",
    )
    df_proj["previous_month"] = df_proj["previous_month"].fillna(False)
    return df_proj


class AggregateDataType(Enum):
    """Tipos de agregação de dados de impacto.

    - ALL: considera todas as granularidades com preço sugerido ou presentes
    no histórico de vendas. Difere das outras por ser um FULL OUTER JOIN.
    Compara o mês vigente com o anterior.
    - PRICED: considera granularidades com >= 1 preço sugerido. Compara o
    mês vigente com o anterior.
    - APPROVED: considera granularidades com >= 1 preço aprovado. Compara
    o mês vigente com o anterior.
    - ADOPTED: considera granularidades com >= 1 preço adotado. Compara o
    mês vigente com o anterior.
    - ALL_LAST_YEAR: mesma lógica de ALL, mas compara o mês vigente
    com o mesmo mês do ano anterior.
    - PRICED_LAST_YEAR: mesma lógica do PRICED, mas compara o mês vigente
    com o mesmo mês do ano anterior.
    - APPROVED_LAST_YEAR: mesma lógica do APPROVED, mas compara o mês
    vigente com o mesmo mês do ano anterior.
    - ADOPTED_LAST_YEAR: mesma lógica do ADOPTED, mas compara o mês
    vigente com o mesmo mês do ano anterior.
    """

    ALL = 0
    PRICED = 1
    APPROVED = 2
    ADOPTED = 3
    ALL_LAST_YEAR = 4
    PRICED_LAST_YEAR = 5
    APPROVED_LAST_YEAR = 6
    ADOPTED_LAST_YEAR = 7


def _get_monthly_sales_subquery(
    pg_conn: PostgreSQLConnection,
    pg_metadata: MetaData,
    id_company: int,
    year_month: int,
    granularity: GranularityGroup,
) -> Subquery:
    table_monthly_sales_history = Table(
        "MonthlySaleHistoryData", pg_metadata, autoload_with=pg_conn
    )

    sales_subquery = (
        table_monthly_sales_history.select()
        .where(
            table_monthly_sales_history.c.YearMonth == year_month,
            table_monthly_sales_history.c.CompanyId == id_company,
            table_monthly_sales_history.c.GranularityGroupId == granularity.group_id,
        )
        .subquery()
    )
    return sales_subquery


def _get_monthly_proj_subquery(
    pg_conn: PostgreSQLConnection,
    pg_metadata: MetaData,
    id_company: int,
    year_month: int,
    granularity: GranularityGroup,
) -> Subquery:
    table_monthly_projection = Table(
        "MonthlyProjectionData", pg_metadata, autoload_with=pg_conn
    )
    projections_subquery = (
        select(
            table_monthly_projection.c.ProductId,
            table_monthly_projection.c.ConsolidateGroupBy,
            table_monthly_projection.c.MajorGranularity,
            table_monthly_projection.c.AdoptionCount,
            table_monthly_projection.c.NotAdoptionCount,
            table_monthly_projection.c.PricingCount,
            (
                table_monthly_projection.c.Demand
                + table_monthly_projection.c.DemandNotProjected
            ).label("Demand"),
            (
                table_monthly_projection.c.Revenue
                + table_monthly_projection.c.RevenueNotProjected
            ).label("Revenue"),
            (
                table_monthly_projection.c.Profit
                + table_monthly_projection.c.ProfitNotProjected
            ).label("Profit"),
        )
        .where(
            table_monthly_projection.c.GranularityGroupId == granularity.group_id,
            table_monthly_projection.c.CompanyId == id_company,
            table_monthly_projection.c.YearMonth == year_month,
        )
        .subquery()
    )

    return projections_subquery


def _outer_join_sales_projection(
    sales_before: Subquery, sales_after: Subquery, projections: Subquery
) -> Subquery:
    join_subquery = (
        select(
            func.coalesce(
                projections.c.ConsolidateGroupBy,
                sales_after.c.ConsolidateGroupBy,
                sales_before.c.ConsolidateGroupBy,
            ).label("ConsolidateGroupBy"),
            func.coalesce(
                projections.c.MajorGranularity,
                sales_after.c.MajorGranularity,
                sales_before.c.MajorGranularity,
            ).label("MajorGranularity"),
            projections.c.AdoptionCount,
            projections.c.NotAdoptionCount,
            projections.c.PricingCount,
            projections.c.Demand.label("ProjectionDemand"),
            projections.c.Revenue.label("ProjectionRevenue"),
            projections.c.Profit.label("ProjectionProfit"),
            sales_before.c.TotalQuantity.label("PriorDemand"),
            sales_before.c.TotalCost.label("PriorCost"),
            sales_before.c.Revenue.label("PriorRevenue"),
            sales_before.c.Profit.label("PriorProfit"),
            sales_before.c.RoyaltyReal.label("PriorRoyalty"),
            sales_after.c.TotalQuantity.label("RealDemand"),
            sales_after.c.TotalCost.label("RealCost"),
            sales_after.c.Revenue.label("RealRevenue"),
            sales_after.c.Profit.label("RealProfit"),
            sales_after.c.RoyaltyReal.label("RealRoyalty"),
        )
        .join(
            sales_before,
            projections.c.ProductId == sales_before.c.ProductId,
            isouter=True,
            full=True,
        )
        .join(
            sales_after,
            projections.c.ProductId == sales_after.c.ProductId,
            isouter=True,
            full=True,
        )
        .subquery()
    )
    return join_subquery


def _join_sales_projection(
    sales_before: Subquery, sales_after: Subquery, projections: Subquery
) -> Subquery:
    join_subquery = (
        select(
            projections.c.ConsolidateGroupBy,
            projections.c.MajorGranularity,
            projections.c.AdoptionCount,
            projections.c.NotAdoptionCount,
            projections.c.PricingCount,
            projections.c.Demand.label("ProjectionDemand"),
            projections.c.Revenue.label("ProjectionRevenue"),
            projections.c.Profit.label("ProjectionProfit"),
            sales_before.c.TotalQuantity.label("PriorDemand"),
            sales_before.c.TotalCost.label("PriorCost"),
            sales_before.c.Revenue.label("PriorRevenue"),
            sales_before.c.Profit.label("PriorProfit"),
            sales_before.c.RoyaltyReal.label("PriorRoyalty"),
            sales_after.c.TotalQuantity.label("RealDemand"),
            sales_after.c.TotalCost.label("RealCost"),
            sales_after.c.Revenue.label("RealRevenue"),
            sales_after.c.Profit.label("RealProfit"),
            sales_after.c.RoyaltyReal.label("RealRoyalty"),
        )
        .join(
            sales_before,
            projections.c.ProductId == sales_before.c.ProductId,
            isouter=True,
        )
        .join(
            sales_after,
            projections.c.ProductId == sales_after.c.ProductId,
            isouter=True,
        )
        .subquery()
    )
    return join_subquery


def _sum_aggregated_metrics(
    join_subquery: Subquery,
    id_company: int,
    year_month: int,
    pg_conn: PostgreSQLConnection,
) -> pd.DataFrame:
    stmt = select(
        join_subquery.c.ConsolidateGroupBy,
        join_subquery.c.MajorGranularity,
        func.sum(join_subquery.c.AdoptionCount).label("AdoptionCount"),
        func.sum(join_subquery.c.NotAdoptionCount).label("NotAdoptionCount"),
        func.sum(join_subquery.c.PricingCount).label("PricingCount"),
        func.sum(join_subquery.c.ProjectionDemand).label("ProjectionDemand"),
        func.sum(join_subquery.c.ProjectionRevenue).label("ProjectionRevenue"),
        func.sum(join_subquery.c.ProjectionProfit).label("ProjectionProfit"),
        func.sum(join_subquery.c.PriorDemand).label("PriorDemand"),
        func.sum(join_subquery.c.PriorCost).label("PriorCost"),
        func.sum(join_subquery.c.PriorRevenue).label("PriorRevenue"),
        func.sum(join_subquery.c.PriorProfit).label("PriorProfit"),
        func.sum(join_subquery.c.PriorRoyalty).label("PriorRoyalty"),
        func.sum(join_subquery.c.RealDemand).label("RealDemand"),
        func.sum(join_subquery.c.RealCost).label("RealCost"),
        func.sum(join_subquery.c.RealRevenue).label("RealRevenue"),
        func.sum(join_subquery.c.RealProfit).label("RealProfit"),
        func.sum(join_subquery.c.RealRoyalty).label("RealRoyalty"),
    ).group_by(
        join_subquery.c.ConsolidateGroupBy,
        join_subquery.c.MajorGranularity,
    )

    logger.debug(
        "impact query:\n%s\nparams: %s",
        stmt,
        stmt.compile().params,
    )
    df_monthly = pd.read_sql(stmt, pg_conn)

    df_monthly["ConsolidateGroupBy"] = df_monthly["ConsolidateGroupBy"].fillna("")
    num_cols = [
        "AdoptionCount",
        "NotAdoptionCount",
        "PricingCount",
        "ProjectionDemand",
        "ProjectionRevenue",
        "ProjectionProfit",
        "RealDemand",
        "RealCost",
        "RealRevenue",
        "RealProfit",
        "RealRoyalty",
        "PriorDemand",
        "PriorCost",
        "PriorRevenue",
        "PriorProfit",
        "PriorRoyalty",
    ]
    df_monthly[num_cols] = df_monthly[num_cols].fillna(0)

    df_monthly["ProductId"] = build_product_id(
        df_monthly, ["MajorGranularity", "ConsolidateGroupBy"]
    )
    df_monthly["CompanyId"] = id_company
    df_monthly["YearMonth"] = year_month

    # FIXME corrigir tabela
    df_monthly["ProjectionCost"] = 0
    df_monthly["ProjectionRoyalty"] = 0
    df_monthly = df_monthly.rename(columns={"ConsolidateGroupBy": "ConsolidadeGroupBy"})

    check_product_id_uniqueness(df_monthly)
    return df_monthly


def _aggregate_monthly_impact(
    *,
    pg_conn: PostgreSQLConnection,
    pg_metadata: MetaData,
    id_company: int,
    year_month: int,
    previous_year_month: int,
    granularity: GranularityGroup,
    projections_filter_fn: Callable[[Subquery], Subquery],
    full_outer_join: bool = False,
) -> pd.DataFrame:
    sales_before = _get_monthly_sales_subquery(
        pg_conn, pg_metadata, id_company, previous_year_month, granularity
    )
    sales_after = _get_monthly_sales_subquery(
        pg_conn, pg_metadata, id_company, year_month, granularity
    )
    projections_subquery = _get_monthly_proj_subquery(
        pg_conn, pg_metadata, id_company, year_month, granularity
    )
    projections_subquery = projections_filter_fn(projections_subquery)

    join_fn = (
        _outer_join_sales_projection if full_outer_join else _join_sales_projection
    )
    join_subquery = join_fn(sales_before, sales_after, projections_subquery)
    df_monthly = _sum_aggregated_metrics(join_subquery, id_company, year_month, pg_conn)
    return df_monthly


def aggregate_monthly_impact_all(
    *,
    pg_conn: PostgreSQLConnection,
    pg_metadata: MetaData,
    id_company: int,
    year_month: int,
    previous_year_month: int,
    granularity: GranularityGroup,
) -> pd.DataFrame:
    return _aggregate_monthly_impact(
        pg_conn=pg_conn,
        pg_metadata=pg_metadata,
        id_company=id_company,
        year_month=year_month,
        previous_year_month=previous_year_month,
        granularity=granularity,
        projections_filter_fn=lambda q: q,
        full_outer_join=True,
    )


def aggregate_monthly_impact_priced(
    *,
    pg_conn: PostgreSQLConnection,
    pg_metadata: MetaData,
    id_company: int,
    year_month: int,
    previous_year_month: int,
    granularity: GranularityGroup,
) -> pd.DataFrame:
    return _aggregate_monthly_impact(
        pg_conn=pg_conn,
        pg_metadata=pg_metadata,
        id_company=id_company,
        year_month=year_month,
        previous_year_month=previous_year_month,
        granularity=granularity,
        projections_filter_fn=lambda q: q.select()
        .where(q.c.PricingCount > 0)
        .subquery(),
    )


def aggregate_monthly_impact_approved(
    *,
    pg_conn: PostgreSQLConnection,
    pg_metadata: MetaData,
    id_company: int,
    year_month: int,
    previous_year_month: int,
    granularity: GranularityGroup,
) -> pd.DataFrame:
    return _aggregate_monthly_impact(
        pg_conn=pg_conn,
        pg_metadata=pg_metadata,
        id_company=id_company,
        year_month=year_month,
        previous_year_month=previous_year_month,
        granularity=granularity,
        projections_filter_fn=lambda q: q.select()
        .where(q.c.AdoptionCount + q.c.NotAdoptionCount > 0)
        .subquery(),
    )


def aggregate_monthly_impact_adopted(
    *,
    pg_conn: PostgreSQLConnection,
    pg_metadata: MetaData,
    id_company: int,
    year_month: int,
    previous_year_month: int,
    granularity: GranularityGroup,
) -> pd.DataFrame:
    return _aggregate_monthly_impact(
        pg_conn=pg_conn,
        pg_metadata=pg_metadata,
        id_company=id_company,
        year_month=year_month,
        previous_year_month=previous_year_month,
        granularity=granularity,
        projections_filter_fn=lambda q: q.select()
        .where(q.c.AdoptionCount > 0)
        .subquery(),
    )


def upsert_monthly_impact(
    *,
    pg_conn: PostgreSQLConnection,
    pg_metadata: MetaData,
    df_impact: pd.DataFrame,
    id_company: int,
    year_month: int,
    aggregation_type: AggregateDataType,
) -> None:
    table_monthly_impact = Table(
        "MonthlyImpactData", pg_metadata, autoload_with=pg_conn
    )

    stmt = delete(table_monthly_impact).where(
        table_monthly_impact.c.CompanyId == id_company,
        table_monthly_impact.c.YearMonth == year_month,
        table_monthly_impact.c.DataType == aggregation_type.value,
    )
    result = pg_conn.execute(stmt)
    logger.info(
        "deleted %d rows from MonthlyImpactData with filter id_company = %d, "
        "year_month = %d, aggregation_type = %s",
        result.rowcount,
        id_company,
        year_month,
        aggregation_type,
    )

    if df_impact.empty:
        logger.info(
            "empty dataframe, skipping insertion of id_company %s and year_month %s",
            id_company,
            year_month,
        )
        return

    df_impact["DataType"] = aggregation_type.value
    df_impact["CreatedDate"] = datetime.now(tz=timezone.utc)
    rows = df_impact.to_dict("records")
    stmt = table_monthly_impact.insert().values(
        {col: bindparam(col) for col in df_impact.columns}
    )
    logger.info(
        "inserting %d rows for id_company = %d, year_month = %d, "
        "aggregation_type = %s into MonthlyImpactData",
        len(rows),
        id_company,
        year_month,
        aggregation_type,
    )
    pg_conn.execute(stmt, rows)


def fetch_price_projections_by_date(
    sql_conn: SQLServerConnection,
    sql_metadata: MetaData,
    id_company: int,
    initial_date: date,
    final_date: date,
    granularity: GranularityGroup,
    consolidate_group_by_col: str,
) -> pd.DataFrame:
    extended_initial_date = (initial_date - relativedelta(months=3)).replace(day=1)
    logger.info(
        "reading price groups between dates %s and %s", initial_date, final_date
    )
    df_groups = read_price_groups(
        conn=sql_conn,
        metadata=sql_metadata,
        id_company=id_company,
        initial_date=initial_date,
        final_date=final_date,
    )

    logger.info(
        "finding last price group for each granularity value between dates %s and %s",
        extended_initial_date,
        initial_date,
    )
    df_last_pg = find_last_price_projection(
        conn=sql_conn,
        metadata=sql_metadata,
        id_company=id_company,
        granularity=granularity.to_columns(),
        initial_date=extended_initial_date,
        final_date=initial_date,
    )

    price_groups = sorted(
        set(df_groups["IdEnterprisePriceGroups"].values.tolist())
        | set(df_last_pg["IdEnterprisePriceGroups"].values.tolist())
    )
    logger.debug(
        "using the following price groups to fetch projections: %s", price_groups
    )

    logger.info("fetching %d projections", len(price_groups))
    df_proj = fetch_projections(
        conn=sql_conn,
        metadata=sql_metadata,
        id_price_groups=price_groups,
        granularity=granularity.to_columns(),
        consolidade_group_by_col=consolidate_group_by_col,
        include_manual_price=True,
    )

    df_proj = _add_last_price_group(df_proj, df_last_pg, granularity.to_columns())
    df_proj["ProductId"] = build_product_id(df_proj, granularity.to_columns())

    return df_proj


def aggregate_monthly_impact(
    pg_conn: PostgreSQLConnection,
    pg_metadata: MetaData,
    id_company: int,
    granularity: GranularityGroup,
    current_month: int,
    previous_month: int,
    last_year_month: int,
):
    for agg_fn, agg_type, prev_ym in (
        (aggregate_monthly_impact_all, AggregateDataType.ALL, previous_month),
        (aggregate_monthly_impact_priced, AggregateDataType.PRICED, previous_month),
        (
            aggregate_monthly_impact_approved,
            AggregateDataType.APPROVED,
            previous_month,
        ),
        (
            aggregate_monthly_impact_adopted,
            AggregateDataType.ADOPTED,
            previous_month,
        ),
        (
            aggregate_monthly_impact_all,
            AggregateDataType.ALL_LAST_YEAR,
            last_year_month,
        ),
        (
            aggregate_monthly_impact_priced,
            AggregateDataType.PRICED_LAST_YEAR,
            last_year_month,
        ),
        (
            aggregate_monthly_impact_approved,
            AggregateDataType.APPROVED_LAST_YEAR,
            last_year_month,
        ),
        (
            aggregate_monthly_impact_adopted,
            AggregateDataType.ADOPTED_LAST_YEAR,
            last_year_month,
        ),
    ):
        df_monthly_agg = agg_fn(
            pg_conn=pg_conn,
            pg_metadata=pg_metadata,
            id_company=id_company,
            year_month=current_month,
            previous_year_month=prev_ym,
            granularity=granularity,
        )

        if df_monthly_agg.empty:
            logger.warning(
                "no impact data for id_company = %d, year_month = %d, "
                "aggregation_type = %s",
                id_company,
                current_month,
                agg_type,
            )
            continue

        upsert_monthly_impact(
            pg_conn=pg_conn,
            pg_metadata=pg_metadata,
            df_impact=df_monthly_agg,
            id_company=id_company,
            year_month=current_month,
            aggregation_type=agg_type,
        )


def import_monthly_projections(
    *,
    pg_engine: PostgreSQLEngine,
    pg_metadata: MetaData,
    sql_engine: SQLServerEngine,
    sql_metadata: MetaData,
    id_company: int,
    initial_date: date,
    final_date: date,
):
    current_month = int(initial_date.strftime("%Y%m"))
    previous_month = int((initial_date - relativedelta(months=1)).strftime("%Y%m"))

    with pg_engine.connect() as pg_conn:
        proj_granularity_group = load_granularity(
            pg_conn=pg_conn,
            metadata=pg_metadata,
            id_company=id_company,
            granularity_type=GranularityType.PROJECTION,
        )
        proj_granularity_cols = proj_granularity_group.to_columns()

        consolidate_group_by_col = get_consolidate_group_by(
            pg_conn=pg_conn,
            metadata=pg_metadata,
            id_company=id_company,
            granularity=proj_granularity_cols,
        )
        if consolidate_group_by_col is None:
            raise ConfigError(
                f"ConsolidateFieldGroupBy not configured for CompanyId {id_company}"
            )

        df_history = get_history_data(
            pg_conn,
            pg_metadata,
            id_company,
            previous_month,
            proj_granularity_group,
        )

    logger.info("using projection granularity group: %s", proj_granularity_group)

    with sql_engine.connect() as sql_conn:
        df_proj = fetch_price_projections_by_date(
            sql_conn=sql_conn,
            sql_metadata=sql_metadata,
            id_company=id_company,
            initial_date=initial_date,
            final_date=final_date,
            granularity=proj_granularity_group,
            consolidate_group_by_col=consolidate_group_by_col,
        )
        logger.info(
            "calculating adoption for df_projection with shape %s between dates %s and %s",
            df_proj.shape,
            initial_date,
            final_date,
        )
        df_adoption = calculate_adoption(
            conn=sql_conn,
            metadata=sql_metadata,
            df_projections=df_proj,
            id_company=id_company,
            granularity=proj_granularity_cols,
            consolidate_group_by_col=consolidate_group_by_col,
            initial_date=initial_date,
            final_date=final_date,
        )
        df_adoption_approved = df_adoption.loc[df_adoption["Approved"], :].copy()

        logger.info("calculating projected metrics")
        df_projected_metrics = calculate_projected_metrics(
            conn=sql_conn,
            metadata=sql_metadata,
            df_adoption=df_adoption_approved,
            df_projections=df_proj,
            id_company=id_company,
            granularity=proj_granularity_cols,
            initial_date=initial_date,
            final_date=final_date,
        )

    df_agg = aggregate_projections(
        df_projected_metrics,
        proj_granularity_cols,
        initial_date,
    )
    df_adoption_count = count_adoptions(df_adoption, proj_granularity_cols)

    df_monthly_proj = prepare_monthly_projections(
        year_month=current_month,
        df_history=df_history,
        df_adoption_count=df_adoption_count,
        df_agg_projections=df_agg,
        granularity_group=proj_granularity_group,
        df_projections=df_proj,
        consolidate_group_by_col=consolidate_group_by_col,
    )

    with pg_engine.begin() as pg_conn_write:
        upsert_monthly_projections(
            conn=pg_conn_write,
            metadata=pg_metadata,
            id_company=id_company,
            year_month=current_month,
            df_projections=df_monthly_proj,
            granularity_group=proj_granularity_group,
        )

        last_year_month = int((initial_date - relativedelta(years=1)).strftime("%Y%m"))
        aggregate_monthly_impact(
            pg_conn=pg_conn_write,
            pg_metadata=pg_metadata,
            id_company=id_company,
            granularity=proj_granularity_group,
            current_month=current_month,
            previous_month=previous_month,
            last_year_month=last_year_month,
        )


class MonthlyTask(NamedTuple):
    id_company: int
    initial_date: date
    final_date: date


# TODO limitar pela ultima data do historico?
def get_monthly_tasks(
    id_company: int, initial_date: date, final_date: date
) -> list[MonthlyTask]:
    tasks = []
    current = initial_date.replace(day=1)
    while current <= final_date:
        _, num_days = calendar.monthrange(current.year, current.month)
        tasks.append(
            MonthlyTask(
                id_company,
                date(current.year, current.month, 1),
                date(current.year, current.month, num_days) + timedelta(days=1),
            )
        )
        current += relativedelta(months=1)

    logger.debug(
        "found %d pending monthly tasks between dates %s and %s",
        len(tasks),
        initial_date,
        final_date,
    )
    return tasks


def _date_to_month_range(date_: datetime) -> tuple[date, date]:
    initial_date = date_.replace(day=1).date()
    _, num_days = calendar.monthrange(date_.year, date_.month)
    final_date = date(initial_date.year, initial_date.month, num_days)
    return initial_date, final_date


def get_price_group_monthly_task(
    sql_conn: SQLServerConnection,
    metadata: MetaData,
    id_company: int,
    id_price_group: int,
) -> Optional[MonthlyTask]:
    published_date = get_published_date(
        conn=sql_conn,
        metadata=metadata,
        id_company=id_company,
        id_price_group=id_price_group,
    )
    if published_date is None:
        return None
    initial_date, final_date = _date_to_month_range(published_date)
    return MonthlyTask(id_company, initial_date, final_date)
