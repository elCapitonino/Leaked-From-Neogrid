﻿using DI.Repository.Attributes;
using DI.Repository.Contexts;
using DI.Repository.Entities;
using DI.Repository.Interfaces.Repositories;
using DI.Repository.Repositories.Base;

namespace DI.Repository.Repositories
{
    [UsePostgreContext]
    public sealed class GranularityGroupRepository : PostgreGenericNoModifyRepository<GranularityGroupEntity>, IGranularityGroupRepository
    {
        public GranularityGroupRepository(PostgreContext dbContext) : base(dbContext)
        {
        }

        public IQueryable<GranularityGroupEntity> GetByCompanyId(long CompanyId)
        {
            return _dbContext
                .Set<GranularityGroupEntity>()
                .Where(x => x.CompanyId == CompanyId);
        }
    }
}