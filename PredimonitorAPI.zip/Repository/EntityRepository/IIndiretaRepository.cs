﻿using MongoDB.Bson;
using Repository.Entity;
using Repository.EntityRepository.Bases;

namespace Repository.EntityRepository
{
    public interface IIndiretaRepository : IGenericRepository<IndiretaEntity, ObjectId>, IMongoRepository
    {
    }
}
