from search_products import Search_products

from logger import logger


class Mean_larger_smaller:
    '''
    referente ao endpoint /v1/search_mean_larger_smaller/    
    '''

    def __init__(self):
        try:
            self.search_products = Search_products()
        except Exception as ex:
            logger.error(" ------ mean larger smaller  ------")
            logger.error(ex)

    async def mean_larger_smaller(self, data_resp, start_date, end_date, idcrawlers):
        ''' 
        Calcula o media e o maior e o menor valor de um produto de acordo com a busca
        Parametros:
        data_resp: lista de produtos da busca no normalizador
        start_date: data inicial da busca
        end_date: data final da busca
        idcrawlers: id do crawler que realizou a busca
        return: lista de produtos com o valor medio e o maior e o menor valor
        '''
        # FIXME missing arguments
        result_search = await self.search_products.get_products(
            data_resp, start_date, end_date, idcrawlers)
        price_list = []
        for i in result_search:
            for j in i['results']:
                for x in j['sellers']:
                    price = 0
                    price = float(x['prices'][0]['price'])
                    if price != None:
                        price_list.append(price)
            average_price = round(sum(price_list) / len(price_list), 2)
            price_max_min_average = {'max_price': max(price_list),
                                     'min_price': min(price_list), 'average_price': average_price}

        return price_max_min_average
