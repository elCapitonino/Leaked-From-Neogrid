﻿namespace PH.Domain.DTO
{
    public class ApiPredifyFilterResponse
    {
        public Result[] Result { get; set; }
        public bool Success { get; set; }
        public object Messages { get; set; }
    }

    public class Result
    {
        public int IdEnterprisePriceGroupDefaultFilter { get; set; }
        public object IdParent { get; set; }
        public string FieldName { get; set; }
        public int Order { get; set; }
        public int DbField { get; set; }
        public object GroupTag { get; set; }
        public bool PreSelect { get; set; }
        public FilterValues[] Values { get; set; }
    }

    public class FilterValues
    {
        public int IdEnterprisePriceGroupDefaultFilterValue { get; set; }
        public object IdParent { get; set; }
        public string Value { get; set; }
        public string description { get; set; }
    }
}
