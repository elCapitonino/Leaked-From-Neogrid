namespace Domain.Product.Models
{
    public class ProductResponse
    {
        public IEnumerable<ProductGroupedResponse>? Products { get; set; }
        public int TotalCount { get; set; }
    }

    public class ProductGroupedResponse
    {
        public string? Name { get; set; }
        public decimal MinPrice { get; set; }
        public decimal AvgPrice { get; set; }
        public decimal MaxPrice { get; set; }
        public decimal LatestPrice { get; set; }
        public decimal CompetitivenessIndex { get; set; }
        public List<string>? ProductIds { get; set; }
    }
}