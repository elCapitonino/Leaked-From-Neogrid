from dotenv import load_dotenv
import os
from linxIntegration import linxIntegration

#habilita configuração local
load_dotenv(dotenv_path='.env.local', override=True)

linxService = linxIntegration(os.getenv("GOOGLE_BIGQUERY_CREDENCIALS"), os.getenv("MONGO_CONECTION_STRING"))
tickets_control = linxService.get_control_to_import()

for tc in tickets_control:
    print(f"importing {tc['week_invoice']} {tc['year_invoice']} {tc['cnae']} {tc['sequence_ingestion']}")
    linxService.fact_ticket_to_mongo(tc)
    print(f"imported {tc['week_invoice']} {tc['year_invoice']} {tc['cnae']} {tc['sequence_ingestion']}")





