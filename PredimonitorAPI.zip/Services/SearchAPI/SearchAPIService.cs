﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Services.SearchAPI.Models;
using System.Net.Http.Json;
using System.Text;

namespace Services.SearchAPI
{
    public partial class SearchAPIService : ISearchAPIService
    {
        private readonly HttpClient _client;
        private readonly IOptions<SearchAPIOptions> _settings;
        private readonly ILogger<SearchAPIService> _logger;


        public SearchAPIService(ILogger<SearchAPIService> logger, HttpClient client, IOptions<SearchAPIOptions> settings)
        {
            _logger = logger;
            _client = client;
            _settings = settings;
        }

        public async Task<IEnumerable<SearchAPIResponse>> SearchV4(SearchAPIRequest request)
        {
            var jsonContent = JsonConvert.SerializeObject(request);
            var httpContent = new StringContent(jsonContent, Encoding.UTF8, "application/json");

            _logger.LogInformation($"REQUEST ----------- {jsonContent}");

            var response = await _client.PostAsync("v4/search", httpContent);
            var content = await response.Content.ReadAsStringAsync();


            if (response.IsSuccessStatusCode)
            {
                if (content.Contains("Acesso não autorizado", StringComparison.InvariantCultureIgnoreCase))
                {
                    throw new Exception("Acesso não autorizado");
                }

                return JsonConvert.DeserializeObject<IEnumerable<SearchAPIResponse>>(content);
            }
            else
            {
                _logger.LogInformation($"Erro a buscar produto no search , Empresa {request.CompanyId}");
                return new List<SearchAPIResponse>();
            }
        }



        public async Task<IEnumerable<SearchAPIResponse>> SearchV4WithTask(SearchAPIRequest request)
        {
            var jsonContent = JsonConvert.SerializeObject(request);
            var httpContent = new StringContent(jsonContent, Encoding.UTF8, "application/json");

            var response = await _client.PostAsync("v4/search_task", httpContent);
            var content = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
            {
                if (content.Contains("Acesso não autorizado", StringComparison.InvariantCultureIgnoreCase))
                {
                    throw new Exception("Acesso não autorizado");
                }

                return JsonConvert.DeserializeObject<IEnumerable<SearchAPIResponse>>(content);
            }

            throw new Exception(content);
        }
    }
}
