﻿using DI.Repository.Attributes;
using DI.Repository.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DI.Repository.TypeConfiguration
{
    [UsePostgreContext]
    public sealed class MonthlyProjectionDataTypeConfiguration : TypeConfigurationBase<MonthlyProjectionDataEntity>, IEntityTypeConfiguration<MonthlyProjectionDataEntity>
    {
        public override void Configure(EntityTypeBuilder<MonthlyProjectionDataEntity> builder)
        {
            ConfigureTableName(builder, "MonthlyProjectionData");
            builder.HasKey(x => x.Id);
            builder.Property(x => x.Id).ValueGeneratedOnAdd().HasDefaultValueSql("uuid_generate_v4()").IsRequired();
            builder.Property(x => x.ProductId).HasMaxLength(512);
            builder.Property(x => x.CompanyId).IsRequired();
            builder.Property(x => x.MajorGranularity).HasMaxLength(128);
            builder.Property(x => x.ConsolidateGroupBy).HasMaxLength(128);

            builder.HasOne(x => x.GranularityGroup).WithMany().HasForeignKey(x => x.GranularityGroupId);

            builder.HasIndex(x => new { x.CompanyId, x.YearMonth });
        }
    }
}
