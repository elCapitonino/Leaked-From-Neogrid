﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace Domain.Models
{
    public class CopilotAPIResponse
    {
        [JsonProperty("action_id")]
        public int ActionId { get; set; }
        public string? Message { get; set; }

        [JsonProperty("index_start")]
        public int IndexStart { get; set; }

        [JsonProperty("index_end")]
        public int IndexEnd { get; set; }

        [JsonProperty("group_name")]
        public string? GroupName { get; set; }
        public string? Error { get; set; }

        [JsonProperty("group_id")]
        public int? GroupId { get; set; }
        public string? Response { get; set; }

        [JsonProperty("abc_curve")]
        public string? AbcCurve { get; set; }
        public int? Elasticity { get; set; }
        public CopilotAPIRule[]? Rules { get; set; }

        [JsonProperty("sellernames_not_ok")]
        public string[]? SellernamesNotOk { get; set; }

        [JsonProperty("sellernames_ok")]
        public string[]? SellernamesOk { get; set; }
        public CopilotAPIFilter[]? Filters { get; set; }
    }

    public class CopilotAPIRule
    {
        [JsonProperty("rule_id")]
        public int? RuleId { get; set; }

        [JsonProperty("rule_name")]
        public string? RuleName { get; set; }

        public JObject? Parameters { get; set; }

        [JsonProperty("condition_type")]
        public int? ConditionType { get; set; }
    }

    public class CopilotAPIFilter
    {
        public int? Id { get; set; }
        public string? Description { get; set; }
        public string? Value { get; set; }
    }


}
