﻿namespace PredifyClientAPI.Services.PredimonitorAPI.DynamicFilter.Models
{
    public enum PriceUnitType
    {
        UNITARIO = 0,
        CAIXA = 1,
    }
}
