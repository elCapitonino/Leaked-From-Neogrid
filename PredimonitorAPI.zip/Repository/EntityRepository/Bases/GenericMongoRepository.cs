﻿using Microsoft.EntityFrameworkCore;
using MongoDB.Bson;
using MongoDB.Driver;
using Repository.DbContexts;
using Repository.Entity;

namespace Repository.EntityRepository.Bases
{
    public abstract class GenericMongoRepository<TEntity> : GenericRepository<TEntity, ObjectId> where TEntity : class, IEntityBase<ObjectId>
    {
        protected GenericMongoRepository(DbContext dbContext) : base(dbContext)
        {

        }
        public IMongoClient Client => ((HorusDbContext)_dbContext).Client;
    }
}
