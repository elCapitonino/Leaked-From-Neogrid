"""
Script para gerar intervalos de margem por categoria/subcategoria para Torre (3244).

https://dev.azure.com/predify/Predify%20Board%20Oficial/_workitems/edit/12485
"""

# %%
import sys

import numpy as np
import pandas as pd
from plotnine import *

sys.path.append("../")  # go to parent dir
from geral.config import getDadosAWSSession

# %%

df_margins = pd.read_csv("dados_torre.csv")
df_margins.head()

# %%

df_margins = df_margins.assign(Margin=lambda x: (x.SalePrice - x.PbCost) / x.SalePrice)
df_margins["Issuance"] = pd.to_datetime(df_margins["Issuance"])
df_margins["Affiliate"] = df_margins["Affiliate"].astype(str)
df_margins.head()

# %%

df_l = (
    df_margins[["Issuance", "Category3"]]
    .sort_values("Issuance")
    .assign(length=lambda x: x.Category3.str.len())
)

# %%

ggplot(df_l.sample(10_000), aes(x="Issuance", y="length")) + geom_point(alpha=0.2)

# %%

df_l.query("length < 20").sort_values("Issuance").head()

# %%

df_l.query("Issuance >= '2024-07-21'")["length"].describe()

# %%

# NOTE formato novo de categoria a partir desta data
df_margins = df_margins.query("Issuance >= '2024-07-21'")
df_margins.head()

# %%

df_margins["Issuance"].max()

# %%

df_margins["issuance_day"] = df_margins["Issuance"].dt.ceil("D")

agg_map = {"Quantity": "sum", "SalePrice": "mean", "Margin": "mean", "PbCost": "mean"}
for col in ["Category4", "Category3"]:
    agg_map[col] = "first"

df_margins = (
    df_margins.groupby(["Product", "Affiliate", "issuance_day"])
    .agg(agg_map)
    .reset_index()
)

df_margins = df_margins[
    ~df_margins[["Affiliate", "Category4", "Category3"]].isna().any(axis=1)
]
df_margins = df_margins[df_margins["Quantity"] > 0]
df_margins = df_margins[df_margins["SalePrice"] > 0]

# %%

df_margins = df_margins.query("Margin > 0")

# %%


def _quantiles(x):
    return pd.Series(
        [
            np.quantile(x["Margin"], 0.25),
            np.quantile(x["Margin"], 0.50),
            np.quantile(x["Margin"], 0.75),
            x.shape[0],
        ]
    )


# %%

df_boundaries = (
    df_margins.groupby(["Affiliate", "Category4"]).apply(_quantiles).reset_index()
)
df_boundaries.columns = ["Affiliate", "Category4", "q1", "q2", "q3", "count"]

# %%

df_boundaries.head()

# %%

df_boundaries_sub = (
    df_margins.groupby(["Affiliate", "Category4", "Category3"])
    .apply(_quantiles)
    .reset_index()
)
df_boundaries_sub.columns = [
    "Affiliate",
    "Category4",
    "Category3",
    "q1_sub",
    "q2_sub",
    "q3_sub",
    "count_sub",
]

# %%

df_boundaries_sub.head()

# %%

df_boundaries_join = pd.merge(
    df_boundaries.query("count >= 20"),
    df_boundaries_sub.query("count_sub >= 20"),
    on=["Affiliate", "Category4"],
    how="left",
)
df_boundaries_join.head(50)

# %%

conn = getDadosAWSSession("producao")

df_aff_name = pd.read_sql(
    """
    SELECT DISTINCT Affiliate, AffiliateName
    FROM Enterprise_Sales_History WHERE IdCompany = 3244 AND IsDeletado = 0
    AND Issuance > '2024-07-21'
    """,
    conn,
)

# %%


def longest_string(group):
    return group.loc[group["AffiliateName"].str.len().idxmax()]


df_aff_name = (
    df_aff_name.groupby("Affiliate").apply(longest_string).reset_index(drop=True)
)
df_aff_name.head()

# %%

df_boundaries_join = pd.merge(
    df_boundaries_join, df_aff_name, on="Affiliate", how="left"
)
df_boundaries_join.head()

# %%

df_boundaries_join.to_csv("torre_margins_raw.csv", sep=";", index=False)

# %%

df_report = (
    df_boundaries_join[
        [
            "Affiliate",
            "AffiliateName",
            "Category4",
            "Category3",
            "q1",
            # "q2",
            "q3",
            "q1_sub",
            # "q2_sub",
            "q3_sub",
        ]
    ]
    .rename(
        columns={
            "Affiliate": "Filial",
            "AffiliateName": "Nome da filial",
            "Category4": "Categoria",
            "Category3": "Subcategoria",
            "q1": "Margem da categoria (limite inferior)",
            "q3": "Margem da categoria (limite superior)",
            "q1_sub": "Margem da subcategoria (limite inferior)",
            "q3_sub": "Margem da subcategoria (limite superior)",
        }
    )
    .to_excel("torre_margins.xlsx", index=False)
)

# %%
