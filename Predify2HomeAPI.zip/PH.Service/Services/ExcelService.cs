﻿using ClosedXML.Excel;
using DocumentFormat.OpenXml.Spreadsheet;
using Microsoft.AspNetCore.Http;
using PH.Domain.DTO;

namespace PU.Service.Services
{
    public static class ExcelService
    {
        public const string FILE_NAME = "RelatoriosPromocionais.xlsx";

        public static void FillingExcel(List<ProductAcaoPromocionalResponseDTO> relatorio, IXLWorksheet worksheet)
        {
            for (int index = 1; index <= relatorio.Count; index++)
            {
                worksheet.Cell(index + 1, 1).Value = relatorio[index - 1].ActionType;
                worksheet.Cell(index + 1, 2).Value = relatorio[index - 1].ProductName;
                worksheet.Cell(index + 1, 3).Value = relatorio[index - 1].EAN;
                worksheet.Cell(index + 1, 4).Value = relatorio[index - 1].Price;
                worksheet.Cell(index + 1, 5).Value = relatorio[index - 1].ComboTranslate;
                worksheet.Cell(index + 1, 6).Value = relatorio[index - 1].StartDate;
                worksheet.Cell(index + 1, 7).Value = relatorio[index - 1].EndDate;
            }
        }

        public static IXLWorksheet CriandoCabecalhoExcel(XLWorkbook workbook)
        {
            string nomeSheet = "Ação Promocional";
            IXLWorksheet worksheet = workbook.Worksheets.Add($"{nomeSheet}");
            worksheet.Cell(1, 1).Value = "Nome da promoção";
            worksheet.Cell(1, 2).Value = "Nome do produto";
            worksheet.Cell(1, 3).Value = "EAN do produto";
            worksheet.Cell(1, 4).Value = "Preço";
            worksheet.Cell(1, 5).Value = "Combo";
            worksheet.Cell(1, 6).Value = "Data de início da promoção";
            worksheet.Cell(1, 7).Value = "Data de fim da promoção";
            return worksheet;
        }

        public static string GetFileName()
        {
            string fileName = FILE_NAME;
            string fullPath = Path.Combine($"{Environment.GetEnvironmentVariable("TEMP")}", fileName);
            return fullPath;
        }
    }
}
