using HealthChecks.UI.Client;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using PH.API.Configurations;
using PH.CrossCutting.Services;
using PH.Data.Repositories;
using PH.Domain.Interfaces.Repositories;
using PH.Domain.Interfaces.Services;
using PH.Domain.Settings;
using PH.Service.Services;

var builder = WebApplication.CreateBuilder(args);

SerilogConfig.AddSerilog(builder);
builder.Services.AddCustomHealthChecks(builder.Configuration);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());

builder.Services.AddScoped<IAcaoPromocionalRepository, AcaoPromocionalRepository>();
builder.Services.AddScoped<IAcaoPromocionalServices, AcaoPromocionalServices>();

builder.Services.AddScoped<IGraficoRepository, GraficoRepository>();
builder.Services.AddScoped<IGraficoServices, GraficoServices>();

builder.Services.AddScoped<IAlertRepository, AlertRepository>();
builder.Services.AddScoped<IAlertServices, AlertServices>();

builder.Services.AddScoped<IFiltersRepository, FiltersRepository>();
builder.Services.AddScoped<IFiltersServices, FiltersServices>();

builder.Services.AddScoped<IRecipeRepository, RecipeRepository>();
builder.Services.AddScoped<IRecipeServices, RecipeServices>();

builder.Services.AddScoped<IOportunitiesRepository, OportunitiesRepository>();
builder.Services.AddScoped<IOportunitiesServices, OportunitiesServices>();

builder.Services.AddScoped<ICacheControlService, CacheControlService>();

builder.Services.AddScoped<IGraficoICRepository, GraficoICRepository>();
builder.Services.AddScoped<IGraficoICServices, GraficoICServices>();

builder.Services.AddScoped<IGraficoMargemMediaRepository, GraficoMargemMediaRepository>();
builder.Services.AddScoped<IGraficoMargemMediaServices, GraficoMargemMediaServices>();

builder.Services.AddScoped<IProdutosTabeladosRepository, ProdutosTabeladosRepository>();
builder.Services.AddScoped<IProdutosTabeladosServices, ProdutosTabeladosServices>();

builder.Services.Configure<MongoSettings>(
    builder.Configuration.GetSection("MongoSettings"));

builder.Services.AddMemoryCache();

builder.Services.AddCors(p => p.AddPolicy("corsapp", builder =>
{
    builder.WithOrigins("*").AllowAnyMethod().AllowAnyHeader();
}));

var app = builder.Build();

app.UseHealthChecks("/hc", new HealthCheckOptions
{
    Predicate = _ => true,
    ResponseWriter = UIResponseWriter.WriteHealthCheckUIResponse
});
app.UseHealthChecksUI(options =>
{
    options.UIPath = "/healthchecks-ui";
});

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseCors("corsapp");

app.UseAuthorization();

app.MapControllers();

app.Run();
