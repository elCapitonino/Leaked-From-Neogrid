﻿using DI.Repository.Attributes;
using DI.Repository.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DI.Repository.TypeConfiguration
{
    [UsePostgreContext]
    public sealed class ImpactReportConfigurationTypeConfiguration : TypeConfigurationBase<ImpactReportConfigurationEntity>, IEntityTypeConfiguration<ImpactReportConfigurationEntity>
    {
        public override void Configure(EntityTypeBuilder<ImpactReportConfigurationEntity> builder)
        {
            ConfigureTableName(builder, "ImpactReportConfiguration");
            builder.Ignore(x => x.Id);
            builder.HasKey(x => x.CompanyId);
            builder.Property(x => x.CompanyId).ValueGeneratedNever().IsRequired();
            builder.Property(x => x.ConsolidateFieldGroupBy).HasMaxLength(64);
            builder.Property(x => x.RawCategoryField).HasMaxLength(64);
            builder.Property(x => x.RawSubCategoryField).HasMaxLength(64);
            builder.Property(x => x.PriceVariableToCalc).HasMaxLength(64);
        }
    }
}
