using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using MongoDB.EntityFrameworkCore.Extensions;
using Repository.Attributes;
using Repository.DbContexts;
using Repository.Entity;

namespace Repository.TypeConfiguration
{
    [DbContextTypeConfiguration(typeof(OfflineDbContext))]
    public class OfflineSupermarketTorreTypeConfiguration : TypeConfigurationBase<OfflineSupermarketTorreEntity>, IEntityTypeConfiguration<OfflineSupermarketTorreEntity>
    {
        public override void Configure(EntityTypeBuilder<OfflineSupermarketTorreEntity> builder)
        {
            builder.ToTable("supermarket_torre").ToCollection("supermarket_torre");
        }
    }

}
