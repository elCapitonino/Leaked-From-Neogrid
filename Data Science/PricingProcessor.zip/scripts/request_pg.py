"""
Script para processar um grupo de precificação específico.
"""

import argparse
import time

import requests

from scripts.request_retroactive import (
    _get_price_group_task_status,
    _get_date_task_status,
    LOCAL_URL,
)


def calculate(id_company: int, price_group: int, api_url: str) -> None:
    print(f"-> requesting price_group {price_group}")
    res = requests.post(
        api_url
        + f"/calculate_projection_metrics/{id_company}/price_group?id_price_group={price_group}"
    )
    if res.status_code != 200:
        if res.status_code == 400:
            error = res.json()["detail"]
            if error == f"no projections found in price_group {price_group}":
                print(f"{error} -> skipping...")
                return
        raise RuntimeError(f"error when requesting: {res.text}")

    res_json = res.json()
    print(res_json)
    date_task_id = res_json["date_task_id"]
    pg_task_ids = res_json["pg_task_ids"]

    while True:
        time.sleep(10)
        date_status = _get_date_task_status(date_task_id, api_url)
        pg_status = [
            _get_price_group_task_status(uuid, api_url) for uuid in pg_task_ids
        ]
        if date_status == "success" and all(s == "success" for s in pg_status):
            print(f"-> price_group {price_group} finished successfully")
            break

        if date_status not in ("running", "success"):
            raise RuntimeError(f"date task failed for price_group {price_group}")

        if any(s not in ("running", "success") for s in pg_status):
            raise RuntimeError(
                f"at least one pg task failed for price_group {price_group}"
            )

        print("continue...")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--id-company", type=int, required=True)
    parser.add_argument("--pg", type=str, default=LOCAL_URL)
    parser.add_argument("--api-url", type=str, default=LOCAL_URL)
    args = parser.parse_args()

    calculate(args.id_company, args.pg, args.api_url)


if __name__ == "__main__":
    main()
