﻿using Repository.Entity;

namespace Repository.EntityRepository
{
    public sealed class RuleGroupRepository : GenericRepository<DinPreRuleEntity>, IRuleGroupRepository
    {
        public new static string DbContextName => nameof(ApplicationDbContext);
        public RuleGroupRepository(ApplicationDbContext dbContext) : base(dbContext)
        {
        }
    }
}
