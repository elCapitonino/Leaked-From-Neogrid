﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Services.Copilot.Models;
using System.Text;

namespace Services.Copilot
{
    public class CopilotService
    {
        private readonly HttpClient httpClient;
        private CopilotOptions settings;

        private const string RULES_TEXT = "/dialog";

        public CopilotService(IOptions<CopilotOptions> options,HttpClient httpClient)
        {
            this.settings = options.Value;
            this.httpClient = httpClient;
        }

        public async Task<string> GenerateRulesWithText(long companyId, string text)
        {         
            var payload = JsonConvert.SerializeObject(new { company_id = companyId, text });
            var content = new StringContent(payload,Encoding.UTF8,"application/json");
            var response = await this.httpClient.PostAsync(RULES_TEXT, content);
            return await response.Content.ReadAsStringAsync();
        }
    }
}
