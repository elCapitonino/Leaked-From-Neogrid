﻿using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using PH.Domain.DTO;
using PH.Domain.Interfaces.Services;
using System.Net.Http.Headers;

namespace PredifyCoreAPI
{
    public class PredifyAPIService : IPredifyAPIService
    {
        private readonly HttpClient _client;
        private ILogger<PredifyAPIService> _log;
        private readonly IConfiguration _configuration;
        private readonly IMemoryCache _memoryCache;
        private bool _jaTentouUsarToken;

        public PredifyAPIService(ILogger<PredifyAPIService> log,
                                 IConfiguration configuration,
                                 IMemoryCache memoryCache)
        {
            _configuration = configuration;
            _memoryCache = memoryCache;

            _client = new HttpClient();
            _client.BaseAddress = new Uri(_configuration["PredifyApiURL"]);
            _client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            _jaTentouUsarToken = false;
            _log = log;
        }

        public async Task<ApiPredifyFilterResponse> GetFilters(string token)
        {
            _log.LogInformation("Iniciando chamada filters api predify");

            try
            {
                _client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                ApiPredifyFilterResponse? response = (ApiPredifyFilterResponse)_memoryCache.Get("ApiPredifyFilters");

                if (response == null)
                {
                    var result = await _client.GetAsync("/api/V2/Enterprise/PriceGroups/Filter?idCompany=3026&preSelect=true");
                    var responseMessage = await result.Content.ReadAsStringAsync();

                    if (result.IsSuccessStatusCode)
                    {
                        response = JsonConvert.DeserializeObject<ApiPredifyFilterResponse>(responseMessage);
                        SettingTimeAndCache(response, "ApiPredifyFilters");
                    }
                    else
                    {
                        if (!_jaTentouUsarToken)
                        {
                            _jaTentouUsarToken = true;
                            token = _configuration["TokenApiPredify"];
                            return await GetFilters(token);
                        }
                        throw new Exception(responseMessage);
                    }
                }

                return response;
            }
            catch (Exception ex)
            {
                _log.LogError(ex, $"Erro ao chamar api da predify. Erro {ex.Message}");
                throw;
            }
        }

        private void SettingTimeAndCache(object cacheObject, string cacheKey)
        {
            var cacheEntryOptions = new MemoryCacheEntryOptions()
                                 .SetAbsoluteExpiration(TimeSpan.FromMinutes(120));

            _memoryCache.Set(cacheKey, cacheObject, cacheEntryOptions);
        }
    }
}