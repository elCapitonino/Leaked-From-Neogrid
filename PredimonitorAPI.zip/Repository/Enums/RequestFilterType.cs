﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Enums
{
    public enum RequestFilterType
    {
        None = 0,
        Product = 1,
        Category = 2,
        Seller = 3,
        Brand = 4,
        State = 5,
        Year = 6,
        Origin = 7,
        Model = 8
    }
}
