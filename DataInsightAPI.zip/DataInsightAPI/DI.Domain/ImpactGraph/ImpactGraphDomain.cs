﻿using AutoMapper;
using DI.Domain.ImpactGraph.Models;
using DI.Domain.Utils;
using DI.Repository.Entities;
using DI.Repository.Enum;
using DI.Repository.Interfaces;

namespace DI.Domain.ImpactGraph
{
    public class ImpactGraphDomain : IImpactGraphDomain
    {
        private readonly IUnitOfWork _uow;

        public ImpactGraphDomain(IUnitOfWork uow)
        {
            _uow = uow;
        }

        public AdoptionGraphResponseModel GetAdoptionImpactGraph(long companyId, List<string> affiliateIds)
        {
            var endYearMonth = new YearMonth(DateTime.Now);
            var startYearMonth = endYearMonth.AddYears(-1);

            var data = _uow.MonthlyImpactDataRepository.GetAll(
                companyId,
                startYearMonth.Value,
                endYearMonth.Value, MonthlyImpactDataType.Normal);

            if (affiliateIds.Any())
            {
                data = data.Where(x => affiliateIds.Contains(x.MajorGranularity!));
            }

            var monthlyImpactData = data.GroupBy(x => x.YearMonth).Select(x => new MonthlyImpactDataEntity()
            {
                CompanyId = companyId,
                YearMonth = x.Key,
                RealRoyalty = x.Sum(y => y.RealRoyalty),
                PriorRoyalty = x.Sum(y => y.PriorRoyalty),

                AdoptionCount = x.Sum(y => y.AdoptionCount),
                NotAdoptionCount = x.Sum(y => y.NotAdoptionCount),
                PricingCount = x.Sum(y => y.PricingCount),
            }).ToDictionary(x => new YearMonth(x.YearMonth), x => x);

            var companyConfiguration = _uow.ImpactReportConfigurationRepository.GetByCompanyId(companyId);

            var uniqueAffiliateCount = data
                .Select(x => x.MajorGranularity)
                .Distinct()
                .Count();

            AdoptionGraphResponseModel responseModel = new AdoptionGraphResponseModel();

            for (var yearMonth = startYearMonth; yearMonth < endYearMonth; yearMonth++)
            {
                responseModel.Categories.Add(new GraphCategoryModel(yearMonth.Year.ToString(), DateTimeExtension.MonthNameInYearMonth[yearMonth.Month]));

                if (!monthlyImpactData.ContainsKey(yearMonth))
                {
                    responseModel.Adoptions.Data.Add(null);
                    responseModel.NotAdoptions.Data.Add(null);
                    responseModel.PricingCount.Data.Add(null);
                    responseModel.Goal.Data.Add(null);
                    responseModel.Royalties.Data.Add(null);
                    continue;
                }

                responseModel.Adoptions.Data.Add(monthlyImpactData[yearMonth].AdoptionCount);
                responseModel.NotAdoptions.Data.Add(monthlyImpactData[yearMonth].NotAdoptionCount);
                responseModel.PricingCount.Data.Add(monthlyImpactData[yearMonth].PricingCount);

                if (companyConfiguration?.ConsolidateReportRoyalty == true)
                {
                    var additionalRoyalty = monthlyImpactData[yearMonth].RealRoyalty - monthlyImpactData[yearMonth].PriorRoyalty;
                    responseModel.Royalties.Data.Add(additionalRoyalty);
                    responseModel.Goal.Data.Add(((companyConfiguration?.Goal ?? 0) * uniqueAffiliateCount) + additionalRoyalty);
                }
            }

            return responseModel;
        }

        public DemandGraphResponseModel GetDemandImpactGraph(long companyId, List<string> affiliateIds)
        {
            var endYearMonth = new YearMonth(DateTime.Now);
            var startYearMonth = endYearMonth.AddYears(-1);

            var data = _uow.MonthlyImpactDataRepository.GetAll(
            companyId,
            startYearMonth.Value,
            endYearMonth.Value, MonthlyImpactDataType.Normal);

            if (affiliateIds.Any())
            {
                data = data.Where(x => affiliateIds.Contains(x.MajorGranularity));
            }

            var monthlyImpactData = data.GroupBy(x => x.YearMonth).Select(x => new MonthlyImpactDataEntity()
            {
                CompanyId = companyId,
                YearMonth = x.Key,
                RealRoyalty = x.Sum(y => y.RealRoyalty),
                PriorRoyalty = x.Sum(y => y.PriorRoyalty),

                RealDemand = x.Sum(y => y.RealDemand),
                ProjectionDemand = x.Sum(y => y.ProjectionDemand),
                PriorDemand = x.Sum(y => y.PriorDemand)
            }).ToDictionary(x => new YearMonth(x.YearMonth), x => x);

            var companyConfiguration = _uow.ImpactReportConfigurationRepository.GetByCompanyId(companyId);

            var uniqueAffiliateCount = data
                .Select(x => x.MajorGranularity)
                .Distinct()
                .Count();

            DemandGraphResponseModel responseModel = new DemandGraphResponseModel();

            for (var yearMonth = startYearMonth; yearMonth < endYearMonth; yearMonth++)
            {
                responseModel.Categories.Add(new GraphCategoryModel(yearMonth.Year.ToString(), DateTimeExtension.MonthNameInYearMonth[yearMonth.Month]));

                if (!monthlyImpactData.ContainsKey(yearMonth))
                {
                    responseModel.PreviousDemand.Data.Add(null);
                    responseModel.RealizedDemand.Data.Add(null);
                    responseModel.ProjectedDemand.Data.Add(null);
                    responseModel.Goal.Data.Add(null);
                    responseModel.Royalties.Data.Add(null);
                    continue;
                }

                responseModel.PreviousDemand.Data.Add(monthlyImpactData[yearMonth].PriorDemand);
                responseModel.RealizedDemand.Data.Add(monthlyImpactData[yearMonth].RealDemand);
                responseModel.ProjectedDemand.Data.Add(monthlyImpactData[yearMonth].ProjectionDemand);

                if (companyConfiguration?.ConsolidateReportRoyalty == true)
                {
                    var additionalRoyalty = monthlyImpactData[yearMonth].RealRoyalty - monthlyImpactData[yearMonth].PriorRoyalty;
                    responseModel.Royalties.Data.Add(additionalRoyalty);
                    responseModel.Goal.Data.Add(((companyConfiguration?.Goal ?? 0) * uniqueAffiliateCount) + additionalRoyalty);
                }
            }

            return responseModel;
        }

        public MarginGraphResponseModel GetMarginImpactGraph(long companyId, List<string> affiliateIds)
        {
            var endYearMonth = new YearMonth(DateTime.Now);
            var startYearMonth = endYearMonth.AddYears(-1);

            var data = _uow.MonthlyImpactDataRepository.GetAll(
            companyId,
            startYearMonth.Value,
            endYearMonth.Value, MonthlyImpactDataType.Normal);

            if (affiliateIds.Any())
            {
                data = data.Where(x => affiliateIds.Contains(x.MajorGranularity));
            };

            var monthlyImpactData = data.GroupBy(x => x.YearMonth).Select(x => new MonthlyImpactDataEntity()
            {
                CompanyId = companyId,
                YearMonth = x.Key,
                RealRoyalty = x.Sum(y => y.RealRoyalty),
                PriorRoyalty = x.Sum(y => y.PriorRoyalty),

                PriorRevenue = x.Sum(y => y.PriorRevenue),
                ProjectionRevenue = x.Sum(y => y.ProjectionRevenue),
                RealRevenue = x.Sum(y => y.RealRevenue),

                PriorProfit = x.Sum(y => y.PriorProfit),
                ProjectionProfit = x.Sum(y => y.ProjectionProfit),
                RealProfit = x.Sum(y => y.RealProfit),
            }).ToDictionary(x => new YearMonth(x.YearMonth), x => x);

            var companyConfiguration = _uow.ImpactReportConfigurationRepository.GetByCompanyId(companyId);

            var uniqueAffiliateCount = data
                .Select(x => x.MajorGranularity)
                .Distinct()
                .Count();

            MarginGraphResponseModel responseModel = new MarginGraphResponseModel();

            for (var yearMonth = startYearMonth; yearMonth < endYearMonth; yearMonth++)
            {
                responseModel.Categories.Add(new GraphCategoryModel(yearMonth.Year.ToString(), DateTimeExtension.MonthNameInYearMonth[yearMonth.Month]));

                if (!monthlyImpactData.ContainsKey(yearMonth))
                {
                    responseModel.PreviousMargin.Data.Add(null);
                    responseModel.RealizedMargin.Data.Add(null);
                    responseModel.ProjectedMargin.Data.Add(null);
                    responseModel.Goal.Data.Add(null);
                    responseModel.Royalties.Data.Add(null);
                    continue;
                }

                if (monthlyImpactData[yearMonth].RealRevenue == 0)
                    responseModel.RealizedMargin.Data.Add(null);
                else
                    responseModel.RealizedMargin.Data.Add(monthlyImpactData[yearMonth].RealProfit / monthlyImpactData[yearMonth].RealRevenue);

                if (monthlyImpactData[yearMonth].PriorRevenue == 0)
                    responseModel.PreviousMargin.Data.Add(null);
                else
                    responseModel.PreviousMargin.Data.Add(monthlyImpactData[yearMonth].PriorProfit / monthlyImpactData[yearMonth].PriorRevenue);

                decimal? profit = monthlyImpactData[yearMonth]?.ProjectionProfit ?? 0;
                decimal? revenue = monthlyImpactData[yearMonth]?.ProjectionRevenue ?? 0;
                decimal? result = revenue != 0 ? profit / revenue : 0;

                responseModel.ProjectedMargin.Data.Add(result);

                if (companyConfiguration?.ConsolidateReportRoyalty == true)
                {
                    var additionalRoyalty = monthlyImpactData[yearMonth].RealRoyalty - monthlyImpactData[yearMonth].PriorRoyalty;
                    responseModel.Royalties.Data.Add(additionalRoyalty);
                    responseModel.Goal.Data.Add(((companyConfiguration?.Goal ?? 0) * uniqueAffiliateCount) + additionalRoyalty);
                }
            }

            return responseModel;
        }

        public RevenueGraphResponseModel GetRevenueImpactGraph(long companyId, List<string> affiliateIds)
        {
            var endYearMonth = new YearMonth(DateTime.Now);
            var startYearMonth = endYearMonth.AddYears(-1);

            var data = _uow.MonthlyImpactDataRepository.GetAll(
                companyId,
                startYearMonth.Value,
                endYearMonth.Value, MonthlyImpactDataType.Normal);

            if (affiliateIds.Any())
            {
                data = data.Where(x => affiliateIds.Contains(x.MajorGranularity));
            }

            var monthlyImpactData = data.GroupBy(x => x.YearMonth).Select(x => new MonthlyImpactDataEntity()
            {
                CompanyId = companyId,
                YearMonth = x.Key,
                RealRoyalty = x.Sum(y => y.RealRoyalty),
                PriorRoyalty = x.Sum(y => y.PriorRoyalty),

                RealRevenue = x.Sum(y => y.RealRevenue),
                ProjectionRevenue = x.Sum(y => y.ProjectionRevenue),
                PriorRevenue = x.Sum(y => y.PriorRevenue)
            }).ToDictionary(x => new YearMonth(x.YearMonth), x => x);

            var companyConfiguration = _uow.ImpactReportConfigurationRepository.GetByCompanyId(companyId);

            var uniqueAffiliateCount = data
                .Select(x => x.MajorGranularity)
                .Distinct()
                .Count();

            RevenueGraphResponseModel responseModel = new RevenueGraphResponseModel();

            for (var yearMonth = startYearMonth; yearMonth < endYearMonth; yearMonth++)
            {
                responseModel.Categories.Add(new GraphCategoryModel(yearMonth.Year.ToString(), DateTimeExtension.MonthNameInYearMonth[yearMonth.Month]));

                if (!monthlyImpactData.ContainsKey(yearMonth))
                {
                    responseModel.RealizedRevenue.Data.Add(null);
                    responseModel.PreviousRevenue.Data.Add(null);
                    responseModel.ProjectedRevenue.Data.Add(null);
                    responseModel.Goal.Data.Add(null);
                    responseModel.Royalties.Data.Add(null);
                    continue;
                }

                responseModel.PreviousRevenue.Data.Add(monthlyImpactData[yearMonth].PriorRevenue);
                responseModel.RealizedRevenue.Data.Add(monthlyImpactData[yearMonth].RealRevenue);
                responseModel.ProjectedRevenue.Data.Add(monthlyImpactData[yearMonth]?.ProjectionRevenue ?? 0);

                if (companyConfiguration?.ConsolidateReportRoyalty == true)
                {
                    var additionalRoyalty = monthlyImpactData[yearMonth].RealRoyalty - monthlyImpactData[yearMonth].PriorRoyalty;
                    responseModel.Royalties.Data.Add(additionalRoyalty);
                    responseModel.Goal.Data.Add(((companyConfiguration?.Goal ?? 0) * uniqueAffiliateCount) + additionalRoyalty);
                }
            }

            return responseModel;
        }

        public ProfitGraphResponseModel GetProfitImpactGraph(long companyId, List<string> affiliateIds)
        {
            var endYearMonth = new YearMonth(DateTime.Now);
            var startYearMonth = endYearMonth.AddYears(-1);

            var data = _uow.MonthlyImpactDataRepository.GetAll(
             companyId,
             startYearMonth.Value,
             endYearMonth.Value, MonthlyImpactDataType.Normal);

            if (affiliateIds.Any())
            {
                data = data.Where(x => affiliateIds.Contains(x.MajorGranularity));
            }

            var monthlyImpactData = data.GroupBy(x => x.YearMonth).Select(x => new MonthlyImpactDataEntity()
            {
                CompanyId = companyId,
                YearMonth = x.Key,

                RealProfit = x.Sum(y => y.RealProfit),
                ProjectionProfit = x.Sum(y => y.ProjectionProfit),
                PriorProfit = x.Sum(y => y.PriorProfit)
            }).ToDictionary(x => new YearMonth(x.YearMonth), x => x);

            ProfitGraphResponseModel responseModel = new ProfitGraphResponseModel();

            for (var yearMonth = startYearMonth; yearMonth < endYearMonth; yearMonth++)
            {
                responseModel.Categories.Add(new GraphCategoryModel(yearMonth.Year.ToString(), DateTimeExtension.MonthNameInYearMonth[yearMonth.Month]));

                if (!monthlyImpactData.ContainsKey(yearMonth))
                {
                    responseModel.RealizedProfit.Data.Add(null);
                    responseModel.PreviousProfit.Data.Add(null);
                    responseModel.ProjectedProfit.Data.Add(null);
                    continue;
                }

                responseModel.RealizedProfit.Data.Add(monthlyImpactData[yearMonth].RealProfit);
                responseModel.PreviousProfit.Data.Add(monthlyImpactData[yearMonth].PriorProfit);
                responseModel.ProjectedProfit.Data.Add(monthlyImpactData[yearMonth]?.ProjectionProfit ?? 0);

            }

            return responseModel;
        }
    }
}
