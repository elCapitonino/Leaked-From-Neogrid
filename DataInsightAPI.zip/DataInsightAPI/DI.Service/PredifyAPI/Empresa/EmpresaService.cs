﻿using DI.Service.PredifyAPI.Empresa.Models;
using Newtonsoft.Json;

namespace DI.Service.PredifyAPI.Empresa
{
    public class EmpresaService : IEmpresaService
    {
        private readonly HttpClient client;

        public EmpresaService(HttpClient client)
        {
            this.client = client;
        }
        public async Task<IEnumerable<EmpresaSelecionarResponse>> GetEmpresaAsync()
        {
            var response = await client.GetAsync("/api/Empresa/GetEmpresasSelecionar");
            var content = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
            {
                if (content.Contains("Acesso não autorizado", StringComparison.InvariantCultureIgnoreCase))
                {
                    throw new Exception("Acesso não autorizado");
                }

                return JsonConvert.DeserializeObject<IEnumerable<EmpresaSelecionarResponse>>(content);
            }

            throw new Exception(content);
        }
    }
}
