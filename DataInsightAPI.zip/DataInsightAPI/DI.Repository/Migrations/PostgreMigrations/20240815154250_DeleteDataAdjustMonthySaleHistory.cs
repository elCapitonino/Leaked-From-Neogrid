﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DI.Repository.Migrations.PostgreMigrations
{
    /// <inheritdoc />
    public partial class DeleteDataAdjustMonthySaleHistory : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"
                 DELETE FROM public.""MonthlyProjectionData""
                 WHERE ""GranularityGroupId"" IN (
                     SELECT ""Id""
                     FROM public.""GranularityGroup""
                     WHERE ""GranularityType"" <> 1
                 );
             ");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            // Este método está intencionalmente vazio porque não há alterações a serem revertidas nesta migração.
        }
    }
}
