﻿namespace DI.Repository.Entities
{
    public sealed class ImpactReportConfigurationEntity : BaseEntity
    {
        public long CompanyId { get; set; }
        public bool ConsolidateReportRoyalty { get; set; }
        public bool IncludeConsolidateReportFromLastYear { get; set; }
        public bool HasRawReportRoyalty { get; set; }
        public string? ConsolidateFieldGroupBy { get; set; }
        public string? RawCategoryField { get; set; }
        public string? RawSubCategoryField { get; set; }
        public string? PriceVariableToCalc { get; set; }
        public decimal Goal { get; set; }
        public decimal Royalty { get; set; }
    }
}
