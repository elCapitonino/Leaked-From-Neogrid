class ConfigError(Exception):
    """Raise when there is a configuration error."""


class DatabaseResultError(Exception):
    """Raise when the database returns an unexpected or inconsistent value."""
