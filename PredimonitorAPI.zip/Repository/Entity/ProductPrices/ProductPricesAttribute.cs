﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;

namespace Repository.Entity.ProductPrices
{
    public class ProductPricesAttribute
    {
        [BsonElement("key")]
        public string? Key { get; set; }

        [BsonElement("value")]
        public string? Value { get; set; }
    }
}
