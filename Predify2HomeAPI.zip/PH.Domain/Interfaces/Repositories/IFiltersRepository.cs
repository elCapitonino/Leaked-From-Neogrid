﻿using PH.Domain.DTO;

namespace PH.Domain.Interfaces.Repositories
{
    public interface IFiltersRepository
    {
        Task<FiltersMainDTO> Get();
    }
}
