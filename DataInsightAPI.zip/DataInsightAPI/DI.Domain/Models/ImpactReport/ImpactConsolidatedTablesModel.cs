﻿namespace DI.Domain.Models.ImpactReport
{
    public class ImpactConsolidatedTablesModel
    {
        public string? Value { get; set; }
        public decimal? BeforeIA { get; set; }
        public decimal? Projection { get; set; }
        public decimal? AfterIA { get; set; }
        public decimal? DifferentPredifyXCompany { get; set; }
        public decimal? Variation { get; set; }
    }
}
