"""
Script com código usado para estudo de elasticidade por cidade para VEM.

https://dev.azure.com/predify/Predify%20Board%20Oficial/_workitems/edit/11805
"""


# %%

import os
import sys

import pandas as pd
import numpy as np
from unidecode import unidecode
import psycopg

sys.path.append("../")
from geral.config import getDadosAWSSession

# %%

ID_COMPANY = 3026

conn = getDadosAWSSession("producao")
pg_conn = psycopg.connect(
    f"postgresql://{os.getenv('PG_USER')}:{os.getenv('PG_PASSWORD')}@{os.getenv('PG_ADDRESS')}/{os.getenv('PG_DB')}"
)

PRODUCT_ID = "Description"
ALT_PRODUCT_ID = "Product"

# %%

capitais = [
    ("Rio Branco", "AC"),
    ("Maceió", "AL"),
    ("Macapá", "AP"),
    ("Manaus", "AM"),
    ("Salvador", "BA"),
    ("Fortaleza", "CE"),
    ("Brasília", "DF"),
    ("Vitória", "ES"),
    ("Goiânia", "GO"),
    ("São Luís", "MA"),
    ("Cuiabá", "MT"),
    ("Campo Grande", "MS"),
    ("Belo Horizonte", "MG"),
    ("Belém", "PA"),
    ("João Pessoa", "PB"),
    ("Curitiba", "PR"),
    ("Recife", "PE"),
    ("Teresina", "PI"),
    ("Rio de Janeiro", "RJ"),
    ("Natal", "RN"),
    ("Porto Alegre", "RS"),
    ("Porto Velho", "RO"),
    ("Boa Vista", "RR"),
    ("Florianópolis", "SC"),
    ("São Paulo", "SP"),
    ("Aracaju", "SE"),
    ("Palmas", "TO"),
]

df_capitais = pd.DataFrame(capitais, columns=["capital", "UF"])
df_capitais = df_capitais.assign(
    capital_clean=lambda x: x.capital.str.lower().apply(unidecode)
)
df_capitais.head()

# %%

stmt = f"""
SELECT
    *
FROM Enterprise_ElasticityNew
WHERE IdCompany = {ID_COMPANY}
AND IsDeletado = 0
AND DataHoraCriacao = (
    SELECT MAX(DataHoraCriacao) FROM Enterprise_ElasticityNew
    WHERE IdCompany = {ID_COMPANY} AND IsDeletado = 0
)
"""

df_elast = pd.read_sql(stmt, conn)
df_elast = df_elast.rename(
    columns={"Granularity1": "Description", "Granularity2": "Affiliate"}
)

# NOTE versão que usa elasticidade calculada via Databricks com outra granularidade
# df_elast = pd.read_csv("../data/vem_elast_databricks.csv")
# df_elast = df_elast.rename(columns={"clipped_elast": "Elasticity"}).drop(
#     columns=["Revenue"]
# )
# df_elast = df_elast.assign(Affiliate=df_elast.Affiliate.astype(str))

df_elast.head()

# %%

stmt = f"""
SELECT Affiliate, AffiliateCity, AffiliateState, Product, Description, PackageDescription, Category4
FROM Enterprise_Sales_History WHERE IdCompany = {ID_COMPANY}
AND IsDeletado = 0 AND IsLastPrice = 1
"""

df_info = pd.read_sql(stmt, conn)

# %%

df_info.head()

# %%

df_m = pd.merge(df_elast, df_info, on=["Affiliate", PRODUCT_ID], how="left")
df_m = df_m.loc[~df_m["PackageDescription"].isna()]
df_m.head()

# %%


def _elast_type(x):
    return "Elástico" if x <= -1 else "Inelástico"


df_m["elast_type"] = df_m["Elasticity"].apply(_elast_type)
df_m_vote = (
    df_m.groupby([PRODUCT_ID, "AffiliateCity", "AffiliateState"])
    .agg(
        {
            "elast_type": pd.Series.mode,
            "Category4": "first",
            "PackageDescription": "first",
            ALT_PRODUCT_ID: "first",
        }
    )
    .reset_index()
)


def replace_arrays(value):
    if isinstance(value, np.ndarray):
        return "Elástico"
    return value


df_m_vote["elast_type"] = df_m_vote["elast_type"].apply(replace_arrays)
df_m_vote.head()

# %%

df_m_vote = pd.merge(
    df_m_vote,
    df_capitais,
    left_on=["AffiliateCity", "AffiliateState"],
    right_on=["capital_clean", "UF"],
    how="inner",
)
df_m_vote.head()

# %%

df_report = df_m_vote[
    ["Description", "PackageDescription", "Category4", "capital", "UF", "elast_type"]
]

# %%

df_report = df_report.rename(
    columns={
        "Description": "Descrição",
        "PackageDescription": "EAN",
        "Category4": "Subcategoria",
        "capital": "Cidade",
        "elast_type": "Elasticidade",
    }
)
df_report.to_excel("vem_elast_report.xlsx", index=False)

# %%
df_report = df_report.assign(dummy=1)
# %%

from plotnine import (
    ggplot,
    aes,
    geom_bar,
    theme,
    element_text,
    theme_bw,
    labs,
    scale_y_continuous,
)


(
    ggplot(df_report, aes(fill="Elasticidade", y="dummy", x="Cidade"))
    + geom_bar(position="fill", stat="identity")
    + theme(axis_text_x=element_text(angle=45, hjust=1))
    + scale_y_continuous(labels=lambda l: ["%d%%" % (v * 100) for v in l])
    + labs(y="Proporção")
)

# %%

(
    ggplot(df_report, aes(fill="Elasticidade", y="dummy", x="Subcategoria"))
    + geom_bar(position="fill", stat="identity")
    + theme(axis_text_x=element_text(angle=45, hjust=1))
    + scale_y_continuous(labels=lambda l: ["%d%%" % (v * 100) for v in l])
    + labs(y="Proporção")
)

# %%

(
    ggplot(df_report, aes(fill="Elasticidade", y="dummy", x="Subcategoria"))
    + geom_bar(stat="identity")
    + theme(axis_text_x=element_text(angle=45, hjust=1))
    + labs(y="Número de itens")
)

# %%


stmt = f"""
SELECT "ProductId", "Revenue", "TotalQuantity", "Profit"
FROM "MonthlySaleHistoryData"
WHERE "CompanyId" = 3026 AND "YearMonth" = 202409
"""

df_pg = pd.read_sql(stmt, pg_conn)
df_pg.head()

# %%


def build_product_id(df: pd.DataFrame, granularity: list[str]):
    if not granularity:
        return None

    if df.empty:
        return None

    product_id = df[granularity].fillna("").agg("||".join, axis=1)
    return product_id


df_m["ProductId"] = build_product_id(df_m, ["Affiliate", "Product"])

# %%

df_m_pg = pd.merge(df_m, df_pg, on="ProductId", how="left")

# %%

df_m_pg = pd.merge(
    df_m_pg,
    df_capitais,
    left_on=["AffiliateCity", "AffiliateState"],
    right_on=["capital_clean", "UF"],
    how="inner",
)

# %%

df_aggregated = df_m_pg.groupby(["capital", "elast_type"], as_index=False)[
    "Revenue"
].sum()

(
    ggplot(df_aggregated, aes(x="capital", y="Revenue", fill="elast_type"))
    + geom_bar(stat="identity", position="stack")
    + theme(axis_text_x=element_text(angle=45, hjust=1))
    + labs(x="Subcategoria", y="Receita (R$)", fill="Elasticidade")
)

# %%

df_aggregated = df_m_pg.groupby(["Category4", "elast_type"], as_index=False)[
    "Revenue"
].sum()

(
    ggplot(df_aggregated, aes(x="Category4", y="Revenue", fill="elast_type"))
    + geom_bar(stat="identity", position="stack")
    + theme(axis_text_x=element_text(angle=45, hjust=1))
    + labs(x="Subcategoria", y="Receita (R$)", fill="Elasticidade")
)

# %%
