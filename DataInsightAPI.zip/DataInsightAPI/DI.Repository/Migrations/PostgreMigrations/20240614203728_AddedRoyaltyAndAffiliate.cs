﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DI.Repository.Migrations.PostgreMigrations
{
    /// <inheritdoc />
    public partial class AddedRoyaltyAndAffiliate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Affiliate",
                table: "MonthlySaleHistoryData",
                type: "character varying(128)",
                maxLength: 128,
                nullable: true);

            migrationBuilder.AddColumn<decimal>(
                name: "Profit",
                table: "MonthlySaleHistoryData",
                type: "numeric",
                nullable: false,
                defaultValue: 0m);

            migrationBuilder.AddColumn<decimal>(
                name: "RoyaltyPercentege",
                table: "MonthlySaleHistoryData",
                type: "numeric",
                nullable: false,
                defaultValue: 0m);

            migrationBuilder.AddColumn<decimal>(
                name: "RoyaltyReal",
                table: "MonthlySaleHistoryData",
                type: "numeric",
                nullable: false,
                defaultValue: 0m);

            migrationBuilder.AddColumn<string>(
                name: "Affiliate",
                table: "MonthlyProjectionData",
                type: "character varying(128)",
                maxLength: 128,
                nullable: true);

            migrationBuilder.AddColumn<decimal>(
                name: "Royalty",
                table: "ImpactReportConfiguration",
                type: "numeric",
                nullable: false,
                defaultValue: 0m);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Affiliate",
                table: "MonthlySaleHistoryData");

            migrationBuilder.DropColumn(
                name: "Profit",
                table: "MonthlySaleHistoryData");

            migrationBuilder.DropColumn(
                name: "RoyaltyPercentege",
                table: "MonthlySaleHistoryData");

            migrationBuilder.DropColumn(
                name: "RoyaltyReal",
                table: "MonthlySaleHistoryData");

            migrationBuilder.DropColumn(
                name: "Affiliate",
                table: "MonthlyProjectionData");

            migrationBuilder.DropColumn(
                name: "Royalty",
                table: "ImpactReportConfiguration");
        }
    }
}
