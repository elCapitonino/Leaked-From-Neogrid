﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PH.Domain.Domain
{
    public class IntervaloMargem
    {
        public IntervaloMargem()
        {
            CreateDate = DateTime.Now;
        }

        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string? Id { get; private set; }
        public string? ValueType { get; set; }
        public DateTime CreateDate { get; set; }
        public double? Max { get; set; }
        public double? Min { get; set; }
        public long IdCompany { get; set; }
    }
}
