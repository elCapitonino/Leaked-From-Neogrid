﻿using DI.Domain.ImpactGraph.Models;
using DI.Domain.Models.ImpactReport;

namespace DI.Domain.Utils.Cache
{
    public class CacheClearRequestDto
    {
        public string GraphType { get; set; }
        public GraphRequestModel GraphRequest { get; set; }
        public ImpactRawRequestModel ReportRequest { get; set; }
        public ImpactConsolidatedRequestModel ConsolidatedRequest { get; set; }

        public string GenerateCacheKey()
        {
            if (GraphRequest != null && !string.IsNullOrEmpty(GraphType))
            {
                return GraphRequest.GenerateCacheKey(GraphType);
            }

            if (ReportRequest != null)
            {
                return ReportRequest.GenerateCacheKey();
            }

            if (ConsolidatedRequest != null)
            {
                return ConsolidatedRequest.GenerateCacheKey();
            }

            throw new ArgumentException("Invalid request model.");
        }
    }
}
