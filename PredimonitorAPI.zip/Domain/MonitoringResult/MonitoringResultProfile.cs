﻿using AutoMapper;
using Domain.MonitoringResult.Converters;
using Domain.MonitoringResult.Models;
using Repository.Entity;

namespace Domain.MonitoringResult
{
    public class MonitoringResultProfile : Profile
    {
        public MonitoringResultProfile()
        {
            CreateMap<HorusProductsEntity, ResultFilterResponse>().ConvertUsing<HorusToResultFilterResponseConverter>();
            CreateMap<InfoPriceSaoJoaoEntity, ResultFilterResponse>().ConvertUsing<InfoPriceSaoJoaoToResultFilterResponseConverter>();
            CreateMap<InfoPricePeraltaEntity, ResultFilterResponse>().ConvertUsing<InfoPricePeraltaToResultFilterResponseConverter>();
            CreateMap<IndiretaEntity, ResultFilterResponse>().ConvertUsing<IndiretaToResultFilterResponseConverter>();
            CreateMap<AbvEntity, ResultFilterResponse>().ConvertUsing<SmarketABVFilterResponseConverter>();
            CreateMap<PeraltaEntity, ResultFilterResponse>().ConvertUsing<NielsenPeraltaToResultFilterResponseConverter>();
            CreateMap<VemEntity, ResultFilterResponse>().ConvertUsing<NielsenVemToResultFilterResponseConverter>();
            CreateMap<OfflineSupermarketTorreEntity, ResultFilterResponse>().ConvertUsing<OfflineSupermarketTorreToResultFilterResponseConverter>();
            CreateMap<ResultFilterResponse, MonitoringProductMarketResultItemEntity>().ConvertUsing<ResultFilterResponseToMonitoringProductMarketResultItemConverter>();
            CreateMap<InfoPriceTorreEntity, ResultFilterResponse>().ConvertUsing<InfoPriceTorreToResultFilterResponseConverter>();
            CreateMap<ScantechSupermaxiEntity, ResultFilterResponse>().ConvertUsing<ScantechSupermaxiToResultFilterResponseConverter>();

        }
    }
}
