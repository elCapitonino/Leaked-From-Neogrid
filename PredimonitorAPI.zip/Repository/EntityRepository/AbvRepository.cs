﻿using Repository.DbContexts;
using Repository.Entity;
using Repository.EntityRepository.Bases;

namespace Repository.EntityRepository
{
    public class AbvRepository : GenericMongoRepository<AbvEntity>, IAbvRepository
    {
        public AbvRepository(SmarketCompetitorDbContext dbContext) : base(dbContext)
        {

        }
        public static string DbContextName => nameof(SmarketCompetitorDbContext);
    }
}
