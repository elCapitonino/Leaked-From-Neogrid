using Repository.Entity.Databricks;
using Repository.EntityRepository.Bases;
using System;

namespace Repository.EntityRepository;

public interface IIgnoredPriceRepository : IGenericDatabricksRepository<IgnoredPriceEntity>
{
}
