﻿namespace DI.Service.PredifyAPI.Access
{
    public class AccessService : IAccessService
    {
        private readonly HttpClient client;

        public AccessService(HttpClient client)
        {
            this.client = client;
        }

        public async Task<bool> UserHasAccess(long companyId)
        {
            var response = await client.GetAsync($"/api/V2/Access/Validation/ValidateCompany?idCompany={companyId}");
            var content = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
                return true;
            else if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                return false;

            throw new Exception(content);
        }
    }
}
