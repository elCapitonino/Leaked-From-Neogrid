from typing import Optional

from pydantic import BaseModel


class InputAddressInfo(BaseModel):
    base: str
    id_consulta: str
    address: str
    neighborhood: Optional[str]
    city: Optional[str]
    state: Optional[str]
    country: Optional[str]

    def __hash__(self):
        return hash((type(self),) + tuple(self.__dict__.values()))


class GeosearchRequest(BaseModel):
    address_info: InputAddressInfo
    use_cache: bool = True


class DiscoverRequest(BaseModel):
    query: str
    lat: float = 0
    long: float = 0
    use_cache: bool = True

    def __hash__(self):
        return hash((self.query, self.lat, self.long, self.use_cache))
