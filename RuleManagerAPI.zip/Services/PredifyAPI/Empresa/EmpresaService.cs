﻿using Newtonsoft.Json;
using Services.PredifyAPI.Empresa.Models;

namespace Services.PredifyAPI.Empresa
{
    public class EmpresaService: IEmpresaService
    {
        private readonly HttpClient client;

        public EmpresaService(HttpClient client)
        {
            this.client = client;
        }
        public async Task<IEnumerable<EmpresaSelecionarResponse>> GetEmpresaAsync()
        {
            var response = await this.client.GetAsync("/api/Empresa/GetEmpresasSelecionar");
            var content = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
            {
                if (content.Contains("Acesso não autorizado", StringComparison.InvariantCultureIgnoreCase))
                {
                    throw new Exception("Acesso não autorizado");
                }

                return JsonConvert.DeserializeObject<IEnumerable<EmpresaSelecionarResponse>>(content);
            }

            throw new Exception(content);
        }
    }
}
