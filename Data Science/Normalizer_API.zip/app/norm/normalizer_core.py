from concurrent.futures import process
import threading
import time
from datetime import datetime
from norm.memorycache import MemoryCache
from norm.processing import Processing
from norm.extraction import Extraction
from norm.validate_products import ValidateProducts
from norm.conect_mongo import MongoConnect
from norm.NormalizerExtraction import NormalizerExtraction
from norm.log_normalizador import LogNormalizador
from threading import Lock
from bson import ObjectId
import time

class Normalizer_core(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)
        self.prep = Processing()
        self.extr = Extraction()
        self.Validate_P = ValidateProducts()
        self.memory = MemoryCache()
        self.dbMongo = MongoConnect()
        self.norm_extraction = NormalizerExtraction()
        self.log_norm = LogNormalizador()
        self._event = threading.Event()
        self.lockPriorities = Lock()
        
        # Ids das Empresas que serão priorizadas.
        self.idCompaniesPriorities = []

        self.status_norm = True
        self.status_real_norm = True
        self.timeToProcess = 0

        print("Normalizer_core initialized")

    def set_status(self, status):
        self.status_norm = status
        # print("status_norm: ", self.status_norm)

    def pause(self):
        self.status_real_norm = True
        print("Normalizer_core em pausa --- ",
              datetime.now().strftime('%d-%m-%Y %H:%M:%S.%f'))
        self._event.clear()
        self._event.wait()

    def resume(self, status_norm):
        self.status_norm = status_norm
        self.status_real_norm = False
        print("Normalizer_core executando --- ",
              datetime.now().strftime('%d-%m-%Y %H:%M:%S.%f'))
        self._event.set()

    
    def set_quantityToNormalize(self, quantity=50):
        self.dbMongo.set_quantityToNormalize(quantity)
    
    def get_quantityToNormalize(self):
        return self.dbMongo.get_quantityToNormalize()

    def get_cache(self):
        cache =self.dbMongo.get_cache()
        cache.update({"Last process time (s)": self.timeToProcess}) 
        return cache

    def AddIdCompanyToPriorities(self, idCompany: int):
        if (idCompany <= 0):
            return

        self.lockPriorities.acquire()
        try:
            if (idCompany not in self.idCompaniesPriorities):
                self.idCompaniesPriorities.append(idCompany)
        finally:
            self.lockPriorities.release()
    
    def RemoveIdCompanyFromPriorities(self, idCompany: int):
        self.lockPriorities.acquire()
        try:
            if (idCompany in self.idCompaniesPriorities):
                self.idCompaniesPriorities.remove(idCompany)
        finally:
            self.lockPriorities.release()        

    def GetIdCompanyPriorities(self):
        return self.idCompaniesPriorities

    def run(self):
        print("Normalizer_core inicializada ")
        # print(self.memory.products_normalized)
        # texto = "ventilador de ar condicionado de piso de alta eficiencia"
        ean = ''
        ncm = ''
        product_model = ''
        shipping = ''
        stock_quantity = ''
        product_link = ''
        site_sku = ''

        priorityIndex = -1
        idCompanyPriority = 0
        gotten = 0
        # print("#################################################")

        while True:
            # print("----------------------------------")

            if self.status_norm == True:
                # print("Normalizador Pausado")
                self.pause()

            # time.sleep(2)
            # self._event.set()

            if (gotten <= 0):
                self.lockPriorities.acquire()
                idCompanyPriority = 0
                try:
                    if (len(self.idCompaniesPriorities) > 0):
                        priorityIndex += 1
                        if (priorityIndex == len(self.idCompaniesPriorities)):
                            priorityIndex = -1
                        else:
                            idCompanyPriority = self.idCompaniesPriorities[priorityIndex]
                            gotten = 2
                finally:
                    self.lockPriorities.release()
            else:
                gotten -= 1
            startTime = time.time()

            data = self.dbMongo.get_products_to_normalize(idCompanyPriority)
            results = list(data)
            
            if (priorityIndex > -1 and len(results) == 0):
                gotten = 0
                continue
            

            if(len(results) == 0):
                # print("Não há produtos para normalizar", len(results))
                time.sleep(1)
            if True:
                # print("Produtos para normalizar: ", len(results))
                # print("-------------test---------------------")
                for i in results:
                    # variavaies
                    ListNorm = None
                    product = None
                    produto_valido = None
                    insert = None

                    if(i["id_company"] == 2814 or i["id_company"] == 2815 or i["id_company"] == 2816): 
                        self.dbMongo.insert_products_netshoes(i)
                    # process_product = self.norm_extraction.normalize_preprocessing(
                    #     i["product_name"])
                    if (i["product_name"] == None or i["product_name"] == ""):
                        self.dbMongo.insert_failed_to_normalize(i, 4)
                        continue

                    ##############################################################
                    product_brand = ''
                    product_model = ''
                    product_voltage = ''
                    attributes = ''
                    product_description = ''

                    if "product_model" in i:
                        product_model = i["product_model"]
                    if "product_brand" in i:
                        product_brand = i["product_brand"]
                    if "product_voltage" in i:
                        product_voltage = i["product_voltage"]
                    # if "attributes" in i:
                    #     attributes = i["attributes"]
                    # if "product_description" in i:
                    #     product_description = i["product_description"]

                    ##########################################
                    if "product_category_name" in i:
                        category_name = self.norm_extraction.normalizer_extraction_category_dafiti(
                            i["product_category_name"], i["language"])
                        if category_name != None and category_name != "":
                            if category_name not in str(i["product_name"]).lower():
                                i["product_name"] = i["product_name"] + \
                                    " " + category_name

                    ##########################################
                    product_concat = i["product_name"]
                    if str(product_model).lower() not in str(i["product_name"]).lower():
                        product_concat = product_concat + \
                            " " + product_model
                    if str(product_brand).lower() not in str(i["product_name"]).lower():
                        product_concat = product_concat + " " + product_brand
                    if str(product_voltage).lower() not in str(i["product_name"]).lower():
                        product_concat = product_concat + " " + product_voltage

                    # product_concat = (
                    #     i["product_name"] + " " + product_model + " " + product_brand + " " + product_voltage)

                    ##############################################################

                    product = self.norm_extraction.normalizer_extraction(
                        product_concat, i["language"])

                    ######################################################
                    ''' Adicionar marca e voltagem no produto coletado'''
                    # if ("product_brand" not in i) and (product['brands']):
                    #     i['product_brand'] = product['brands']
                    # if ("product_voltage" not in i) and (product['voltage']):
                    #     i['product_voltage'] = product['voltage']

                    #####################################################

                    ##########################################################

                    produto_valido, log = self.Validate_P.validate_products(
                        product)

                    # print("produto_valido: ", produto_valido)
                    ##########################################
                    #########################################################################
                    if "product_ean" in i:
                        ean = i["product_ean"]
                    if "product_ncm" in i:
                        ncm = i["product_ncm"]
                    if "product_model" in i:
                        product_model = i["product_model"]
                    if "shipping" in i:
                        shipping = i["shipping"]
                    # if "stock_quantity" in i:
                    #    stock_quantity = i["stock_quantity"]
                    if "product_link" in i:
                        # print("------- ", i["product_link"])
                        product_link = i["product_link"]
                    if "site_sku" in i:
                        # print("------- ", i["site_sku"])
                        site_sku = i["site_sku"]

                    ########################################################################

                    # Verifica de produto esta na lista de produtos normalizados

                    if produto_valido == True:
                        #########################################################
                        #print("product 02 ", product)
                        if(("product_description" in i) and (product["brands"] == None or product["voltage"] == None)):

                            try:
                                product_description = self.norm_extraction.normalizer_extraction_brand_voltage(
                                    i["product_description"], i["language"])

                                if product['brands'] == None or product['brands'] == "":
                                    if product_description['brands']:
                                        i['product_brand'] = product_description['brands']
                                        product['brands'] = product_description['brands']
                                if product['voltage'] == None or product['voltage'] == "":
                                    if product_description['voltage']:
                                        i['product_voltage'] = product_description['voltage']
                                        product['voltage'] = product_description['voltage']
                            except:
                                pass

                        ########################################################

                        product.update({"model": product_model, "ean": ean,
                                        "ncm": ncm, "idcrawlers": i["id_crawler"]})
                        ##########################################
                        if "product_local" in i:
                            if "state" in i["product_local"]:
                                state = self.norm_extraction.normalizer_extraction_state(
                                    i["product_local"]["state"], i["language"])

                                if (str(state) != str(i["product_local"]["state"])):
                                    i["product_local"]["state"] = state

                        if "product_manufacture_year" in i:
                            # extrair ano de fabricação
                            year = self.norm_extraction.normalizer_extraction_year(
                                i["product_manufacture_year"])
                            if (str(year) != str(i["product_manufacture_year"])):

                                i["product_manufacture_year"] = year

                        if "product_used_hours" in i:
                            # extrair horas de uso
                            hours = self.norm_extraction.normalizer_extraction_hours(
                                i["product_used_hours"])
                            if (str(hours) != str(i["product_used_hours"])):
                                i["product_used_hours"] = hours
                        ##########################################
                        if "product_category_name" in i:
                            category_name = self.norm_extraction.normalizer_extraction_category_dafiti(
                                i["product_category_name"], i["language"])

                        ##########################################

                        # print("product: ", product)

                        ListNorm = self.Validate_P.checks_products_register(
                            self.memory.get_products_normalized(i["language"]), product)
                        # print("ListNorm: ", ListNorm)
                    ################################################################################

                    # Produto é valido e não esta na lista de produtos normalizados
                    # - Salvar no mongo e na lista de produtos normalizados

                    # print("Registrado 1 ---- ", len(self.memory.products_normalized))
                    if (produto_valido == True and ListNorm == None):

                        # print(i["_id"], product, brands, categories, materials, voltage, metric_units, power, leftover,

                        #      product_model, ean, ncm, i["id_crawler"])


                        product.update({"_id": ObjectId() })

                        ListNorm, insert = self.dbMongo.register_norm(
                            i["_id"], product)

                        # ListNorm = ListNorm.inserted_id

                        # atualizar lista de produtos normalizados em memoria
                        # print("insert ", insert)
                        if(insert != None):
                            # print(insert)
                            self.memory.update_products_nomal(insert)
                    ################################################################################

                    if produto_valido == True and ListNorm != None:
                        id_price = self.dbMongo.update_price(
                            ListNorm, i, product['trash'])
                        self.log_norm.log_normalization(
                            id_price, ListNorm, product["product"], i["product_name"], i["id_crawler"], 0)

                        # print("Registrado 2 ---- ")

                    ################################################################################

                    if produto_valido == False:

                        self.dbMongo.insert_failed_to_normalize(i, log)

                    # time.sleep(2)
                
                self.dbMongo.flush()
                self.log_norm.flush()
                endTime = time.time()
                self.timeToProcess = (endTime-startTime) 
