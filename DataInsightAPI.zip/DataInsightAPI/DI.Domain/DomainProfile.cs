﻿using AutoMapper;

namespace DI.Domain
{
    public class DomainProfile : Profile
    {

    }
}
