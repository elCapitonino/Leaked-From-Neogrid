﻿namespace Repository.Entity
{
    public class ProductMarketResultSellerEntity : BaseEntity
    {
        public long CompanyId { get; set; }

        public string SellerName { get; set; }

        public bool IsDeleted { get; set; }
    }
}
