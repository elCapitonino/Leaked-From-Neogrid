﻿using DI.Repository.Attributes;
using DI.Repository.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DI.Repository.TypeConfiguration
{
    [UsePostgreContext]
    public sealed class ProductLaterPeriodTypeConfiguration : TypeConfigurationBase<ProductLaterPeriodEntity>, IEntityTypeConfiguration<ProductLaterPeriodEntity>
    {
        public override void Configure(EntityTypeBuilder<ProductLaterPeriodEntity> builder)
        {
            ConfigureTableName(builder, "ProductLaterPeriod");

            builder.HasKey(x => x.Id);
            builder.Property(x => x.Id).ValueGeneratedOnAdd().HasDefaultValueSql("uuid_generate_v4()").IsRequired();

            builder.Property(x => x.CompanyId).IsRequired();
            builder.Property(x => x.ProductId).HasMaxLength(255).IsRequired();
            builder.Property(x => x.PriceGroupId).IsRequired();
            builder.Property(x => x.LaterPeriod);
            builder.Property(x => x.ApprovedDate).IsRequired();
            builder.Property(x => x.Found).IsRequired();
            builder.Property(x => x.ReferenceId);

            builder.HasOne(x => x.Reference)
                .WithMany()
                .HasForeignKey(x => x.ReferenceId);
        }
    }
}
