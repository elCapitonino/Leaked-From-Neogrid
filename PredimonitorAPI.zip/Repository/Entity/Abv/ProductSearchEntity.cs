﻿using MongoDB.Bson.Serialization.Attributes;

namespace Repository.Entity.Abv
{
    public class ProductSearchEntity
    {
        [BsonElement("SEQPRODUTO")]
        public long? SeqProduto { get; set; }

        [BsonElement("PRECO_VAREJO")]
        public string? PrecoVarejo { get; set; }

        [BsonElement("PRECO_ATACADO")]
        public string? PrecoAtacado { get; set; }

        [BsonElement("PROMOCAO")]
        public string? Promocao { get; set; }

        [BsonElement("DT_PESQUISA")]
        public DateTime? DtPesquisa { get; set; }

        [BsonElement("QUANTIDADE_ATACADO")]
        public string? QuantidadeAtacado { get; set; }

        [BsonElement("OBSERVACAO")]
        public string? Observacao { get; set; }

        [BsonElement("URL")]
        public string? Url { get; set; }
    }

}
