﻿using AutoMapper;
using Domain.MonitoringResult.Models;
using Repository.Entity;
using Repository.Enums;

namespace Domain.MonitoringResult.Converters
{
    public class InfoPriceSaoJoaoToResultFilterResponseConverter : ITypeConverter<InfoPriceSaoJoaoEntity, ResultFilterResponse>
    {
        public ResultFilterResponse Convert(InfoPriceSaoJoaoEntity source, ResultFilterResponse destination, ResolutionContext context)
        {
            var dest = new ResultFilterResponse()
            {
                ProductName = source.Descricao,
                ProductLink = source.Hash,
                ProductBrand = source.Rede,
                SellerName = source.Loja,
                Marketplace = (string)context.Items["CrawlerName"],
                Price = source.PrecoPago,
                PaymentType = "-",
                Price_unit_type = PriceUnitType.UNITARIO,
                CrawlerDate = source.DataPreco,
                Disregarded = false,               
                IdCrawler = (int)context.Items["CrawlerId"],
                City = source.Cidade,               
                On_request = false,                
                State = source.UF,
                Coordinates = new PrediMonitorProduct_CoordinatesModel()
                {
                    Longitude = (decimal)source.Longitude,
                    Latitude = (decimal)source.Latitude,
                },
            };

            return dest;
        }
    }
}
