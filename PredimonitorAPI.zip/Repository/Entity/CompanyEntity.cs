namespace Repository.Entity
{
    public class CompanyEntity : BaseEntity
    {

        public string Company { get; set; }

        public long? CityId { get; set; }

        public string? Cnpj { get; set; }
        public bool? IsFinalizedForm { get; set; }

        public long? MainCompanyId { get; set; }

        public bool? IntelligentPricing { get; set; }

        public bool? RoutineCompleted { get; set; }

        public string? MonitoringLanguage { get; set; }

        public long? PartnerId { get; set; }

        public long? CountryId { get; set; }

        public Guid? GUID { get; set; } = Guid.NewGuid();

    }
}
