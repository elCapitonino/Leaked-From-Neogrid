import requests
from fastapi import HTTPException
# from search_products import Search_products
from predimonitor_type import *
from config import *
from fastapi.encoders import jsonable_encoder
from search_products import *
from search_neogrid import Search_neogrid
from search_horus import Search_horus
# from restriction_search_company import RestrictionSearchCompany


class Search_predify:
    def __init__(self):
        self.Restriction_list = RestrictionList()
        self.search_restrict = RestrictionSearchCompany()

    async def search(self, products: Search_products_predmonitor):
        # print(products)
        list_restrict = self.Restriction_list.get_restriction(
            products.id_company)
        list_seach_restrict = self.search_restrict.get_company()
        # print(list_seach_restrict)
        result = []
        result_horus = []
        result_final = []
        full_result_predmonitor = []
        result_search = []
        result_pred = None
        name_product_ean = None

        if (products.filters.products != None and len(products.filters.products) != 0):

            for i in products.filters.products:

                request_filters = products.filters.copy()
                request_filters.products = [i]
                request_filters.categories = []
                if (products.filters.brands != None and products.filters.brands != []):
                    request_filters.brands = products.filters.brands

                result_pred = requests.post(url=url_normalizer_predmonitor,
                                            json=jsonable_encoder(request_filters))
                
                print(result_pred.json())

                full_result_predmonitor.append({
                    "product": i,
                    "result": result_pred.json()
                })

        elif (products.filters.categories != None and len(products.filters.categories) != 0):
            for i in products.filters.categories:
                request_filters = products.filters.copy()
                request_filters.products = [i]
                request_filters.categories = []

                result_pred = requests.post(url=url_normalizer_predmonitor,
                                            json=jsonable_encoder(request_filters))

                full_result_predmonitor.append({
                    "product": i,
                    "result": result_pred.json()
                })

        if result_pred != None:
            data_resp_pred = result_pred.json()
        # print(full_result_predmonitor)
        # if (data_resp_pred['products_list'][0] == []):
        #     print("teste ", full_result_predmonitor)
        #     return []

        if (products.data_source == search_source_type.Horus_search):
            search_horus = Search_horus()
            result_horus = await search_horus.search_get(
                products.idcrawlers_offline, products.data_source, products.filters.eans, products.start_date, products.end_date)


        full_result = []
        try:
            if (products.filters.products != None or len(products.filters.products) != 0):
                name_product_ean = products.filters.products[0]

            # if (data_resp_pred['products_list'][0] != []):
            search_products_general = Search_products()

            for i in full_result_predmonitor:

                if (i['result']['products_list'][0] == []):
                    continue
                


                if (products.id_company not in list_seach_restrict):
                    
                    mandatoryTagModel = ""
                    if(products.filters.mandatoryTagModel != None):
                        mandatoryTagModel = products.filters.mandatoryTagModel
                    result = await search_products_general.get_products_pred_monitor(
                        i['result'], products.start_date, products.end_date, products.idcrawlers, products.filters.local_states,
                        products.filters.manufacture_years, products.filters.used_hours, products.filters.language, products.id_company,  list_restrict, mandatoryTagModel, products.filters.exactVector, products.filters.categories, products.filters.brands)

                else:
                    result = await search_products_general.get_products_pred_monitor_restricted(
                        i['result'], products.start_date, products.end_date, products.idcrawlers, products.filters.local_states,
                        products.filters.manufacture_years, products.filters.used_hours, products.filters.language, products.id_company, list_restrict)

                result_search.extend(result)
                result = []
                # if (result == None):
                #     result = []

                # full_result.append({
                #     "product": i['product'],
                #     "result": result
                # })

        except Exception as e:
            # print(e)
            return HTTPException(status_code=500, detail=e)

        result_final = result_search + result_horus

        if name_product_ean == None and products.filters.eans != None:
            name_product_ean = products.filters.eans[0].ean
        if (name_product_ean == None):
            name_product_ean = "Outros"

        full_result.append({
            "product": name_product_ean,
            "result": result_final
        })

        return full_result
