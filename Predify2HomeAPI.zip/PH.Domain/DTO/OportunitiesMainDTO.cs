﻿namespace PH.Domain.DTO
{
    public class OportunitiesMainDTO
    {
        public OportunitiesMainDTO()
        {
            IncreaseProfit = new OportunitiesDTO()
            {
                TotalItems = 0,
                ActualPriceProfit = 0,
                TotalItemsProfit = 0
            };

            IncreaseMargin = new OportunitiesDTO()
            {
                TotalItems = 0,
                ActualPriceProfit = 0,
                TotalItemsProfit = 0
            };
        }
        public OportunitiesDTO IncreaseProfit { get; set; }
        public OportunitiesDTO IncreaseMargin { get; set; }
    }

    public class OportunitiesSQLDTO
    {
        public int Itens { get; set; }
        public double PrecoAtual { get; set; }
        public double PrecoNovo { get; set; }
    }

    public class OportunitiesDTO
    {
        public double TotalItems { get; set; }
        public double ActualPriceProfit { get; set; }
        public double TotalItemsProfit { get; set; }
    }
}
