﻿using Repository.Entity;

namespace DomainTests.DynamicFilter.Seed
{
    public class CompanySeed
    {
        public static List<CompanyEntity> GetTestData() => new List<CompanyEntity>()
        {
            new CompanyEntity { Id = 1, Company = "Company A" },
            new CompanyEntity { Id = 2, Company = "Company B" },
            new CompanyEntity { Id = 3, Company = "Company C" }
        };
    }


}
