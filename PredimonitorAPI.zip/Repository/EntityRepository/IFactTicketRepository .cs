﻿using MongoDB.Bson;
using Repository.Entity;
using Repository.EntityRepository.Bases;

namespace Repository.EntityRepository
{
    public interface IFactTicketRepository : IGenericRepository<FactTicketEntity, ObjectId>, IMongoRepository
    {
    }
}
