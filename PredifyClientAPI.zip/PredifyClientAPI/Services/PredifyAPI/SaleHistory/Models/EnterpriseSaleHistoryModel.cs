﻿namespace PredifyClientAPI.Services.PredifyAPI.SaleHistory.Models
{
    /// <summary>
    /// Modelo de dados do histórico de vendas.
    /// </summary>
    public class EnterpriseSalesHistoryModel
    {
        /// <summary>
        /// Identificador do Produto no ERP.
        /// </summary>
        public string? externalProductID { get; set; }

        /// <summary>
        /// Nome do produto.
        /// </summary>
        public string? productName { get; set; }

        /// <summary>
        /// Identificador da Loja
        /// </summary>
        public string? storeID { get; set; }

        /// <summary>
        /// Custo do Produto pbcusto
        /// </summary>
        public decimal? productCost { get; set; }

        /// <summary>
        /// Quantity vendida
        /// </summary>
        public decimal? quantity { get; set; }

        /// <summary>
        /// Total da venda
        /// </summary>
        public decimal? total { get; set; }

        /// <summary>
        /// Preço de venda unitário
        /// </summary>
        public decimal? salePrice { get; set; }

        /// <summary>
        /// Identificador do Cliente
        /// </summary>
        public string? customerID { get; set; }

        /// <summary>
        /// Nome do cliente
        /// </summary>
        public string? customerName { get; set; }

        /// <summary>
        /// Data da emissão da Nf
        /// </summary>
        public DateTime issuance { get; set; }

        /// <summary>
        /// Identificador da filial
        /// </summary>
        public string? affiliateID { get; set; }

        /// <summary>
        /// Nome da filial
        /// </summary>
        public string? affiliateName { get; set; }


        /// <summary>
        /// Número do documento da venda
        /// </summary>
        public string? Document { get; set; }

        /// <summary>
        /// Código do segmento que o cliente esta.
        /// </summary>
        public string? codSegment { get; set; }

        /// <summary>
        /// Nome do segmento que o cliente esta.
        /// </summary>
        public string? nameSegment { get; set; }

        /// <summary>
        /// Valor do frete.
        /// </summary>
        public decimal? shippingValue { get; set; }

        /// <summary>
        /// Grupo do produto.
        /// </summary>
        public string? productGroup { get; set; }

        /// <summary>
        /// Código do Grupo Econômico.
        /// </summary>
        public string? economicGroupCode { get; set; }

        /// <summary>
        /// Grupo Econômico.
        /// </summary>
        public string? economicGroup { get; set; }


        /// <summary>
        /// Número do Pedido
        /// </summary>
        public string? invoceNumber { get; set; }

        /// <summary>
        /// Preço de venda final, que o cliente vai pagar.
        /// </summary>
        public decimal? clientSalesPrice { get; set; }

        /// <summary>
        /// Código do fornecedor.
        /// </summary>
        public string? supplierCode { get; set; }

        /// <summary>
        /// Nome do fornecedor.
        /// </summary>
        public string? supplierName { get; set; }

        /// <summary>
        /// Descrição da unidade de medida, da embalagem.
        /// </summary>
        public string? packageDescription { get; set; }

        /// <summary>
        /// Unidade de medida da embalagem
        /// </summary>
        public string? packageUnity { get; set; }

        /// <summary>
        /// Nomeclatura Brasileira de Mercadoria.
        /// </summary>
        public long nbm { get; set; }

        /// <summary>
        /// Se o preço é promocional
        /// </summary>
        public bool promotional { get; set; }

        /// <summary>
        /// Tipo de expedição/envio
        /// </summary>
        public string? TypeOfShipping { get; set; }

        /// <summary>
        /// Margem definida
        /// </summary>
        public decimal? Margin { get; set; }

        /// <summary>
        /// País do Cliente (em casos de e commerce)
        /// </summary>
        public string? ClientCountry { get; set; }

        /// <summary>
        /// Estado do Cliente (em casos de e commerce)
        /// </summary>
        public string? ClientState { get; set; }

        /// <summary>
        /// Cidade do Cliente (em casos de e commerce)
        /// </summary>
        public string? ClientCity { get; set; }

        /// <summary>
        /// Local de venda. Ex: loja fisica, callcente ou loja virtual
        /// </summary>
        public string? TypeOfStore { get; set; }

        /// <summary>
        /// Categoria do cliente
        /// </summary>
        public string? ClientType { get; set; }

        /// <summary>
        /// País da Filial 
        /// </summary>
        public string? AffiliateCountry { get; set; }

        /// <summary>
        /// Estado da Filial 
        /// </summary>
        public string? AffiliateState { get; set; }

        /// <summary>
        /// Cidade da Filial 
        /// </summary>
        public string? AffiliateCity { get; set; }

        /// <summary>
        /// Centro de distribuição 
        /// </summary>
        public string? DistributionCenter { get; set; }

        /// <summary>
        /// Categoria Menor
        /// </summary>
        public string? Category1 { get; set; }

        /// <summary>
        /// Categoria Intermediaria
        /// </summary>
        public string? Category2 { get; set; }

        /// <summary>
        /// Categoria Mais Ampla
        /// </summary>
        public string? Category3 { get; set; }

        /// <summary>
        /// Mais ampla que a category3 
        /// </summary>
        public string? Category4 { get; set; }

        /// <summary>
        /// Mais ampla que a category4 
        /// </summary>
        public string? Category5 { get; set; }

        /// <summary>
        /// Id do categoty1
        /// </summary>
        public string? Category1Id { get; set; }

        /// <summary>
        /// Id do categoty2
        /// </summary>
        public string? Category2Id { get; set; }

        /// <summary>
        /// Id do categoty3
        /// </summary>
        public string? Category3Id { get; set; }

        /// <summary>
        /// Id do categoty4
        /// </summary>
        public string? Category4Id { get; set; }

        /// <summary>
        /// Id do categoty5 
        /// </summary>
        public string? Category5Id { get; set; }

        /// <summary>
        /// Código da promoção. Utilizado para algumas filiais da Farmácia São João 
        /// </summary>
        public string? StatusProduct { get; set; }

        /// <summary>
        /// Receita do ultimo preço 
        /// </summary>
        public decimal? LastSaleRevenue { get; set; }

        /// <summary>
        /// Cep da Filial
        /// </summary>
        public string? AffiliatePostalCode { get; set; }

        /// <summary>
        /// Nivel de atividade cupom Total
        /// </summary>
        public decimal? ALTotalTickets { get; set; }

        /// <summary>
        /// Nivel de atividade cupom unitario
        /// </summary>
        public decimal? ALGranularityTickets { get; set; }

        /// <summary>
        /// Json para guardar informações adicionais
        /// </summary>
        public string? JSON { get; set; }

        /// <summary>
        /// Custo Médio da rede 
        /// </summary>
        public decimal? AverageNetworkCost { get; set; }
    }
}
