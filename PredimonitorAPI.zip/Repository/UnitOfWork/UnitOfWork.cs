﻿using Microsoft.Extensions.DependencyInjection;
using MongoDB.Driver;
using Repository.DbContexts;
using Repository.DbContexts.Bases;
using Repository.EntityRepository;
using System.Reflection;
using System.Transactions;

namespace Repository.UnitOfWork
{
    public class UnitOfWork : IUnitOfWork
    {
        private bool _disposed = false;
        private readonly DbContextBase[] _dbContexts;

        public UnitOfWork(IServiceProvider serviceProvider, IMongoClient mongoClient)
        {
            _dbContexts = Assembly.GetExecutingAssembly().GetTypes()
                                     .Where(type => type.IsSubclassOf(typeof(DbContextBase)) && !type.IsAbstract)
                                     .Select(contextType => (DbContextBase)serviceProvider.GetRequiredService(contextType))
                                     .ToArray();

            this.InitializeRepository(mongoClient, serviceProvider.GetRequiredService<DatabricsDbContext>(), _dbContexts.ToArray());
        }

        public IMonitoringCrawlerRepository MonitoringCrawler { get; }
        public ICompanyMonitoringCrawlerRepository CompanyMonitoringCrawler { get; }
        public IMonitoringItemConfigRepository MonitoringItemConfig { get; }
        public IMonitoringItemRepository MonitoringItem { get; }
        public ICompanyConfigurationRepository CompanyConfiguration { get; }
        public ICompanyRepository Company { get; }
        public IMonitoringItemResultsRepository MonitoringItemResults { get; }
        public IMonitoringItemResultsStatusRepository MonitoringItemResultsStatus { get; }

        public IProductPricesRepository ProductPrices { get; }
        public Repository.EntityRepository.IHorusProductsRepository HorusProducts { get; }
        public IInfoPriceSaoJoaoRepository InfoPriceSaoJoao { get; }
        public IFactTicketRepository FactTicketRepository { get; }
        public IIndiretaRepository IndiretaRepository { get; }
        public IPeraltaRepository PeraltaRepository { get; }
        public IVemRepository VemRepository { get; }
        public IAbvRepository AbvRepository { get; }
        public IIgnoredMonitoringItemRepository IgnoredMonitoringItemRepository { get; }
        public IMonitoringProductMarketResultRepository MonitoringProductMarketResultRepository { get; }
        public IMonitoringProductMarketResultItemRepository MonitoringProductMarketResultItemRepository { get; }
        public IProductMarketResultSellerRepository ProductMarketResultSellerRepository { get; }
        public IInfoPricePeraltaRepository InfoPricePeraltaRepository { get; }
        public IOfflineSupermarketTorreRepository OfflineSupermarketTorres { get; }
        public IProductRepository ProductRepository { get; }
        public IProductSellerRepository ProductSellerRepository { get; }
        public IProductPriceRepository ProductPriceRepository { get; }
        public IIgnoredPriceRepository IgnoredPriceRepository { get; }
        public ICompanyMonitoringCrawlerFiltersRepository CompanyMonitoringCrawlerFiltersRepository { get; }
        public ICompanyMonitoringCrawlerFiltersValuesRepository CompanyMonitoringCrawlerFiltersValuesRepository { get; }
        public ICompanyProductPriceRepository CompanyProductPriceRepository { get; }
        public IInfoPriceTorreRepository InfoPriceTorreRepository { get; }
        public IScantechSupermaxiRepository ScantechSupermaxiRepository { get; }


        protected virtual void Dispose(bool disposing)
        {
            if (!this._disposed)
            {
                if (disposing)
                {
                    foreach (var dbContext in _dbContexts)
                        dbContext?.Dispose();
                }
            }
            this._disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            System.GC.SuppressFinalize(this);
        }

        public TransactionScope CreateTransactionScope() => new TransactionScope();
        public TransactionScope CreateTransactionScope(TransactionScopeAsyncFlowOption asyncFlowOption) => new TransactionScope(TransactionScopeOption.Required, TimeSpan.FromMinutes(60), asyncFlowOption);
    }
}
