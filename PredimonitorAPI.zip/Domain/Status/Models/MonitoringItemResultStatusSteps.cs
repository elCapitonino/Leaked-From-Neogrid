﻿#pragma warning disable IDE1006

namespace Domain.Status.Models
{
    public static class MonitoringItemResultStatusSteps
    {
        public const int IMPORTING_MONITORING_ITEMS_ERROR = -1;
        public const int IMPORTING_MONITORING_ITEMS = 1;
        public const int IMPORTING_MONITORING_ITEM_RESULTS = 2;
        public const int CLEANUP_ITEMS = 3;
        public const int REINDEXING_DATABASE = 4;
    }
}
