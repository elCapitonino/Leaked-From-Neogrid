﻿using Repository.Enums;

namespace Repository.Entity
{
    public sealed class EnterprisePriceGroups_DefaultFilterEntity : BaseEntity
    {
        public long EnterprisePriceGroups_DefaultFilterId { get; set; }
        public long IdCompany { get; set; }
        public long? IdParent { get; set; }
        public EnterprisePriceGroups_DefaultFilterEntity? Parent { get; set; }
        public string? FieldName { get; set; }
        public int Order { get; set; }
        public EPriceGroupFilterType dbField { get; set; }
        public bool PreSelect { get; set; }
        public int DisplaySide { get; set; }
        public string? GroupTag { get; set; }
        public bool ShowInPricing { get; set; }
        public bool ShowInApriori { get; set; }
        public string? Tooltip { get; set; }
        public bool IsDeleted { get; set; }
        public ICollection<EnterprisePriceGroups_DefaultFilterValueEntity>? Values { get; set; }
    }
}
