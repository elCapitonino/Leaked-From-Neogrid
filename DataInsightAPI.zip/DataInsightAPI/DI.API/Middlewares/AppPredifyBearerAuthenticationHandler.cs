﻿using DI.API.Middlewares.Models;
using DI.Domain.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Options;
using System.Security.Claims;
using System.Text.Encodings.Web;

namespace DI.API.Middlewares
{

    public class AppPredifyBearerAuthenticationHandler : AuthenticationHandler<AuthenticationSchemeOptions>
    {

        private readonly AppsettingsOptions appsettings;
        private readonly HttpClient httpClient;

        public AppPredifyBearerAuthenticationHandler(IOptionsMonitor<AuthenticationSchemeOptions> options, ILoggerFactory logger,
                                        UrlEncoder encoder, ISystemClock clock,
                                        HttpClient httpClient, IOptions<AppsettingsOptions> appsettings)
            : base(options, logger, encoder, clock)
        {
            this.appsettings = appsettings.Value;
            this.httpClient = httpClient;
        }
        public static string AuthenticationScheme => "Bearer";
        protected override async Task<AuthenticateResult> HandleAuthenticateAsync()
        {
            var userInformation = await GetUserInformationAsync(Request.Headers["Authorization"]);
            if (userInformation == null)
            {
                return AuthenticateResult.Fail("Invalid token");
            }
            var token = Request.Headers["Authorization"].ToString().Split(" ")[1];

            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, userInformation.nome),
                new Claim(ClaimTypes.Email, userInformation.email),
                new Claim(ClaimTypes.NameIdentifier, userInformation.idUsuario),
                new Claim("predifyAdmin", userInformation.predifyAdmin.ToString()),
                new Claim("lang", userInformation.lang),
                new Claim("addCompany", userInformation.addCompany.ToString()),
                new Claim("isProprietario", userInformation.isProprietario.ToString()),
                new Claim("adminRoles", Newtonsoft.Json.JsonConvert.SerializeObject(userInformation.adminRoles)),
                new Claim("access_token",token)
            };

            var identity = new ClaimsIdentity(claims, AuthenticationScheme);
            var principal = new ClaimsPrincipal(identity);
            var ticket = new AuthenticationTicket(principal, Scheme.Name);

            return AuthenticateResult.Success(ticket);
        }


        private async Task<UserInformationResponse> GetUserInformationAsync(string token)
        {
            if (string.IsNullOrEmpty(token))
            {
                return null;
            }
            httpClient.DefaultRequestHeaders.Add("Authorization", token);
            var response = await httpClient.GetAsync($"{appsettings.Auth.Host}/api/Usuario/GetUsuario");
            var content = await response.Content.ReadAsStringAsync();
            if (!response.IsSuccessStatusCode)
            {
                return null;
            }
            var userInformation = Newtonsoft.Json.JsonConvert.DeserializeObject<UserInformationResponse>(content);
            return userInformation;
        }
    }

}
