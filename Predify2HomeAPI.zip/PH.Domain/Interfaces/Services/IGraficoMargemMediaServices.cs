﻿using PH.Domain.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PH.Domain.Interfaces.Services
{
    public interface IGraficoMargemMediaServices
    {
        Task<List<GraficoMargemMediaDTO>> GetGraficoMargem(string loja);
    }
}
