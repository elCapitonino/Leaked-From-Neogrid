import threading
import time
from norm.conect_mongo import MongoConnect
from norm.memorycache import MemoryCache


class Load_normalized(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)
        self.dbMongo = MongoConnect()
        self.memory = MemoryCache()
        print("inicio norlalização -----")

    def products_nomal(self):
        self.products_nomal = self.dbMongo.get_products_normalized()

        self.ProductsNomalized = {}
        for j in self.products_nomal:
            #print(" ----------------------------------- ")
            #print("j : ", j)
            norm_dict = []
            for i in j["data"]:
                #print("i : ", i)
                # product_name = []
                # product_name.append(i["product"])
                norm_dict.append({"_id": i["_id"],
                                  "product": None if "product" not in i else i["product"],
                                  "brands": None if "brands" not in i else i["brands"],
                                  "category": None if "category" not in i else i["category"],
                                  "voltage": None if "voltage" not in i else i["voltage"],
                                  "metric_units": None if "metric_units" not in i else i["metric_units"],
                                  "power": None if "power" not in i else i["power"],
                                  "ean": None if "ean" not in i else i["ean"],
                                  "ncm": None if "ncm" not in i else i["ncm"],
                                  "model": None if "model" not in i else i["model"],
                                  "trash": None if "trash" not in i else i["trash"],
                                  "materials": None if "materials" not in i else i["materials"],
                                  "dimensions": None if "dimensions" not in i else i["dimensions"],
                                  "energy_source": None if "energy_source" not in i else i["energy_source"],
                                  "size": None if "size" not in i else i["size"],
                                  "language": None if "language" not in i else i["language"]})
                #print("i[product] : ", product_name)
                # product_name = []

            self.ProductsNomalized.update({j['_id']: norm_dict})

        #print("ProductsNomalized : ", self.ProductsNomalized['pt-br'])

        # self.ProductsNomalized = []
        # for i in self.products_nomal:
        #     # print(i)

        #     self.ProductsNomalized.append({"_id": i["_id"], "product": i["product"], "brands": i["brands"],
        #                                    "category": i["category"], "materials": i["materials"], "voltage": i["voltage"],
        #                                    "metric_units": i["metric_units"], "power": i["power"], "ean": i["ean"], "ncm": i["ncm"],
        #                                    "model": i["model"], "trash": i["trash"],
        #                                    "dimensions": None if "dimensions" not in i else i["dimensions"],
        #                                    "energy_source": None if "energy_source" not in i else i["energy_source"],
        #                                    "size": None if "size" not in i else i["size"],
        #                                    "language": None if "language" not in i else i["language"]})
        # print(self.ProductsNomalized)
        # # return ProductsNomalized

        self.memory.set_products_nomalized(self.ProductsNomalized)

    def run(self):

        print("Load_normalized running")

        self.products_nomal()

        # print(ProductsNomalized)

        # time.sleep(2)
