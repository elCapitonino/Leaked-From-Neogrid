﻿using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using PH.Domain.DTO;
using PH.Domain.Interfaces.Repositories;
using PH.Domain.Interfaces.Services;

namespace PH.Service.Services
{
    public class OportunitiesServices : IOportunitiesServices
    {
        private readonly ILogger<OportunitiesServices> _logger;
        private readonly IOportunitiesRepository _repository;
        private readonly IMemoryCache _memoryCache;
        private readonly ICacheControlService _cacheControlService;

        public OportunitiesServices(ILogger<OportunitiesServices> logger,
                               IOportunitiesRepository repository,
                               IMemoryCache memoryCache,
                               ICacheControlService cacheControlService)
        {
            _logger = logger;
            _repository = repository;
            _memoryCache = memoryCache;
            _cacheControlService = cacheControlService;
        }

        public async Task<OportunitiesMainDTO> Get(long idCompany, long idPriceGroup)
        {
            _logger.LogInformation("Service: buscando todos os Oportunities");

            try
            {
                return await _repository.Get(idCompany, idPriceGroup);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Service: erro ao buscar todos os Oportunities. {ex.Message}");
                throw;
            }
        }
    }
}
