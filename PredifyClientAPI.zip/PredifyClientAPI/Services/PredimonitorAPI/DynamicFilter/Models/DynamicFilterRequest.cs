﻿using System.ComponentModel;

namespace PredifyClientAPI.Services.PredimonitorAPI.DynamicFilter.Models
{
    public class DynamicFilterRequest
    {
        public List<string> ProductNames { get; set; } = [];
        public List<long> MonitoringItemIds { get; set; } = [];
        public List<string> Categories { get; set; } = [];
        public List<string> Sellers { get; set; } = [];
        public List<string> Brands { get; set; } = [];
        public List<string> Origins { get; set; } = [];
        public List<string> States { get; set; } = [];
        public List<string> Years { get; set; } = [];

        [DefaultValue(false)]
        public bool IsCost { get; set; } = false;
    }
}
