from google.cloud import bigquery
import hashlib
from async_mongo import AsyncMongoConnect
from models.search_v3_models import SearchProductsPredmonitorBM25
from predimonitor_type import *
from logger import logger


class Search_linx():

    def __init__(self):
        print("desabilitado")
        # self.dbMongo = AsyncMongoConnect()
        # self.configFile = './app/sa-prd-pdc-bigquery-reader-01.json'
                        

    def search(self, products: Search_products_predmonitor):
        return []
        ean_where = ""
        state_where = ""

        if (products.filters.eans != None and len(products.filters.eans) != 0):
            for i in products.filters.eans:
                ean_where += "cd_ean = '" + i.ean + "' OR "

            ean_where = ean_where[:-4]

        # data=2022-09-11 23:59:56,

        client = bigquery.Client.from_service_account_json(self.configFile)

        if (ean_where != ""):
            ean_where = "({}) and ".format(ean_where)
        
        if products.filters != None and products.filters.local_states != None and len(products.filters.local_states) > 0: 
            state_where = "cd_state in ("
            for st in products.filters.local_states:
                state_where += "'{}',".format(st)
            state_where = state_where[:-1] + ") AND "

        postal_code = ""
        if products.filters != None and products.filters.postal_code != None and len(products.filters.postal_code) > 0:
            postal_code = "cd_postalcode in ("
            for code in products.filters.postal_code:
                postal_code += "'{}',".format(code)
            postal_code = postal_code[:-1] + ") AND "
        
        print(state_where)
        
        query = """
            SELECT cd_ean
                ,cd_supplier
                ,cd_state
                ,cd_postalcode
                ,Data
                ,AVG(vl_item_price) AS average_price
            FROM (
                SELECT cd_ean
                    ,cd_supplier
                    ,cd_state
                    ,cd_postalcode
                    ,CONCAT(EXTRACT(YEAR FROM id_time),'-', EXTRACT(MONTH FROM id_time),'-', EXTRACT(DAY FROM id_time)) as Data
                    ,vl_item_price
                FROM `shared-data-platform-prd.linx.fact_ticket`
                WHERE {} {} {} id_time >= '{} 00:00:00' and id_time <= '{} 23:59:59') AS T
            GROUP BY cd_ean, cd_supplier, cd_state, cd_postalcode, Data
            ORDER BY cd_ean, Data
            
            """.format(ean_where, state_where, postal_code, products.start_date.strftime("%Y-%m-%d"), products.end_date.strftime("%Y-%m-%d"))

        query_job = client.query(query)  # Make an API request.

        lista_result = []
        for ean in products.filters.eans:
            # print(ean)
            lista_ean = []
            quantidade = 0
            total = 0
            for row in query_job.result():
                if(str(ean.ean) == str(row['cd_ean'])):
                    total += row['average_price']
                    quantidade += 1
                    result_list = {'id': None,
                                   'id_crawler': "0",
                                   "product_name":  ean.description,
                                   "product_ean": row['cd_ean'],
                                   "product_link": str(row['cd_postalcode']) + "_" + row['cd_ean'] + "_" + row['cd_state'],
                                   "site_sku": None,
                                   "source": "physics",
                                   "language": "pt-br",
                                   "product_brand": "Linx" if row['cd_supplier'] is None else row['cd_supplier'],
                                   "id_product_normalized": None,
                                   "trash_score": 0,
                                   "crawler_date": row['Data'],
                                   "seller_name": "Seller" if row['cd_supplier'] is None else row['cd_supplier'],
                                   "prices": [ { "price": row['average_price'],"price_currency":"R$" }],
                                   "product_local": {"state": row['cd_state']} ,
                                   "product_manufacture_year": None,
                                   "product_used_hours": None,
                                   }

                    lista_ean.append(result_list)
            lista_result.append({"product": ean.description, "result": lista_ean})

        return lista_result

    def test_connection(self):
        return []
        client = bigquery.Client.from_service_account_json(self.configFile)

        query = """
                SELECT *
                FROM `shared-data-platform-prd.linx.fact_ticket` LIMIT 10
            """

        query_job = client.query(query)  # Make an API request.

        return list(query_job.result())
        

    def ean_sync(self):
        return []
        controle = True
        offset = 0
        cont = 0

        client = bigquery.Client.from_service_account_json(self.configFile)
        while controle:
            query = """
                select * from (
                    SELECT cd_ean
                        , ds_item
                        , cd_supplier
                        ,row_number() over (partition by cd_ean order by cd_ean) as linha
                    FROM `shared-data-platform-prd.linx.fact_ticket`
                    WHERE ds_item is not null and ds_item != '' and LOWER(TRIM(ds_item)) != 'outro' and LOWER(TRIM(ds_item)) != 'outros'
                        and cd_ean is not null and cd_ean != '' and cd_ean != '0' and length(cd_ean) >= 8
                        and cd_supplier is not null) as T
                WHERE linha = 1
                order by cd_ean asc LIMIT 100 offset {};

                """.format(offset)
            # print(query)

            query_job = client.query(query)  # Make an API request.
            controle = len(list(query_job.result())) > 0
            cont += len(list(query_job.result()))
            #print("Fim --  cont = {}".format(cont))
            if controle == False:
                print("Fim --  cont = {}".format(cont))
                break

            print(len(list(query_job.result())))
            print(list(query_job.result()))
            for row in query_job.result():
                print('cd_ean={}, ds_item={}' .format(
                    row['cd_ean'], row['ds_item'].split("\t")[0]))

                # NOTE se descomentar, a função precisa virar async
                # self.dbMongo.insert_linx_ean(
                #     row['cd_ean'], row['ds_item'].split("\t")[0])

            offset += 100

    #Metodo de inserção de pesquisa e produtos no mongo
    async def sent_memory_cache(self, request, products):
        return None
        #transforma requisição e um sha1
        key = hashlib.sha1(str(request).encode())
        products_list = products

        await self.dbMongo.insert_linx_memory_cache(key.hexdigest(), products_list)
        
        return logger.info(f"Produtos inseridos no cache key: {key.hexdigest()}")
    
    #Metodo de coleta de pesquisa e produtos no mongo
    async def get_itens_memory_cache(self, request):
        return None
        string = str(request)
        #Transforma a requição feita em sha1 para fazer a pesquisa no mongo
        key = hashlib.sha1(string.encode())

        request_memory_cache = await self.dbMongo.get_linx_memory_cache(key.hexdigest())

        return request_memory_cache

    async def search_get_V2_cost(self, products: SearchProductsPredmonitorBM25):
        ean_where = []
        start_date = ""
        end_date = ""
        full_result = []
        result_list = []

        if (products.filters.eans is not None and len(products.filters.eans) != 0):
            for i in products.filters.eans:
                ean_where.append(i.ean)

        if (products.start_date is not None and products.end_date is not None):
            start_date = products.start_date
            end_date = products.end_date

        if (products.filters.eans is not None and len(products.filters.eans) != 0):
            for i in products.filters.eans:
                ean_where.append(i.ean)

        try:
            for ean in ean_where:
                result_list = []
                result_mongo = await self.dbMongo.get_linx_fact_convenience_ticket_sellin(start_date, end_date, ean)

                for documento in result_mongo:
                    item = documento
                    try:
                        name = item['description']
                        result_list.append({
                            'id': str(item['_id']),
                            'id_crawler': 85,
                            "product_name": name,
                            "product_link": item['ean']+item['cnpj'],
                            "product_ean": item['ean'],
                            "site_sku": 0,
                            "source": "Horus",
                            "language": "pt-br",
                            "product_brand": item['brand'],
                            "id_product_normalized": None,
                            "trash_score": 0,
                            "crawler_date": item["date"],
                            "seller_name": item["brand"],
                            "format_market": item.get("format_market"),
                            "coordinates": {
                                "longitude": item['coordinates']['coordinates'][0],
                                "latitude": item['coordinates']['coordinates'][1],
                            } if 'coordinates' in item and 'coordinates' in item['coordinates'] and len(item['coordinates']['coordinates']) == 2 else None,
                            "prices": [
                                {
                                    'price': str(item['price'])
                                }
                            ],
                            "product_local":
                            {
                                'state': item['uf'],
                                'city': item['city']
                            },
                            "product_manufacture_year": None,
                            "product_used_hours": None
                        })
                        
                    except Exception as ex:
                        print(" ------ Erro dados Horus  ------")
                        print(str(ex))

                full_result.append({
                    "product": ean,
                    "result": result_list
                })

        except Exception as ex:
            print(" ------ Erro dados Horus  ------")
            print(str(ex))

        return full_result


