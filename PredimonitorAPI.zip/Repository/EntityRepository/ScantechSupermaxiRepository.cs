﻿using Microsoft.EntityFrameworkCore;
using Repository.DbContexts;
using Repository.Entity;
using Repository.EntityRepository.Bases;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.EntityRepository
{
    public class ScantechSupermaxiRepository : GenericMongoRepository<ScantechSupermaxiEntity>, IScantechSupermaxiRepository
    {
        public ScantechSupermaxiRepository(ScantechSupermaxiDbContext dbContext) : base(dbContext)
        {
        }
        public static string DbContextName => nameof(ScantechSupermaxiDbContext);
    }
}
