﻿using DI.Repository.Attributes;
using DI.Repository.Contexts;
using DI.Repository.Entities;
using DI.Repository.Enum;
using DI.Repository.Interfaces.Repositories;
using DI.Repository.Repositories.Base;
using Microsoft.EntityFrameworkCore;

namespace DI.Repository.Repositories
{
    [UsePostgreContext]
    public sealed class MonthlySaleHistoryDataRepository : PostgreGenericNoModifyRepository<MonthlySaleHistoryDataEntity>, IMonthlySaleHistoryDataRepository
    {
        public MonthlySaleHistoryDataRepository(PostgreContext dbContext) : base(dbContext)
        {
        }

        public IEnumerable<MonthlySaleHistoryDataEntity> GetAll(long CompanyId, int startYearMonth, int endYearMonth, EGranularityType eGranularityType)
        {
            return _dbContext
                .Set<MonthlySaleHistoryDataEntity>()
                .Where(x => x.CompanyId == CompanyId && x.YearMonth >= startYearMonth && x.YearMonth <= endYearMonth && x.GranularityGroup!.GranularityType == eGranularityType);
        }

        public IEnumerable<MonthlySaleHistoryDataEntity> GetAll(long CompanyId, EGranularityType eGranularityType)
        {
            return _dbContext
                .Set<MonthlySaleHistoryDataEntity>()
                .Where(x => x.CompanyId == CompanyId && x.GranularityGroup!.GranularityType == eGranularityType);
        }

        public async Task<int> GetCountSkus(long CompanyId, EGranularityType granularityType, IEnumerable<string> majorGranularityFilter, CancellationToken cancellationToken)
        {
            return await _dbContext
                .Set<MonthlySaleHistoryDataEntity>()
                .AsNoTracking()
                .Where(x => x.CompanyId == CompanyId
                    && x.GranularityGroup!.GranularityType == granularityType
                    && majorGranularityFilter.Contains(x.MajorGranularity))
                .Select(x => x.ProductId)
                .Distinct()
                .CountAsync(cancellationToken);
        }

        public async Task<int> GetCountSkus(long CompanyId, EGranularityType granularityType, CancellationToken cancellationToken)
        {
            return await _dbContext
                .Set<MonthlySaleHistoryDataEntity>()
                .AsNoTracking()
                .Where(x => x.CompanyId == CompanyId
                    && x.GranularityGroup!.GranularityType == granularityType)
                .Select(x => x.ProductId)
                .Distinct()
                .CountAsync(cancellationToken);
        }

    }
}
