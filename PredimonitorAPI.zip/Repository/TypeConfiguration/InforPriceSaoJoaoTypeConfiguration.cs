﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using MongoDB.EntityFrameworkCore.Extensions;
using Repository.Attributes;
using Repository.DbContexts;
using Repository.Entity;

namespace Repository.TypeConfiguration
{
    [DbContextTypeConfiguration(typeof(InfoPriceSaoJoaoDbContext))]
    public class InfroPriceSaoJoaoTypeConfiguration : TypeConfigurationBase<InfoPriceSaoJoaoEntity>, IEntityTypeConfiguration<InfoPriceSaoJoaoEntity>
    {
        public override void Configure(EntityTypeBuilder<InfoPriceSaoJoaoEntity> builder)
        {
            builder.ToTable("FarmaciaSaoJoao").ToCollection("FarmaciaSaoJoao");
        }
    }
}
