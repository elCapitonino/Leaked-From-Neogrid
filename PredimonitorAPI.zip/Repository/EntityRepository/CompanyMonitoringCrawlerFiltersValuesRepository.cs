﻿using Repository.DbContexts;
using Repository.Entity;
using Repository.EntityRepository.Bases;

namespace Repository.EntityRepository
{
    public class CompanyMonitoringCrawlerFiltersValuesRepository : GenericRepository<CompanyMonitoringCrawlerFiltersValuesEntity, long>, ICompanyMonitoringCrawlerFiltersValuesRepository
    {
        public CompanyMonitoringCrawlerFiltersValuesRepository(ApplicationDbContext dbContext) : base(dbContext)
        {
        }
        public static string DbContextName => nameof(ApplicationDbContext);
    }
}
