# Relatório do Cenário de Precificação

Trata-se basicamente de baixar o relatório de precificação disponível no cenário de precificação e aplicar algumas mudanças de filtros ou cosméticas.

Desenvolvido para que os usuários da VEM (3026) não precisem entrar na plataforma para poder acessar os preços.

## Como gerar

A partir de um arquivo CSV contendo uma ou mais filiais, rode o script main:

```bash
python main_vem.py --csv <CSV_FILE> --affiliate-info <AFFILIATE_INFO_FILE>
```

Opcionalmente, pode-se passar um JSON com produtos selecionados por filial gerados pelo script `activity_level/vem_get_top_products.py` deste repositório.

O arquivo CSV é gerado rodando o _backend_ localmente a partir de uma lista de `IdEnterprisePriceGroups`.
