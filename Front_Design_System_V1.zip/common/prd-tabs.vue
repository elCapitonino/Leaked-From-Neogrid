<template>
    <div>
    <v-tabs class="ml-n3" 
        height="25px" 
        v-bind="$attrs" 
        v-on="$listeners"  
        :value="value"
        @change="(v)=>$emit('input',v)">
        
        <slot name="slider">
        </slot>

        <v-tab v-for="(tab,index) in tabs" :key="index">
            {{ $t(tab.title) }}
            <prd-tooltip :text="tab.tooltipText" v-if="tab.tooltipText"></prd-tooltip>
        </v-tab>

    </v-tabs>

    <v-tabs-items :value="value">
            <v-tab-item
                v-for="(item,index) in tabs"
                :key="item"
            >
                TAB: {{ index }}
            </v-tab-item>
    </v-tabs-items>
</div>
</template>

<script>

import prdTooltip from "./prd-tooltip.vue"

export default {
    components:{
        prdTooltip
    },
    name: "PredifyTabs",
    data(){
        return {
        }
    },
    props:{
        value: Number,
        tabs: []
    }

}
</script>
