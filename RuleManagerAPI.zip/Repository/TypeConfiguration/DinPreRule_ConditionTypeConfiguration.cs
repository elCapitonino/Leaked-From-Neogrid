﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Repository.Entity;

namespace Repository.TypeConfiguration
{
    public sealed class DinPreRule_ConditionTypeConfiguration : TypeConfigurationBase<DinPreRule_ConditionEntity>, IEntityTypeConfiguration<DinPreRule_ConditionEntity>
    {
        public override void Configure(EntityTypeBuilder<DinPreRule_ConditionEntity> builder)
        {
            ConfigureTableName(builder, "DinPreRule_Condition");
            builder.ToTable("DinPreRule_Condition", table => table.ExcludeFromMigrations());
            builder.Ignore(x => x.Id);
            builder.HasKey(x => x.ConditionId);
            builder.Property(x => x.ConditionId).HasColumnName("IdCondition");
            builder.Property(x => x.CreatedDate).HasColumnName("DataHoraCriacao");
            builder.Property(x => x.UpdatedDate).HasColumnName("DataHoraUltimaAlteracao");

            builder.HasOne(x => x.Rule).WithMany(x => x.Conditions).HasForeignKey(x => x.IdRule);
        }
    }
}
