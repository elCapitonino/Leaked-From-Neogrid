﻿using DI.Domain.Models.ImpactReport;

namespace DI.Domain.ImpactReport
{
    public interface IImpactReportDomain
    {
        MemoryStream GenerateRawImpactReport(long companyId, List<long> priceGroupIds, string userId);
        Task<MemoryStream> GenerateConsolidatedReport(ImpactConsolidatedRequestModel request, CancellationToken cancellationToken, string userId);
    }
}
