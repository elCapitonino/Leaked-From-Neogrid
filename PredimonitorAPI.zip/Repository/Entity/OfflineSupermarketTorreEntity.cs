﻿using MongoDB.Bson.Serialization.Attributes;

namespace Repository.Entity
{
    public class OfflineSupermarketTorreEntity : BaseMongoEntity
    {
        [BsonElement("item")]
        public string Item { get; set; }
        [BsonElement("ean")]
        public string EAN { get; set; }
        [BsonElement("nome_do_produto")]
        public string ProductName { get; set; }
        [BsonElement("preco_unitario")]
        public decimal UnitPrice { get; set; }
        [BsonElement("data")]
        public DateTime Date { get; set; }
        [BsonElement("segmento")]
        public string? Segment { get; set; }
        [BsonElement("nome_do_concorrente")]
        public string? SellerName { get; set; }
        [BsonElement("bairro")]
        public string? Neighborhood { get; set; }
        [BsonElement("cidade")]
        public string? City { get; set; }
        [BsonElement("estado")]
        public string? State { get; set; }
        [BsonElement("hash")]
        public string Hash { get; set; }
        [BsonElement("coordinates")]
        public GeoJson2DGeographicCoordinatesWrapper? Coordinates { get; set; }
    }
}
