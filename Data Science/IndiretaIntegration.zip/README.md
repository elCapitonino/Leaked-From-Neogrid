# Introduction 
Integração dos dados concorrentes da indireta
Os arquivos .txt vindos via email atualmente neste commit(27/05/2024) são os atuais dados a serem importados ao mongo para uso no monitoramento

# Getting Started
Arquivo .txt para a importação

O usuario mongo tem que ter acesso de escrita as database 'neogrid' e a collection 'indireta'

# Build and Test
pip install -r requirements.txt
python main.py
