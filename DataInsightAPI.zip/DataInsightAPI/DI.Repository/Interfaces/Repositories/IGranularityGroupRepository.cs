﻿using DI.Repository.Entities;

namespace DI.Repository.Interfaces.Repositories
{
    public interface IGranularityGroupRepository
    {
        IQueryable<GranularityGroupEntity> GetByCompanyId(long CompanyId);
    }
}