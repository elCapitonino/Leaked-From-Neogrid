﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DI.Repository.Migrations.PostgreMigrations
{
    /// <inheritdoc />
    public partial class ChangeAffiliateToConsolidateGroupBy : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Affiliate",
                table: "MonthlySaleHistoryData",
                newName: "MajorGranularity");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "MajorGranularity",
                table: "MonthlySaleHistoryData",
                newName: "Affiliate");
        }
    }
}
