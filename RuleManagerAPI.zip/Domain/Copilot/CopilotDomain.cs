﻿using Domain.Models;
using Domain.Utils;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Repository.Enums;
using Services.AzureDevops;
using Services.AzureDevops.Models;
using Services.Copilot;
using Services.PredifyAPI;

namespace Domain.Copilot
{
    public class CopilotDomain : ICopilotDomain
    {
        private readonly ILogger<CopilotDomain> logger;
        private readonly IConfiguration configuration;
        private readonly CopilotService copilot;
        private readonly AzureDevopsService azureDevops;
        private readonly PredifyAPIUserManager apiAsUser;

        public CopilotDomain(ILogger<CopilotDomain> logger, IConfiguration configuration, CopilotService copilot, AzureDevopsService azureDevops, PredifyAPIUserManager apiAsUser)
        {
            this.logger = logger;
            this.configuration = configuration;
            this.copilot = copilot;
            this.azureDevops = azureDevops;
            this.apiAsUser = apiAsUser;
        }

        public void SetToken(string token)
        {
            apiAsUser.SetAuthorization(token);
        }

        public async Task<string> SendMessageAsync(int companyId, string message)
        {
            if(!await apiAsUser.AccessService.UserHasAccess(companyId))
                throw new UnauthorizedAccessException($"Acesso não autorizado a empresa {companyId}");

            string? copilotStringResponse = null;
            try
            {
                copilotStringResponse = await copilot.GenerateRulesWithText(companyId, message);

                var copilotResponse = Newtonsoft.Json.JsonConvert.DeserializeObject<List<CopilotAPIResponse>>(copilotStringResponse);

                var response = new CopilotFrontResponse()
                {
                    Input = message,
                    Output = copilotResponse?.Select(x => x.Response),
                    Operations = copilotResponse?.Select(action => new CopilotOperationFront()
                    {
                        Output = action.Response,
                        OperationType = (ECopilotOperation)action.ActionId,
                        Error = !string.IsNullOrWhiteSpace(action.Error),
                        ErrorMessage = action.Response,
                        RuleGroup = new CopilotOperationRuleGroupFront()
                        {
                            AllowAbcCurve = action.AbcCurve,
                            Description = action.GroupName,
                            Elasticity = action.Elasticity == null ? null : (EElasticityFilter?)action.Elasticity,
                            Id = action.GroupId,
                            Filters = action.Filters?.Select(filter => new CopilotOperationRuleGroupFilterFront()
                            {
                                Id = filter.Id,
                                Description = filter.Description,
                                Value = filter.Value,
                            }),
                            Rules = action.Rules?.Select(rule => new CopilotOperationRuleGroupRuleFront()
                            {
                                Id = rule.RuleId,
                                Type = (ERuleType)rule.ConditionType!,
                                Values = rule.Parameters.GenerateParameters(),
                            })
                        }
                    }),
                };
                return Newtonsoft.Json.JsonConvert.SerializeObject(response);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);

                string errorMessage = "Ocorreu um erro, nossos técnicos foram notificados.";

                var response = new CopilotFrontResponse()
                {
                    Input = errorMessage,
                    Output = [errorMessage],
                    CopilotAPIResponse = copilotStringResponse,
                    Operations = [new CopilotOperationFront()
                    {
                        Output = errorMessage,
                        OperationType = ECopilotOperation.Error,
                        Error = true,
                        ErrorMessage = ex.Message,
                        RuleGroup = null,
                    }],
                };

                return Newtonsoft.Json.JsonConvert.SerializeObject(response);
            }
            
        }

        public async Task<List<GetAvailablePromptsResponse>> GetAvailablePrompts()
        {
            var _params = new AzureDevopsGetItemParams();
            configuration.GetSection("Services:AzureDevops:PromptsItem").Bind(_params);
            var json = await azureDevops.GetJson(_params);

            var entities = JsonConvert.DeserializeObject<List<GetAvailablePromptsResponse>>(json);
            if (entities is null)
            {
                throw new FormatException("Failed to parse JSON: could not parse to entity.");
            }
            return entities;
        }
    }
}
