"""
Módulo para conectar e realizar queries com o MongoDB.
"""

from typing import Sequence
from datetime import datetime, date
from typing import List

from pymongo import ASCENDING, DESCENDING
from motor.motor_asyncio import AsyncIOMotorClient

from config import *
from logger import logger


CLIENT = None


def reset_mongo_connection():
    """Reset async Mongo connection."""
    global CLIENT
    logger.debug(Server)
    CLIENT = AsyncIOMotorClient(
        Server["host"], username=Server["user"], password=Server["password"], authMechanism="DEFAULT"
    )


def gather_async_cursor(function):
    """Decorator to gather an async mongo cursor."""

    async def gather(*args, **kwargs):
        cursor = function(*args, **kwargs)
        result = []
        async for doc in cursor:
            result.append(doc)
        return result

    return gather


class AsyncMongoConnect:
    def __init__(self):
        try:
            if CLIENT is None:
                reset_mongo_connection()

            self.client = CLIENT
            self.database_normalizer = self.client["normalizer"]
            self.database_dictionary = self.client["dictionary"]
            self.database_europe = self.client["europe"]
            self.database_test_normalizer = self.client["test_normalizer"]
            logger.debug(" ------ mongo iniciado  ------ ")
        except Exception as ex:
            logger.error(" ------ mongo não iniciado  ------ ")
            logger.error(ex)

    @gather_async_cursor
    def get_products_general(self, j, start_date, end_date, idcrawlers_busca):
        result = self.database_normalizer.product_prices.aggregate(
            [
                {
                    "$match": {
                        "id_product_normalized": j,
                        "crawler_date": {"$gte": start_date, "$lt": end_date},
                        "id_crawler": {"$in": idcrawlers_busca},
                    }
                },
                {"$sort": {"crawler_date": -1}},
                {"$group": {"_id": "$product_link", "data": {"$first": "$$ROOT"}}},
                {"$replaceRoot": {"newRoot": "$data"}},
            ]
        )
        return result

    @gather_async_cursor
    def get_products_pred_monitor_horus(self, city_off, state_off, network_off, cnpj_off, start_date, end_date, ean):
        dic = {}
        if ean != None or ean != "":
            dic.update({"ean": ean})
        if state_off != None:
            dic.update({"uf": {"$regex": state_off, "$options": "i"}})
        if city_off != None:
            dic.update({"city": {"$regex": city_off, "$options": "i"}})
        if network_off != None:
            dic.update({"brand": {"$regex": network_off, "$options": "i"}})
        if cnpj_off != None:
            dic.update({"cnpj": cnpj_off})

        dic.update({"date": {"$gte": start_date, "$lt": end_date}})

        result_horus = self.client.horus.products.find(dic)
        return result_horus

    @gather_async_cursor
    def get_products_horus_market_inteligence_by_ean(self, start_date, end_date, ean, cnpjs):
        pipeline = [
            {
                '$match': {
                    'ean': ean,
                    'date': {
                        '$gte': start_date,
                        '$lt': end_date
                    },
                }
            },
            {
                '$sort': {
                    'date': -1
                }
            },
            {
                '$group': {
                    '_id': {
                        'ean': '$ean',
                        'cnpj': '$cnpj'
                    },
                    'documento': {
                        '$first': '$$ROOT'
                    }
                }
            }
        ]

        if cnpjs is not None and len(cnpjs) > 0:
            pipeline[0]["$match"]["cnpj"] = {"$in": cnpjs}

        # print(pipeline)
        result_horus = self.client.horus.products.aggregate(
            pipeline
        )

        return result_horus

    @gather_async_cursor
    def get_products_horus_v2_by_ean(self, start_date, end_date, ean, cnpjs, brands, categories, sellers):
        pipeline = [
            {
                '$match': {
                    'ean': ean,
                    'date': {
                        '$gte': start_date,
                        '$lt': end_date
                    },
                }
            }
        ]

        if cnpjs is not None and len(cnpjs) > 0:
            pipeline[0]["$match"]["cnpj"] = {"$in": cnpjs}

        if brands is not None and len(brands) > 0:
            pipeline[0]["$match"]["brand"] = {"$in": brands}
            
        if categories is not None and len(categories) > 0:
            pipeline[0]["$match"]["category"] = {"$in": categories}
            
        if sellers is not None and len(sellers) > 0:
            pipeline[0]["$match"]["sellers.seller_name"] = {"$in": sellers}

        result_horus = self.client.horus.products.aggregate(
            pipeline
        )

        return result_horus
    
    @gather_async_cursor
    def get_products_horus_v2_cost_by_ean(self, start_date, end_date, ean, cnpjs, brands, categories, sellers):
        pipeline = [
            {
                '$match': {
                    'ean': ean,
                    'date': {
                        '$gte': start_date,
                        '$lt': end_date
                    },
                    'format_market': 'Atacadista'
                }
            }
        ]

        if cnpjs is not None and len(cnpjs) > 0:
            pipeline[0]["$match"]["cnpj"] = {"$in": cnpjs}

        if brands is not None and len(brands) > 0:
            pipeline[0]["$match"]["brand"] = {"$in": brands}
            
        if categories is not None and len(categories) > 0:
            pipeline[0]["$match"]["category"] = {"$in": categories}
            
        if sellers is not None and len(sellers) > 0:
            pipeline[0]["$match"]["sellers.seller_name"] = {"$in": sellers}

        result_horus = self.client.horus.products.aggregate(
            pipeline
        )

        return result_horus

    @gather_async_cursor
    def get_product_search_neogrid_ecoa_by_date(self, start_date, end_date, ean):
        result_neogrid = self.client.neogrid.ecoa_database.aggregate(
            [
                {"$match": {"product_ean": ean, "crawler_date": {
                    "$gte": start_date, "$lte": end_date}}},
                {"$sort": {"crawler_date": -1}},
                {"$group": {"_id": "$product_ean", "documento": {"$first": "$$ROOT"}}},
            ]
        )

        return result_neogrid

    @gather_async_cursor
    def get_city_search_by_postal_code(self, postalcode):
        result_city_by_postal_code = self.client.predimonitor.linx_ceps.find(
            {"cep":postalcode}
        )

        return result_city_by_postal_code

    @gather_async_cursor
    def get_product_search_neogrid_ecoa_by_date_v2(self, start_date, end_date, ean):
        result_neogrid = self.client.neogrid.ecoa_database_final.find(
            {"product_ean": ean, "crawler_date": {
                "$gte": start_date, "$lte": end_date}}
        )

        return result_neogrid
    
    @gather_async_cursor
    def get_product_search_neogrid_ecoa_v3_v2(self, start_date, end_date, ean, states):
        
        query = {"product_ean": ean, "crawler_date": {"$gte": start_date, "$lte": end_date}}

        if states is not None and len(states) > 0:
            query["product_local.state"] = {"$in": states}

        result_neogrid = self.client.neogrid.ecoa_database_final.find(query)

        return result_neogrid
    
    @gather_async_cursor
    def get_product_search_neogrid_indireta_v3_v2(self, start_date, end_date, ean, states):
        
        query = {"EAN PRODUTO": ean, "ULTIMA VENDA": {"$gte": start_date, "$lte": end_date}}

        if states is not None and len(states) > 0:
            query["UF2"] = {"$in": states}

        result_neogrid = self.client.neogrid.indireta.find(query)

        return result_neogrid
    
    @gather_async_cursor
    def get_product_search_abv(self, start_date, end_date, ean):
        pipeline = [
            {
                '$match': {
                    'ProdutoEan.EAN': ean,
                    'PesquisaProduto.DT_PESQUISA': {
                        '$gte': start_date,
                        '$lt': end_date
                    },
                }
            },
            {
                '$sort': {
                    'PesquisaProduto.DT_PESQUISA': -1
                }
            },
            {
                '$group': {
                    '_id': {
                        'EAN': '$ProdutoEan.EAN',
                        'SEQCONCORRENTE': '$Concorrente.SEQCONCORRENTE'
                    },
                    'documento': {
                        '$first': '$$ROOT'
                    }
                }
            }
        ]

        result = self.client.smarket_competitor.abv.aggregate(
            pipeline
        )

        return result

    @gather_async_cursor
    def get_product_search_nielsen_vem_by_ean(self, start_date, end_date, ean, states, store_type):
        pipeline = [
            {
                '$match': {
                    'EAN': ean,
                    'DATE': {
                        '$gte': start_date,
                        '$lt': end_date
                    },
                }
            },
            {
                '$sort': {
                    'DATE': -1
                }
            },
            {
                '$group': {
                    '_id': {
                        'EAN': '$EAN',
                        'STATE_UF': '$STATE_UF',
                        'STORE': '$STORE'
                    },
                    'documento': {
                        '$first': '$$ROOT'
                    }
                }
            }
        ]

        if states is not None and len(states) > 0:
            pipeline[0]["$match"]["STATE_UF"] = {"$in": states}
            
        if store_type is not None and len(store_type) > 0:
            pipeline[0]["$match"]["FORMAT_MARKET"] = {"$in": store_type}

        result_nielsen = self.client.nielsen.base_vem.aggregate(
            pipeline
        )

        return result_nielsen

    @gather_async_cursor
    def get_product_search_nielsen_by_ean(self, start_date, end_date, ean, states, stores):
        pipeline = [
            {
                '$match': {
                    'EAN': ean,
                    'DATE': {
                        '$gte': start_date,
                        '$lt': end_date
                    },
                }
            },
            {
                '$sort': {
                    'DATE': -1
                }
            },
            {
                '$group': {
                    '_id': {
                        'EAN': '$EAN',
                        'STATE_UF': '$STATE_UF',
                        'STORE': '$STORE'
                    },
                    'documento': {
                        '$first': '$$ROOT'
                    }
                }
            }
        ]

        if states is not None and len(states) > 0:
            pipeline[0]["$match"]["STATE_UF"] = {"$in": states}
            
        if stores is not None and len(stores) > 0:
            pipeline[0]["$match"]["STORE_ID"] = {"$in": stores}

        # print(pipeline)
        result_nielsen = self.client.nielsen.base_peralta.aggregate(
            pipeline
        )

        return result_nielsen

    @gather_async_cursor
    def get_product_search_abv_v2(self, start_date, end_date, ean, states, brands, categories):

        query = {"ProdutoEan.EAN": ean, "PesquisaProduto.DT_PESQUISA": {"$gte": start_date, "$lte": end_date}}

        if states is not None and len(states) > 0:
            query["Concorrente.ESTADO"] = {"$in": states}

        if brands is not None and len(brands) > 0:
            query["ProdutoDescricao.MARCA"] = {"$in": brands}
            
        if categories is not None and len(categories) > 0:
            query["Categoria.CATEGORIA"] = {"$in": categories}
            
        result = self.client.smarket_competitor.abv.find(query)

        return result

    @gather_async_cursor
    def get_product_search_nielsen_by_ean_v2_vem(self, start_date, end_date, ean, states, store_type, brands, categories, sellers):

        query = {"EAN": ean, "DATE": {"$gte": start_date, "$lte": end_date}}

        if states is not None and len(states) > 0:
            query["STATE_UF"] = {"$in": states}

        if store_type is not None and len(store_type) > 0:
            query["FORMAT_MARKET"] = {"$in": store_type}

        if brands is not None and len(brands) > 0:
            query["BRAND"] = {"$in": brands}
            
        if categories is not None and len(categories) > 0:
            query["CATEGORY"] = {"$in": categories}

        if sellers is not None and len(sellers) > 0:
            query["RETAILER"] = {"$in": sellers}

        result_nielsen = self.client.nielsen.base_vem.find(query)

        return result_nielsen

    @gather_async_cursor
    def get_product_search_nielsen_by_ean_v2(self, start_date, end_date, ean, states, stores, brands, categories, sellers):

        query = {"EAN": ean, "DATE": {"$gte": start_date, "$lte": end_date}}

        if states is not None and len(states) > 0:
            query["STATE_UF"] = {"$in": states}

        if stores is not None and len(stores) > 0:
            query["STORE_ID"] = {"$in": stores}

        if brands is not None and len(brands) > 0:
            query["BRAND"] = {"$in": brands}
            
        if categories is not None and len(categories) > 0:
            query["CATEGORY"] = {"$in": categories}

        if sellers is not None and len(sellers) > 0:
            query["RETAILER"] = {"$in": sellers}
            
        result_nielsen = self.client.nielsen.base_peralta.find(query)

        return result_nielsen
    
    @gather_async_cursor
    def get_product_search_v1_nova_era(self, start_date, end_date, ean):
        pipeline = [
            {
                '$match': {
                    'EAN': ean,
                    'DATA_PESQ': {
                        '$gte': start_date,
                        '$lt': end_date
                    },
                }
            },
            {
                '$sort': {
                    'DATA_PESQ': -1
                }
            },
            {
                '$group': {
                    '_id': {
                        'EAN': '$EAN',
                        'CONCORRENTE': '$CONCORRENTE',
                        'DESC_PRODC': '$DESC_PRODC'
                    },
                    'documento': {
                        '$first': '$$ROOT'
                    }
                }
            }
        ]
        result_mercantil_nova_era = self.client.offline.MercantilNovaEra.aggregate(pipeline)
        return result_mercantil_nova_era

    @gather_async_cursor
    def get_product_search_v2_nova_era(self, start_date, end_date, ean):
        pipeline = [
            {
                '$match': {
                    'EAN': ean,
                    'DATA_PESQ': {
                        '$gte': start_date,
                        '$lt': end_date
                    },
                }
            },
        ]
        result_mercantil_nova_era = self.client.offline.MercantilNovaEra.aggregate(pipeline)
        return result_mercantil_nova_era

    async def get_product_search_smarket_imperatriz(self, code):
        return await self.client.enterprise.imperatriz_brasilatacadista_sales_history.find_one({"seqproduto": code})

    @gather_async_cursor
    def get_concorrente_search_smarket_imperatriz(self, start_date, end_date, code):
        # dic = {}
        # if (code != None or code != ""):
        #     dic.update({'seqproduto': code})

        # dic.update({'dt_pesquisa': {'$gte': start_date, '$lt': end_date}})

        # result_smarket2 = self.client.enterprise.imperatriz_brasilatacadista_concorrentes.find(dic)

        # for result in result_smarket2:
        #     print('1',result)

        result_smarket = self.client.enterprise.imperatriz_brasilatacadista_concorrentes.aggregate(
            [
                {"$match": {"seqproduto": code, "dt_pesquisa": {
                    "$gte": start_date, "$lte": end_date}}},
                {"$sort": {"seqproduto": 1, "dt_pesquisa": -1}},
                {"$group": {"_id": "$seqproduto", "documento": {"$first": "$$ROOT"}}},
            ]
        )

        # print('result_smarket:', result_smarket)
        return result_smarket

    @gather_async_cursor
    def get_products_pred_monitor(self, list_id_normalized, start_date, end_date, idcrawlers_busca):
        result_predmonitor = self.database_normalizer.product_prices.aggregate(
            [
                {
                    "$match": {
                        "id_product_normalized": {"$in": list_id_normalized},
                        "crawler_date": {"$gte": start_date, "$lt": end_date},
                        "id_crawler": {"$in": idcrawlers_busca},
                    }
                }
            ]
        )

        return result_predmonitor

    @gather_async_cursor
    def get_products_pred_monitor_bm25(self, start_date, end_date, idcrawlers_busca, id_company=None, ids_task=None):
        match_query = {"crawler_date": {"$gte": start_date,
                                        "$lt": end_date}, "id_crawler": {"$in": idcrawlers_busca}}
        if id_company is not None:
            match_query["id_company"] = id_company

        if ids_task is not None and len(ids_task) > 0:
            match_query["id_task"] = { "$in": ids_task }

        logger.debug("match query: %s", match_query)
        result_predmonitor = self.database_normalizer.product_prices.aggregate(
            [
                {
                    "$match": match_query,
                },
                {
                    "$group": {
                        "_id": {
                            "product_name": "$product_name",
                            "product_model": "$product_model",
                        },
                        "ids": {"$push": "$_id"},
                    }
                },
            ],
            # TODO encontrar solução melhor para agregação muito grande
            allowDiskUse=True
        )

        return result_predmonitor
    
    @gather_async_cursor
    def get_products_europe_products_bm25(self, start_date, end_date, idcrawlers_busca, id_company=None):
        match_query = {"crawler_date": {"$gte": start_date,
                                        "$lt": end_date}, "id_crawler": {"$in": idcrawlers_busca}}
        if id_company is not None:
            match_query["id_company"] = id_company

        result_europe = self.database_europe.europe_product.aggregate(
            [
                {
                    "$match": match_query,
                },
                {
                    "$group": {
                        "_id": {
                            "product_name": "$product_name",
                            "product_model": "$product_model",
                        },
                        "ids": {"$push": "$_id"},
                    }
                },
            ],
            # TODO encontrar solução melhor para agregação muito grande
            allowDiskUse=True
        )

        return result_europe
    
    @gather_async_cursor
    def get_lidl_addresses(self):

        result_lidl_addresses = self.client.europe.address.find()

        return result_lidl_addresses

    @gather_async_cursor
    def get_products_netshoes(self, start_date, end_date, idcrawlers_busca, id_company=None):
        match_query = {"crawler_date": {"$gte": start_date,
                                        "$lt": end_date}, "id_crawler": {"$in": idcrawlers_busca}}
        if id_company is not None:
            match_query["id_company"] = id_company

        result_predmonitor = self.database_normalizer.products_netshoes.aggregate(
            [
                {
                    "$match": match_query,
                },
                {
                    "$group": {
                        "_id": {
                            "product_name": "$product_name",
                            "product_model": "$product_model",
                        },
                        "ids": {"$push": "$_id"},
                    }
                },
            ],
            # TODO encontrar solução melhor para agregação muito grande
            allowDiskUse=True
        )

        return result_predmonitor

    @gather_async_cursor
    def get_products_by_monitoring_id(
        self,
        start_date,
        end_date,
        idcrawlers_busca,
        monitoring_ids: Sequence[str],
        id_company=None,
        ids_task=None,
    ):
        match_query = {
            "crawler_date": {"$gte": start_date, "$lt": end_date},
            "id_crawler": {"$in": idcrawlers_busca},
        }
        if len(monitoring_ids) == 1:
            match_query["id_monitoring_item"] = monitoring_ids[0]
        else:
            match_query["id_monitoring_item"] = {"$in": monitoring_ids}

        if id_company is not None:
            match_query["id_company"] = id_company

        if ids_task is not None and len(ids_task) > 0:
            match_query["id_task"] = { "$in": ids_task }

        logger.debug("match query: %s", match_query)
        result_predmonitor = self.database_normalizer.product_prices.aggregate(
            [
                {
                    "$match": match_query,
                },
                {
                    "$group": {
                        "_id": {
                            "product_name": "$product_name",
                            "product_model": "$product_model",
                        },
                        "ids": {"$push": "$_id"},
                    }
                },
            ],
            # TODO encontrar solução melhor para agregação muito grande
            allowDiskUse=True
        )

        return result_predmonitor

    @gather_async_cursor
    def get_selected_products_netshoes(self, ids):
        selected_products = self.database_normalizer.products_netshoes.find({
                                                                            "_id": {"$in": ids}})
        return selected_products

    @gather_async_cursor
    def get_selected_products_pred_monitor(self, ids):
        selected_products = self.database_normalizer.product_prices.find(
            {"_id": {"$in": ids}})
        return selected_products
    
    @gather_async_cursor
    def get_selected_products_europe_products(self, ids):
        selected_products = self.client.europe.europe_product.find( 
            {"_id": {"$in": ids}})
        return selected_products

    async def log_search(self, name_product, time_search, time_mongo, time_request, end_point):
        dados = {
            "end_point": end_point,
            "name_product": name_product,
            "time_search": time_search,
            "time_mongo": time_mongo,
            "time_request": time_request,
            "data_time": datetime.now(),
        }
        await self.client.log.log_products_search.insert_one(dados)

    @gather_async_cursor
    def get_produto_internal(self, j, start_date, end_date, idcrawlers_busca):
        result = self.database_normalizer.product_prices.find(
            {"$and": [{"crawler_date": {"$gte": start_date, "$lt": end_date}}, {
                "id_product_normalized": j}]}
        )

        return result

    async def get_categories(self, language):
        categories = []
        async for r in self.database_dictionary.dict_categories.find({"language": language}):
            categories.append(
                {"category": r["name"], "products": r["products"]})

        return categories

    async def get_brands(self, language):
        brands = []
        async for r in self.database_dictionary.dict_brands.find({"language": language}):
            brands.append({"name": r["name"]})

        return brands

    async def insert_linx_ean(self, ean, product, supplier):
        logger.info("insert_linx_ean %s product %s", ean, product)
        # self.client.offline.ean.insert_one({'ean': ean, 'product': product})
        await self.client.offline.eans.insert_one({"ean": ean, "product": product, "supplier": supplier})

    async def insert_linx_memory_cache(self, key, products_list):
        logger.info(f"insert_linx_memory_cache key: {key}")
        await self.client.predimonitor.memory_cache.insert_one({"date": datetime.now(), "key": key, "product_list": products_list})

    async def get_linx_memory_cache(self, key): 
        logger.info(f"get_linx_memory_cache key: {key}")
        query = {"key": key}
        result_cache = await self.client.predimonitor.memory_cache.find_one(query)
        return result_cache

    async def get_linx_ean_lastUpdate(self):
        resultMongo = await self.client.offline.lastUpdate.find_one()
        return resultMongo["ultmadatasync"]

    async def get_linx_ean(self, ean):
        n_documents = await self.client.offline.eans.count_documents({"ean": ean})
        return n_documents

    async def get_linx_products(self, filter):
        result = []
        resultMongo = (
            self.client.offline.ean.find(
                {"$or": [{"ean": {"$regex": "{}".format(filter)}}, {"product": {
                    "$regex": "{}".format(filter)}}]}
            )
            .sort([("product", ASCENDING), ("ean", DESCENDING)])
            .limit(10)
        )
        async for r in resultMongo:
            result.append({"ean": r["ean"], "product": r["product"]})
        return result

    @gather_async_cursor
    def load_list_restrictions(self):
        resultMongo = self.database_normalizer.restriction_search.find()
        return resultMongo

    @gather_async_cursor
    def get_list_restrictions(self, id_company, termo_restricao):
        resultMongo = self.database_normalizer.restriction_search.find(
            {"id_company": id_company, "list_restriction": termo_restricao}
        )

        return resultMongo

    async def update_list_restrictions(self, id_company, restriction):
        await self.database_normalizer.restriction_search.update_one(
            {"id_company": id_company}, {
                "$addToSet": {"list_restriction": restriction}}
        )

    @gather_async_cursor
    def load_list_company(self):
        resultMongo = self.database_normalizer.restriction_search_company.find()
        return resultMongo

    @gather_async_cursor
    def get_all_products(self, id_crawler_list, start_date, end_date):
        logger.info("-> get_all_products")
        logger.info("id_crawler_list: %s", id_crawler_list)
        logger.info("start_date: %s", start_date)
        logger.info("end_date: %s", end_date)

        query = {"crawler_date": {"$gte": start_date, "$lt": end_date},
                 "id_crawler": {"$in": id_crawler_list}}

        result = self.database_normalizer.product_prices.find(query)
        return result

    @gather_async_cursor
    def get_all_products_netshoes(self, id_crawler_list, start_date, end_date):
        logger.warning("!!! APENAS PARA NETSHOES !!!")
        logger.info("-> get_all_products")
        logger.info("id_crawler_list: %s", id_crawler_list)
        logger.info("start_date: %s", start_date)
        logger.info("end_date: %s", end_date)

        query = {"crawler_date": {"$gte": start_date, "$lt": end_date},
                 "id_crawler": {"$in": id_crawler_list}}

        result = self.database_normalizer.products_netshoes.find(query)
        return result
    
    @gather_async_cursor
    def search_get_all_by_link(self, product_links, start_date, end_date):
        logger.info("-> get_all_by_link")
        logger.info("product_link: %s", product_links)
        logger.info("start_date: %s", start_date)
        logger.info("end_date: %s", end_date)

        query = {"crawler_date": {"$gte": start_date, "$lte": end_date},
                 "product_link": {"$in": product_links}}
        
        result = self.client.normalizer.product_prices.find(query)
        return result

    @gather_async_cursor
    async def get_linx_fact_convenience_ticket_sellin(self, ean, start_date, end_date):
        query = {"EAN": ean, "DATE": {"$gte": start_date, "$lte": end_date}}

        result = self.client.linx.fact_convenience_ticket_sellin.find(query)

        return result

    @gather_async_cursor
    def get_products_InfoPrice(self, start_date, end_date, ean, cnpjs):
        pipeline = [
            {
                '$match': {
                    'origem_preco': 'Nota Fiscal',
                    'gtin_formated': ean,
                    'data_preco': {
                        '$gte': start_date,
                        '$lt': end_date
                    },
                }
            },
            {
                '$sort': {
                    'data_preco': -1
                }
            },
            {
                '$group': {
                    '_id': {
                        'gtin_formated': '$gtin_formated',
                        'loja': '$loja'
                    }, 
                    'documento': {
                        '$first': '$$ROOT'
                    }
                }
            }
        ]

        if cnpjs is not None and len(cnpjs) > 0:
            pipeline[0]["$match"]["cnpj"] = {"$in": cnpjs}

        # print(pipeline)
        result = self.client.info_price.FarmaciaSaoJoao.aggregate(
            pipeline
        )

        return result
    
    @gather_async_cursor
    def get_products_InfoPrice_v2(self, start_date, end_date, ean, cnpjs, brands, categories, sellers):
        pipeline = [
            {
                '$match': {
                    'gtin_formated': ean,
                    'data_preco': {
                        '$gte': start_date,
                        '$lt': end_date
                    },
                }
            }
        ]

        if cnpjs is not None and len(cnpjs) > 0:
            pipeline[0]["$match"]["cnpj"] = {"$in": cnpjs}

        if brands is not None and len(brands) > 0:
            pipeline[0]["$match"]["rede"] = {"$in": brands}
            
        if categories is not None and len(categories) > 0:
            pipeline[0]["$match"]["category"] = {"$in": categories}
            
        if sellers is not None and len(sellers) > 0:
            pipeline[0]["$match"]["rede"] = {"$in": sellers}

        result_horus = self.client.info_price.FarmaciaSaoJoao.aggregate(
            pipeline
        )

        return result_horus
    
    @gather_async_cursor
    def get_products_linx_sellout_v2(self, start_date, end_date, ean, sellers):
        pipeline = [
                {
                    '$match': {
                        'cd_ean': ean,
                        'id_time': {
                            '$gte': start_date,
                            '$lt': end_date
                        },
                        'cd_cnae': {
                            '$in': [
                                '4644301','4645101','4645103','4646001',
                                '4646002','4711302','4712100','4761003',
                                '4763602','4771701','4771702','4771703',
                                '4772500','4773300','4781400','4785799',
                                '9602501','9602502','9609208'
                            ]
                        }
                    }
                }
            ]
        
        if sellers is not None and len(sellers) > 0:
            pipeline[0]["$match"]["cd_supplier"] = {"$in": sellers}

        result_horus = self.client.linx.fact_ticket.aggregate(
            pipeline
        )

        return result_horus

    @gather_async_cursor
    def get_products_v1_linx_sellout(self, start_date, end_date, ean):
        pipeline = [
            {
                '$match': {
                    'cd_ean': ean,
                    'id_time': {
                        '$gte': start_date,
                        '$lt': end_date
                    },
                    'cd_cnae': {
                        '$in': [
                            '4644301','4645101','4645103','4646001',
                            '4646002','4711302','4712100','4761003',
                            '4763602','4771701','4771702','4771703',
                            '4772500','4773300','4781400','4785799',
                            '9602501','9602502','9609208'
                        ]
                    }
                }
            },
            {
                '$sort': {
                    'id_time': -1
                }
            },
            {
                '$group': {
                    '_id': {
                        'cd_ean': '$cd_ean',
                        'cd_postalcode': '$cd_postalcode'
                    }, 
                    'documento': {
                        '$first': '$$ROOT'
                    }
                }
            }
        ]
        
        result = self.client.linx.fact_ticket.aggregate(
            pipeline
        )

        return result

    @gather_async_cursor
    def get_documents_search_v4(
        self,
        start_date: date,
        end_date: date,
        id_crawlers: List[int],
        id_company: int,
    ):
        start_datetime = datetime.combine(start_date, datetime.min.time())
        end_datetime = datetime.combine(end_date, datetime.min.time())
        match_query = {
            "crawler_date": {"$gte": start_datetime, "$lt": end_datetime},
            "id_crawler": {"$in": id_crawlers},
            "id_company": id_company,
        }

        logger.debug("match query: %s", match_query)
        result = self.database_normalizer.product_prices.find(
            match_query,
            {
                "product_name": 1,
                "product_link": 1,
                "product_brand": 1,
                "id_monitoring_item": 1,
                "id_crawler": 1,
                "product_category": 1,
                "sellers.seller_name": 1,
                "sellers.state_uf": 1,
                "product_local.state": 1,
                "product_vehicle_year_model": 1,
                "product_model": 1,
            }
        )
        return result

    @gather_async_cursor
    def get_documents_search_v4_task(
        self,
        task_ids: List[str],
    ):
        match_query = {"id_task": { "$in": task_ids }}

        logger.debug("match query: %s", match_query)
        result = self.database_normalizer.product_prices.find(
            match_query,
            {
                "product_name": 1,
                "product_model": 1,
                "product_link": 1,
                "product_brand": 1,
                "id_monitoring_item": 1,
                "id_crawler": 1,
                "product_category": 1,
                "sellers.seller_name": 1,
                "sellers.state_uf": 1,
                "product_local.state": 1,
                "product_vehicle_year_model": 1,
                "trash": 1,
                "product_ean": 1,
                "product_description": 1,
                "site_sku": 1,
            }
        )
        return result
