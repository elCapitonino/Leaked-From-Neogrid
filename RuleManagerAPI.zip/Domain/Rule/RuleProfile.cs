﻿using AutoMapper;
using Domain.Models;
using Repository.Entity;

namespace Domain.Rule
{
    public class RuleProfile : Profile
    {
        public RuleProfile()
        {
            CreateMap<DinPreRule_ConditionEntity, RuleResponse>();
            CreateMap<DinPreRule_Cond_ValueEntity, RuleValueResponse>();
        }
    }
}
