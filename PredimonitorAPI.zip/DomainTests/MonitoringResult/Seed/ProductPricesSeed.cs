﻿using MongoDB.Bson;
using Repository.Entity;
using Repository.Entity.ProductPrices;

namespace DomainTests.MonitoringResult.Seed
{
    public class ProductPricesSeed
    {
        public static List<ProductPricesEntity> GetTestData() => new List<ProductPricesEntity>()
        {
            new ProductPricesEntity
            {
                Id = ObjectId.Parse("66c135b2783059672396fde5"),
                IdTask = "7298bdd6-e82c-41c5-8528-9ecdd7638bc5",
                IdCrawler = 294,
                CrawlerDate = DateTime.Parse("2024-08-17T23:43:45.828Z"),
                ProductName = "COLETE PARA SINALIZACAO BRASCAMP 1 BOLSO AMARELO FLUORESCENTE G",
                ProductLink = "https://www.feraatacado.com/DetalhesItem.aspx?p=109387-COLETE-PARA-SINALIZACAO-BRASCAMP-1-BOLSO-AMARELO-FLUORESCENTE-G",
                ProductEAN = "7898623819450",
                ProductNCM = "61143000",
                Source = "online",
                IdMonitoringItem = 671935,
                Language = "pt-br",
                IdCompany = 2617,
                Sellers = new List<ProductPricesSeller>
                {
                    new ProductPricesSeller {
                    SellerName = "Fera Atacado",
                    SellerLink = "https://www.feraatacado.com/",
                    Prices = new List<ProductPricesSellerPrice> {
                        new ProductPricesSellerPrice {
                        Price = 21.290m,
                        PriceUnitType = 0,
                        PriceCurrency = "R$"
                    }
                    }
                }
                }
            }, new ProductPricesEntity
            {
                Id = ObjectId.Parse("66c135b2783059672396fde4"),
                IdTask = "7298bdd6-e82c-41c5-8528-9ecdd7638bc5",
                IdCrawler = 294,
                CrawlerDate = DateTime.Parse("2024-08-17T23:43:45.510Z"),
                ProductName = "COLETE PARA SINALIZACAO BRASCAMP 1 BOLSO AMARELO FLUORESCENTE  M",
                ProductLink = "https://www.feraatacado.com/DetalhesItem.aspx?p=109386-COLETE-PARA-SINALIZACAO-BRASCAMP-1-BOLSO-AMARELO-FLUORESCENTE--M",
                ProductEAN = "7898623819443",
                ProductNCM = "61143000",
                Source = "online",
                IdMonitoringItem = 671935,
                Language = "pt-br",
                IdCompany = 2617,
                Sellers = new List<ProductPricesSeller>
                {
                    new ProductPricesSeller {
                    SellerName = "Fera Atacado",
                    SellerLink = "https://www.feraatacado.com/",
                    Prices = new List<ProductPricesSellerPrice> {
                        new ProductPricesSellerPrice {
                        Price = 21.290m,
                        PriceUnitType = 0,
                        PriceCurrency = "R$"
                    }
                    }
                }
                }
            }, new ProductPricesEntity
            {
                Id = ObjectId.Parse("66c135b2783059672396fde3"),
                IdTask = "7298bdd6-e82c-41c5-8528-9ecdd7638bc5",
                IdCrawler = 294,
                CrawlerDate = DateTime.Parse("2024-08-17T23:43:45.202Z"),
                ProductName = "COLETE PARA FERRAMENTA BRASFORT COM 10 BOLSOS 567",
                ProductLink = "https://www.feraatacado.com/DetalhesItem.aspx?p=104311-COLETE-PARA-FERRAMENTA-BRASFORT-COM-10-BOLSOS-567",
                ProductEAN = "7898464739573",
                ProductNCM = "42029200",
                Source = "online",
                IdMonitoringItem = 671935,
                Language = "pt-br",
                IdCompany = 2617,
                Sellers = new List<ProductPricesSeller>
                {
                    new ProductPricesSeller {
                    SellerName = "Fera Atacado",
                    SellerLink = "https://www.feraatacado.com/",
                    Prices = new List<ProductPricesSellerPrice> {
                        new ProductPricesSellerPrice {
                        Price = 119.716m,
                        PriceUnitType = 0,
                        PriceCurrency = "R$"
                    }
                    }
                }
                }
            }, new ProductPricesEntity
            {
                Id = ObjectId.Parse("66c135b2783059672396fde2"),
                IdTask = "7298bdd6-e82c-41c5-8528-9ecdd7638bc5",
                IdCrawler = 294,
                CrawlerDate = DateTime.Parse("2024-08-17T23:43:44.792Z"),
                ProductName = "COLEIRA PARA CAES TATI FORRADA Nº 8 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;",
                ProductLink = "https://www.feraatacado.com/DetalhesItem.aspx?p=112173-COLEIRA-PARA-CAES-TATI-FORRADA-Nº-8-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;",
                ProductEAN = "7898539896736",
                ProductNCM = "42010010",
                Source = "online",
                IdMonitoringItem = 671935,
                Language = "pt-br",
                IdCompany = 2617,
                Sellers = new List<ProductPricesSeller>
                {
                    new ProductPricesSeller {
                    SellerName = "Fera Atacado",
                    SellerLink = "https://www.feraatacado.com/",
                    Prices = new List<ProductPricesSellerPrice> {
                        new ProductPricesSellerPrice {
                        Price = 17.655m,
                        PriceUnitType = 0,
                        PriceCurrency = "R$"
                    }
                    }
                }
                }
            }, new ProductPricesEntity
            {
                Id = ObjectId.Parse("66c135b2783059672396fde1"),
                IdTask = "7298bdd6-e82c-41c5-8528-9ecdd7638bc5",
                IdCrawler = 294,
                CrawlerDate = DateTime.Parse("2024-08-17T23:43:44.450Z"),
                ProductName = "COLEIRA PARA CAES TATI FORRADA Nº 7 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;",
                ProductLink = "https://www.feraatacado.com/DetalhesItem.aspx?p=112172-COLEIRA-PARA-CAES-TATI-FORRADA-Nº-7-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;",
                ProductEAN = "7898539896729",
                ProductNCM = "42010010",
                Source = "online",
                IdMonitoringItem = 671935,
                Language = "pt-br",
                IdCompany = 2617,
                Sellers = new List<ProductPricesSeller>
                {
                    new ProductPricesSeller {
                    SellerName = "Fera Atacado",
                    SellerLink = "https://www.feraatacado.com/",
                    Prices = new List<ProductPricesSellerPrice> {
                        new ProductPricesSellerPrice {
                        Price = 12.228m,
                        PriceUnitType = 0,
                        PriceCurrency = "R$"
                    }
                    }
                }
                }
            }, new ProductPricesEntity
            {
                Id = ObjectId.Parse("66c135b2783059672396fde0"),
                IdTask = "7298bdd6-e82c-41c5-8528-9ecdd7638bc5",
                IdCrawler = 294,
                CrawlerDate = DateTime.Parse("2024-08-17T23:43:44.139Z"),
                ProductName = "COLEIRA PARA CAES TATI FORRADA Nº 6 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;",
                ProductLink = "https://www.feraatacado.com/DetalhesItem.aspx?p=112171-COLEIRA-PARA-CAES-TATI-FORRADA-Nº-6-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;",
                ProductEAN = "7898539896712",
                ProductNCM = "42010010",
                Source = "online",
                IdMonitoringItem = 671935,
                Language = "pt-br",
                IdCompany = 2617,
                Sellers = new List<ProductPricesSeller>
                {
                    new ProductPricesSeller {
                    SellerName = "Fera Atacado",
                    SellerLink = "https://www.feraatacado.com/",
                    Prices = new List<ProductPricesSellerPrice> {
                        new ProductPricesSellerPrice {
                        Price = 11.547m,
                        PriceUnitType = 0,
                        PriceCurrency = "R$"
                    }
                    }
                }
                }
            }, new ProductPricesEntity
            {
                Id = ObjectId.Parse("66c135b2783059672396fddf"),
                IdTask = "7298bdd6-e82c-41c5-8528-9ecdd7638bc5",
                IdCrawler = 294,
                CrawlerDate = DateTime.Parse("2024-08-17T23:43:43.839Z"),
                ProductName = "COLEIRA PARA CAES TATI FORRADA Nº 5 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;",
                ProductLink = "https://www.feraatacado.com/DetalhesItem.aspx?p=112170-COLEIRA-PARA-CAES-TATI-FORRADA-Nº-5-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;",
                ProductEAN = "7898539896705",
                ProductNCM = "42010010",
                Source = "online",
                IdMonitoringItem = 671935,
                Language = "pt-br",
                IdCompany = 2617,
                Sellers = new List<ProductPricesSeller>
                {
                    new ProductPricesSeller {
                    SellerName = "Fera Atacado",
                    SellerLink = "https://www.feraatacado.com/",
                    Prices = new List<ProductPricesSellerPrice> {
                        new ProductPricesSellerPrice {
                        Price = 13.786m,
                        PriceUnitType = 0,
                        PriceCurrency = "R$"
                    }
                    }
                }
                }
            }, new ProductPricesEntity
            {
                Id = ObjectId.Parse("66c135b2783059672396fdde"),
                IdTask = "7298bdd6-e82c-41c5-8528-9ecdd7638bc5",
                IdCrawler = 294,
                CrawlerDate = DateTime.Parse("2024-08-17T23:43:43.498Z"),
                ProductName = "COLEIRA PARA CAES TATI FORRADA Nº 4 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;",
                ProductLink = "https://www.feraatacado.com/DetalhesItem.aspx?p=112169-COLEIRA-PARA-CAES-TATI-FORRADA-Nº-4-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;",
                ProductEAN = "7898539896699",
                ProductNCM = "42010010",
                Source = "online",
                IdMonitoringItem = 671935,
                Language = "pt-br",
                IdCompany = 2617,
                Sellers = new List<ProductPricesSeller>
                {
                    new ProductPricesSeller {
                    SellerName = "Fera Atacado",
                    SellerLink = "https://www.feraatacado.com/",
                    Prices = new List<ProductPricesSellerPrice> {
                        new ProductPricesSellerPrice {
                        Price = 7.880m,
                        PriceUnitType = 0,
                        PriceCurrency = "R$"
                    }
                    }
                }
                }
            }, new ProductPricesEntity
            {
                Id = ObjectId.Parse("66c135b2783059672396fddd"),
                IdTask = "7298bdd6-e82c-41c5-8528-9ecdd7638bc5",
                IdCrawler = 294,
                CrawlerDate = DateTime.Parse("2024-08-17T23:43:43.175Z"),
                ProductName = "COLEIRA PARA CAES TATI FORRADA Nº 3 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;",
                ProductLink = "https://www.feraatacado.com/DetalhesItem.aspx?p=112168-COLEIRA-PARA-CAES-TATI-FORRADA-Nº-3-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;",
                ProductEAN = "7898539896682",
                ProductNCM = "42010010",
                Source = "online",
                IdMonitoringItem = 671935,
                Language = "pt-br",
                IdCompany = 2617,
                Sellers = new List<ProductPricesSeller>
                {
                    new ProductPricesSeller {
                    SellerName = "Fera Atacado",
                    SellerLink = "https://www.feraatacado.com/",
                    Prices = new List<ProductPricesSellerPrice> {
                        new ProductPricesSellerPrice {
                        Price = 6.102m,
                        PriceUnitType = 0,
                        PriceCurrency = "R$"
                    }
                    }
                }
                }
            }, new ProductPricesEntity
            {
                Id = ObjectId.Parse("66c135b2783059672396fddc"),
                IdTask = "7298bdd6-e82c-41c5-8528-9ecdd7638bc5",
                IdCrawler = 294,
                CrawlerDate = DateTime.Parse("2024-08-17T23:43:42.870Z"),
                ProductName = "COLEIRA PARA CAES TATI FORRADA Nº 2 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;",
                ProductLink = "https://www.feraatacado.com/DetalhesItem.aspx?p=112167-COLEIRA-PARA-CAES-TATI-FORRADA-Nº-2-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;",
                ProductEAN = "7898539896675",
                ProductNCM = "42010010",
                Source = "online",
                IdMonitoringItem = 671935,
                Language = "pt-br",
                IdCompany = 2617,
                Sellers = new List<ProductPricesSeller>
                {
                    new ProductPricesSeller {
                    SellerName = "Fera Atacado",
                    SellerLink = "https://www.feraatacado.com/",
                    Prices = new List<ProductPricesSellerPrice> {
                        new ProductPricesSellerPrice {
                        Price = 5.664m,
                        PriceUnitType = 0,
                        PriceCurrency = "R$"
                    }
                    }
                }
                }
            }
        };
    }


}
