﻿using System.Reflection;
using System.Runtime.CompilerServices;

namespace Repository.UnitOfWork
{
    public static class UnitOfWorkExtension
    {
        public static void InitializeRepository(this IUnitOfWork unitOfWork, params IMultiDbContext[] dbContexts)
        {
            foreach (var property in unitOfWork.GetType().GetProperties())
            {
                try
                {
                    var implementation = Assembly.GetExecutingAssembly()
                        .DefinedTypes
                        .FirstOrDefault(p => property.PropertyType.IsAssignableFrom(p) && !p.IsInterface);
                    if (implementation != null)
                    {
                        var type = unitOfWork.GetType();

                        var backingField = type
                          .GetFields(BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static)
                          .FirstOrDefault(field =>
                            field.Attributes.HasFlag(FieldAttributes.Private) &&
                            field.Attributes.HasFlag(FieldAttributes.InitOnly) &&
                            field.CustomAttributes.Any(attr => attr.AttributeType == typeof(CompilerGeneratedAttribute)) &&
                            (field.DeclaringType == property.DeclaringType) &&
                            field.FieldType.IsAssignableFrom(property.PropertyType) &&
                            field.Name.StartsWith($"<{property.Name}>")
                          );

                        PropertyInfo propertyInfo = implementation.GetProperty("DbContextName", BindingFlags.Static | BindingFlags.Public);

                        if (propertyInfo == null)
                        {
                            throw new Exception($"Não foi possível encontrar o PropertyInfo");
                        }

                        var dbContextName = propertyInfo.GetValue(property).ToString();
                        var dbContext = dbContexts.FirstOrDefault(p => p.DbContextName == dbContextName);

                        if(dbContext == null)
                        {
                            throw new Exception($"Não foi possível encontrar o DbContext {dbContextName}");
                        }

                        backingField.SetValue(unitOfWork, Activator.CreateInstance(implementation, new object[] { dbContext }));

                    }
                }
                catch (Exception ex)
                {
                    throw new Exception($"Erro ao criar a instância da propriedade {property.Name}", ex);
                }
            }
        }
    }
}
