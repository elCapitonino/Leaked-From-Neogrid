using Microsoft.Extensions.Options;
using System.Data;
using System.Data.Odbc;

namespace Repository.DbContexts;

public class DatabricsDbContext : IDisposable
{
    private readonly string _connectionString;
    private readonly string _schema;

    public DatabricsDbContext(string connectionString, string schema)
    {
        _connectionString = connectionString;
        _schema = schema;
    }

    public string GetSchema()
    {
        return _schema;
    }

    public async Task<List<T>> ExecuteQuery<T>(string sql) where T : class, new()
    {
        var entities = new List<T>();

        using (OdbcConnection connection = new(_connectionString))
        {
            await connection.OpenAsync();

            using (var command = connection.CreateCommand())
            {
                command.CommandText = sql;

                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        T entity = MapReaderToEntity<T>(reader);
                        entities.Add(entity);
                    }
                }
            }
        }

        return entities;
    }

    public async Task<int> ExecuteCountQuery(string sql)
    {
        int totalCount = 0;

        using (OdbcConnection connection = new(_connectionString))
        {
            await connection.OpenAsync();

            using (var command = connection.CreateCommand())
            {
                command.CommandText = sql;

                object result = await command.ExecuteScalarAsync();
                totalCount = result != null ? Convert.ToInt32(result) : 0;
            }
        }

        return totalCount;
    }

    public void ExecuteCommand(string sql)
    {
        using (OdbcConnection connection = new(_connectionString))
        {
            connection.Open();

            using (var command = connection.CreateCommand())
            {
                command.CommandText = sql;

                command.ExecuteNonQuery();
            }
        }
    }

    private static T MapReaderToEntity<T>(OdbcDataReader reader) where T : class, new()
    {
        try
        {
            T entity = new T();

            for (int i = 0; i < reader.FieldCount; i++)
            {
                string columnName = reader.GetName(i);
                var property = typeof(T).GetProperty(columnName);

                if (property != null && !reader.IsDBNull(i))
                {
                    var value = reader[columnName];
                    var propertyType = property.PropertyType;

                    if (propertyType == typeof(List<string>))
                    {
                        if (value is string arrayString)
                        {
                            arrayString = arrayString.Trim('"');
                            arrayString = arrayString.Trim('[', ']');
                            var listValue = new List<string>(arrayString.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries));
                            listValue = listValue.ConvertAll(s => s.Trim('"', ' '));

                            property.SetValue(entity, listValue);
                        }
                    }
                    else
                    {
                        // Converte o valor normalmente para o tipo da propriedade
                        var convertedValue = Convert.ChangeType(value, propertyType);
                        property.SetValue(entity, convertedValue);
                    }
                }
            }

            return entity;
        }
        catch (Exception ex)
        {
            throw;
        }
    }

    public DataTable ExecuteQueryDatatable(string sql)
    {
        DataTable resultTable = new DataTable();

        using (OdbcConnection connection = new(_connectionString))
        {
            connection.Open();

            using (var command = connection.CreateCommand())
            {
                command.CommandText = sql;

                using (var reader = command.ExecuteReader())
                {
                    resultTable.Load(reader);
                }
            }
        }

        return resultTable;
    }

    public void Dispose()
    {
        GC.SuppressFinalize(this);
    }
}