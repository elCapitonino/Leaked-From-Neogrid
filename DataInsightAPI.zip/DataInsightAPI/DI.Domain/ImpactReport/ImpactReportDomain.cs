﻿using ClosedXML.Excel;
using DI.Domain.Models.ImpactReport;
using DI.Domain.Services.Interfaces.Reports;
using DI.Domain.Utils.ImpactReport;
using DI.Repository.Entities;
using DI.Repository.Interfaces;

namespace DI.Domain.ImpactReport
{
    public class ImpactReportDomain : IImpactReportDomain
    {
        private readonly IUnitOfWork _uow;
        private readonly IGetImpactReportDataService _impactReportService;
        private readonly IGenerateImpactReportExcelFileService _generateImpactReportExcelFileService;

        public ImpactReportDomain(IUnitOfWork uow, IGetImpactReportDataService impactReportService, IGenerateImpactReportExcelFileService generateImpactReportExcelFileService)
        {
            this._uow = uow;
            this._impactReportService = impactReportService;
            this._generateImpactReportExcelFileService = generateImpactReportExcelFileService;
        }

        public MemoryStream GenerateRawImpactReport(long companyId, List<long> priceGroupIds, string userId)
        {
            var impactReportConfiguration = _uow.ImpactReportConfigurationRepository.GetByCompanyId(companyId);
            var userResourceType = _uow.GrupoRecursosRepository.GetHierarchyUserById(companyId, userId);

            var impactReportModels = priceGroupIds.SelectMany(
                x => GetAllImpactReportByPriceGroup(x, impactReportConfiguration?.Royalty ?? 0)
                );

            var workbook = ExcelReportRawUtil.CreateWorkbook(impactReportModels.GroupBy(x => x.AffiliateName!),
                userResourceType, impactReportConfiguration!.HasRawReportRoyalty);

            return ExcelReportRawUtil.SaveWorkbookToMemoryStream(workbook);
        }

        private List<ImpactReportModel> GetAllImpactReportByPriceGroup(long priceGroupId, decimal royalty = 0)
        {
            var priceGroup = _uow.EnterprisePriceGroupRepository.GetById(priceGroupId);

            var priceProjections = _uow.EnterprisePriceProjectionRepository.GetByIdPriceGroup(priceGroupId);

            var projectionImpacts = _uow.ProjectionImpactDataRepository.GetAllByPriceGroupId(priceGroupId).Where(x => x.HasSuggestion);

            return MapToImpactReportModels(priceGroup, priceProjections, projectionImpacts, royalty);
        }

        private List<ImpactReportModel> MapToImpactReportModels(EnterprisePriceGroupEntity priceGroup, IEnumerable<EnterprisePriceProjectionEntity> priceProjections, IEnumerable<ProjectionImpactDataEntity> projectionImpacts, decimal royalty)
        {
            List<ImpactReportModel> models = [];

            var piDict = projectionImpacts.ToDictionary(x => x.PriceProjectionId);

            foreach (var pp in priceProjections)
            {
                ProjectionImpactDataEntity? pi = null;
                if (piDict.ContainsKey(pp.EnterprisePricesProjectionId))
                    pi = piDict[pp.EnterprisePricesProjectionId];

                var model = new ImpactReportModel
                {
                    EnterprisePriceGroupsId = pp.EnterprisePriceGroupsId,
                    EnterprisePriceGroupsName = priceGroup.Name,
                    AffiliateName = pp.AffiliateName,
                    Category = pp.Category3,
                    SubCategory = pp.Category4,
                    Product = pp.Product,
                    PackageDescription = pp.PackageDescription,
                    ProductName = pp.ProductName,
                    ActionResult = pp.Workflows.FirstOrDefault()?.LastAction?.ActionResult,
                    ElasticityResult = pp.Elasticity?.ElasticityResult,
                    SalePriceInferiorLimit_Demand_CurveABC = pp.SalePriceInferiorLimit_Demand_CurveABC,
                    PublishedDate = pp.PriceGroup?.PublishedDate,
                    PriorCost = pi?.PriorCost ?? 0,
                    ProjectionCost = pi?.ProjectionCost ?? 0,
                    RealCost = pi?.RealCost ?? 0,
                    PriorPrice = pi?.PriorPrice ?? 0,
                    ProjectionPrice = pi?.ProjectionPrice ?? 0,
                    RealPrice = pi?.RealPrice ?? 0,
                    Adopted = pi?.Adopted ?? false,
                    PriorDemand = pi?.PriorDemand ?? 0,
                    ProjectionDemand = pi?.ProjectionDemand ?? 0,
                    RealDemand = pi?.RealDemand ?? 0,
                    PriorRevenue = pi?.PriorRevenue ?? 0,
                    ProjectionRevenue = pi?.ProjectionRevenue ?? 0,
                    RealRevenue = pi?.RealRevenue ?? 0,
                    PriorProfit = pi?.PriorProfit ?? 0,
                    ProjectionProfit = pi?.ProjectionProfit ?? 0,
                    RealProfit = pi?.RealProfit ?? 0,
                    PriorMargin = pi?.PriorMargin ?? 0,
                    ProjectionMargin = pi?.ProjectionMargin ?? 0,
                    RealMargin = pi?.RealMargin ?? 0,
                    Royalty = royalty,
                };

                models.Add(model);
            }

            return models;
        }

        public async Task<MemoryStream> GenerateConsolidatedReport(ImpactConsolidatedRequestModel request, CancellationToken cancellationToken, string userId)
        {
            var data = await _impactReportService.GenerateImpactReportData(request, cancellationToken, userId);

            return await _generateImpactReportExcelFileService.Generate(data, cancellationToken);
        }
    }
}