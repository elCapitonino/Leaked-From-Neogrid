﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using Repository.Attributes;
using Repository.DbContexts;
using Repository.Entity;
using MongoDB.EntityFrameworkCore.Extensions;

namespace Repository.TypeConfiguration
{
    [DbContextTypeConfiguration(typeof(NielsenDbContext))]
    public class PeraltaTypeConfiguration : TypeConfigurationBase<PeraltaEntity>, IEntityTypeConfiguration<PeraltaEntity>
    {
        public override void Configure(EntityTypeBuilder<PeraltaEntity> builder)
        {
            builder.ToTable("base_peralta").ToCollection("base_peralta");
        }
    }

}
