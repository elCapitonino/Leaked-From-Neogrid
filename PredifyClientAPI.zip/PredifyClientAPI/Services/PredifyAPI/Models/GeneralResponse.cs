﻿namespace PredifyClientAPI.Services.PredifyAPI.Models
{
    public sealed class GeneralResponse : GeneralResponse<object>
    {
        public GeneralResponse()
        {

        }

        public GeneralResponse(object result)
        {
            Result = result;
        }
    }

    public class GeneralResponse<T>
    {
        public GeneralResponse()
        {

        }

        public GeneralResponse(T result)
        {
            Result = result;
        }

        public T Result { get; set; }

        public bool Success { get; set; } = true;

        public List<GeneralResponse_Message> Messages { get; set; }

        public GeneralResponse<T> AddMessages(List<GeneralResponse_Message> messages)
        {
            if (Messages == null)
                Messages = messages;
            else
                Messages.AddRange(messages);

            return this;
        }

        public GeneralResponse<T> AddError(string message, int code = 1)
        {
            if (Messages == null)
                Messages = new List<GeneralResponse_Message>();

            Messages.Add(new GeneralResponse_Message()
            {
                Code = code,
                Message = message,
                Type = GeneralResponse_Message.EMessageType.ERROR
            });

            return this;
        }
        public GeneralResponse<T> SetSuccess(bool success)
        {
            Success = success;

            return this;
        }
    }

    public sealed class GeneralResponse_Message
    {
        public EMessageType Type { get; set; }
        public int Code { get; set; }
        public string Message { get; set; }
        public IEnumerable<GeneralResponse_Message_Inner> Inner { get; set; }

        public enum EMessageType
        {
            INFO = 0,
            WARNING = 1,
            ERROR = 2,
        }
    }

    public sealed class GeneralResponse_Message_Inner
    {
        public int Code { get; set; }
        public string Message { get; set; }
    }







    public class GeneralPaginationResponse<T>
    {

        public GeneralPaginationResponse()
        {
        }

        public GeneralPaginationResponse(List<T> list)
        {
            Records = list;
        }

        public GeneralPaginationResponse(GeneralAccessPagination param)
        {
            CurrentPage = param.Page;
            RecordsPerPage = param.RecordsPerPage;
        }

        /// <summary>
        /// Pagina atual
        /// </summary>
        public int CurrentPage { get; set; }

        /// <summary>
        /// Total de páginas
        /// </summary>
        public int TotalPages { get { return (int)Math.Ceiling(TotalRecords / (decimal)(RecordsPerPage != 0 ? RecordsPerPage : 1)); } }

        /// <summary>
        /// Registros por página
        /// </summary>
        public int RecordsPerPage { get; set; }

        /// <summary>
        /// Quantidade de registros na página atual.
        /// </summary>
        public int NumberOfRecords { get { return Records == null ? 0 : Records.Count(); } }

        /// <summary>
        /// Total de registros.
        /// </summary>
        public int TotalRecords { get; set; }

        /// <summary>
        /// Dados a serem listados
        /// </summary>
        public List<T> Records { get; set; }
    }
}
