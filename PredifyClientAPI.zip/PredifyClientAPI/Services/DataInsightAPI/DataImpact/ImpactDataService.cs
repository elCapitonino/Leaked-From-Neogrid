﻿using Newtonsoft.Json;
using PredifyClientAPI.Services.DataInsightAPI.DataImpact.Models;

namespace PredifyClientAPI.Services.DataInsightAPI.DataImpact
{
    public class ImpactDataService : IImpactDataService
    {
        private readonly HttpClient _client;

        public ImpactDataService(HttpClient client)
        {
            _client = client;
        }

        public async Task<IEnumerable<GranularityGroupResponse>> GetGranularities(long companyId)
        {
            var response = await _client.GetAsync($"/api/ImpactData/Granularities?CompanyId={companyId}");
            var content = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
                return JsonConvert.DeserializeObject<IEnumerable<GranularityGroupResponse>>(content);
            else if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                throw new UnauthorizedAccessException();

            throw new Exception(content);
        }

        public async Task<IEnumerable<MonthlyImpactDataResponse>> GetMonthlyImpactData(long companyId, int startDate, int endDate)
        {
            var response = await _client.GetAsync($"/api/ImpactData/MonthlyImpactData?companyId={companyId}&startDate={startDate}&endDate={endDate}");
            var content = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
                return JsonConvert.DeserializeObject<IEnumerable<MonthlyImpactDataResponse>>(content);
            else if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                throw new UnauthorizedAccessException();

            throw new Exception(content);
        }

        public async Task<IEnumerable<ProjectionImpactDataResponse>> GetProjectionImpactData(long companyId, long priceGroupId)
        {
            var response = await _client.GetAsync($"/api/ImpactData/ProjectionImpactData?companyId={companyId}&priceGroupId={priceGroupId}");
            var content = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
                return JsonConvert.DeserializeObject<IEnumerable<ProjectionImpactDataResponse>>(content);
            else if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                throw new UnauthorizedAccessException();

            throw new Exception(content);
        }
    }
}
