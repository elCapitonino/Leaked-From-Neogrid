using Domain.CompanyMonitoringCrawler;
using Domain.ProductPrice.Models;
using Microsoft.Extensions.Logging;
using Repository.Entity.Databricks;
using Repository.Models.Databricks;
using Repository.UnitOfWork;
using System;
using System.Diagnostics;

namespace Domain.ProductPrice;

public class ProductPriceDomain : IProductPriceDomain
{
    private readonly IUnitOfWork _uow;
    private readonly ICompanyMonitoringCrawlerDomain _companyMonitoringCrawlerDomain;
    private readonly ILogger<ProductPriceDomain> _logger;

    public ProductPriceDomain(ILogger<ProductPriceDomain> logger, IUnitOfWork uow, ICompanyMonitoringCrawlerDomain companyMonitoringCrawlerDomain)
    {
        _logger = logger;
        _uow = uow;
        _companyMonitoringCrawlerDomain = companyMonitoringCrawlerDomain;
    }

    public bool IgnoreProductPrice(int companyId, string priceId)
    {
        try
        {
            var ignoredPrice = new IgnoredPriceEntity()
            {
                Id = Guid.NewGuid().ToString(),
                CompanyId = companyId,
                ProductPriceId = priceId
            };

            _uow.IgnoredPriceRepository.Insert(ignoredPrice);

            _logger.LogInformation("Price ignored for company {company}", companyId);

            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception while ignoring price for company {company}", companyId);
            throw;
        }
    }

    public async Task<bool> UnignoreProductPrice(int companyId, string priceId)
    {
        try
        {
            var queryFilters = new List<QueryFilter>(){
                new (){Column = "CompanyId", Operator = "=", Value = companyId},
                new (){Column = "ProductPriceId", Operator = "=", Value = priceId}
            };

            var ignoredPrices = await _uow.IgnoredPriceRepository.Get(queryFilters);
            var ids = ignoredPrices.Select(x => x.Id);

            _uow.IgnoredPriceRepository.Remove(ids);

            _logger.LogInformation("Price unignored for company {company}", companyId);

            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception while unignoring price for company {company}", companyId);
            throw;
        }
    }

    public async Task<List<IgnoredProductPriceResponse>> GetIgnoredPrices(int companyId, string productId)
    {
        try
        {
            var companyCrawlers = await _companyMonitoringCrawlerDomain.GetCompanyMonitoringCrawler(companyId, false);
            companyCrawlers.AddRange(await _companyMonitoringCrawlerDomain.GetCompanyMonitoringCrawler(companyId, true));

            if (companyCrawlers == null || companyCrawlers.Count == 0)
            {
                _logger.LogError($"No crawlers found for company {companyId}");
                throw new ArgumentException($"No crawlers found for company {companyId}");
            }

            var query = CreateIgnoredPricesQuery(companyId, productId);

            _logger.LogInformation("Searching for ignored prices for company {CompanyId}.", companyId);

            var sw = Stopwatch.StartNew();
            var ignoredPrices = await _uow.IgnoredPriceRepository.GetWithJoin<IgnoredProductPriceResponse>(query);
            sw.Stop();
            _logger.LogInformation("Ignored prices query took {ms} ms to execute for company {CompanyId} found {found} ignored prices", sw.ElapsedMilliseconds, companyId, ignoredPrices.Count);

            foreach (var price in ignoredPrices)
            {
                var crawlerId = price.Origin;

                price.CrawlerName = companyCrawlers.FirstOrDefault(x => x.MonitoringCrawlerId == crawlerId)?.MonitoringCrawler?.Description ?? "";
            }

            return ignoredPrices;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception while ignoring price for company {company}", companyId);
            throw;
        }
    }

    private static QueryParameters CreateIgnoredPricesQuery(int companyId, string productId)
    {
        var query = new QueryParameters()
        {
            Select = [],
            Joins = [],
            Filters = [],
            GroupBy = [],
            OrderBy = [],
            SqlFilters = []
        };

        query.Joins.AddRange(
        [
            new (){ JoinTable = "product_prices AS pp", JoinCondition = "ProductPriceId = pp.Id", JoinWithMainTable = true },
            new (){ JoinTable = "product_sellers AS ps", JoinCondition = "ps.Id = pp.ProductSellerId" },
            new (){ JoinTable = "products AS p", JoinCondition = "p.id = ps.ProductId"}
        ]);

        query.Select.AddRange([
            new (){ Column = "p.Id AS ProductId" },
            new (){ Column = "ps.Id AS ProductSellerId" },
            new (){ Column = "p.Name" },
            new (){ Column = "pp.ProductLink" },
            new (){ Column = "p.Brand" },
            new (){ Column = "p.CrawlerId AS Origin" },
            new (){ Column = "pp.Price" },
            new (){ Column = "pp.CollectedDate AS Date" }
        ]);

        query.Filters.AddRange(
        [
            new (){ Column = "ps.ProductId", Operator = "=", Value = productId },
            new (){ Column = "CompanyId", Operator = "=", Value = companyId }
        ]);

        query.Take = 10000;

        return query;
    }
}