using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Repository.Entity;
using Repository.Enums;
using Repository.Models.Databricks;
using Repository.UnitOfWork;
using System.Collections.Generic;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace Domain.CompanyMonitoringCrawler;

public class CompanyMonitoringCrawlerDomain : ICompanyMonitoringCrawlerDomain
{
    private readonly ILogger<CompanyMonitoringCrawlerDomain> _logger;
    private readonly IUnitOfWork _uow;


    public CompanyMonitoringCrawlerDomain(ILogger<CompanyMonitoringCrawlerDomain> logger, IUnitOfWork uow)
    {
        _logger = logger;
        _uow = uow;
    }

    public async Task<List<CompanyMonitoringCrawlerEntity>> GetCompanyMonitoringCrawler(long companyId, bool IsCost)
    {
        try
        {
            var companyMonitoringCrawlers = _uow.CompanyMonitoringCrawler.GetAll()
            .Include(x => x.MonitoringCrawler)
            .Include(x => x.CompanyMonitoringCrawlerFilters)
            .ThenInclude(y => y.CompanyMonitoringCrawlerFiltersValues)
            .Where(x => x.CompanyId == companyId && x.IsDeleted == false);

            if (IsCost)
                companyMonitoringCrawlers = companyMonitoringCrawlers.Where(x => x.IsCost);
            else
                companyMonitoringCrawlers = companyMonitoringCrawlers.Where(x => x.IsSale);

            return companyMonitoringCrawlers.ToList();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, $"An error occurred while searching CompanyMonitoringCrawler for company {companyId}.");
            throw new ArgumentException($"An error occurred while searching CompanyMonitoringCrawler for company {companyId}.");
        }
    }

    public static List<int> GetCrawlerIdsByNames(List<string?> crawlerNames, List<CompanyMonitoringCrawlerEntity> companyCrawlers, bool returnAllIfNoNames)
    {
        var crawlerIds = new List<int>();

        if (crawlerNames != null && crawlerNames.Count > 0)
        {
            crawlerNames = crawlerNames.Where(x => x != null).ToList();
            crawlerIds = companyCrawlers.Where(x => crawlerNames.Contains(x.MonitoringCrawler.Description)).Select(c => c.MonitoringCrawlerId).ToList();
        }

        if (returnAllIfNoNames)
        {
            crawlerIds = companyCrawlers.Select(c => c.MonitoringCrawlerId).ToList();
        }

        return crawlerIds.Distinct().ToList();
    }

    public static List<string> GetCrawlerNamesByIds(List<int> crawlerIds, List<CompanyMonitoringCrawlerEntity> companyCrawlers)
    {
        var crawlerNames = new List<string>();

        if (crawlerIds != null && crawlerIds.Count > 0)
        {
            crawlerNames = companyCrawlers.Where(x => crawlerIds.Contains(x.MonitoringCrawlerId)).Select(c => c.MonitoringCrawler.Description).ToList();
        }

        return crawlerNames.Distinct().ToList();
    }
}