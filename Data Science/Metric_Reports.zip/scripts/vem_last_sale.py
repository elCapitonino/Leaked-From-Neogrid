"""
Script para gerar relatório com informações sobre a última venda
e valores associados a precificações específicas da VEM.

Mantido para registro, não para ser utilizado diretamente em outro contexto.
"""

# %%

import sys
from datetime import datetime, timedelta

import pandas as pd
from xlsxwriter.utility import xl_col_to_name

sys.path.append("..")
from geral import config

# %%

conn = config.getDadosAWSSession("producao")
if conn is None:
    raise RuntimeError()

# %%

df_latest_sale = pd.read_sql_query(
    """
    SELECT
        Affiliate,
        Product,
        Description,
        Issuance,
        Category3 AS Categoria,
        Category4 AS Subcategoria,
        PackageDescription AS EAN
    FROM Enterprise_Sales_History
    WHERE IdCompany = 3026
    AND IsDeletado = 0
    AND IsLastPrice = 1
    AND Affiliate IN ('303645', '303341', '308058', '300173', '300596')
    """,
    conn,
)

# %%

# try:
#     df_ean = pd.read_excel("sql_ean.xlsx")
# except Exception:
#     df_ean = pd.read_sql_query(
#         """
#         SELECT DISTINCT Description, PackageDescription AS EAN
#         FROM Enterprise_Sales_History
#         WHERE IdCompany = 3026
#         AND IsDeletado = 0
#         """,
#         conn,
#     )
#     df_ean.to_excel("sql_ean.xlsx", index=False)

# %%

df_descriptions = pd.read_csv("aff_desc.csv", sep=";").rename(
    columns={"Product": "Description"}
)
df_descriptions["Affiliate"] = df_descriptions["Affiliate"].astype(str)
df_descriptions.head()

# %%

df_latest_sale.shape
# %%

df_latest_sale.head()


# %%

df_elast = pd.read_sql_query(
    """
    SELECT
        Elasticity,
        Granularity1 AS Description,
        Granularity2 AS Affiliate
    FROM Enterprise_ElasticityNew 
    WHERE IdCompany = 3026
    AND IsDeletado = 0
    AND DataHoraCriacao = (
        SELECT MAX(DataHoraCriacao)
        FROM Enterprise_ElasticityNew
        WHERE IdCompany = 3026 AND IsDeletado = 0
    )
    """,
    conn,
)

df_elast.head()

# %%

# XXX há descrições com mais de um EAN (dado não normalizado), qual usaria para preencher sem vendas?
# df_desc_ean = pd.merge(df_descriptions, df_ean.rename(columns={"EAN": "ean_bkp"}), on=["Description"], how="left")
# df_merge = pd.merge(
#     df_desc_ean, df_latest_sale, on=["Affiliate", "Description"], how="left"
# )

df_merge = pd.merge(
    df_descriptions, df_latest_sale, on=["Affiliate", "Description"], how="left"
)

df_merge = pd.merge(df_merge, df_elast, on=["Description", "Affiliate"], how="left")


# %%


df_no_sale = df_merge.copy()
cutoff_date = datetime.today() - timedelta(days=90)
df_no_sale = df_no_sale[
    (df_no_sale["Issuance"] < cutoff_date) | (df_no_sale["Issuance"].isna())
][["Affiliate", "Description"]]
df_no_sale = df_no_sale.fillna("SEM VENDAS")

col_name = f"Produtos sem venda desde {cutoff_date.strftime('%d/%m/%Y')}"
df_no_sale = df_no_sale.rename(columns={"Affiliate": "Filial", "Description": col_name})

# %%

# XXX hardcoded
price_groups = (18480, 18515, 18516, 18483, 18484)

from geral.db import query_selected_price_groups, query_projections, query_history

df_price_groups = query_selected_price_groups(
    conn,
    3026,
    price_groups,
    group_granularity=["Affiliate"],
    days_lookback=14,
    days_lookforward=14,
    days_interval=1,
)
df_price_groups.head()

# %%

GRANULARITY = ["Affiliate", "Description"]

df_metrics = []
for _, row in df_price_groups.iterrows():
    pg = row["IdEnterprisePriceGroups"]
    dias_fwd = abs((row["EndDateFwd"] - row["InitialDateFwd"]).days)

    df_pp = query_projections(conn, pg, GRANULARITY, None)
    df_pp["d_projecao"] = df_pp["d_projecao"] * dias_fwd
    df_pp["r_projecao"] = df_pp["r_projecao"] * dias_fwd
    df_pp["l_projecao"] = df_pp["l_projecao"] * dias_fwd

    df_past = query_history(
        conn,
        row["InitialDateBack"],
        row["EndDateBack"],
        GRANULARITY,
        3026,
        "anterior",
        None,
        [("Affiliate", row["Affiliate"])],
    )

    df_fwd = query_history(
        conn,
        row["InitialDateFwd"],
        row["EndDateFwd"],
        GRANULARITY,
        3026,
        "posterior",
        None,
        [("Affiliate", row["Affiliate"])],
    )

    print(df_pp.shape)

    df_join = pd.merge(df_pp, df_past, on=GRANULARITY, how="left")
    print(df_join.shape)

    df_join = pd.merge(df_join, df_fwd, on=GRANULARITY, how="left")
    print(df_join.shape)

    df_metrics.append(df_join)

df_metrics = pd.concat(df_metrics)

# %%

print(df_merge.shape)

df_merge_metrics = pd.merge(
    df_merge, df_metrics, on=["Affiliate", "Description"], how="left"
)

print(df_merge_metrics.shape)

# %%

df_geral = df_merge_metrics.copy()
df_geral["Elasticity"] = df_geral["Elasticity"].apply(
    lambda x: "Elástico" if x < -1 else "Inelástico"
)
df_geral["Issuance"] = df_geral["Issuance"].dt.date
# df_geral["EAN"] = df_geral["EAN"].fillna(df_geral["ean_bkp"])
df_geral.loc[df_geral["Issuance"].isna(), "Elasticity"] = pd.NA

df_geral[["Categoria", "Subcategoria", "Issuance"]] = df_geral[
    ["Categoria", "Subcategoria", "Issuance"]
].fillna("SEM VENDAS")
df_geral = df_geral.sort_values(["Affiliate", "Issuance"], na_position="first")
df_geral = df_geral.drop(columns=["Product"])
df_geral["q_posterior"] = df_geral["q_posterior"].fillna(0)
df_geral = df_geral.rename(
    columns={
        "Affiliate": "Filial",
        "Issuance": "Última Venda",
        "Description": "Produto",
        "Elasticity": "Elasticidade",
        "m_projecao": "Margem Projetada (%)",
        "m_posterior": "Margem Média Real (%)",
        "d_projecao": "Demanda Projetada",
        "q_posterior": "Demanda Real",
    }
)

# %%

# NOTE reordena as colunas
df_geral = df_geral[
    [
        "Filial",
        "Categoria",
        "Subcategoria",
        "Produto",
        "EAN",
        "Elasticidade",
        "Última Venda",
        "Margem Projetada (%)",
        "Margem Média Real (%)",
        "Demanda Projetada",
        "Demanda Real",
    ]
]

# %%

df_margin_impact = df_merge_metrics.copy()
df_margin_impact = df_margin_impact[df_margin_impact["m_posterior"].notna()]
# XXX pode pegar venda antiga ou, se não houver venda antes, descartar mesmo
# que tenha venda no período posterior
df_margin_impact = df_margin_impact[df_margin_impact["m_anterior"].notna()]
df_margin_impact["margin_diff"] = (
    df_margin_impact["m_posterior"] - df_margin_impact["m_anterior"]
)
df_margin_impact = df_margin_impact.sort_values("margin_diff")
df_margin_impact = df_margin_impact[
    [*GRANULARITY, "m_projecao", "m_anterior", "m_posterior", "margin_diff"]
]
df_margin_impact = df_margin_impact.rename(
    columns={
        "Affiliate": "Filial",
        "Description": "Produto",
        "m_anterior": "Margem Média Real Anterior (%)",
        "m_projecao": "Margem Projetada (%)",
        "m_posterior": "Margem Média Real Posterior (%)",
        "margin_diff": "Impacto na Margem (%)",
    }
)

# %%

df_demand_impact = df_merge_metrics.copy()
df_demand_impact = df_demand_impact[df_demand_impact["q_posterior"].notna()]
df_demand_impact["q_anterior"] = df_demand_impact["q_anterior"].fillna(0)
df_demand_impact["demand_diff"] = (
    df_demand_impact["q_posterior"] - df_demand_impact["q_anterior"]
)
df_demand_impact = df_demand_impact.sort_values("demand_diff")
df_demand_impact = df_demand_impact[
    [*GRANULARITY, "d_projecao", "q_anterior", "q_posterior", "demand_diff"]
]
df_demand_impact = df_demand_impact.rename(
    columns={
        "Affiliate": "Filial",
        "Description": "Produto",
        "d_projecao": "Demanda Projetada",
        "q_anterior": "Demanda Real Anterior",
        "q_posterior": "Demanda Real Posterior",
        "demand_diff": "Impacto na Demanda",
    }
)

# %%

df_sheets = (
    (df_geral, "Geral"),
    (df_no_sale, "Sem Vendas"),
    (df_margin_impact, "Maior Impacto Margem"),
    (df_demand_impact, "Maior Impacto Demanda"),
)

# %%

with pd.ExcelWriter(f"vem_last_sale.xlsx", engine="xlsxwriter") as writer:
    for df, sheet_name in df_sheets:
        df.to_excel(writer, sheet_name=sheet_name, index=False)

        # Get the xlsxwriter workbook and worksheet objects.
        workbook = writer.book
        worksheet = writer.sheets[sheet_name]

        float_cols = [
            i
            for i, type in enumerate(df.dtypes)
            if type == "float" and "%" not in df.columns[i]
        ]
        format1 = workbook.add_format({"num_format": "0.00"})
        for col in float_cols:
            worksheet.set_column(
                f"{xl_col_to_name(col)}:{xl_col_to_name(col)}", None, format1
            )

        pct_cols = [
            i
            for i, type in enumerate(df.dtypes)
            if type == "float" and "%" in df.columns[i]
        ]

        format2 = workbook.add_format({"num_format": "0.00%"})
        for col in pct_cols:
            worksheet.set_column(
                f"{xl_col_to_name(col)}:{xl_col_to_name(col)}", None, format2
            )
        worksheet.autofit()

# %%
