using Domain.CompanyMonitoringCrawler;
using Domain.Product.Models;
using Domain.ProductSeller.Models;
using Domain.Utils;
using Microsoft.Extensions.Logging;
using Repository.Entity;
using Repository.Enums;
using Repository.Models.Databricks;
using Repository.UnitOfWork;
using System.Diagnostics;

namespace Domain.ProductSeller;

public class ProductSellerDomain : IProductSellerDomain
{
    private readonly ILogger<ProductSellerDomain> _logger;
    private readonly IUnitOfWork _uow;
    private readonly ICompanyMonitoringCrawlerDomain _companyMonitoringCrawlerDomain;

    public ProductSellerDomain(ILogger<ProductSellerDomain> logger, IUnitOfWork uow, ICompanyMonitoringCrawlerDomain companyMonitoringCrawlerDomain)
    {
        _logger = logger;
        _uow = uow;
        _companyMonitoringCrawlerDomain = companyMonitoringCrawlerDomain;
    }

    public async Task<ProductSellerResponse> GetProductSellersWithPrices(FiltersRequest request)
    {
        var companyCrawlers = await _companyMonitoringCrawlerDomain.GetCompanyMonitoringCrawler(request.CompanyId, request.IsCost);

        if (companyCrawlers == null || companyCrawlers.Count == 0)
        {
            _logger.LogError($"No crawlers found for company {request.CompanyId}");
            throw new ArgumentException($"No crawlers found for company {request.CompanyId}");
        }

        var query = CreateProductSellersAndPricesQuery(request, companyCrawlers);

        _logger.LogInformation("Searching products prices for company {CompanyId}.", request.CompanyId);

        var sw = Stopwatch.StartNew();
        var prices = await _uow.ProductSellerRepository.GetWithJoin<ProductSellerPricesResponse>(query);
        var count = await _uow.ProductSellerRepository.GetCount(query);
        sw.Stop();
        _logger.LogInformation("Product Seller query took {ms} ms to execute for company {CompanyId} found {found} prices", sw.ElapsedMilliseconds, request.CompanyId, prices.Count);

        foreach (var price in prices)
        {
            var crawlerId = int.Parse(price.Origin);

            price.CrawlerName = companyCrawlers.FirstOrDefault(x => x.MonitoringCrawlerId == crawlerId).MonitoringCrawler.Description;
        }

        var response = new ProductSellerResponse
        {
            SellerPrices = prices,
            TotalCount = count
        };

        return response;
    }

    private QueryParameters CreateProductSellersAndPricesQuery(FiltersRequest request, List<CompanyMonitoringCrawlerEntity> companyCrawlers)
    {
        var query = new QueryParameters();

        query.Joins.AddRange(
        [
            new (){ JoinTable = "products AS p", JoinCondition = "ProductId = p.Id", JoinWithMainTable = true },
            new (){ JoinTable = "product_prices AS pp", JoinCondition = "Id = pp.ProductSellerId", JoinWithMainTable = true },
            new (){ JoinTable = "ignored_prices AS ip", JoinCondition = $"pp.Id = ip.ProductPriceId and ip.CompanyId == {request.CompanyId}", JoinType = "LEFT"}
        ]);

        query.Select.AddRange([
            new (){ Column = "pp.Id as PriceId" },
            new (){ Column = "p.Name" },
            new (){ Column = "pp.ProductLink" },
            new (){ Column = "p.Brand" },
            new (){ Column = "p.CrawlerId as Origin" },
            new (){ Column = "pp.Price" },
            new (){ Column = "pp.CollectedDate as Date" }
        ]);

        query.Filters.AddRange(DatabricksQueryHelper.CreateResultBaseFilters(request, companyCrawlers));
        query.SqlFilters.AddRange(DatabricksQueryHelper.CreateCompanyMandatoryFilters(companyCrawlers));

        request.OrderBy = string.IsNullOrEmpty(request.OrderBy) ? "Name ASC" : request.OrderBy;
        query.OrderBy.Add(new QueryOrderBy { Column = request.OrderBy });

        request.Page = request.Page == 0 ? 1 : request.Page;
        request.Take = request.Take == 0 ? 10 : request.Take;

        query.Skip = (request.Page - 1) * request.Take;
        query.Take = request.Take;

        return query;
    }
}