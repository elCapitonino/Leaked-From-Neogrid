import datetime as dt
import warnings

import numpy as np
import pandas as pd

from src.exceptions import ConsistencyError
from src.logger import logger
from src.report_config import get_granularity_id
from src.utils import build_product_id


def formato_consulta(input_date):
    formatted_date = input_date.strftime("%Y-%m-%d")
    return formatted_date


def get_filter_clause(Granularidade, df_projections):
    simpler_gran_col = df_projections[Granularidade].nunique().sort_values().index[0]
    simpler_gran_values = df_projections[simpler_gran_col].unique().tolist()

    logger.info(
        "using column %s with values %s for filtering",
        simpler_gran_col,
        simpler_gran_values,
    )

    if simpler_gran_values:
        if any(isinstance(x, str) for x in simpler_gran_values):
            str_values = [f"'{x}'" for x in simpler_gran_values]
            filter_clause = (
                f"AND {simpler_gran_col} IN ({', '.join(str_values)})"
            )
        else:
            str_values = [f"{x}" for x in simpler_gran_values]
            filter_clause = (
                f"AND {simpler_gran_col} IN ({', '.join(str_values)})"
            )

    else:
        filter_clause = "AND 0 = 1"

    return filter_clause


def get_price_projection(
    sql_raw_conn, PriceGroup, Granularidade_sql, Granularidade_join_operation
):
    warnings.filterwarnings("ignore", category=UserWarning)
    query_dados_projecao_predify = f"""
    With tb_base as (
        SELECT *
        FROM Enterprise_Prices_Projection
        WHERE IdEnterprisePriceGroups = {PriceGroup}
        AND IsDeletado = 0
    ),
    tb_num as (
        SELECT PP.SalePrice as p_sem_regra_projecao, PP.SalePrice_Demand_CurveABC, VO.IsManual, VO.Manual_Price, VO.Manual_Price_Demand,
            COALESCE(VO.Price, PP.SalePrice) AS p_projecao,
            COALESCE(VO.Price_Demand, PP.SalePrice_Demand) AS d_projecao,
            PP.PbCost as custo_projecao,
            Customer, IdElasticity, {Granularidade_sql},
            ProductName as Description
        FROM tb_base AS PP
        LEFT JOIN Enterprise_Values_Overrides AS VO
        ON VO.ProjectionsReference = PP.ProjectionsReference
        AND VO.IsDeletado = 0
    ),
    tb_str as (
        select DISTINCT
            {Granularidade_sql}, IdEnterprisePricesProjection,
            CASE WHEN ppwa.[Action] = 0 THEN 'Aprovado'
                WHEN ppwa.[Action] = 1 THEN 'Reprovado'
                ELSE 'Escalado' END AS Approval
        FROM tb_base AS PP
        JOIN enterprisepriceprojection_workflow ppw
        ON ppw.identerprisepriceprojection = PP.IdEnterprisePricesProjection
        JOIN enterprisepriceprojection_workflowaction ppwa
        ON ppwa.IdEnterprisePriceProjection_WorkflowAction = ppw.IdLastAction
    )
    SELECT t2.*, t1.Customer, t1.Description, t1.SalePrice_Demand_CurveABC,
        t1.custo_projecao, t1.p_sem_regra_projecao, t1.p_projecao, t1.d_projecao, t1.IsManual, t1.Manual_Price, t1.Manual_Price_Demand,
        Case When ABS(t3.Elasticity) <= 1 THEN 'Inelástico'
            Else 'Elástico' END AS [Elasticidade]
    FROM tb_num AS t1
    JOIN tb_str AS t2
    ON {Granularidade_join_operation}
    LEFT JOIN enterprise_ElasticityNew as t3
    ON t1.IdElasticity = t3.Identerprise_ElasticityNew
    """
    logger.info(
        f"Collecting price projection data from Enterprise_Prices_Projection for PriceGroup: {PriceGroup}."
    )
    dados_projecao_predify = pd.read_sql_query(
        query_dados_projecao_predify, sql_raw_conn
    )
    dados_projecao_predify.loc[
        (dados_projecao_predify["IsManual"] == 1)
        & (dados_projecao_predify["Approval"] == "Aprovado"),
        "p_projecao",
    ] = dados_projecao_predify["Manual_Price"]
    dados_projecao_predify.loc[
        (dados_projecao_predify["IsManual"] == 1)
        & (dados_projecao_predify["Approval"] == "Aprovado"),
        "d_projecao",
    ] = dados_projecao_predify["Manual_Price_Demand"]
    logger.debug(f"{PriceGroup} Projection shape: {dados_projecao_predify.shape}")
    return dados_projecao_predify

def get_forward_sales(
    sql_raw_conn,
    idCompany,
    Granularidade,
    price_var,
    df_periods,
    Granularidade_sql,
    filter_clause,
):
    warnings.filterwarnings("ignore", category=UserWarning)
    df_periods.loc[:, "NextPriceDate"] += pd.Timedelta(days=1)
    df_periods['PublishedDate'] = df_periods['PublishedDate'] + pd.Timedelta(days=1)
    Unique_Periods_tuples = df_periods[['PublishedDate', 'NextPriceDate']].drop_duplicates().apply(tuple, axis=1).tolist()
    for unique_period in Unique_Periods_tuples:
        query_dados_posteriores = f"""
        SELECT PbCost, Quantity, {price_var}, {Granularidade_sql},
            ROW_NUMBER() OVER (PARTITION BY {Granularidade_sql} ORDER BY Issuance DESC) AS ordem
        FROM Enterprise_Sales_History WITH (NOLOCK)
        WHERE idcompany={idCompany}
            AND Issuance >= '{formato_consulta(unique_period[0])}'
            AND Issuance < '{formato_consulta(unique_period[1])}'
            {filter_clause}
        """
        logger.debug("query_dados_posteriores: %s", query_dados_posteriores)
        logger.info(
            f"Collecting sales data from Enterprise_Sales_History for idCompany: {idCompany} between {unique_period[0]} and {unique_period[1]}."
        )

        dados_posteriores = pd.read_sql_query(query_dados_posteriores, sql_raw_conn)

        last_price = dados_posteriores[dados_posteriores["ordem"] == 1].copy()
        last_price.drop(["Quantity", "ordem"], axis=1, inplace=True)
        dados_posteriores["Receita"] = (
            dados_posteriores["Quantity"] * dados_posteriores[price_var]
        )

        qtd = dados_posteriores.groupby(Granularidade, as_index=False).agg(
            p_dps_mean=pd.NamedAgg(price_var, "mean"),
            custo_dps_mean=pd.NamedAgg("PbCost", "mean"),
            q_dps_sum=pd.NamedAgg("Quantity", "sum"),
            q_dps_mean=pd.NamedAgg("Quantity", "mean"),
            receita_dps_sum=pd.NamedAgg("Receita", "sum"),
        )
        dados_posteriores = qtd.merge(last_price, on=Granularidade, how="inner")
        dados_posteriores.rename(columns=lambda x: x.replace("_x", ""), inplace=True)
        dados_posteriores.rename(
            columns={
                "PbCost": "custo_dps",
                price_var: "p_dps",
            },
            inplace=True,
        )

        df_periods.loc[
            (df_periods['PublishedDate'] == unique_period[0]) & (df_periods['NextPriceDate'] == unique_period[1]),
            ['q_dps_sum', 'p_dps_mean', 'custo_dps_mean', 'receita_dps_sum']
        ] = dados_posteriores[['q_dps_sum', 'p_dps_mean', 'custo_dps_mean', 'receita_dps_sum']]
        del last_price, qtd

    logger.debug(f"{idCompany} Forward Sales shape: {dados_posteriores.shape}")

    return dados_posteriores


def get_lookback_sales(
    sql_raw_conn,
    idCompany,
    Granularidade,
    price_var,
    df_periods,
    Granularidade_sql,
    filter_clause,
):
    warnings.filterwarnings("ignore", category=UserWarning)
    df_periods.loc[:, "LookbackPriceDate"] += pd.Timedelta(days=1)
    df_periods['PublishedDate'] = df_periods['PublishedDate'] + pd.Timedelta(days=1)
    Unique_Periods_tuples = df_periods[['PublishedDate', 'LookbackPriceDate']].drop_duplicates().apply(tuple, axis=1).tolist()
    for unique_period in Unique_Periods_tuples:
        query_dados_lookback = f"""
        SELECT PbCost, Quantity, {price_var}, {Granularidade_sql},
            ROW_NUMBER() OVER (PARTITION BY {Granularidade_sql} ORDER BY Issuance DESC) AS ordem
        FROM Enterprise_Sales_History WITH (NOLOCK)
        WHERE idcompany={idCompany}
            AND Issuance >= '{formato_consulta(unique_period[1])}'
            AND Issuance < '{formato_consulta(unique_period[0])}'
            {filter_clause}
        """
        logger.debug("query_dados_posteriores: %s", query_dados_lookback)
        logger.info(
            f"Collecting sales data from Enterprise_Sales_History for idCompany: {idCompany} between {unique_period[1]} and {unique_period[0]}."
        )

        dados_lookback = pd.read_sql_query(query_dados_lookback, sql_raw_conn)

        last_price = dados_lookback[dados_lookback["ordem"] == 1].copy()
        last_price.drop(["Quantity", "ordem"], axis=1, inplace=True)
        dados_lookback["Receita"] = dados_lookback["Quantity"] * dados_lookback[price_var]

        qtd = dados_lookback.groupby(Granularidade, as_index=False).agg(
            p_antes_mean=pd.NamedAgg(price_var, "mean"),
            custo_antes_mean=pd.NamedAgg("PbCost", "mean"),
            q_antes_sum=pd.NamedAgg("Quantity", "sum"),
            q_antes_mean=pd.NamedAgg("Quantity", "mean"),
            receita_antes_sum=pd.NamedAgg("Receita", "sum"),
        )
        dados_lookback = qtd.merge(last_price, on=Granularidade, how="inner")
        dados_lookback.rename(columns=lambda x: x.replace("_x", ""), inplace=True)
        dados_lookback.rename(
            columns={
                "PbCost": "custo_antes",
                price_var: "p_antes",
            },
            inplace=True,
        )

        df_periods.loc[
            (df_periods["PublishedDate"] == unique_period[0])
            & (df_periods["LookbackPriceDate"] == unique_period[1]),
            ["q_antes_sum", "p_antes_mean", "custo_antes_mean", "receita_antes_sum"],
        ] = dados_lookback[
            ["q_antes_sum", "p_antes_mean", "custo_antes_mean", "receita_antes_sum"]
        ]
        del last_price, qtd

    logger.debug(f"{idCompany} Lookback Sales shape: {dados_lookback.shape}")
    return dados_lookback


def get_applied_prices(
    sql_raw_conn,
    idCompany,
    Data_Referencia,
    price_var,
    df_periods,
    Granularidade_sql,
    granularidade,
    filter_clause,
):
    warnings.filterwarnings("ignore", category=UserWarning)
    df_periods.loc[:, "NextPriceDate"] += pd.Timedelta(days=1)
    df_periods['PublishedDate'] = df_periods['PublishedDate'] + pd.Timedelta(days=1)
    max_next_date = df_periods['NextPriceDate'].max()
    query_dados_posteriores = f"""
    SELECT PbCost, Quantity, {price_var}, {Granularidade_sql}, Issuance,
        ROW_NUMBER() OVER (PARTITION BY {Granularidade_sql} ORDER BY Issuance DESC) AS ordem
    FROM Enterprise_Sales_History WITH (NOLOCK)
    WHERE idcompany={idCompany}
        AND Issuance >= '{formato_consulta(Data_Referencia)}'
        AND Issuance < '{formato_consulta(max_next_date)}'
        {filter_clause}
    """
    logger.debug("query_dados_posteriores: %s", query_dados_posteriores)
    logger.info(
        f"Collecting sales data from Enterprise_Sales_History for idCompany: {idCompany} between {Data_Referencia} and {max_next_date}."
    )
    dados_posteriores = pd.read_sql_query(query_dados_posteriores, sql_raw_conn)
    logger.debug(f"{idCompany} Forward Sales shape: {dados_posteriores.shape}")
    dados_posteriores["ProductId"] = build_product_id(dados_posteriores, granularidade)
    dados_posteriores = pd.merge(dados_posteriores, df_periods[["ProductId", "NextPriceDate"]], how="inner")
    if not dados_posteriores.empty:
        dados_posteriores["NextPriceDate"] = dados_posteriores["NextPriceDate"].dt.tz_localize(None)
        dados_posteriores = dados_posteriores.loc[dados_posteriores['Issuance'] <= dados_posteriores['NextPriceDate'], :]
    return dados_posteriores


def generate_report(
    sql_raw_conn,
    idCompany: int,
    PriceGroup: int,
    Data_Referencia: dt.datetime,
    Granularidade: list,
    price_var: str,
    df_periods: pd.DataFrame,
):
    logger.info(
        f"Generating report for idCompany: {idCompany} and PriceGroup: {PriceGroup}."
    )
    Granularidade_sql = ", ".join(Granularidade)
    Granularidade_join_operation = " AND ".join(
        [f"t1.{g} = t2.{g}" for g in Granularidade]
    )

    dados_projecao_predify = get_price_projection(
        sql_raw_conn, PriceGroup, Granularidade_sql, Granularidade_join_operation
    )

    filter_clause = get_filter_clause(Granularidade, dados_projecao_predify)

    dados_anteriores = get_lookback_sales(
        sql_raw_conn,
        idCompany,
        Granularidade,
        price_var,
        df_periods,
        Granularidade_sql,
        filter_clause,
    )

    dados_posteriores = get_forward_sales(
        sql_raw_conn,
        idCompany,
        Granularidade,
        price_var,
        df_periods,
        Granularidade_sql,
        filter_clause,
    )
    logger.debug(dados_projecao_predify.shape)
    df_projection = dados_projecao_predify.merge(
        dados_anteriores, on=Granularidade, how="left"
    ).merge(dados_posteriores, on=Granularidade, how="left")
    df_projection["ProductId"] = build_product_id(df_projection, Granularidade)
    logger.debug(f"{idCompany} Merged Projection shape: {df_projection.shape}")

    shape_pre = df_periods.shape
    df_projection = pd.merge(
        df_periods[["ProductId", "Impact_days"]], df_projection, how="inner"
    )
    if df_projection.shape[0] != shape_pre[0]:
        raise ConsistencyError("lost rows when merging with df_periods")

    df_projection["Data da Precificação"] = Data_Referencia
    df_projection["Impact_days"] = pd.to_timedelta(df_projection["Impact_days"])
    df_projection["d_projecao_periodo"] = (
        df_projection["d_projecao"] * df_projection["Impact_days"].dt.days
    )
    quantity_columns = ["q_antes_sum", "q_dps_sum"]
    df_projection[quantity_columns] = df_projection[quantity_columns].fillna(0)

    logger.debug(f"{idCompany} Projection shape: {df_projection.shape}")

    df_projection["lucro_antes_mean"] = df_projection["receita_antes_sum"] - (
        df_projection["q_antes_sum"] * df_projection["custo_antes_mean"]
    )
    df_projection["lucro_dps_mean"] = df_projection["receita_dps_sum"] - (
        df_projection["q_dps_sum"] * df_projection["custo_dps_mean"]
    )

    df_projection["lucro_antes_mean"] = df_projection["lucro_antes_mean"].fillna(0)
    df_projection["lucro_dps_mean"] = df_projection["lucro_dps_mean"].fillna(0)

    df_projection["margem_antes_mean"] = df_projection[
        "lucro_antes_mean"
    ] / df_projection["receita_antes_sum"].fillna(0)
    df_projection["margem_dps_mean"] = df_projection["lucro_dps_mean"] / df_projection[
        "receita_dps_sum"
    ].fillna(0)

    colunas_fixas = [
        "Data da Precificação",
        "Description",
        "IdEnterprisePricesProjection",
        "custo_antes",
        "custo_antes_mean",
        "custo_projecao",
        "custo_dps",
        "custo_dps_mean",
        "p_antes",
        "p_antes_mean",
        "p_projecao",
        "p_dps",
        "p_dps_mean",
        "d_projecao",
        "q_antes_sum",
        "d_projecao_periodo",
        "q_dps_sum",
        "Elasticidade",
        "SalePrice_Demand_CurveABC",
        "receita_antes_sum",
        "receita_dps_sum",
        "lucro_antes_mean",
        "lucro_dps_mean",
        "margem_antes_mean",
        "margem_dps_mean",
        "Impact_days",
    ]

    colunas_finais = colunas_fixas + Granularidade
    df_projection = df_projection[colunas_finais].copy()
    logger.debug(f"{idCompany} Final Projection shape: {df_projection.shape}")
    logger.info("Report generated successfully.")
    logger.info(
        "Collecting applied prices data from Enterprise_Sales_History further period."
    )

    df_applied_prices = get_applied_prices(
        sql_raw_conn,
        idCompany,
        Data_Referencia,
        price_var,
        df_periods,
        Granularidade_sql,
        Granularidade,
        filter_clause,
    )
    return df_projection, df_applied_prices


def recalculate_metrics(df_report):
    logger.info("Recalculating metrics for the report.")
    df_report["d_projecao_periodo"] = df_report["d_projecao"] * df_report["Impact_days"].dt.days
    df_report["receita_projecao"] = df_report["d_projecao_periodo"] * df_report[
        "p_projecao"
    ].fillna(0)
    df_report["receita_projecao"] = df_report["receita_projecao"].astype(float) + 1e-6
    df_report["lucro_projecao"] = df_report["receita_projecao"] - (
        df_report["d_projecao_periodo"] * df_report["custo_projecao"]
    )
    df_report["margem_projecao"] = df_report["lucro_projecao"] / df_report[
        "receita_projecao"
    ].fillna(0)
    return df_report


def prepare_report(
    pg_conn, pg_metadata, df_report, idCompany, Granularity, Published_Date
):
    logger.info("Preparing report for insertion.")
    df_report["CompanyId"] = idCompany
    df_report["ProductId"] = build_product_id(df_report, Granularity)
    df_report["CreatedDate"] = dt.datetime.now()
    df_report["UpdatedDate"] = dt.datetime.now()
    df_report["YearMonth"] = int(Published_Date.strftime("%Y%m"))
    df_report["GranularityGroupId"] = get_granularity_id(
        pg_conn, pg_metadata, idCompany
    )
    df_report = df_report.replace(np.nan, None)
    df_report.rename(
        columns={
            "IdEnterprisePricesProjection": "PriceProjectionId",
            "IdEnterprisePriceGroups": "PriceGroupId",
            "Data da Precificação": "Pricing Date",
            "Description": "Product Description",
            "custo_antes_mean": "PriorCost",
            "custo_projecao": "ProjectionCost",
            "custo_dps_mean": "RealCost",
            "p_antes_mean": "PriorPrice",
            "p_projecao": "ProjectionPrice",
            "p_dps_mean": "RealPrice",
            "q_antes_sum": "PriorDemand",
            "d_projecao_periodo": "ProjectionDemand",
            "q_dps_sum": "RealDemand",
            "receita_antes_sum": "PriorRevenue",
            "receita_projecao": "ProjectionRevenue",
            "receita_dps_sum": "RealRevenue",
            "lucro_antes_mean": "PriorProfit",
            "lucro_projecao": "ProjectionProfit",
            "lucro_dps_mean": "RealProfit",
            "margem_antes_mean": "PriorMargin",
            "margem_projecao": "ProjectionMargin",
            "margem_dps_mean": "RealMargin",
        },
        inplace=True,
    )
    logger.info("Report prepared successfully.")

    if "Affiliate" not in df_report:
        df_report["Affiliate"] = None

    df_report = df_report[
        [
            "PriceProjectionId",
            "PriceGroupId",
            "GranularityGroupId",
            "ProductId",
            "Pricing Date",
            "Product Description",
            "PriorCost",
            "ProjectionCost",
            "RealCost",
            "PriorPrice",
            "ProjectionPrice",
            "RealPrice",
            "PriorDemand",
            "ProjectionDemand",
            "RealDemand",
            "PriorRevenue",
            "ProjectionRevenue",
            "RealRevenue",
            "PriorProfit",
            "ProjectionProfit",
            "RealProfit",
            "PriorMargin",
            "ProjectionMargin",
            "RealMargin",
            "Adopted",
            "CreatedDate",
            "UpdatedDate",
            "YearMonth",
            "CompanyId",
            "HasSuggestion",
            "Affiliate",
        ]
    ]
    logger.debug(f"Final Report shape: {df_report.shape}")
    return df_report
