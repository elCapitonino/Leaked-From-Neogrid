from dataclasses import dataclass
from enum import Enum
from typing import Optional
from uuid import UUID

from sqlalchemy import MetaData, Table, func, literal, select

from src.db import PostgreSQLConnection
from src.exceptions import ConfigError
from src.logger import logger


class GranularityType(Enum):
    NONE = 0
    PROJECTION = 1
    ELASTICITY = 2
    CONSOLIDATED = 3


@dataclass
class GranularityLevel:
    level_id: UUID
    description: Optional[str]
    field_key: str
    field_value: str


@dataclass
class GranularityGroup:
    group_id: UUID
    granularity_levels: list[GranularityLevel]

    def to_columns(self) -> list[str]:
        return [level.field_key for level in self.granularity_levels]


def load_granularity(
    *,
    pg_conn: PostgreSQLConnection,
    metadata: MetaData,
    id_company: int,
    granularity_type: GranularityType,
) -> GranularityGroup:
    logger.debug(
        "loading granularity of type %s for id_company %d", granularity_type, id_company
    )

    table_granularity_group = Table("GranularityGroup", metadata, autoload_with=pg_conn)
    table_granularity_level = Table("GranularityLevel", metadata, autoload_with=pg_conn)

    query_gran_group = (
        select(table_granularity_group.c.Id)
        .where(
            table_granularity_group.c.CompanyId == id_company,
            table_granularity_group.c.GranularityType == granularity_type.value,
        )
        .order_by(
            func.coalesce(
                table_granularity_group.c.UpdatedDate,
                table_granularity_group.c.CreatedDate,
            ).desc()
        )
        .limit(1)
    )
    logger.debug(
        "granularity group subquery:\n%s\nparams: %s",
        query_gran_group,
        query_gran_group.compile().params,
    )
    result = pg_conn.execute(query_gran_group).fetchone()

    if result is None:
        raise ConfigError(
            f"missing granularity configuration of type {granularity_type} for id_company = {id_company}"
        )

    group_id = result[0]
    logger.debug("found granularity group with ID %s", group_id)

    level_subquery = (
        select(
            table_granularity_level.c.Id,
            table_granularity_level.c.ParentId,
            table_granularity_level.c.Description,
            table_granularity_level.c.FieldKey,
            table_granularity_level.c.FieldValue,
        )
        .where(
            table_granularity_level.c.GranularityGroupId == group_id,
        )
        .subquery("level_subquery")
    )
    logger.debug(
        "granularity level subquery:\n%s\nparams: %s",
        level_subquery,
        level_subquery.compile().params,
    )

    cte_recursive = (
        select(
            level_subquery.c.Id,
            level_subquery.c.ParentId,
            level_subquery.c.Description,
            level_subquery.c.FieldKey,
            level_subquery.c.FieldValue,
            literal(1).label("level"),
        )
        .where(level_subquery.c.ParentId.is_(None))
        .cte("parent_cte", recursive=True)
    )

    cte_recursive = cte_recursive.union_all(
        select(
            level_subquery.c.Id,
            level_subquery.c.ParentId,
            level_subquery.c.Description,
            level_subquery.c.FieldKey,
            level_subquery.c.FieldValue,
            (cte_recursive.c.level + 1).label("level"),
        ).join(cte_recursive, cte_recursive.c.Id == level_subquery.c.ParentId)
    )

    stmt = select(
        cte_recursive.c.Id,
        cte_recursive.c.Description,
        cte_recursive.c.FieldKey,
        cte_recursive.c.FieldValue,
    ).order_by(cte_recursive.c.level)

    logger.debug(
        "granularity query:\n%s\nparams: %s",
        stmt,
        stmt.compile().params,
    )
    levels = [GranularityLevel(*row) for row in pg_conn.execute(stmt)]
    group_id = GranularityGroup(group_id=group_id, granularity_levels=levels)
    return group_id
