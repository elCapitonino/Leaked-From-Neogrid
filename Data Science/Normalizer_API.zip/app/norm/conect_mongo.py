from pymongo import MongoClient
from norm.config import *
from bson import ObjectId
from norm.config import *


class MongoConnect:
    def __init__(self):

        try:
            self.client = MongoClient(
                Server['host'], username=Server["user"], password=Server["password"], authMechanism='DEFAULT')
            # CONNECTION_STRING = "mongodb+srv://teste:d51JopruGt8DzIFl@cluster0.3rvbz.mongodb.net/myFirstDatabase?retryWrites=true&w=majority"
            # self.client = MongoClient(CONNECTION_STRING)
            self.database_normalizer = self.client['normalizer']
            self.database_dictionary = self.client['dictionary']

            self.products_to_insert = []
            self.products_to_delete = []
            self.prices_to_insert = []
            self.log_normalizer_to_insert = []
            self.product_failed = []
            self.products_netshoes = []
            self.quantityToNormalize = 50


            print(" ------ mongo iniciado  ------")
        except Exception:
            print(" ------ mongo não iniciado  ------")

    def set_quantityToNormalize(self, quantity = 50):
        if (quantity < 50):
            quantity = 50

        self.quantityToNormalize = quantity

    def get_quantityToNormalize(self):
        return self.quantityToNormalize

    def get_cache(self):
        return {
            "ProductToInsert": len(self.products_to_insert) ,
            "PricesToInsert": len(self.prices_to_insert),
            "ProductsFailed":len(self.product_failed),
            "ProductsToDelete": len(self.products_to_delete),
            "LogNormalizrToInsert": len(self.log_normalizer_to_insert)
        }

    def get_dict_brands(self):
        #brands = self.client.dictionary.dict_brands.find()
        brands = self.database_dictionary.dict_brands.aggregate(
            [
                {
                    '$group': {
                        '_id': '$language',
                        'data': {
                            '$push': '$$ROOT'
                        }
                    }
                }
            ]
        )
        return brands

    def get_dict_categories(self):
        categories = self.database_dictionary.dict_categories.aggregate(
            [
                {
                    '$group': {
                        '_id': '$language',
                        'data': {
                            '$push': '$$ROOT'
                        }
                    }
                }
            ]
        )
        return categories

    def get_dict_materials(self):
        materials = self.database_dictionary.dict_materials.aggregate(
            [
                {
                    '$group': {
                        '_id': '$language',
                        'data': {
                            '$push': '$$ROOT'
                        }
                    }
                }
            ]
        )
        return materials

    def get_dict_metric_units(self):
        metric_units = self.database_dictionary.dict_metric_units.aggregate(
            [
                {
                    '$group': {
                        '_id': '$language',
                        'data': {
                            '$push': '$$ROOT'
                        }
                    }
                }
            ]
        )
        return metric_units

    def get_dict_products(self):
        #products = self.client.dictionary.dict_products.find()
        products = self.database_dictionary.dict_products.aggregate(
            [
                {
                    '$group': {
                        '_id': '$language',
                        'data': {
                            '$push': '$$ROOT'
                        }
                    }
                }
            ]
        )
        return products

    def get_dict_products_synonyms(self):
        products = self.database_dictionary.dict_products.find()
        return products

    def get_dict_voltage(self):
        voltage = self.database_dictionary.dict_voltage.aggregate(
            [
                {
                    '$group': {
                        '_id': '$language',
                        'data': {
                            '$push': '$$ROOT'
                        }
                    }
                }
            ]
        )
        return voltage

    def get_dict_power(self):
        power = self.database_dictionary.dict_power.aggregate(
            [
                {
                    '$group': {
                        '_id': '$language',
                        'data': {
                            '$push': '$$ROOT'
                        }
                    }
                }
            ]
        )
        return power

    def get_dict_energy_source(self):
        energy_source = self.database_dictionary.dict_energy_source.aggregate(
            [
                {
                    '$group': {
                        '_id': '$language',
                        'data': {
                            '$push': '$$ROOT'
                        }
                    }
                }
            ]
        )
        return energy_source

    def get_dict_dimensions(self):
        dimensions = self.database_dictionary.dict_dimensions.aggregate(
            [
                {
                    '$group': {
                        '_id': '$language',
                        'data': {
                            '$push': '$$ROOT'
                        }
                    }
                }
            ]
        )
        return dimensions

    def get_dict_size(self):
        dict_size = self.database_dictionary.dict_size.aggregate(
            [
                {
                    '$group': {
                        '_id': '$language',
                        'data': {
                            '$push': '$$ROOT'
                        }
                    }
                }
            ]
        )
        return dict_size

    def get_dict_state(self):
        state = self.database_dictionary.dict_state.aggregate(
            [
                {
                    '$group': {
                        '_id': '$language',
                        'data': {
                            '$push': '$$ROOT'
                        }
                    }
                }
            ]
        )
        return state

    def get_products_normalized(self):
        list_language = self.get_language()
        # print(list_language)

        products_normalized_language = []
        # list_language = ['en-us', 'pt-br']
        for language in list_language:
            products_normalized = self.database_normalizer.products_normalized.find(
                {'language': language})
            products_normalized_language.append(
                {'_id': language, 'data': list(products_normalized)})
        return products_normalized_language

    def get_language(self):
        language_product = self.database_normalizer.products_normalized.aggregate(
            [
                {
                    '$match': {
                        'language': {
                            '$exists': True
                        }
                    }
                }, {
                    '$group': {
                        '_id': '$language',
                        'data': {
                            '$first': '$$ROOT'
                        }
                    }
                }, {
                    '$project': {
                        '_id': '$data.language'
                    }
                }
            ]
        )
        language = []
        for product in language_product:
            language.append(product['_id'])

        return language

        # products_normalized = self.client.normalizer.products_normalized.aggregate(
        #     [
        #         {
        #             '$group': {
        #                 '_id': '$language',
        #                 'data': {
        #                     '$last': '$$ROOT'
        #                 }
        #             }
        #         }
        #     ]
        # )

    def get_products_to_normalize(self, idCompanyPriority: int = 0):
        if (idCompanyPriority <= 0):
            products_to_normalize = self.database_normalizer.products_to_normalize.find().sort('crawler_date',-1).limit(self.quantityToNormalize)
        else:
            products_to_normalize = self.database_normalizer.products_to_normalize.find({'id_company': idCompanyPriority}).sort('crawler_date',-1).limit(self.quantityToNormalize)
        return products_to_normalize
        # return []

    def get_products_Renormalization(self, crawler_id, start_date, end_date):

        products_prices = self.database_normalizer.product_prices.find(
            {"$and": [{'id_crawler': crawler_id}, {'crawler_date': {'$gte': start_date, '$lt': end_date}}]})

        # products_prices = self.client.normalizer.product_prices.find(
        #     {'id_crawler': {'$in': crawler_id}, 'crawler_date': {'$gte': start_date, '$lt': end_date}}).limit(10)

        # products_prices = self.client.normalizer.product_prices.find(
        #     {"id_crawler": crawler_id})
        return products_prices

    def get_products_failed(self, crawler_id):
        products_failed = self.database_normalizer.products_failed_to_normalize.find(
            {"id_crawler": crawler_id})
        return products_failed

    def flush(self):
        if (len(self.products_to_insert) > 0):
            self.database_normalizer.products_normalized.insert_many(self.products_to_insert)
            self.products_to_insert.clear()
        
        if (len(self.prices_to_insert) > 0):
            self.database_normalizer.product_prices.insert_many(self.prices_to_insert)
            self.prices_to_insert.clear()
        
        if (len(self.product_failed) > 0):
            self.database_normalizer.products_failed_to_normalize.insert_many(self.product_failed)
            self.product_failed.clear()

        if (len(self.products_to_delete) > 0):
            self.database_normalizer.products_to_normalize.delete_many({'_id': {'$in':  self.products_to_delete}})
            self.products_to_delete.clear()
        
        if (len(self.log_normalizer_to_insert) > 0):
            self.database_normalizer.log_products_normalized.insert_many(self.log_normalizer_to_insert)
            self.log_normalizer_to_insert.clear()
            

    ############################################################################
    # i["_id"], product, product_model, ean, ncm, i["id_crawler"]
    def register_norm(self, _id, products):

        #print("products: ", products)

        self.products_to_insert.append(products)

        # id_norm = self.database_normalizer.products_normalized.insert_one(
        #     products)

        # a = self.database_normalizer.products_to_normalize.delete_one({
        #     "_id": _id})

        return products["_id"], products

    def register_renorm(self, products):

        id_norm = self.database_normalizer.products_normalized.insert_one(
            products)

        return id_norm, products

    def update_price(self, _id_norm, i, trash):
        # print(i)
        id_to_normalize = i['_id']
        i.pop('_id')
        i.update({'_id': ObjectId()})
        # print(_id_norm)

        i.update({"id_product_normalized": str(_id_norm)})
        i.update({"trash": trash})
        # print("---------------------------------------------")

        # print(i)

        # id_prices = self.database_normalizer.product_prices.insert_one(i)
        self.prices_to_insert.append(i)
        self.products_to_delete.append(id_to_normalize)

        # self.database_normalizer.products_to_normalize.delete_one({
        #     "_id": id_to_normalize})

        return i['_id']
        ''' 

        for j in i['sellers']:
            # print(" -------------------------- ")
            # print(j['stock_quantity'])
            stock_quantity = j['stock_quantity']
            for k in j['prices']:
                # print(k)
                prices = k

        # print(" -------------------------- ")

        # print("_id_norm: ", _id_norm)
        # print("i: ", i)
        # print(" ---------------------- ")

        a = {
            "id_product_normalized": _id_norm,
            "prices": prices,
            "shipping": shipping,
            "stock_quantity": stock_quantity,
            "product_name": i["product_name"],
            "product_link": product_link,
            "product_ean": ean,
            "idcrawler": i["id_crawler"],
            "site_sku": site_sku,
            "crawler_date": i["crawler_date"],

        }
        '''

        # print(i['_id'])
        # 'fonte': i['fonte']

        # print("inserted normalizer.product_prices ")

    def insert_price_failed(self, _id_norm, i):

        # print(i)
        id_to_normalize = i['_id']
        i.pop('_id')
        # print(_id_norm)
        i.update({"id_product_normalized": str(_id_norm)})

        idprice = self.database_normalizer.product_prices.insert_one(i)

        #print("ID 3 ", id_to_normalize)

        rest = self.database_normalizer.products_failed_to_normalize.delete_one(
            {"_id": id_to_normalize})

        return idprice.inserted_id

        #print("deleted: ", rest.deleted_count, " _id: ", id_to_normalize)
    def insert_products_netshoes(self, product_netshoes):
        try:
            self.database_normalizer.products_netshoes.insert_one(product_netshoes)
        except Exception as ex:
            print(ex)


    def insert_failed_to_normalize(self, produt_failed, log):
        # print("log ", log)
        produt_failed.update({"log": log})
        # print(produt_failed)

        id_produt_failed = produt_failed['_id']
        produt_failed.pop('_id')

        self.product_failed.append(produt_failed)
        self.products_to_delete.append(id_produt_failed)

        # self.database_normalizer.products_failed_to_normalize.insert_one(
        #     produt_failed)
        # self.database_normalizer.products_to_normalize.delete_one(
        #     {"_id": id_produt_failed})

    def update_renorm_state_horus_years(self, id_prod, label, update_state_horus_years):

        # print("id_prod: ", id_prod, "label: ", label,
        #       "update_state_horus_years: ", update_state_horus_years)

        id_mod = self.database_normalizer.product_prices.update_one(
            {"_id": id_prod}, {"$set": {label: update_state_horus_years}})

        #print("id_mod: ", id_mod.modified_count)

        # return id_prod

    def update_renorm_price(self, id_norm_new, id_prod):

        #print("id_norm_new: ", id_norm_new, " id_prod: ", id_prod)

        id_mod = self.database_normalizer.product_prices.update_one(
            {"_id": id_prod}, {"$set": {"id_product_normalized": id_norm_new}})

        #print("Atualizado id : ", id_mod.modified_count)

        return id_prod

    def insert_log_normalizer(self, log):
        self.log_normalizer_to_insert.append(log)
        # self.client.log.log_products_normalized.insert_one(log)

    def update_renormalizer_product_name(self, id_prod, product_name, label):

        self.database_normalizer.product_prices.update_one(
            {"_id": id_prod}, {"$set": {label: product_name}})

    ############################## precificação dinamica #######################
    # def get_calculated_status(self):

    #     # return self.client.log.log_crawler_status.find({"$and": [{"status": "Ended"}, {"isCalculated": False},{"$or":[{}]}]})
    #     return self.client.log.log_crawler_status.find({"$and": [{"status": "Ended"}, {"$or": [{"isCalculated": False}, {"isCalculated": {"$exists": False}}]}]})

    # def get_id_task_to_norm(self, id_task):

    #     return self.database_normalizer.products_to_normalize.find({"id_task": str(id_task)}).limit(1)

    # def update_id_task_to_norm(self, id_):

    #     self.client.log.log_crawler_status.update_many(
    #         {"id_task": str(id_)}, {"$set": {"isCalculated": True}})
