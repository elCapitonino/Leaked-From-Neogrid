﻿using DI.Repository.Attributes;
using DI.Repository.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DI.Repository.TypeConfiguration
{
    [UseSQLContext]
    public class EnterprisePriceProjection_WorkflowActionTypeConfiguration : TypeConfigurationBase<EnterprisePriceProjection_WorkflowActionEntity>, IEntityTypeConfiguration<EnterprisePriceProjection_WorkflowActionEntity>
    {
        public override void Configure(EntityTypeBuilder<EnterprisePriceProjection_WorkflowActionEntity> builder)
        {
            ConfigureTableName(builder, "EnterprisePriceProjection_WorkflowAction");
            builder.ToTable("EnterprisePriceProjection_WorkflowAction", table => table.ExcludeFromMigrations());
            builder.HasKey(x => x.EnterprisePriceProjection_WorkflowActionId);
            builder.Ignore(x => x.Id);
            builder.Ignore(x => x.UpdatedDate);
            builder.Ignore(x => x.CreatedDate);

            builder.Property(x => x.EnterprisePriceProjection_WorkflowActionId).HasColumnName("IdEnterprisePriceProjection_WorkflowAction");
            builder.Property(x => x.PriceProjection_WorkflowId).HasColumnName("IdPriceProjection_Workflow");
            builder.Property(x => x.WorkflowActionId).HasColumnName("IdWorkflowAction");
            builder.Property(x => x.UserId).HasColumnName("IdUser");
            builder.Property(x => x.IsDeleted).HasColumnName("IsDeletado");
        }
    }
}
