from models.search_v3_models import SearchHistoryV1
from async_mongo import AsyncMongoConnect

class Search_History():

    def __init__(self):
        self.dbMongo = AsyncMongoConnect()

    async def search_get_all_by_link(self, params: SearchHistoryV1):
        
        result = await self.dbMongo.search_get_all_by_link( params.product_links, params.start_date, params.end_date)
        
        response = []
        for item in result:
            for seller in item["sellers"]:
                for price in seller["prices"]:
                    r = {
                            "id_crawler": item.get("id_crawler"),
                            "product_name": item["product_name"],
                            "product_link": item["product_link"],                       
                            "crawler_date": item["crawler_date"],
                            "seller_name": seller["seller_name"],                           
                            "price": price["price"],
                            "product_description": item.get("product_description"),
                            "price_payment_type": price.get("price_payment_type"),
                            "price_unit_type": price.get("price_unit_type"),
                            "stock_quantity": seller.get("stock_quantity")
                        }
                    
                    if("installments" in price):
                        r["installments"] = price["installments"]

                    response.append(r)                                 

        return response