from datetime import datetime
from sre_parse import CATEGORIES
from fastapi import FastAPI
from norm.normalizer import Normalizer
from norm.normalizerClient import normalizerClient
from logserver import LogServer
from fastapi.concurrency import run_in_threadpool
# from pricing.dynamic_pricing import DynamicPricing
from elasticsearch import Elasticsearch

from fastapi.responses import ORJSONResponse
from pydantic import BaseModel
from typing import Optional
from typing import List
import logging

# Create a logger object
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# Create a console handler and set its level to DEBUG
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.DEBUG)

# Create a formatter and add it to the console handler
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
console_handler.setFormatter(formatter)

logger.addHandler(console_handler)

from fastapi.encoders import jsonable_encoder

import logging
from elasticsearch import Elasticsearch
from logging.handlers import TimedRotatingFileHandler

class ElasticsearchHandler(logging.Handler):
    def __init__(self, es_client, index, *args, **kwargs):
        super(ElasticsearchHandler, self).__init__(*args, **kwargs)
        self.es_client = es_client
        self.index = index

    def emit(self, record):
        try:
            log_entry = self.format(record)
            self.es_client.index(index=self.index, body={'message': log_entry})
        except Exception:
            self.handleError(record)

es = Elasticsearch('https://8518f77cd4964a2890ad7bcc8b7d3620.es.brazilsouth.azure.elastic-cloud.com:9243', http_auth=('predifyUser', 'c#@6!UKMPrSBoflS'))
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s', handlers=[ElasticsearchHandler(es, index='normalizer-')])

# python -m uvicorn main:app --reload

full_log = False


class Products(BaseModel):
    idPredify: str
    texto: str
    ean: Optional[str] = None
    ncm: Optional[str] = None
    model: Optional[str] = None
    #language: Optional[str] = None

    # result: list = None


class Product_language(BaseModel):
    language: Optional[str] = None
    # result: list = None


class List_products(BaseModel):
    id: str
    name: str
    ean: Optional[str] = None
    ncm: Optional[str] = None
    model: Optional[str] = None
    language: Optional[str] = None

####Pred monitor#########


class List_products_pred_monitor(BaseModel):
    products: Optional[List[str]] = None
    categories: Optional[List[str]] = None
    networks: Optional[List[str]] = None
    brands: Optional[List[str]] = None
    sources: Optional[List[str]] = None
    models: Optional[List[str]] = None
    language: Optional[str] = None
    exactVector: Optional[bool] = True


''' 
class Search_Products(BaseModel):

    start_date: datetime = None
    end_date: datetime = None
    products_list: Optional[List[List_products]] = None
    idcrawlers: Optional[list] = None

'''

######################################################


class List_product_client(BaseModel):
    id: str
    name: str
    language: Optional[str] = None


class Search_Client(BaseModel):
    products_client: Optional[List[List_product_client]] = None


class Control_Nomalize(BaseModel):
    id: str
    status_normalizer: bool = False


class Control_Renomalize(BaseModel):
    id: str
    start_date: datetime = None
    end_date: datetime = None
    idcrawlers: Optional[list] = None
    status_renormalization: bool = False


class Control_Renomalize_Failed(BaseModel):
    id: str
    status_renormalization_failed: bool = False


class Control_dictionaries(BaseModel):
    id: str
    status_dictionaries: bool = False


#####################################################


app = FastAPI()

norm = Normalizer()
norm.dictio_load()
norm.norm_load()
norm.norm_core_load()
norm.renorm_core_load()
#norm.controle_core_norm(False)
normClient = normalizerClient()

#D_Pricing = DynamicPricing()


@app.post("/")
def raiz(products: List[List_products]):
    logging.info('teste elastic')

    list_result = []

    # print(products)

    # print("-------------------------------")

    for product_list in products:
        # print(product_list.id)
        # print(product_list.name)
        # print(product_list.language)

        list_id_score_brand = norm.normalize_search(
            product_list.name, product_list.ean, product_list.ncm, product_list.model, product_list.id, product_list.language)

        list_result.append(list_id_score_brand)

        # print(list_id)
        # print(score)

    # print("-------------------")
    # print(len(list_result))
    results = {"products_list": list_result}
    # result_json = jsonable_encoder(results)

    #print("return : ", results)
    return results
    #         "result": list_id, "score": score}

    #list_id, score = norm.normalize_search(product.texto, product.ean, product.ncm, product.model)

    '''    
    print(type(product.end_date))
    # print(product.products_list[1].id)
    print(product.end_date)
    '''


@ app.post("/search_pred_monitor/")
async def search_pred_monitor(products: List_products_pred_monitor):

    list_result_pred = []
    # print(products.products)
    # print(products.brands)

    # for list_product in products:
    if full_log == True:
        print(products)
    result = await run_in_threadpool(lambda:norm.normalize_search_pred_monitor(products.products, products.categories,
                                                products.networks, products.brands, products.models, products.sources, products.language, full_log, products.exactVector))

    list_result_pred.append(result)
    # print(len(list_result_pred))
    results = {"products_list": list_result_pred}
    #print(" ---------------------------- ")
    #print("result ", results)
    return results


@ app.post("/search/")
async def search(products: List[Products]):
    results = []
    print(products)

    return "teste normalizer"

#########################


@app.post("/search_Client")
async def search_Client(products: Search_Client):

    #print("-------------------", products.products_client)

    product_norm = await run_in_threadpool(lambda:normClient.normalize_seearch_client(
        products.products_client))

    return product_norm


@app.post("/v1/control_norm/")
async def Control_norm(control: Control_Nomalize):
    ''' 
     True para parar
     False para continuar
     '''
    result = await run_in_threadpool(lambda:norm.controle_core_norm(control.status_normalizer))

    return result


@app.post("/v1/control_renorm/")
async def Control_renorm(control: Control_Renomalize):
    ''' 
     True para parar
     False para continuar
    '''
    # print(control)

    result = await run_in_threadpool(lambda:norm.controle_core_renorm(control))

    # return result


@app.post("/v1/control_renorm_failed/")
async def Control_renorm_Failed(control: Control_Renomalize_Failed):

    result = await run_in_threadpool(lambda:norm.controle_core_renorm_failed(
        control.status_renormalization_failed))

    return result


@app.post("/v1/control_dictionaries/")
async def control_dictionaries(control: Control_dictionaries):

    result_dict = await run_in_threadpool(lambda:norm.dictio_load(control.status_dictionaries))
    return result_dict

@ app.get("/v1/control_getQuantityToNormalize")
async def Control_GetQuantityToNormalize():
    thread_result = await run_in_threadpool(lambda: norm.get_quantityToNormalize())
    results = {"quantity": thread_result }
    return results

@ app.post("/v1/control_setQuantityToNormalize")
async def Control_SetQuantityToNormalize(quantity: int):
    await run_in_threadpool(lambda:norm.set_quantityToNormalize(quantity))
    thread_result = await run_in_threadpool(lambda:norm.get_quantityToNormalize())
    results = {"quantity": thread_result}
    return results

@ app.get("/v1/control_getCache")
async def Control_GetCache():
    return await run_in_threadpool(lambda:norm.get_cache())

@ app.get("/v1/control_priorities")
async def Control_Priorities():
    result = await run_in_threadpool(lambda:norm.controle_core_norm_getPriorities())
    results = {"priorities": result}
    return results

@app.post("/v1/control_priorities_add/")
async def Control_Priorities_Add(idCompany: int):
    await run_in_threadpool(lambda:norm.controle_core_norm_addPriority(idCompany))
    result = await run_in_threadpool(lambda:norm.controle_core_norm_getPriorities())
    results = {"priorities": result}
    return results

@app.post("/v1/control_priorities_remove/")
async def Control_Priorities_Remove(idCompany: int):
    result_dict = await run_in_threadpool(lambda:norm.controle_core_norm_removePriority(idCompany))
    result = await run_in_threadpool(lambda:norm.controle_core_norm_getPriorities())
    results = {"priorities": result}
    return results

@app.get("/v1/monitor/")
async def Control_monitor():

    result = await run_in_threadpool(lambda:norm.resource_monitor())

    #print("monitor : ", result)

    return result


@app.get("/v1/log/")
async def Control_log():

    log = LogServer()

    result_log = await run_in_threadpool(lambda:log.log_norm_serv())

    return result_log


# @app.get("/v1/dynamic_pricing/")
# async def dynamic_pricing():

#     #D_Pricing = DynamicPricing()
