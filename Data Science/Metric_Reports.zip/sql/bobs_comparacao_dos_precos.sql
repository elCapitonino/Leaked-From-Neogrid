/*
      Conferindo se o registro no relatorio esta correto:
*/
declare @prod varchar(50);
declare @affi INTEGER;
declare @prec_data varchar(15);

set @prod = '1079';
set @affi = 1813;
set @prec_data = '2023-07-03';

SELECT Product, Affiliate, EconomicGroupCode,
      AVG(SalePrice) as p_anterior, SUM(Quantity) as q_anterior
from Enterprise_Sales_History
where IdCompany = 2550
      and Product = @prod
      and affiliate = @affi
      and Issuance >= DATEADD(Day, -7, Convert(date, @prec_data))
      and Issuance < @prec_data
      and EconomicGroupCode in ('1', '2')
GROUP BY Product, Affiliate, EconomicGroupCode

SELECT Product, Affiliate, EconomicGroupCode,
      AVG(SalePrice) as p_seguinte, SUM(Quantity) as q_seguinte
from Enterprise_Sales_History
where IdCompany = 2550
      and Product = @prod
      and affiliate = @affi
      and Issuance >= @prec_data
      and Issuance < DATEADD(Day, 7, Convert(date, @prec_data))
      and EconomicGroupCode in ('1', '2')
GROUP BY Product, Affiliate, EconomicGroupCode


/*
      Conferindo a quantidade de vendas registradas no banco (apenas para os produtos que devemos precificar):
*/
SELECT count(product) as qtd_registro_Junho from enterprise_sales_history where idcompany=2550
and issuance >= '2023-06-01' and issuance < '2023-07-01' and EconomicGroupCode in ('1', '2')
and Product in (
      '1079', '10816', '10903', '3536', '452', '50018', '50023', '50028', '50033', '50185',
      '50044', '50049', '50055', '50122', '50191', '50179', '50182', '50188', '50185' 
)

SELECT count(product) as qtd_registro_Julho from enterprise_sales_history where idcompany=2550
and issuance >= '2023-07-01' and issuance < '2023-08-01' and EconomicGroupCode in ('1', '2')
and Product in (
      '1079', '10816', '10903', '3536', '452', '50018', '50023', '50028', '50033', '50185',
      '50044', '50049', '50055', '50122', '50191', '50179', '50182', '50188', '50185' 
)


/*
      Verificando cada um dos registros de vendas (apenas dos produtos que devemos precificar):
*/
select Issuance, Product, DESCRIPTION, Affiliate, AffiliateName,
      EconomicGroupCode, PbCost, SalePrice, Quantity --count(product)
from enterprise_sales_history
where idcompany=2550
and issuance >= '2023-07-01'
and issuance < '2023-08-01'
and SalePrice < 1
and EconomicGroupCode in ('1', '2')
and Product in (
      '1079', '10816', '10903', '3536', '50191',
      '50018', '50023', '50028', '50033', '50185',
      '50044', '50049', '50055', '50122', '452',
      '50179', '50182', '50188', '50185' 
)



/*
      Verificando quais sao os ids do price group
*/
SELECT *
FROM Enterprise_Price_Groups
where IdCompany=2550


/*
      Verificando se existem precificacoes para os ids do price group
*/
SELECT *
FROM Enterprise_Prices_Projection
where IdEnterprisePriceGroups = 1664
--Order BY 



/*
      Conferindo valores estranho no historico de vendas
*/
SELECT Issuance, Product, Description, Store, PbCost, Quantity, Total, SalePrice,
       CustomerName, Affiliate, AffiliateName, IdCompany, DataHoraCriacao
FROM Enterprise_Sales_History
where IdCompany= 2550
      AND Issuance >= '2023-05-01' AND Issuance < '2023-08-01'
      AND (SalePrice > 0.01 OR Quantity >= 0)
ORDER BY Issuance DESC



/*
      Query para puxar os valores projetados:
*/
SELECT * FROM (
      SELECT 
      CASE WHEN VO.IsManual IS NULL THEN PP.SalePrice
            WHEN VO.IsManual = 0 THEN VO.Price
            WHEN VO.IsManual = 1 THEN VO.Price
            END AS Preco_Ajustado,
      CASE WHEN VO.IsManual IS NULL THEN PP.SalePrice_Demand
            WHEN VO.IsManual = 0 THEN VO.Price_Demand
            WHEN VO.IsManual = 1 THEN VO.Price_Demand
            END AS Demanda_Ajustada,
      PP.PbCost, 
      PP.Product, PP.ProductName,
      PP.Affiliate, PP.AffiliateName,
      PP.EconomicGroupCode
      FROM Enterprise_Prices_Projection PP
      LEFT JOIN Enterprise_Values_Overrides VO
      ON VO.ProjectionsReference = PP.ProjectionsReference
      WHERE PP.isDeletado = 0
      AND PP.IdEnterprisePriceGroups in (2199, 2487, 2716, 2958)
      AND PP.Product in (
            '1079', '10816', '10903', '3536', '452',
            '50018', '50023', '50028', '50033', '50185',
            '50044', '50049', '50055', '50122', '50191',
            '50179', '50182', '50188', '50185' 
      )
) as A
WHERE A.Demanda_Ajustada < 0.2

