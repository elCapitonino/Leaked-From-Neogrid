using DI.Repository.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace DI.Repository.Repositories.Base
{
    public abstract class SqlGenericNoModifyRepository<TEntity> : SqlGenericRepository<TEntity> where TEntity : class, IEntity
    {
        protected SqlGenericNoModifyRepository(DbContext dbContext) : base(dbContext)
        {
        }

        public override void Delete(Guid id)
        {
            throw new NotImplementedException("Devido ao intuito da entitade n�o � para fazer altera��o no banco apenas consulta");
        }

        public override void Delete(TEntity entity, bool autosave = true)
        {
            throw new NotImplementedException("Devido ao intuito da entitade n�o � para fazer altera��o no banco apenas consulta");
        }

        public override IQueryable<TEntity> GetAll()
        {
            throw new NotImplementedException("Devido ao volume de dados e ao intuito da entitade n�o � viavel um GetAll");
        }

        public override void AddRange(IEnumerable<TEntity> entities, bool autosave = false)
        {
            throw new NotImplementedException("Devido ao intuito da entitade n�o � para fazer altera��o no banco apenas consulta");
        }

        public override TEntity Create(TEntity entity, bool autosave = true)
        {
            throw new NotImplementedException("Devido ao intuito da entitade n�o � para fazer altera��o no banco apenas consulta");
        }

        public override void Update(TEntity entity, bool autosave = true)
        {
            throw new NotImplementedException("Devido ao intuito da entitade n�o � para fazer altera��o no banco apenas consulta");
        }
    }
}
