import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from nltk.corpus import stopwords
import re
from unicodedata import normalize


class Processing:

    def __init__(self):
        print(" ------ Inicio processamento ------")

        self.stopwords = stopwords.words('portuguese')
        self.regex_limpeza = re.compile(r'nan[^\w]+')

        # '|Monitor[^\S]+'
        # '|"[^\s]+'
    # remover dados nan

    def limpeza(self, texto: str) -> str:
        texto = self.regex_limpeza.sub('', texto)
        return texto
    # separar palavras

    def tokenizador(self, texto: str) -> list:
        return re.findall(r'[\w]+', texto)
    # remover stopwords

    def remover_stopwords(self, texto_tokenizado: list) -> list:
        return [t for t in texto_tokenizado if t not in self.stopwords]

    # remove acentuação - codifica em bytes de decodifica em string
    def normalizador(self, texto: str) -> str:
        texto = texto.lower()
        return normalize('NFKD', texto).encode('latin-1', 'ignore').decode('latin-1')

    def run(self, texto: str) -> str:
        #textooriginal = texto

        # excluir dados faltantes
        texto = self.limpeza(texto)
        # letra minúscula
        texto = texto.lower()
        # print(texto)

        # separar palavras
        texto_tokenizado = self.tokenizador(texto)
        #print(texto_tokenizado ," -------- " ,textooriginal)

        # remover stopwords
        texto_tokenizado = self.remover_stopwords(texto_tokenizado)
        #print(texto_tokenizado ," -------- " ,textooriginal)

        # agrupar palavras com espaço
        texto = " ".join(texto_tokenizado)
        #print(texto ," -------- " ,textooriginal)

        # remove acentuação
        texto = self.normalizador(texto)

        # print(" -------- ", texto)

        return texto
