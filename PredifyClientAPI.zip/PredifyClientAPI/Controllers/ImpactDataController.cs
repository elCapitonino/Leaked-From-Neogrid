﻿using Asp.Versioning;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PredifyClientAPI.Services.DataInsightAPI;
using PredifyClientAPI.Services.DataInsightAPI.DataImpact.Models;

namespace PredifyClientAPI.Controllers
{
    [ApiController]
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiVersion("1.0")]
    [Authorize]
    public class ImpactDataController : ControllerBase
    {
        private readonly ILogger<ImpactDataController> _logger;
        private readonly DataInsightAPIManager _dataInsightAPIManager;

        public ImpactDataController(ILogger<ImpactDataController> logger, DataInsightAPIManager dataInsightAPIManager)
        {
            _logger = logger;
            _dataInsightAPIManager = dataInsightAPIManager;
        }

        [HttpGet("Granularities")]
        [MapToApiVersion("1.0")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<GranularityGroupResponse>))]
        [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status401Unauthorized, Type = typeof(string))]
        public async Task<IActionResult> Granularities(long companyId)
        {
            try
            {
                var response = await _dataInsightAPIManager.DataImpactDataService.GetGranularities(companyId);
                return Ok(response);
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized(ex.Message);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("MonthlyImpactData")]
        [MapToApiVersion("1.0")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<MonthlyImpactDataResponse>))]
        [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status401Unauthorized, Type = typeof(string))]
        public async Task<IActionResult> MonthlyImpactData(long companyId, int startDate, int endDate)
        {
            try
            {
                var response = await _dataInsightAPIManager.DataImpactDataService.GetMonthlyImpactData(companyId, startDate, endDate);
                return Ok(response);
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized(ex.Message);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("ProjectionImpactData")]
        [MapToApiVersion("1.0")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<ProjectionImpactDataResponse>))]
        [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status401Unauthorized, Type = typeof(string))]
        public async Task<IActionResult> ProjectionImpactData(long companyId, long priceGroupId)
        {
            try
            {
                var response = await _dataInsightAPIManager.DataImpactDataService.GetProjectionImpactData(companyId, priceGroupId);
                return Ok(response);
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized(ex.Message);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
