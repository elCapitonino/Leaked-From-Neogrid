﻿using MongoDB.Driver;
using Serilog;
using UpdateHash.Models;
using UpdateHashHorus;

namespace UpdateHash.Handlers
{
    public class NielsenVemHandler
    {
        private readonly MongoClient _client;

        public NielsenVemHandler(MongoClient client)
        {
            _client = client;
        }

        public async Task ExecuteAsync(string baseName, string collectionName, DateTime startDate, DateTime endDate, int batchSize, bool dryRun = false)
        {
            var database = _client.GetDatabase(baseName);
            var collection = database.GetCollection<NielsenVemProducts>(collectionName);

            var filter = Builders<NielsenVemProducts>.Filter.And(
                Builders<NielsenVemProducts>.Filter.Gte(doc => doc.DATE, startDate),
                Builders<NielsenVemProducts>.Filter.Lte(doc => doc.DATE, endDate)
            );

            var projection = Builders<NielsenVemProducts>.Projection
                .Include(doc => doc.PRODUCT_DESCRIPTION)
                .Include(doc => doc.EAN)
                .Include(doc => doc.STORE)
                .Include(doc => doc.STATE_UF);

            int take = batchSize;
            int skip = 0;

            while (true)
            {
                Log.Information("Buscando Produtos");

                var documents = await collection.Find(filter)
                                                 .Sort(Builders<NielsenVemProducts>.Sort.Descending(doc => doc.DATE))
                                                 .Skip(skip)
                                                 .Limit(take)
                                                 .Project<NielsenVemProducts>(projection)
                                                 .ToListAsync();

                if (documents.Count == 0)
                {
                    break;
                }

                Log.Information("Atualizando Produtos");

                var updates = new List<WriteModel<NielsenVemProducts>>();

                foreach (var doc in documents)
                {
                    var ean = doc.EAN;
                    var store = doc.STORE;
                    var state_uf = doc.STATE_UF;

                    var concatenatedString = $"{ean}|{store}|{state_uf}";

                    var hashValue = Utils.CalculateSHA256(concatenatedString);

                    var filterDoc = Builders<NielsenVemProducts>.Filter.Eq("_id", doc._id);
                    var update = Builders<NielsenVemProducts>.Update.Set("HASH", hashValue);
                    updates.Add(new UpdateOneModel<NielsenVemProducts>(filterDoc, update));
                }

                if (!dryRun)
                    await collection.BulkWriteAsync(updates);

                Log.Information($"Atualizados {skip + take} documentos");

                skip += take;
            }
        }
    }
}
