﻿using MongoDB.Bson;

namespace UpdateHash.Models
{
    public class SmarketProducts
    {
        public ObjectId _id { get; set; }
        public string ImportTaskId { get; set; }
        public DateTime? ImportDate { get; set; }
        public Produtodescricao ProdutoDescricao { get; set; }
        public Categoria Categoria { get; set; }
        public Concorrente Concorrente { get; set; }
        public Familia Familia { get; set; }
        public Loja Loja { get; set; }
        public Pesquisa Pesquisa { get; set; }
        public Pesquisaproduto PesquisaProduto { get; set; }
        public Produtoean ProdutoEan { get; set; }
        public string Segmento { get; set; }
    }

    public class Produtodescricao
    {
        public int? SEQPRODUTO { get; set; }
        public string SEQSIMILARIDADE { get; set; }
        public int? SEQFORNECEDOR { get; set; }
        public string DESCRICAO { get; set; }
        public string TIPO_EMBALAGEM { get; set; }
        public string QUANTIDADE_EMBALAGEM { get; set; }
        public string QUANTIDADE_PROPORCIONAL { get; set; }
        public string UNIDADE_EMBALAGEM { get; set; }
        public string UNIDADE_PROPORCIONAL { get; set; }
        public string MARCA { get; set; }
    }

    public class Categoria
    {
        public int? SEQCATEGORIA { get; set; }
        public int? SEQCATEGORIA_PAI { get; set; }
        public string CATEGORIA { get; set; }
    }

    public class Concorrente
    {
        public int? SEQCONCORRENTE { get; set; }
        public string CONCORRENTE { get; set; }
        public string LOGRADOURO { get; set; }
        public string NUMERO { get; set; }
        public string COMPLEMENTO { get; set; }
        public string BAIRRO { get; set; }
        public string CIDADE { get; set; }
        public string ESTADO { get; set; }
        public string PAIS { get; set; }
        public string CEP { get; set; }
        public string RAZAO_SOCIAL { get; set; }
        public string CNPJ { get; set; }
        public string IE { get; set; }
    }

    public class Familia
    {
        public int? SEQFAMILIA { get; set; }
        public string FAMILIA { get; set; }
    }


    public class Loja
    {
        public int? SEQLOJA { get; set; }
    }

    public class Pesquisa
    {
        public int? SEQPESQUISA { get; set; }
        public string DESCRICAO { get; set; }
        public DateTime? DH_INICIO { get; set; }
        public DateTime? DH_FIM { get; set; }
    }


    public class Pesquisaproduto
    {
        public int? SEQPRODUTO { get; set; }
        public string PRECO_VAREJO { get; set; }
        public string PRECO_ATACADO { get; set; }
        public string PROMOCAO { get; set; }
        public DateTime DT_PESQUISA { get; set; }
        public string QUANTIDADE_ATACADO { get; set; }
        public string OBSERVACAO { get; set; }
        public string URL { get; set; }
    }

    public class Produtoean
    {
        public string EAN { get; set; }
    }
}
