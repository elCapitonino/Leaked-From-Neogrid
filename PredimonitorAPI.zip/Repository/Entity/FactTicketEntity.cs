﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;
using MongoDB.Driver.GeoJsonObjectModel;

namespace Repository.Entity
{
    public class FactTicketEntity : BaseMongoEntity
    {
        [BsonElement("hash")]
        public string? Hash { get; set; }

        [BsonElement("id_time")]
        public DateTime? IdTime { get; set; }

        [BsonElement("cd_location")]
        public string? CdLocation { get; set; }

        [BsonElement("cd_ticket")]
        public string? CdTicket { get; set; }

        [BsonElement("cd_supplier")]
        public string? CdSupplier { get; set; }

        [BsonElement("cd_ean")]
        public string? CdEan { get; set; }

        [BsonElement("nm_item")]
        public string? NmItem { get; set; }

        [BsonElement("vl_quantity_sold")]
        public int? VlQuantitySold { get; set; }

        [BsonElement("vl_item_price")]
        public decimal? VlItemPrice { get; set; }

        [BsonElement("vl_item_discount")]
        public decimal? VlItemDiscount { get; set; }

        [BsonElement("vl_item_total_value")]
        public decimal? VlItemTotalValue { get; set; }

        [BsonElement("vl_sales_total_value")]
        public decimal? VlSalesTotalValue { get; set; }

        [BsonElement("cd_ncm")]
        public string? CdNcm { get; set; }

        [BsonElement("cd_currency")]
        public string? CdCurrency { get; set; }

        [BsonElement("cd_cnae")]
        public string? CdCnae { get; set; }

        [BsonElement("cd_state")]
        public string? CdState { get; set; }

        [BsonElement("cd_postalcode")]
        public string? CdPostalcode { get; set; }

        [BsonElement("cd_item")]
        public string? CdItem { get; set; }

        [BsonElement("ds_item")]
        public string? DsItem { get; set; }

        [BsonElement("cd_unit_measure")]
        public string? CdUnitMeasure { get; set; }

        [BsonElement("dh_created")]
        public DateTime? DhCreated { get; set; }

        [BsonElement("dh_updated")]
        public DateTime? DhUpdated { get; set; }

        [BsonElement("vl_item_addition")]
        public decimal? VlItemAddition { get; set; }

        [BsonElement("ds_billing_range")]
        public string? DsBillingRange { get; set; }

        [BsonElement("id_week_invoice")]
        public int? IdWeekInvoice { get; set; }

        [BsonElement("id_week_ingestion")]
        public int? IdWeekIngestion { get; set; }

        [BsonElement("id_year_invoice")]
        public int? IdYearInvoice { get; set; }

        [BsonElement("id_year_ingestion")]
        public int? IdYearIngestion { get; set; }

        [BsonElement("id_sequence_ingestion")]
        public int? IdSequenceIngestion { get; set; }

        [BsonElement("id_import")]
        public string? IdImport { get; set; }

        [BsonElement("coordinates")]
        public GeoJson2DGeographicCoordinatesWrapper Coordinates { get; set; }
    }

}
