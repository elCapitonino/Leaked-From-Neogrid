﻿using Dapper;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using PH.Domain.Domain;
using PH.Domain.DTO;
using PH.Domain.Interfaces.Repositories;
using PH.Domain.Settings;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PH.Data.Repositories
{
    public class ProdutosTabeladosRepository : IProdutosTabeladosRepository
    {
        private string _sQLConnectionString;
        private readonly IConfiguration _configuration;
        private readonly IMongoCollection<ProdutosTabelados> _collection;
        private static string COLLECTION_NAME = "ProdutosTabelados";
        private IDbConnection CreateSqlConnection() => new SqlConnection(_sQLConnectionString);


        public ProdutosTabeladosRepository(IConfiguration configuration,IOptions<MongoSettings> mongoSettings)
        {
            _configuration = configuration;
            _sQLConnectionString = _configuration.GetConnectionString("SQLConnectionString");
            var mongoClient = new MongoClient(mongoSettings.Value.ConnectionString);
            var mongoDatabase = mongoClient.GetDatabase(mongoSettings.Value.DatabaseName);
            _collection = mongoDatabase.GetCollection<ProdutosTabelados>(COLLECTION_NAME);
        }

        public async Task InsertMany(List<ProdutosTabelados> produtosTabelados)
        {
            await _collection.InsertManyAsync(produtosTabelados);
        }

        public async Task<List<ProdutosTabelados>> GetListProdutosTabelados(long idCompany)
        {
            var acaoPromocionals = await _collection.FindAsync(c => c.IdCompany == idCompany);
            return acaoPromocionals.ToList();
        }

        public async Task<List<LastSales>> GetLastSales(long idCompany , string affiliate)
        {
            try
            {
                IDbConnection connection = CreateSqlConnection();
                var parametros = new { IDCOMPANY = idCompany , FILIAL = affiliate};
                var result = connection.Query<LastSales>("Home_Ultimas_Vendas", parametros, commandType: CommandType.StoredProcedure, commandTimeout: 60000);

                return result.ToList();

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
