﻿namespace DI.Repository.Attributes
{
    [AttributeUsage(AttributeTargets.All, Inherited = false, AllowMultiple = true)]
    sealed class UsePostgreContextAttribute : Attribute
    {
        public UsePostgreContextAttribute()
        {
        }
    }
}
