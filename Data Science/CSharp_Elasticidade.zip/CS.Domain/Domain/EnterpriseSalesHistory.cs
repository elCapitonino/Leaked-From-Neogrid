﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CS.Domain.Domain
{
    [Table("Enterprise_Sales_History")]
    public class EnterpriseSalesHistory
    {
        [Key]
        public string IdEnterpriseSalesHistory { get; set; }
        public string? Product { get; set; }
        public string? Store { get; set; }
        public decimal? PbCost { get; set; }
        public decimal? Quantity { get; set; }
        public decimal? Total { get; set; }
        public decimal? SalePrice { get; set; }
        public string? Customer { get; set; }
        public string? CustomerName { get; set; }
        public DateTime? Issuance { get; set; }
        public string? Affiliate { get; set; }
        public string? AffiliateName { get; set; }
        public string? Description { get; set; }
        public string? Document { get; set; }
        public DateTime? DataHoraCriacao { get; set; }
        public DateTime? DataHoraUltimaAlteracao { get; set; }
        public string? CodSegment { get; set; }
        public string? NameSegment { get; set; }
        public decimal? ShippingValue { get; set; }
        public string? ProductGroup { get; set; }
        public string? EconomicGroupCode { get; set; }
        public string? EconomicGroup { get; set; }
        public long? IdCompany { get; set; }
        public long? IdProductPredify { get; set; }
        public string? InvoceNumber { get; set; }
        public string? SupplierCode { get; set; }
        public string? SupplierName { get; set; }
        public string? PackageDescription { get; set; }
        public string? PackageUnity { get; set; }
        public long? NBM { get; set; }
        public decimal? ClientSalesPrice { get; set; }
    }
}
