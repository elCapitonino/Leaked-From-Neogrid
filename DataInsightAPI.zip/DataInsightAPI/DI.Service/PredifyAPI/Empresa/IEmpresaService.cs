﻿using DI.Service.PredifyAPI.Empresa.Models;

namespace DI.Service.PredifyAPI.Empresa
{
    public interface IEmpresaService
    {
        Task<IEnumerable<EmpresaSelecionarResponse>> GetEmpresaAsync();
    }
}
