﻿using System.ComponentModel;

namespace PredifyClientAPI.Services.PredifyAPI.Models
{
    public enum AnswerType
    {
        //
        // Resumo:
        //     Success
        [Description("Informa que a requisição foi executada corretamente.")]
        Success,
        //
        // Resumo:
        //     Info
        [Description("Informa que a requisição foi executada corretamente, mas retorna alguma informação.")]
        Info,
        //
        // Resumo:
        //     Warning
        [Description("Informa que a requisição foi executada parcialmente.")]
        Warning,
        //
        // Resumo:
        //     Error
        [Description("Informa que ocorreu um erro na requisição.")]
        Error
    }
}
