﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using Repository.Attributes;
using Repository.Entity;
using MongoDB.EntityFrameworkCore.Extensions;
using Repository.DbContexts;

namespace Repository.TypeConfiguration
{
    [DbContextTypeConfiguration(typeof(LinxDbContext))]
    public class FactTicketTypeConfiguration : TypeConfigurationBase<FactTicketEntity>, IEntityTypeConfiguration<FactTicketEntity>
    {
        public override void Configure(EntityTypeBuilder<FactTicketEntity> builder)
        {
            builder.ToTable("fact_ticket").ToCollection("fact_ticket");
        }
    }
}
