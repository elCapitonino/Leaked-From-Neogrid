﻿using Newtonsoft.Json;
using Repository.Enums;
using System.Text.Json.Serialization;

namespace Domain.Models
{
    public sealed class CopilotFrontResponse
    {
        public string? Input { get; set; }
        public IEnumerable<string?>? Output { get; set; }
        public IEnumerable<CopilotOperationFront>? Operations { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string? CopilotAPIResponse { get; set; }
    }

    public sealed class CopilotOperationFront
    {
        public string? Output { get; set; }
        public bool Error { get; set; }
        public string? ErrorMessage { get; set; }
        public ECopilotOperation OperationType { get; set; }
        public CopilotOperationRuleGroupFront? RuleGroup { get; set; }
    }

    public sealed class CopilotOperationRuleGroupFront
    {
        public long? Id { get; set; }
        public string? Description { get; set; }
        public IEnumerable<CopilotOperationRuleGroupFilterFront>? Filters { get; set; }
        public string? AllowAbcCurve { get; set; }
        public EElasticityFilter? Elasticity { get; set; }
        public IEnumerable<CopilotOperationRuleGroupRuleFront>? Rules { get; set; }
    }

    public sealed class CopilotOperationRuleGroupFilterFront
    {
        public long? Id { get; set; }
        public string? Description { get; set; }
        public string? Value { get; set; }
    }

    public sealed class CopilotOperationRuleGroupRuleFront
    {
        public long? Id { get; set; }
        public ERuleType Type { get; set; }
        public IEnumerable<CopilotOperationRuleGroupRuleValueFront>? Values { get; set; }
    }

    public sealed class CopilotOperationRuleGroupRuleValueFront
    {
        public CopilotOperationRuleGroupRuleValueFront(string name)
        {
            StringValue = name;
            DecimalValue = 0;
            BooleanValue = false;
        }

        public string StringValue { get; set; }
        public float DecimalValue { get; set; }
        public bool BooleanValue { get; set; }
    }

}
