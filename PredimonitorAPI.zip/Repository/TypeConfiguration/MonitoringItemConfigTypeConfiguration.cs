﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Repository.Attributes;
using Repository.DbContexts;
using Repository.Entity;

namespace Repository.TypeConfiguration
{
    [DbContextTypeConfiguration(typeof(ApplicationDbContext))]
    public class MonitoringItemConfigTypeConfiguration : TypeConfigurationBase<MonitoringItemConfigEntity>, IEntityTypeConfiguration<MonitoringItemConfigEntity>
    {
        public override void Configure(EntityTypeBuilder<MonitoringItemConfigEntity> builder)
        {
            builder.ToTable("MonitoringItem_Config");
            builder.Property(x => x.Id).HasColumnName("IdMonitoringItem_Config");
            builder.Property(x => x.MonitoringItemId).HasColumnName("IdMonitoringItem");
            builder.HasOne(x => x.MonitoringItem);
            builder.HasOne(w => w.MonitoringItem).WithMany(b => b.Configs).HasForeignKey(w => w.MonitoringItemId);
        }
    }
}
