﻿using DI.Domain.ImpactGraph.Models;

namespace DI.Domain.ImpactGraph
{
    public interface IImpactGraphDomain
    {
        AdoptionGraphResponseModel GetAdoptionImpactGraph(long companyId, List<string> affiliateIds);
        DemandGraphResponseModel GetDemandImpactGraph(long companyId, List<string> affiliateIds);
        MarginGraphResponseModel GetMarginImpactGraph(long companyId, List<string> affiliateIds);
        ProfitGraphResponseModel GetProfitImpactGraph(long companyId, List<string> affiliateIds);
        RevenueGraphResponseModel GetRevenueImpactGraph(long companyId, List<string> affiliateIds);
    }
}
