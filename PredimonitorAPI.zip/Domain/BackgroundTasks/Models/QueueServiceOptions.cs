﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.BackgroundTasks.Models
{
    public class QueueServiceOptions
    {
        public int MaxDegreeOfParallelism { get; set; } = 20;
    }
}
