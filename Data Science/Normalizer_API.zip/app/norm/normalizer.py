import re
from norm.load_dictionaries import Load_dictionaries
from norm.normalizer_core import Normalizer_core
from norm.load_normalized_products import Load_normalized
import time
# from norm.normalizer_search import NormalizerSearch

from norm.memorycache import MemoryCache
from norm.NormalizerExtraction import NormalizerExtraction
from norm.search_M import Search_M
from norm.renormalization import Renormalization
from norm.normalizer_core_failed import Normalizer_core_failed


class Normalizer:
    def __init__(self):
        print("Normalizer initialized")
        self.dict_load = Load_dictionaries()
        self.normalized = Load_normalized()
        self.norm_core = Normalizer_core()
        self.memory = MemoryCache()

        self.renor_core = Renormalization()
        self.norm_core_fail = Normalizer_core_failed()

        self.norm_search = NormalizerExtraction()
        # self.search = NormalizerSearch()
        self.searchM = Search_M()

    def dictio_load(self, status_dic_control=False):

        if self.dict_load.is_alive() != True:
            self.dict_load.start()

        if status_dic_control == False:
            if self.norm_core.status_real_norm == True:
                self.dict_load.resume()

        if status_dic_control == True:
            self.dict_load.set_status(True)

            return "Dicionários em pausa"

        while True:

            if self.dict_load.status_dictionary == False:
                print("aguardando load dic...")
                time.sleep(2)
            if self.dict_load.status_dictionary == True:
                # print("dicionários carregados fim #################")
                return "dicionários carregados"

    def norm_load(self):
        self.normalized.start()

        while True:
            if self.normalized.is_alive():
                if self.dict_load.status_dictionary == False:
                    print("aguardando load norm ...")
                    time.sleep(2)
            else:
                print("normalizado carregado")
                break

    def norm_core_load(self):

        while True:
            if self.normalized.is_alive():
                if self.dict_load.is_alive():
                    print("aguardando load norm ...")
                    time.sleep(2)
            else:
                self.norm_core.start()

                break

    def renorm_core_load(self):

        while True:
            if self.normalized.is_alive():
                if self.dict_load.is_alive():
                    print("aguardando load norm ...")
                    time.sleep(2)
            else:
                self.renor_core.start()
                self.renor_core.set_status(True)

                break

    def controle_core_norm(self, status_normalizer):

        while True:
            if self.normalized.is_alive():
                if self.dict_load.is_alive():
                    print("aguardando load normalized e dictionarios ...")
                    time.sleep(2)
            else:

                if status_normalizer == True:
                    # True para pausar o normalizer
                    self.norm_core.set_status(True)

                    if self.norm_core.status_real_norm == True:
                        # print("status_real: ",
                        #       self.norm_core.status_real_norm)
                        return "Normalizador pausado"
                    time.sleep(3)
                # print(" teste 1   #################")
                if status_normalizer == False:
                    # print(" teste 2   #################")
                    # False para continuar o normalizer
                    # self.norm_core.set_status(False)
                    self.norm_core.resume(False)

                    if self.norm_core.status_real_norm == False:
                        # print("status_real: ",
                        #       self.norm_core.status_real_norm)
                        return "Normalizador reiniciado"
                    time.sleep(3)

    def set_quantityToNormalize(self, quantity=50):
        self.norm_core.set_quantityToNormalize(quantity)

    def get_quantityToNormalize(self):
        return self.norm_core.get_quantityToNormalize()

    def get_cache(self):
        return self.norm_core.get_cache()

    def controle_core_norm_getPriorities(self):
        return self.norm_core.GetIdCompanyPriorities()

    def controle_core_norm_addPriority(self, idCompany: int):
        return self.norm_core.AddIdCompanyToPriorities(idCompany)

    def controle_core_norm_removePriority(self, idCompany: int):
        return self.norm_core.RemoveIdCompanyFromPriorities(idCompany)

    def controle_core_renorm(self, renormalization):

        print("controle_core_renorm",
              renormalization.status_renormalization)

        while True:
            if self.normalized.is_alive():
                if self.dict_load.is_alive():
                    print("aguardando load normalized e dictionarios ...")
                    time.sleep(2)
            else:

                if renormalization.status_renormalization == True:
                    # True para pausar o renormalizer
                    # if self.renor_core.is_alive() == False:
                    #     self.renor_core.start()

                    self.renor_core.set_status(True)

                    # print("status_real_renorm  ",
                    #       self.renor_core.status_real_renorm)

                    if self.renor_core.status_real_renorm == True:
                        # print("status_real renorm pausa: ",
                        #       self.renor_core.status_real_renorm)
                        return "Renormalizador pausado"
                    time.sleep(3)

                if renormalization.status_renormalization == False:
                    # Normalizador tem que esta parado
                    if self.norm_core.status_real_norm == False:
                        return "Pare normalizador para iniciar a renormalizar"

                    if self.norm_core.status_real_norm == True:

                        # False para continuar o normalizer
                        # self.norm_core.set_status(False)
                        print("status_real renorm reiniciado: ")
                        self.renor_core.resume(renormalization)

                    if self.renor_core.status_real_renorm == False:

                        # print("Renormalizador iniciado : ",
                        #       self.renor_core.status_real_renorm)

                        return "Renormalizador reiniciado"

                    # if self.renor_core.comleted_renorm == True:
                    #     print("Renormalizador concluído return")

                    #     return "Renormalização concluída"

                    time.sleep(3)

    def controle_core_renorm_failed(self, controle_core_renorm_failed):
        print("controle_core_renorm_failed", controle_core_renorm_failed)

        if self.norm_core_fail.is_alive() != True:
            print("TH Normalizer_core_failed iniciado ",
                  self.norm_core_fail.is_alive())
            self.norm_core_fail.start()

        if controle_core_renorm_failed == True:
            # True para pausar o normalizer
            self.norm_core_fail.set_status(True)

            if self.norm_core_fail.status_real_failed == True:
                # print("status_real: ", self.norm_core_fail.status_real_failed)
                return "Normalizador Falha em pausado"

        # print(" teste 1   #################")
        if controle_core_renorm_failed == False:
            if self.norm_core.status_real_norm == False:
                return "Pare normalizador para iniciar a renormalizar"

            if self.norm_core.status_real_norm == True:
                self.norm_core_fail.set_status(False)
                self.norm_core_fail.resume(False)

                if self.norm_core_fail.status_real_failed == False:
                    # print("status_real: ",
                    #       self.norm_core_fail.status_real_failed)
                    return "Normalizador falaha reiniciado"


    #########################################################################

    def resource_monitor(self):

        data_monitor = self.memory.monitor_dictionary_normalized()

        data_monitor.update({"status_norm": self.norm_core.status_real_norm, "status_renorm": self.renor_core.status_real_renorm,
                            "status_failed": self.norm_core_fail.status_real_failed, "status_dictionary": self.dict_load.status_dictionary})

        return data_monitor

    ##########################################################################

    def normalize_search(self, texto, ean, ncm, model, id_list, language):

        list_id_score_brand = []
        # list_teste2 = []

        while True:
            if self.normalized.is_alive():
                if self.dict_load.is_alive():
                    print("aguardando load norm ...")
                    time.sleep(2)
            else:
                # print("texto ##: ", texto)
                # texto_pred = self.search.norm_run_Search(texto)
                product = self.norm_search.normalizer_extraction(
                    texto, language)
                # print("product extract  ##: ", product)

                if(product["product"] != None):

                    result_search = self.searchM.search_products(
                        ean, ncm, model, product, language)

                    # print("result_search: ", result_search)

                    # print("result_search:", result_search)
    # verificar quando não tem resultados ou retorna apenas 1 resultado
                    if result_search != None:

                        for j in result_search:
                            # print("j: ", j)
                            result_list_product = []
                            result_list_product.extend(
                                [str(j['_id']), j['score'], j['product'], j['brands'], id_list, j['search_name_trash']])

                            list_id_score_brand.append(result_list_product)

                        # print("list_teste 2: ", list_teste2)

                        # list_id_score_brand.append(list_teste2)

                        # print("result_search", type(result_search))
                        # print(" ------------------------------- ")
                        # print("list_id_score_brand 1 : ", list_id_score_brand)
                        return list_id_score_brand
                    else:
                        list_id_score_brand = [None, None, None]

                        return list_id_score_brand

                else:
                    print("produto não encontrado")
                    return []

        # print("result_search", result_search)

    def normalize_search_pred_monitor(self, products, categories, networks, brands, models, source, language, full_log=False, exactVector:bool=True):
        # print("normalize_search_pred_monitor")
        product_List = []
        list_id_score_brand_pred = []
        # while True:
        if self.normalized.is_alive():
            if self.dict_load.is_alive():
                print("Dicionario indisponivel")
                return []
        else:
            # print("texto ##: ", texto)
            # texto_pred = self.search.norm_run_Search(texto)
            if full_log:
                print("Normalizando produto")

            if products == None:
                products = []
            if categories == None:
                categories = []
            if brands == None:
                brands = []
            if models == None:
                models = []

            if len(products) == 0 and len(brands) == 0 and len(categories) == 0:
                if full_log:
                    print("Nao foi definido o produto, a marca e/ou categoria")
                return []
            if(len(products) != 0):
                if full_log:
                    print("Foi definido o produto")

                for product in products:
                    #print("product: ", product)
                    product_extract = self.norm_search.normalizer_extraction(
                        product, language)
                    # print("product_extract: ", product_extract)
                    # brands

                    if (product_extract['brands'] != None):
                        for b in brands:
                            if (re.match(str(product_extract['brands']).lower(), str(b).lower())):
                                product_List.append(product_extract)
                                # print("product_List: ", product_List)

                    elif (product_extract['brands'] == None and (len(brands) != 0)):
                        for j in brands:
                            product_extract = self.norm_search.update_brand_pred_monitor(
                                j, product_extract)
                            if (len(categories) == 0):
                                product_List.append(product_extract)
                            if (len(categories) != 0):
                                for category in categories:
                                    product_extract_category = self.norm_search.update_category_pred_monitor(
                                        category, product_extract)

                                    product_List.append(
                                        product_extract_category)
                        print("------------------")
                        #print("product_List: ", product_List)

                        result_search_pred = self.searchM.search_pred_monitor(
                            product_List, language, exactVector)
                       # print("result_search_pred: 01 ", result_search_pred)
                        ###################################################
                        for j in result_search_pred:
                            # print("j: ", j)
                            result_list_product = []
                            result_list_product.extend(
                                [str(j['_id']), j['score'], j['product'], j['brands'],  j['search_name_trash']])

                            list_id_score_brand_pred.append(
                                result_list_product)
                        # print("list_id_score_brand_pred: ",
                        #       list_id_score_brand_pred)

                        return list_id_score_brand_pred

                    ########################################################
                    elif (len(categories) != 0):
                        # categoria sem marca
                        for category in categories:
                            print("category: ", category)

                            product_extract_category = self.norm_search.update_category_pred_monitor(
                                category, product_extract)

                            product_List.append(
                                product_extract_category)

                    else:
                        product_List.append(product_extract)
                # print("product_List: 01", product_List)

                result_search_pred = self.searchM.search_pred_monitor(
                    product_List, language, exactVector)
                # print("result_search_pred: 02", len(result_search_pred))
                ########################################################
                for j in result_search_pred:
                    # print("j: ", j)
                    result_list_product = []
                    result_list_product.extend(
                        [str(j['_id']), j['score'], j['product'], j['brands'],  j['search_name_trash']])

                    list_id_score_brand_pred.append(
                        result_list_product)

                return list_id_score_brand_pred
                ########################################################

                # for j in result_search_pred:
                #     # print("j: ", j)
                #     result_list_product = []
                #     result_list_product.extend([str(j['_id']), j['score'], j['product'], j['brands'],  j['search_name_trash']])

                #     list_id_score_brand_pred.append(result_list_product)

                # return result_search_pred

            if(len(brands) != 0):
                if full_log:
                    print("Foi definido a brand")
                # marca e categoria
                for brand in brands:
                    product_extract_brand = self.norm_search.normalizer_extraction(
                        brand, language)

                    if (len(categories) == 0):
                        product_List.append(product_extract_brand)
                    if (len(categories) != 0):
                        for category in categories:
                            product_extract_brands_category = self.norm_search.update_category_pred_monitor(
                                category, product_extract_brand)
                            product_List.append(
                                product_extract_brands_category)

                # print("product_List: 02 ", product_List)
                result_search_pred = self.searchM.search_brand_pred_monitor(
                    product_List, language)
                # print("result_search_pred: 03", result_search_pred)
                ########################################################
                for j in result_search_pred:
                    # print("j: ", j)
                    result_list_product = []
                    result_list_product.extend(
                        [str(j['_id']), j['score'], j['product'], j['brands'],  j['search_name_trash']])

                    list_id_score_brand_pred.append(
                        result_list_product)

                return list_id_score_brand_pred
                ########################################################

            if(len(categories) != 0):
                if full_log:
                    print("Foi definido a categoria")
                for category in categories:
                    # print("category: ", category)

                    product_extract_category = self.norm_search.update_category_unique_pred_monitor(
                        category, language)

                    product_List.append(product_extract_category)

                result_search_pred = self.searchM.search_brand_pred_monitor(
                    product_List, language)
                # print("result_search_pred: 04", result_search_pred)
            ########################################################
                for j in result_search_pred:
                    # print("j: ", j)
                    result_list_product = []
                    result_list_product.extend(
                        [str(j['_id']), j['score'], j['product'], j['brands'],  j['search_name_trash']])

                    list_id_score_brand_pred.append(
                        result_list_product)

                return list_id_score_brand_pred
                ########################################################
