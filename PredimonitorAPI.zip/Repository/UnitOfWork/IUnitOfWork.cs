using Repository.EntityRepository;
using System.Transactions;

namespace Repository.UnitOfWork
{
    public interface IUnitOfWork : IDisposable
    {
        IProductPricesRepository ProductPrices { get; }
        IHorusProductsRepository HorusProducts { get; }
        IMonitoringCrawlerRepository MonitoringCrawler { get; }
        ICompanyMonitoringCrawlerRepository CompanyMonitoringCrawler { get; }
        IMonitoringItemConfigRepository MonitoringItemConfig { get; }
        IMonitoringItemRepository MonitoringItem { get; }
        ICompanyConfigurationRepository CompanyConfiguration { get; }
        IMonitoringItemResultsRepository MonitoringItemResults { get; }
        ICompanyRepository Company { get; }
        IMonitoringItemResultsStatusRepository MonitoringItemResultsStatus { get; }
        IFactTicketRepository FactTicketRepository { get; }
        IIndiretaRepository IndiretaRepository { get; }
        IPeraltaRepository PeraltaRepository { get; }
        IVemRepository VemRepository { get; }
        IAbvRepository AbvRepository { get; }
        IInfoPriceSaoJoaoRepository InfoPriceSaoJoao { get; }
        IIgnoredMonitoringItemRepository IgnoredMonitoringItemRepository { get; }
        IMonitoringProductMarketResultRepository MonitoringProductMarketResultRepository { get; }
        IMonitoringProductMarketResultItemRepository MonitoringProductMarketResultItemRepository { get; }
        IProductMarketResultSellerRepository ProductMarketResultSellerRepository { get; }
        IInfoPricePeraltaRepository InfoPricePeraltaRepository { get; }
        IOfflineSupermarketTorreRepository OfflineSupermarketTorres { get; }
        IProductRepository ProductRepository { get; }
        IProductSellerRepository ProductSellerRepository { get; }
        IProductPriceRepository ProductPriceRepository { get; }
        IIgnoredPriceRepository IgnoredPriceRepository { get; }
        ICompanyMonitoringCrawlerFiltersRepository CompanyMonitoringCrawlerFiltersRepository { get; }
        ICompanyMonitoringCrawlerFiltersValuesRepository CompanyMonitoringCrawlerFiltersValuesRepository { get; }
        ICompanyProductPriceRepository CompanyProductPriceRepository { get; }
        IInfoPriceTorreRepository InfoPriceTorreRepository { get; }
        IScantechSupermaxiRepository ScantechSupermaxiRepository { get; }

        TransactionScope CreateTransactionScope();
        TransactionScope CreateTransactionScope(TransactionScopeAsyncFlowOption asyncFlowOption);
    }
}