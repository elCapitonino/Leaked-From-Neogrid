﻿using DI.Repository.Attributes;
using DI.Repository.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DI.Repository.TypeConfiguration
{
    [UsePostgreContext]
    public sealed class GranularityGroupTypeConfiguration : TypeConfigurationBase<GranularityGroupEntity>, IEntityTypeConfiguration<GranularityGroupEntity>
    {
        public override void Configure(EntityTypeBuilder<GranularityGroupEntity> builder)
        {
            ConfigureTableName(builder, "GranularityGroup");
            builder.HasKey(x => x.Id);
            builder.Property(x => x.Id).ValueGeneratedOnAdd().HasDefaultValueSql("uuid_generate_v4()").IsRequired();
            builder.Property(x => x.Description).HasMaxLength(64);
        }
    }
}
