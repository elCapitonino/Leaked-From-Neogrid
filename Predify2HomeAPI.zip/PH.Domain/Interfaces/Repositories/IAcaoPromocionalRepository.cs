﻿using PH.Domain.Domain;

namespace PH.Domain.Interfaces.Repositories
{
    public interface IAcaoPromocionalRepository
    {
        Task<List<AcaoPromocional>> GetAll();
        Task<AcaoPromocional> GetById(string acaoPromocionalId);
        Task Add(AcaoPromocional acaoPromocional);
        Task RemoveById(string acaoPromocionalId);
        Task Update(string acaoPromocionalId, AcaoPromocional newAcaoPromocional);
    }
}
