import nltk
nltk.download('stopwords')

class Teste:
    def __init__(self):
        self.a = {1, 2, 3}

    def get_a(self):
        return self.a
