﻿using AutoMapper;
using Domain.IndexGenerator.DataSourceDomains.Interfaces;
using Domain.IndexGenerator.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using MongoDB.Driver;
using Repository.Entity;
using Repository.UnitOfWork;
using System.Diagnostics;
using Microsoft.Extensions.Caching.Memory;
using Domain.Status;
using Repository.Enums;
using MongoDB.Bson;

namespace Domain.IndexGenerator.DataSourceDomains
{
    public class IndexGeneratorIndiretaDomain : IndexGeneratorBase, IIndexGeneratorIndiretaDomain
    {
        private readonly ILogger<IndexGeneratorIndiretaDomain> _logger;
        private readonly IUnitOfWork _uow;
        private readonly IMapper _mapper;
        private readonly IStatusDomain _statusDomain;

        public IndexGeneratorIndiretaDomain(ILogger<IndexGeneratorIndiretaDomain> logger, IUnitOfWork uow, IMapper mapper, IStatusDomain statusDomain)
            : base(statusDomain)
        {
            _logger = logger;
            _uow = uow;
            _mapper = mapper;
            _statusDomain = statusDomain;
        }

        public async Task GenerateIndexAsync(long companyId, int crawlerId, IEnumerable<MonitoringItemTags> monitoringItems, DateTime startDate, DateTime endDate, Guid? taskId, List<long> monitoringResultIdsDelete)
        {
            try
            {
                _logger.LogInformation($"Iniciando Geração de index da Indireta");
                var total = monitoringItems.Count();
                var count = 1;
                UpdateStatus(taskId, CrawlerSourceType.Indireta, MonitoringItemResultsStatusType.Running, total, 0);
                Stopwatch totalStopwatch = new Stopwatch();
                totalStopwatch.Start();
                _logger.LogInformation("Indireta - Total de monitoring items para serem processados: {total}", total);
                List<ObjectId> listUpdateHash = new List<ObjectId>();
                EnsureAllMonitoringItemId(monitoringItems);
                foreach (var monitoringItem in monitoringItems)
                {
                    try
                    {
                        if (!monitoringItem.Eans.Any())
                            continue;                    

                        var products = await _uow.IndiretaRepository.GetAll()
                            .Where(x => x.LastSale >= startDate && x.LastSale <= endDate && monitoringItem.Eans.Contains(x.ProductEan))
                            .Select(x => new
                            {
                                x.Id,
                                EAN = x.ProductEan,
                                x.Hash,
                                Seller = x.DistributorName,
                                UF = x.State2,
                            })
                            .ToListAsync();

                        listUpdateHash.AddRange(products.Where(x => string.IsNullOrEmpty(x.Hash)).Select(x => x.Id));

                        var entities = products.GroupBy(x => $"{GetOrGenerateHash(x.Hash, $"{x.EAN}|{x.Seller}")}{x.Seller}{x.UF}")
                            .Select(x => x.First())
                            .Select(x => new MonitoringItemResultsEntity()
                            {
                                Brand = null,
                                Category = null,
                                Hash = GetOrGenerateHash(x.Hash, $"{x.EAN}|{x.Seller}"),
                                CompanyId = companyId,
                                CrawlerId = crawlerId,
                                MonitoringItemId = monitoringItem.MonitoringItemId,
                                Seller = x.Seller,
                                State = x.UF,
                            });

                        _uow.MonitoringItemResults.AddRange(entities, true);

                        UpdateStatus(taskId, CrawlerSourceType.Indireta, MonitoringItemResultsStatusType.Running, total, count);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, $"Error Search Monitoring Item {monitoringItem.MonitoringItemId} Indireta");
                        UpdateStatus(taskId, CrawlerSourceType.Indireta, MonitoringItemResultsStatusType.Error, total, count);
                    }
                    count++;
                }

                if (monitoringResultIdsDelete != null && monitoringResultIdsDelete.Any())
                {
                    _logger.LogInformation("Indireta - Deletando {Count} MonitoringItemResults", monitoringResultIdsDelete.Count);
                    _uow.MonitoringItemResults.DeleteAll(monitoringResultIdsDelete);
                }

                if (listUpdateHash.Any())
                {
                    var productsToUpdate = _uow.IndiretaRepository
                              .GetAll()
                              .Where(x => listUpdateHash.Contains(x.Id))
                              .ToList();

                    foreach (var product in productsToUpdate)
                    {
                        product.Hash = CalculateSHA256($"{product.ProductEan}|{product.DistributorName}");
                    }

                    _uow.IndiretaRepository.Update(productsToUpdate, true);
                }

                totalStopwatch.Stop();
                _logger.LogInformation($"Finalizado Geração de index da Indireta - {totalStopwatch.Elapsed.TotalSeconds}s");
                UpdateStatus(taskId, CrawlerSourceType.Indireta, MonitoringItemResultsStatusType.Finished, total, --count);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error {MethodName}", nameof(GenerateIndexAsync));
                throw;
            }
        }
    }
}
