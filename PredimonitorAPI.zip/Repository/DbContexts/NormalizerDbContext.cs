﻿using Microsoft.EntityFrameworkCore;
using MongoDB.Driver;
using Repository.DbContexts.Bases;

namespace Repository.DbContexts
{
    public class NormalizerDbContext : MongoDbContextBase
    {
        public NormalizerDbContext(DbContextOptions<NormalizerDbContext> options, IMongoClient mongoClient) : base(options, mongoClient)
        {

        }
        public override string DbContextName => nameof(NormalizerDbContext);

    }
}
