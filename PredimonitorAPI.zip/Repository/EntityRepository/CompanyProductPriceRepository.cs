using Repository.DbContexts;
using Repository.Entity.Databricks;
using Repository.EntityRepository.Bases;

namespace Repository.EntityRepository;

public class CompanyProductPriceRepository : GenericDatabricksRepository<CompanyProductPriceEntity>, ICompanyProductPriceRepository
{
    public CompanyProductPriceRepository(DatabricsDbContext dbContext) : base(dbContext, "company_product_prices")
    {     
    }
}