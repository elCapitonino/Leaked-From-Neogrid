from sqlalchemy import MetaData, text

from src.db import PostgreSQLConnection
from src.granularity import GranularityType, load_granularity


def get_price_var(pg_conn: PostgreSQLConnection, idCompany: int) -> str:
    price_var_query = f'SELECT "PriceVariableToCalc" FROM "ImpactReportConfiguration" WHERE "CompanyId" = {idCompany}'
    cursor = pg_conn.execute(text(price_var_query))
    price_var = cursor.fetchone()[0]
    if price_var is None:
        return "SalePrice"
    return price_var


def get_granularity(
    pg_conn: PostgreSQLConnection, metadata: MetaData, idCompany: int
) -> list[str]:
    granularity_group = load_granularity(
        pg_conn=pg_conn,
        metadata=metadata,
        id_company=idCompany,
        granularity_type=GranularityType.PROJECTION,
    )
    return granularity_group.to_columns()


def get_granularity_id(
    pg_conn: PostgreSQLConnection, metadata: MetaData, idCompany: int
):
    granularity_group = load_granularity(
        pg_conn=pg_conn,
        metadata=metadata,
        id_company=idCompany,
        granularity_type=GranularityType.PROJECTION,
    )
    return granularity_group.group_id


def get_granularity_sql(
    pg_conn: PostgreSQLConnection, metadata: MetaData, idCompany: int
) -> str:
    return ", ".join(get_granularity(pg_conn, metadata, idCompany))


def get_granularity_join_operation(
    pg_conn: PostgreSQLConnection, metadata: MetaData, idCompany: int
) -> str:
    return " AND ".join(
        [f"t1.{g} = t2.{g}" for g in get_granularity(pg_conn, metadata, idCompany)]
    )
