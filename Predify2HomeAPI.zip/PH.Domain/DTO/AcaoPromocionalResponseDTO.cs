﻿namespace PH.Domain.DTO
{
    public class AcaoPromocionalMainResponseDTO
    {
        public AcaoPromocionalMainResponseDTO()
        {
            CurrentActions = new List<AcaoPromocionalResponseDTO>();
            NextActions = new List<AcaoPromocionalResponseDTO>();
        }

        public List<AcaoPromocionalResponseDTO> CurrentActions { get; set; }
        public List<AcaoPromocionalResponseDTO> NextActions { get; set; }
    }
    public class AcaoPromocionalResponseDTO
    {
        public string Id { get; private set; }
        public string ActionName { get; set; }
        public string TooltipText { get; set; }
        public string InitialDate { get; set; }
        public string FinalDate { get; set; }
        public List<ProductAcaoPromocionalResponseDTO> Products { get; set; }
    }

    public class ProductAcaoPromocionalResponseDTO
    {
        public int Id { get; set; }
        public string ProductName { get; set; }
        public double Price { get; set; }
        public string EAN { get; set; }
        public bool IsCombo { get; set; }
        public string ComboTranslate
        {
            get
            {
                return IsCombo ? "VERDADEIRO" : "FALSO";
            }
        }
        public string ActionType { get; set; }
        public string? StartDate { get; set; }
        public string? EndDate { get; set; }
    }
}
