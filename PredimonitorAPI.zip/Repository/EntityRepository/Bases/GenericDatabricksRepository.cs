
using Repository.DbContexts;
using Repository.Models.Databricks;
using System.Diagnostics;


namespace Repository.EntityRepository.Bases;

public class GenericDatabricksRepository<T> : IGenericDatabricksRepository<T> where T : class, new()
{
    private readonly DatabricsDbContext _context;
    private readonly string _schema;
    private readonly string _tableName;

    public GenericDatabricksRepository(DatabricsDbContext dbContext, string tableName)
    {
        _context = dbContext;
        _schema = dbContext.GetSchema();
        _tableName = tableName;
    }

    public async Task<List<T>> Get(List<QueryFilter>? filters = null, int limit = 100)
    {
        try
        {
            var query = $"SELECT * FROM {_schema}.{_tableName}";

            query += CreateQueryWhere(filters, null);

            query += $" LIMIT {limit}";

            var result = await _context.ExecuteQuery<T>(query);

            return result;
        }
        catch (Exception ex)
        {
            throw;
        }
    }

    public async Task<List<TResult>> GetWithJoin<TResult>(QueryParameters parameters) where TResult : class, new()
    {
        try
        {
            var query = CreateQuery(parameters);

            var result = await _context.ExecuteQuery<TResult>(query);

            return result;
        }
        catch (Exception ex)
        {
            throw;
        }
    }

    public async Task<int> GetCount(QueryParameters parameters)
    {
        try
        {
            parameters.TakeAll = true;

            var query = CreateQuery(parameters);

            query = $"SELECT COUNT(*) FROM ({query}) as Count";

            var result = await _context.ExecuteCountQuery(query);

            return result;
        }
        catch (Exception ex)
        {
            throw;
        }
    }

    private string CreateQuery(QueryParameters parameters)
    {
        var query = CreateQuerySelect(parameters.Select);
        query += CreateQueryFromAndJoin(parameters.Joins);
        query += CreateQueryWhere(parameters.Filters, parameters.SqlFilters);
        query += CreateQueryGroupBy(parameters.GroupBy);
        query += CreateQueryOrderBy(parameters.OrderBy);
        query += CreateQueryPagination(parameters.Take, parameters.Skip, parameters.TakeAll);

        return query;
    }

    private static string CreateQuerySelect(List<QuerySelect> fieldsToSelect)
    {
        var select = $"SELECT ";

        if (fieldsToSelect != null && fieldsToSelect.Count > 0)
        {
            select += string.Join(", ", fieldsToSelect.Select(x => x.Column));
        }
        else
        {
            select += " *";
        }

        return select;
    }

    private string CreateQueryFromAndJoin(List<QueryJoin> tablesToJoin)
    {
        var from = $" FROM {_schema}.{_tableName}";

        if (tablesToJoin != null && tablesToJoin.Count > 0)
        {
            foreach (var join in tablesToJoin)
            {
                if (string.IsNullOrEmpty(join.JoinSQL))
                {
                    var JoinCondition = join.JoinCondition;

                    if (join.JoinWithMainTable)
                    {
                        JoinCondition = $"{_schema}.{_tableName}.{JoinCondition}";
                    }

                    join.JoinType = (join.JoinType ?? "").Replace("JOIN", "").Replace("join", "");

                    from += $" {join.JoinType} JOIN {_schema}.{join.JoinTable} ON {JoinCondition}";
                }
                else
                {
                    from += join.JoinSQL;
                }
            }
        }

        return from;
    }

    private static string CreateQueryWhere(List<QueryFilter> filters, List<QuerySQL> sqlFilters)
    {
        var filterConditions = new List<string>();

        if (filters != null && filters.Count > 0)
        {
            foreach (var filter in filters.Where(x => x.Value != null && !x.Value.Equals("")))
            {
                string condition = filter.Operator switch
                {
                    "IN" => HandleInOperator(filter),
                    "IS" => HandleIsOperator(filter),
                    "LIKE" => HandleLikeOperator(filter),
                    _ => HandleDefaultOperator(filter)
                };

                if (!string.IsNullOrEmpty(condition))
                {
                    filterConditions.Add(condition);
                }
            }
        }

        return BuildWhereClause(filterConditions, sqlFilters);
    }

    private static string BuildWhereClause(List<string> filterConditions, List<QuerySQL> sqlFilters)
    {
        if (filterConditions.Count == 0 && (sqlFilters == null || sqlFilters.Count == 0))
            return string.Empty;

        var query = " WHERE ";

        if (sqlFilters?.Count > 0)
        {
            query += $"({string.Join(" OR ", sqlFilters.Select(x => x.SQL))}) ";
        }

        if (filterConditions.Count > 0 && sqlFilters?.Count > 0)
        {
            query += $"AND {string.Join(" AND ", filterConditions)}";
        }
        else if (filterConditions.Count > 0)
        {
            query += string.Join(" AND ", filterConditions);
        }

        return query;
    }

    private static string HandleInOperator(QueryFilter filter)
    {
        if (filter.Value is IEnumerable<string> values && values != null)
        {
            values = values.Where(x => !string.IsNullOrEmpty(x)).ToList();
            if (values.Any())
            {
                var formattedValues = string.Join(", ", values.Select(v => $"'{v.Replace("'", "''")}'"));
                return $"{filter.Column} {filter.Operator} ({formattedValues})";
            }
        }
        else if (filter.Value is IEnumerable<int> intValues && intValues != null && intValues.Any())
        {
            var formattedValues = string.Join(", ", intValues);
            return $"{filter.Column} {filter.Operator} ({formattedValues})";
        }
        return string.Empty;
    }

    private static string HandleIsOperator(QueryFilter filter)
    {
        var isValue = filter.Value is string strIsValue ? strIsValue.Replace("'", "''") : filter.Value;
        return $"{filter.Column} {filter.Operator} {isValue}";
    }

    private static string HandleLikeOperator(QueryFilter filter)
    {
        var textToCompare = filter.Value is string strText ? strText.Replace("'", "''") : filter.Value;
        return $"{filter.Column} {filter.Operator} '%{textToCompare}%'";
    }

    private static string HandleDefaultOperator(QueryFilter filter)
    {
        var value = filter.Value is string strValue ? strValue.Replace("'", "''") : filter.Value;
        return $"{filter.Column} {filter.Operator} '{value}'";
    }

    private static string CreateQueryGroupBy(List<QueryGroupBy> fieldsToGroup)
    {
        var groupBy = "";

        if (fieldsToGroup != null && fieldsToGroup.Count > 0)
        {
            groupBy += " GROUP BY " + string.Join(", ", fieldsToGroup.Select(x => x.Column));
        }

        return groupBy;
    }

    private static string CreateQueryOrderBy(List<QueryOrderBy> fieldsToOrder)
    {
        var orderBy = "";

        if (fieldsToOrder != null && fieldsToOrder.Count > 0)
        {
            orderBy += " ORDER BY " + string.Join(", ", fieldsToOrder.Select(x => x.Column));
        }

        return orderBy;
    }

    private static string CreateQueryPagination(int take, int skip, bool takeAll = false)
    {
        take = take == 0 ? 100 : take;

        var pagination = "";

        if (!takeAll)
        {
            pagination = $" LIMIT {take} OFFSET {skip}";
        }

        return pagination;
    }

    public void Insert(List<T> items)
    {
        if (items == null || items.Count == 0)
        {
            throw new ArgumentException("No items to insert");
        }

        var properties = typeof(T).GetProperties();
        var columnNames = string.Join(", ", properties.Select(p => p.Name));

        var values = items.Select(BuildValuesClause);

        var valuesClause = string.Join(", ", values);
        var sql = $"INSERT INTO {_schema}.{_tableName} ({columnNames}) VALUES {valuesClause};";

        _context.ExecuteCommand(sql);
    }

    public void Insert(T item)
    {
        if (item == null)
        {
            throw new ArgumentException("Item to insert is null");
        }

        var properties = typeof(T).GetProperties();
        var columnNames = string.Join(", ", properties.Select(p => p.Name));

        var valuesClause = BuildValuesClause(item);
        var sql = $"INSERT INTO {_schema}.{_tableName} ({columnNames}) VALUES {valuesClause};";

        _context.ExecuteCommand(sql);
    }

    private string BuildValuesClause(T item)
    {
        var properties = typeof(T).GetProperties();
        var valueList = properties.Select(p =>
        {
            var value = p.GetValue(item, null);

            if (value is string)
            {
                return $"'{value}'";
            }
            else if (value is DateTime dateTimeValue)
            {
                return $"'{dateTimeValue:yyyy-MM-dd}'";
            }
            else if (value is decimal || value is double || value is float)
            {
                return ((decimal)value).ToString(System.Globalization.CultureInfo.InvariantCulture);
            }
            else if (value == null)
            {
                return "NULL";
            }
            else
            {
                return value.ToString();
            }
        });

        return $"({string.Join(", ", valueList)})";
    }

    public void Remove(IEnumerable<string> ids)
    {
        var formattedIds = string.Join(", ", ids.Select(id => $"'{id}'"));
        var sql = $"DELETE FROM {_schema}.{_tableName} WHERE Id IN ({formattedIds})";

        _context.ExecuteCommand(sql);
    }

    public void ExecuteSQL(string sql)
    {
        _context.ExecuteCommand(sql);
    }

    public string GetSchema()
    {
        return _schema;
    }
}