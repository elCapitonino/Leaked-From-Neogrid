<template>
  <span>
    <v-card>
      <v-expansion-panels class="mt-2">
        <v-expansion-panel>
          <v-expansion-panel-header class="pa-0 ma-0" expand-icon>
            <v-col cols="auto">
              <v-row
                class="mt-2"
                no-gutters
                style="justify-content: space-between"
              >
                <span>
                  <label class="ml-4 mr-2 label">{{ product }}</label>
                </span>
                <p class="font-weight-bold">
                  <v-icon>mdi-chevron-down</v-icon>
                </p>
              </v-row>
              <v-col class="envio mx-1">
                <label
                  >{{ label1 }}
                  <span>{{ result1 }}</span>
                </label>
              </v-col>

              <v-row no-gutters class="informations mr-8">
                <v-col cols="2" class="ml-4">
                  <label>{{ label2 }}</label>
                  <span class="my-2">{{ result2 }}</span>
                </v-col>
                <v-col cols="2" class="ml-2">
                  <label>{{ label3 }}</label>
                  <span class="my-2">{{ result3 }}</span>
                </v-col>
                <v-col cols="2" class="ml-2">
                  <label>{{ label4 }}</label>
                  <span :label="result4" class="my-2"></span>
                </v-col>
                <v-col cols="2" class="ml-2">
                  <v-icon :color="max" left small
                    >mdi-arrow-up-bold-outline</v-icon
                  >
                  <span>{{ maxPrice }}</span>
                </v-col>
                <v-col cols="2">
                  <v-icon :color="avg" class="mx-2" left small
                    >mdi-minus-circle-outline</v-icon
                  >
                  <span>{{ avgPrice }}</span>
                </v-col>
                <v-col cols="" class="ml-2">
                  <v-icon :color="min" left small
                    >mdi-arrow-down-bold-outline</v-icon
                  >
                  <span>{{ minPrice }}</span>
                </v-col>
              </v-row>
            </v-col>
          </v-expansion-panel-header>
          <v-expansion-panel-content>
            <v-data-table
              id="smart-table"
              :headers="headers"
              :items="items"
              class="elevation-1 text-center input-fontSize"
              dense
            >
              <!-- eslint-disable-next-line -->
              <template #item.product_name="{ item }">
                <span
                  ><a target="_blank" :href="item.product_link">{{
                    item.product_name
                  }}</a></span
                >
              </template>

              <!-- eslint-disable-next-line -->
              <template #item.price="{ item }">
                <span>{{ item.price }} {{ item.price_currency }}</span>
              </template>

              <!-- eslint-disable-next-line -->
              <template #item.crawler_name="{ item }">
                <span>{{ item.crawler_name }}</span>
              </template>

              <!-- eslint-disable-next-line -->
              <template #item.price_payment_type="{ item }">
                <span>{{ item.price_payment_type }}</span>
              </template>

              <!-- eslint-disable-next-line -->
              <template #item.seller_name="{ item }">
                <span
                  ><a
                    v-if="item.seller_link"
                    target="_blank"
                    :href="item.seller_link"
                    >{{ item.seller_name }}</a
                  ></span
                >
              </template>

              <!-- eslint-disable-next-line -->
              <template #item.crawler_date="{ item }">
                <span>{{
                  item.crawler_date.split("T")[0] +
                  " " +
                  item.crawler_date.split("T")[1].split(".")[0]
                }}</span>
              </template>
            </v-data-table>
          </v-expansion-panel-content>
        </v-expansion-panel>
      </v-expansion-panels>
    </v-card>
  </span>
</template>
<script>
export default {
  name: "expansion-panel-component",
  data() {
    return {
      rotateIcon: false,
    };
  },
  props: {
    headers: { type: Array },
    items: { type: Array },
    product: { type: String },
    resultProducts: { type: Number },
    title: { type: String },
    label1: { type: String },
    label2: { type: String },
    label3: { type: String },
    label4: { type: String },
    result1: { type: String },
    result2: { type: String },
    result3: { type: String },
    result4: { type: String },
    avgPrice: { type: Number },
    maxPrice: { type: Number },
    minPrice: { type: Number },
    max: { type: String },
    min: { type: String },
    avg: { type: String },
  },
  methods: {
    onInput(values) {
      this.$emit("input", values);
    },
  },
};
</script>

<style lang="scss" scoped>
* {
  font-family: "Ubuntu" !important;
  font-size: 12px;
}

.label {
  font-weight: bold;
}

.envio {
  font-size: 11px;
  margin-top: -27px;
  margin-bottom: 12px;
}

.informations {
  font-size: 12px;
  margin-left: 16px;
  flex-wrap: nowrap;
}
</style>
