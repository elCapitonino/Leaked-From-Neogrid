namespace DI.Domain.Models
{
    public class AppsettingsOptions
    {
        public AppsettingsAuthOptions Auth { get; set; }


    }
    public class AppsettingsAuthOptions
    {
        public string Host { get; set; }
    }
}
