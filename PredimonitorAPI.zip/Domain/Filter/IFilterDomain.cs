using Domain.Filter.Models;

namespace Domain.Filter;

public interface IFilterDomain
{
    Task<FilterResponse> GetFilters(FilterRequest request);
}