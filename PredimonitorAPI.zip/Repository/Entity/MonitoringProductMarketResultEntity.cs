﻿namespace Repository.Entity
{
    public class MonitoringProductMarketResultEntity : BaseEntity
    {
        public long? ProductId { get; set; }
        public long? MonitoringItemId { get; set; }
        public virtual MonitoringItemEntity MonitoringItem { get; set; }
        public long? CompanyId { get; set; }
        public int? MaxPriceCrawlerId { get; set; }
        public string MaxPriceCrawlerName { get; set; }
        public string MaxPriceProductName { get; set; }
        public string MaxPriceProductLink { get; set; }
        public string MaxPriceSellerName { get; set; }
        public string MaxPriceSellerLink { get; set; }
        public decimal? MaxPrice { get; set; }
        public decimal? MaxSecondPrice { get; set; }
        public decimal? AvgPrice { get; set; }
        public int? MinPriceCrawlerId { get; set; }
        public string MinPriceCrawlerName { get; set; }
        public string MinPriceProductName { get; set; }
        public string MinPriceProductLink { get; set; }
        public string MinPriceSellerName { get; set; }
        public string MinPriceSellerLink { get; set; }
        public decimal? MinPrice { get; set; }
        public decimal? MinSecondPrice { get; set; }
        public decimal ModaPrice { get; set; }
        public DateTime RefDate { get; set; }
        public bool IsDeleted { get; set; }
        public ICollection<MonitoringProductMarketResultItemEntity> MonitoringProductMarketResultItem { get; set; }

        public void SetMaxAvgMin(List<MonitoringProductMarketResultItemEntity> list)
        {
            decimal? sumAvg = 0;
            int countAvg = 0;

            foreach (var item in list)
            {
                if (item.QuantityInstallments > 1 || item.OnRequest)
                    continue;

                if (item.Price > MaxPrice || MaxPrice == null)
                {
                    MaxSecondPrice = MaxPrice;
                    MaxPrice = item.Price;

                    MaxPriceCrawlerId = item.CrawlerId;
                    MaxPriceCrawlerName = item.CrawlerName;
                    MaxPriceProductLink = item.ProductLink;
                    MaxPriceProductName = item.ProductName;
                    MaxPriceSellerLink = item.SellerLink;
                    MaxPriceSellerName = item.SellerName;
                }

                if (item.Price < MinPrice || MinPrice == null)
                {
                    MinSecondPrice = MinPrice;
                    MinPrice = item.Price;

                    MinPriceCrawlerId = item.CrawlerId;
                    MinPriceCrawlerName = item.CrawlerName;
                    MinPriceProductLink = item.ProductLink;
                    MinPriceProductName = item.ProductName;
                    MinPriceSellerLink = item.SellerLink;
                    MinPriceSellerName = item.SellerName;
                }

                sumAvg += item.Price;
                countAvg++;
            }

            ModaPrice = list.Select(x => x.Price ?? 0)
                .GroupBy(x => x)
                .Select(group => new { Valor = group.Key, Frequencia = group.Count() })
                .MaxBy(x => x.Frequencia)?.Valor ?? 0;

            if (countAvg > 0)
                AvgPrice = sumAvg / countAvg;
        }
    }
}
