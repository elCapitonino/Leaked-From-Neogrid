"""
Script para gerar relatório do search (V2 - pred_monitor) com BM25.

Para rodar localmente a API:

python -m uvicorn main:app_search --host 0.0.0.0 --port 8081 --reload

Colunas espradas no arquivo Excel:
 - productCode
 - name_descricao
 - category
 - productEan
 - product_name
"""

import argparse
from datetime import datetime, timedelta
import json
from time import time
from typing import Dict, List

import pandas as pd
import requests


def call_endpoint(
    name: str, start_date: datetime, end_date: datetime, crawler_ids: List[int], language: str
) -> Dict:
    body = {
        "start_date": start_date.isoformat(),
        "end_date": end_date.isoformat(),
        "period_type": 0,
        "id_company": None,
        "idcrawlers": crawler_ids,
        "data_source": 0,
        "filters": {"products": [name], "language": language},
    }
    response = requests.post("http://localhost:8081/v3/search/bm25", json=body, timeout=120)
    return response.json()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("excel_file")
    parser.add_argument("--n-days", type=int, default=7)
    parser.add_argument("--crawler-ids", nargs="+", type=int, required=True)
    parser.add_argument("--language", default="pt-br")
    args = parser.parse_args()

    end_date = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    start_date = end_date - timedelta(days=args.n_days)

    df = pd.read_excel(args.excel_file)
    out = []

    for i, row in df.iterrows():
        init = time()
        response = call_endpoint(
            row["name_descricao"],
            start_date,
            end_date,
            crawler_ids=args.crawler_ids,
            language=args.language,
        )
        row = row.to_dict()
        if "result" not in response[0]:
            out.append(row)
            continue

        result = response[0]["result"]
        print(row["name_descricao"])
        print(json.dumps(result, indent=2, ensure_ascii=False))
        print("--------------------")
        if not result:
            out.append(row)
            continue

        for doc in result:
            row = row.copy()
            row["product_name"] = doc["product_name"]
            row["product_link"] = doc["product_link"]
            row["id_crawler"] = doc["id_crawler"]
            row["seller_name"] = doc["seller_name"]
            row["price"] = (doc["prices"] or [{}])[0].get("price")
            row["crawler_date"] = doc["crawler_date"]
            row["SCORE SIMILARIDADE"] = round(doc["score"], 2)
            out.append(row)

        print(f"processed {i + 1}/{len(df)} products in {time() - init:.1f} s")

    out = pd.DataFrame(out)
    out.to_excel("./report.xlsx", index=False)
    print("relatório salvo em ./report.xlsx")


if __name__ == "__main__":
    main()
