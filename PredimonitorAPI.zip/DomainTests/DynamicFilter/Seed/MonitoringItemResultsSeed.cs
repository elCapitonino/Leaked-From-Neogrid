﻿using Repository.Entity;

namespace DomainTests.DynamicFilter.Seed
{
    public class MonitoringItemResultsSeed
    {
        public static List<MonitoringItemResultsEntity> GetTestData()
        {
            return new List<MonitoringItemResultsEntity>
            {
                new MonitoringItemResultsEntity { Id = 1, CompanyId = 1, MonitoringItemId = 1, CrawlerId = 101, Hash = "abc123", Category = "Fruta", Seller = "Supermarket A", Brand = "Brand A", State = "SP", Year = "2023" },
                new MonitoringItemResultsEntity { Id = 2, CompanyId = 1, MonitoringItemId = 2, CrawlerId = 101, Hash = "def456", Category = "Fruta", Seller = "Supermarket B", Brand = "Brand B", State = "MG", Year = "2023" },
                new MonitoringItemResultsEntity { Id = 3, CompanyId = 1, MonitoringItemId = 3, CrawlerId = 101, Hash = "ghi789", Category = "Fruta", Seller = "Supermarket C", Brand = "Brand C", State = "MG", Year = "2023" },
                new MonitoringItemResultsEntity { Id = 4, CompanyId = 2, MonitoringItemId = 21, CrawlerId = 102, Hash = "jkl012", Category = "Vegetais", Seller = "Supermarket D", Brand = "Brand D", State = "RJ", Year = "2023" },
                new MonitoringItemResultsEntity { Id = 5, CompanyId = 1, MonitoringItemId = 22, CrawlerId = 102, Hash = "mno345", Category = "Vegetais", Seller = "Supermarket E", Brand = "Brand E", State = "SP", Year = "2023" },
                new MonitoringItemResultsEntity { Id = 6, CompanyId = 3, MonitoringItemId = 23, CrawlerId = 103, Hash = "pqr678", Category = "Vegetais", Seller = "Supermarket F", Brand = "Brand F", State = "RS", Year = "2022" },
                new MonitoringItemResultsEntity { Id = 7, CompanyId = 3, MonitoringItemId = 24, CrawlerId = 103, Hash = "stu901", Category = "Vegetais", Seller = "Supermarket G", Brand = "Brand G", State = "SC", Year = "2022" },
                new MonitoringItemResultsEntity { Id = 8, CompanyId = 1, MonitoringItemId = 25, CrawlerId = 101, Hash = "vwx234", Category = "Vegetais", Seller = "Supermarket H", Brand = "Brand H", State = "BA", Year = "2023" },
                new MonitoringItemResultsEntity { Id = 9, CompanyId = 1, MonitoringItemId = 26, CrawlerId = 101, Hash = "yza567", Category = "Vegetais", Seller = "Supermarket I", Brand = "Brand I", State = "CE", Year = "2023" },
                new MonitoringItemResultsEntity { Id = 10, CompanyId = 2, MonitoringItemId = 27, CrawlerId = 102, Hash = "bcd890", Category = "Vegetais", Seller = "Supermarket J", Brand = "Brand J", State = "PR", Year = "2023" },
                new MonitoringItemResultsEntity { Id = 11, CompanyId = 2, MonitoringItemId = 28, CrawlerId = 102, Hash = "efg123", Category = "Vegetais", Seller = "Supermarket K", Brand = "Brand K", State = "SC", Year = "2023" },
                new MonitoringItemResultsEntity { Id = 12, CompanyId = 3, MonitoringItemId = 29, CrawlerId = 103, Hash = "hij456", Category = "Vegetais", Seller = "Supermarket L", Brand = "Brand L", State = "RJ", Year = "2022" },
                new MonitoringItemResultsEntity { Id = 13, CompanyId = 3, MonitoringItemId = 30, CrawlerId = 103, Hash = "klm789", Category = "Vegetais", Seller = "Supermarket M", Brand = "Brand M", State = "MG", Year = "2022" },
                new MonitoringItemResultsEntity { Id = 14, CompanyId = 1, MonitoringItemId = 30, CrawlerId = 101, Hash = "nop012", Category = "Eletrônicos", Seller = "Supermarket N", Brand = "Brand N", State = "SP", Year = "2023" },
                new MonitoringItemResultsEntity { Id = 15, CompanyId = 1, MonitoringItemId = 31, CrawlerId = 101, Hash = "qrs345", Category = "Eletrônicos", Seller = "Supermarket O", Brand = "Brand O", State = "SP", Year = "2023" },
                new MonitoringItemResultsEntity { Id = 16, CompanyId = 1, MonitoringItemId = 32, CrawlerId = 102, Hash = "tuv678", Category = "Eletrônicos", Seller = "Supermarket P", Brand = "Brand P", State = "SP", Year = "2023" },
                new MonitoringItemResultsEntity { Id = 17, CompanyId = 2, MonitoringItemId = 33, CrawlerId = 102, Hash = "wxy901", Category = "Eletrônicos", Seller = "Supermarket Q", Brand = "Brand Q", State = "SP", Year = "2023" },
                new MonitoringItemResultsEntity { Id = 18, CompanyId = 3, MonitoringItemId = 34, CrawlerId = 103, Hash = "zab234", Category = "Eletrônicos", Seller = "Supermarket R", Brand = "Brand R", State = "SP", Year = "2022" },
                new MonitoringItemResultsEntity { Id = 19, CompanyId = 3, MonitoringItemId = 35, CrawlerId = 103, Hash = "cde567", Category = "Eletrônicos", Seller = "Supermarket S", Brand = "Brand S", State = "SP", Year = "2022" },
                new MonitoringItemResultsEntity { Id = 20, CompanyId = 1, MonitoringItemId = 36, CrawlerId = 101, Hash = "fgh890", Category = "Eletrônicos", Seller = "Supermarket T", Brand = "Brand T", State = "SP", Year = "2023" },
                new MonitoringItemResultsEntity { Id = 21, CompanyId = 1, MonitoringItemId = 37, CrawlerId = 101, Hash = "ijk123", Category = "Eletrônicos", Seller = "Supermarket U", Brand = "Brand U", State = "SP", Year = "2023" },
                new MonitoringItemResultsEntity { Id = 22, CompanyId = 2, MonitoringItemId = 38, CrawlerId = 102, Hash = "lmn456", Category = "Eletrônicos", Seller = "Supermarket V", Brand = "Brand V", State = "SP", Year = "2023" },
                new MonitoringItemResultsEntity { Id = 23, CompanyId = 2, MonitoringItemId = 39, CrawlerId = 102, Hash = "opq789", Category = "Eletrônicos", Seller = "Supermarket W", Brand = "Brand W", State = "SP", Year = "2023" },
                new MonitoringItemResultsEntity { Id = 24, CompanyId = 3, MonitoringItemId = 40, CrawlerId = 103, Hash = "rst012", Category = "Eletrônicos", Seller = "Supermarket X", Brand = "Brand X", State = "SP", Year = "2022" },
                new MonitoringItemResultsEntity { Id = 25, CompanyId = 3, MonitoringItemId = 1, CrawlerId = 103, Hash = "uvw345", Category = "Fruta", Seller = "Supermarket Y", Brand = "Brand Y", State = "SP", Year = "2022" },
                new MonitoringItemResultsEntity { Id = 26, CompanyId = 1, MonitoringItemId = 2, CrawlerId = 101, Hash = "xyz678", Category = "Fruta", Seller = "Supermarket Z", Brand = "Brand Z", State = "SP", Year = "2023" },
                new MonitoringItemResultsEntity { Id = 27, CompanyId = 1, MonitoringItemId = 3, CrawlerId = 101, Hash = "abc890", Category = "Fruta", Seller = "Supermarket AA", Brand = "Brand AA", State = "SP", Year = "2023" },
                new MonitoringItemResultsEntity { Id = 28, CompanyId = 2, MonitoringItemId = 4, CrawlerId = 102, Hash = "def012", Category = "Fruta", Seller = "Supermarket AB", Brand = "Brand AB", State = "SP", Year = "2023" },
                new MonitoringItemResultsEntity { Id = 29, CompanyId = 2, MonitoringItemId = 5, CrawlerId = 102, Hash = "ghi345", Category = "Fruta", Seller = "Supermarket AC", Brand = "Brand AC", State = "SP", Year = "2023" },
                new MonitoringItemResultsEntity { Id = 30, CompanyId = 3, MonitoringItemId = 6, CrawlerId = 103, Hash = "jkl678", Category = "Fruta", Seller = "Supermarket AD", Brand = "Brand AD", State = "SP", Year = "2022" },
                new MonitoringItemResultsEntity { Id = 31, CompanyId = 3, MonitoringItemId = 7, CrawlerId = 103, Hash = "mno901", Category = "Fruta", Seller = "Supermarket AE", Brand = "Brand AE", State = "SP", Year = "2022" },
                new MonitoringItemResultsEntity { Id = 32, CompanyId = 1, MonitoringItemId = 8, CrawlerId = 101, Hash = "pqr234", Category = "Fruta", Seller = "Supermarket AF", Brand = "Brand AF", State = "SP", Year = "2023" },
                new MonitoringItemResultsEntity { Id = 33, CompanyId = 1, MonitoringItemId = 9, CrawlerId = 101, Hash = "stu567", Category = "Fruta", Seller = "Supermarket AG", Brand = "Brand AG", State = "SP", Year = "2023" },
                new MonitoringItemResultsEntity { Id = 34, CompanyId = 2, MonitoringItemId = 10, CrawlerId = 102, Hash = "vwx890", Category = "Fruta", Seller = "Supermarket AH", Brand = "Brand AH", State = "SP", Year = "2023" },
                new MonitoringItemResultsEntity { Id = 35, CompanyId = 2, MonitoringItemId = 11, CrawlerId = 102, Hash = "yza123", Category = "Fruta", Seller = "Supermarket AI", Brand = "Brand AI", State = "SP", Year = "2023" },
                new MonitoringItemResultsEntity { Id = 36, CompanyId = 3, MonitoringItemId = 12, CrawlerId = 103, Hash = "bcd456", Category = "Fruta", Seller = "Supermarket AJ", Brand = "Brand AJ", State = "SP", Year = "2022" },
                new MonitoringItemResultsEntity { Id = 37, CompanyId = 3, MonitoringItemId = 13, CrawlerId = 103, Hash = "efg789", Category = "Fruta", Seller = "Supermarket AK", Brand = "Brand AK", State = "SP", Year = "2022" },
                new MonitoringItemResultsEntity { Id = 38, CompanyId = 1, MonitoringItemId = 14, CrawlerId = 101, Hash = "hij012", Category = "Fruta", Seller = "Supermarket AL", Brand = "Brand AL", State = "SP", Year = "2023" },
                new MonitoringItemResultsEntity { Id = 39, CompanyId = 1, MonitoringItemId = 15, CrawlerId = 101, Hash = "klm345", Category = "Fruta", Seller = "Supermarket AM", Brand = "Brand AM", State = "SP", Year = "2023" },
                new MonitoringItemResultsEntity { Id = 40, CompanyId = 2, MonitoringItemId = 16, CrawlerId = 102, Hash = "nop678", Category = "Fruta", Seller = "Supermarket AN", Brand = "Brand AN", State = "SP", Year = "2023" },
                new MonitoringItemResultsEntity { Id = 41, CompanyId = 2, MonitoringItemId = 17, CrawlerId = 102, Hash = "qrs901", Category = "Fruta", Seller = "Supermarket AO", Brand = "Brand AO", State = "SP", Year = "2023" },
                new MonitoringItemResultsEntity { Id = 42, CompanyId = 3, MonitoringItemId = 18, CrawlerId = 103, Hash = "tuv234", Category = "Fruta", Seller = "Supermarket AP", Brand = "Brand AP", State = "SP", Year = "2022" },
                new MonitoringItemResultsEntity { Id = 43, CompanyId = 3, MonitoringItemId = 19, CrawlerId = 103, Hash = "wxy567", Category = "Fruta", Seller = "Supermarket AQ", Brand = "Brand AQ", State = "SP", Year = "2022" },
                new MonitoringItemResultsEntity { Id = 44, CompanyId = 1, MonitoringItemId = 20, CrawlerId = 101, Hash = "zab890", Category = "Fruta", Seller = "Supermarket AR", Brand = "Brand AR", State = "SP", Year = "2023" },
                new MonitoringItemResultsEntity { Id = 45, CompanyId = 1, MonitoringItemId = 21, CrawlerId = 101, Hash = "cde123", Category = "Fruta", Seller = "Supermarket AS", Brand = "Brand AS", State = "SP", Year = "2023" },
                new MonitoringItemResultsEntity { Id = 46, CompanyId = 2, MonitoringItemId = 22, CrawlerId = 102, Hash = "fgh456", Category = "Fruta", Seller = "Supermarket AT", Brand = "Brand AT", State = "SP", Year = "2023" },
                new MonitoringItemResultsEntity { Id = 47, CompanyId = 2, MonitoringItemId = 23, CrawlerId = 102, Hash = "ijk789", Category = "Fruta", Seller = "Supermarket AU", Brand = "Brand AU", State = "SP", Year = "2023" },
                new MonitoringItemResultsEntity { Id = 48, CompanyId = 3, MonitoringItemId = 24, CrawlerId = 103, Hash = "lmn012", Category = "Fruta", Seller = "Supermarket AV", Brand = "Brand AV", State = "SP", Year = "2022" },
                new MonitoringItemResultsEntity { Id = 49, CompanyId = 3, MonitoringItemId = 25, CrawlerId = 103, Hash = "opq345", Category = "Fruta", Seller = "Supermarket AW", Brand = "Brand AW", State = "SP", Year = "2022" },
                new MonitoringItemResultsEntity { Id = 50, CompanyId = 1, MonitoringItemId = 26, CrawlerId = 101, Hash = "rst678", Category = "Fruta", Seller = "Supermarket AX", Brand = "Brand AX", State = "SP", Year = "2023" }
            };
        }
    }
}
