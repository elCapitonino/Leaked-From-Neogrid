﻿using PredifyClientAPI.Services.PredifyAPI.Models;
using PredifyClientAPI.Services.PredifyAPI.PriceGroup.Models;

namespace PredifyClientAPI.Services.PredifyAPI.PriceGroup
{
    public interface IPriceGroupService
    {
        Task<GeneralResponse<List<EnterpriseListGroupsResponse>>> List(EnterpriseListGroupsRequest request);
    }
}
