from pydantic import BaseModel
from typing import Optional
from typing import List
from datetime import datetime
from enum import Enum


class Used_hours(BaseModel):
    min: Optional[int] = None
    max: Optional[int] = None


class search_source_type(Enum):
    predify = 0
    linx = 1
    Horus_search = 2    # Horus search
    Smarket_search = 3    # Smarket search
    Neogrid_search = 4      # Neogrid search
    Nielsen = 5     # Nielsen search
    Nielsen_vem = 6     # Nielsen vem search
    Europe_products = 7 
    Mercantil_Nova_Era = 8
    Linx_Vem = 9
    VEM_Distribuidores = 10
    Demo_Varejo = 11
    ABV = 12
    Sao_Joao_InfoPrice = 13
    Linx_Farma_Sellout = 14

class id_company_config(Enum):
    addiante = 3083 # Addiante Company 


class crawlers_offline(BaseModel):
    idcrawlers: Optional[int] = None
    city: Optional[str] = None
    state: Optional[str] = None
    networks: Optional[str] = None
    cnpj: Optional[str] = None


class ean_list(BaseModel):
    ean: str = None
    description: str = None


class List_products_pred_monitor(BaseModel):
    products: Optional[list] = None
    eans: Optional[List[ean_list]] = None
    categories: Optional[list] = None
    networks: Optional[list] = None
    brands: Optional[list] = None
    sources: Optional[list] = None
    local_states: Optional[list] = None
    postal_code: Optional[list] = None
    manufacture_years: Optional[list] = None
    mandatoryTagModel: Optional[str]= None
    used_hours: Optional[Used_hours] = None
    language: Optional[str] = None
    exactVector: Optional[bool] = True


class   Search_products_predmonitor(BaseModel):
    start_date: datetime = None
    end_date: datetime = None
    period_type: Optional[int] = None
    id_company: Optional[int] = None
    idcrawlers: Optional[list] = None
    idcrawlers_offline: Optional[List[crawlers_offline]] = None
    data_source: Optional[search_source_type] = search_source_type.predify
    filters: List_products_pred_monitor = None
    #exactVector: Optional[bool] = True
