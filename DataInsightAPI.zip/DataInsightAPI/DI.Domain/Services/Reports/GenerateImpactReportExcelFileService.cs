﻿using ClosedXML.Excel;
using DI.Domain.Services.Interfaces.Reports;
using DI.Domain.ValueObjects;
using DI.Repository.Enum;
using System.Diagnostics.CodeAnalysis;

namespace DI.Domain.Services.Reports
{
    /// <summary>
    /// Serviço responsável por gerar arqvuivo do relatório de excel
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class GenerateImpactReportExcelFileService : IGenerateImpactReportExcelFileService
    {
        private const string ColorCategories = "#FFFF00";
        private const string ColorHeaders = "#002060";
        private const string ColorSubHeaders = "#215C98";
        private const string ColorTotalValue = "#00B050";


        /// <summary>
        /// Gera um arquivo Excel e retorna um MemoryStream desse arquivo de acordo com os dados de relatório de impacto fornecidos
        /// </summary>
        /// <param name="data">Dados do relatório de impacto</param>
        /// <param name="cancellation">Token de cancelamento</param>
        /// <returns>Um MemoryStream do arquivo excel gerado</returns>
        public async Task<MemoryStream> Generate(ValueObjects.ImpactReport data, CancellationToken cancellation)
        {
            var stream = new MemoryStream();

            using (var workbook = new XLWorkbook())
            {
                workbook.Style.Font.FontName = "Calibri";

                foreach (var impactData in data.ImpactPreDataConsolidateds)
                {
                    DrawWorkSheet(workbook, impactData, data.ImagePath);
                }

                workbook.SaveAs(stream);
                stream.Position = 0;

                return stream;
            }
        }

        /// <summary>
        /// Cria e desenha um novo Worksheet no arquivo excel
        /// </summary>
        /// <param name="workbook">WorkBook do arquivo excel</param>
        /// <param name="impactData">Dados do relatório a ser desenhado no arquivo excel</param>
        /// <param name="majorGranularity">Granularidade do relatório, antigamente chamado de affiliates</param>
        /// <param name="imagePath">imagem a ser usada no topo de cada worksheet do arquivo excel</param>
        private void DrawWorkSheet(IXLWorkbook workbook, ImpactReportWorksheet impactData, string? imagePath = null)
        {
            var worksheet = workbook.Worksheets.Add(impactData.WorkSheetName);

            if (!string.IsNullOrEmpty(imagePath) && File.Exists(imagePath))
                worksheet.AddPicture(imagePath)
                            .MoveTo(worksheet.Cell("B2"))
                            .ScaleWidth(.75)
                            .ScaleHeight(.75);

            worksheet.Row(6).Height = 40;
            worksheet.Row(12).Height = 40;

            SetConsideredFiltersTableStylesAndData(worksheet, impactData);

            SetPriceApprovalAndAdoptionTableStylesAndData(worksheet, impactData);

            SetTablesStylesAndData(worksheet, 19, 2, impactData.Tables);

        }

        /// <summary>
        /// Desenha uma tabela dentro do worksheet excel com informações dos filtros considerados para o relatório
        /// </summary>
        /// <param name="worksheet">Worksheet onde deve ser desenhado </param>
        /// <param name="majorGranularity">Granularidade do relatório. Antigamente chamado de affiliates</param>
        /// <param name="impactData">Dados do relarório de impacto</param>
        private void SetConsideredFiltersTableStylesAndData(IXLWorksheet worksheet, ImpactReportWorksheet impactData)
        {
            AddTableHeader(worksheet, 6, 2, "FILTROS CONSIDERADOS", 4);

            var firstTableDataRange = worksheet.Range(7, 2, 9, 3).Style;
            firstTableDataRange.Font.FontSize = 11;
            worksheet.Columns(2, 3).Width = 35;
            worksheet.Columns(4, 6).Width = 30;
            worksheet.Column(1).Width = 9;
            worksheet.Column(7).Width = 9;

            worksheet.Cell("B7").Value = "Filiais consideradas:";
            worksheet.Cell("B8").Value = "Período considerado:";
            worksheet.Cell("B9").Value = "Precificações consideradas:";

            worksheet.Cell("C7").Value = impactData.MajorGranularity;
            worksheet.Cell("C8").Value = impactData.PeriodConsidered;
            worksheet.Cell("C9").Value = impactData.GroupName;

            worksheet.Cell("D7").Value = impactData.AffiliatesCount;
            worksheet.Cell("D9").Value = impactData.GroupsCount;

        }

        /// <summary>
        /// Desenha uma tabela dentro do worksheet excel com informaçoes dos totais de aprovações e adoçoes de precos gerados pela IA
        /// </summary>
        /// <param name="worksheet">Worksheet excel onde deve ser desenhado a tabela</param>
        /// <param name="impactData">Dados do relatório para desenahr a tabela no worksheet</param>
        private void SetPriceApprovalAndAdoptionTableStylesAndData(IXLWorksheet worksheet, ImpactReportWorksheet impactData)
        {
            AddTableHeader(worksheet, 12, 2, "APROVAÇÃO E ADOÇÃO DE PREÇOS", 4);

            var secondTableDataRange = worksheet.Range(13, 2, 16, 5).Style;
            secondTableDataRange.Font.FontSize = 11;
            var secondTableCustomRangeStyle = worksheet.Range(13, 2, 16, 3).Style;
            secondTableCustomRangeStyle.Font.FontColor = XLColor.White;
            secondTableCustomRangeStyle.Fill.BackgroundColor = XLColor.FromHtml(ColorHeaders);
            worksheet.Range("B13:C13").Merge().Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
            worksheet.Range("B14:C14").Merge().Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
            worksheet.Range("B15:C15").Merge().Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
            worksheet.Range("B16:C16").Merge().Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;

            worksheet.Range("D13:E13").Merge().Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
            worksheet.Range("D14:E14").Merge().Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;


            worksheet.Cell("B13").Value = "TOTAL DE SKUS DISPONÍVEIS PARA PRECIFICAÇÃO";
            worksheet.Cell("B14").Value = "TOTAL DE SKUS PRECIFICADOS";
            worksheet.Cell("B15").Value = "SKUS APROVADOS";
            worksheet.Cell("B16").Value = "SKUS ADOTADOS";

            worksheet.Cell("D13").Value = impactData.TotalSkus;
            worksheet.Cell("D14").Value = impactData.TotalSkusPrecification;

            worksheet.Cell("D15").Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Right;
            worksheet.Cell("D16").Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Right;
            worksheet.Cell("E16").Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Right;
            worksheet.Cell("E15").Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Right;
            worksheet.Cell("E15").Style.NumberFormat.Format = "#,##0.00%";
            worksheet.Cell("E16").Style.NumberFormat.Format = "#,##0.00%";
            worksheet.Cell("D15").Style.NumberFormat.Format = "#,##0";
            worksheet.Cell("D16").Style.NumberFormat.Format = "#,##0";

            worksheet.Cell("D15").Value = impactData.ApprovedSkus;
            worksheet.Cell("D16").Value = impactData.AdoptedSkus;

            worksheet.Cell("E15").Value = impactData.PercentageApprovedSkus;
            worksheet.Cell("E16").Value = impactData.PercentageAdoptedSkus;
        }

        /// <summary>
        /// Desenha uma lista de tabelas no Worksheet excel informado
        /// </summary>
        /// <param name="worksheet">Worksheet excel onde as tabelas devem ser desenhadas</param>
        /// <param name="startRow">Linha inicial</param>
        /// <param name="startColumn">Coluna inicial onde as tabelas devem ser desenhadas</param>param>
        /// <param name="impactDataTables">Lista de tabelas a serem desenhadas</param>
        private void SetTablesStylesAndData(IXLWorksheet worksheet, int startRow, int startColumn, IEnumerable<ImpactReportTable> impactDataTables)
        {
            var currentRow = startRow;

            foreach (var dataTable in impactDataTables)
            {
                AddTableHeader(worksheet, currentRow, startColumn, dataTable.Header, horizontalLength: 6);
                AddTableSubHeader(worksheet, currentRow + 1, startColumn, dataTable.SubHeaders);
                AddTableLines(worksheet, currentRow + 2, startColumn, dataTable);

                currentRow += 3 + dataTable.Lines.Count();
            }
        }
        /// <summary>
        /// Adiciona um header na tabela que está desenhando. Este header pode ser de qualquer tamanho informado
        /// </summary>
        /// <param name="worksheet">Worksheet excel onde as linhas devem ser desenhadas</param>
        /// <param name="row">Linha onde deve iniciar o desenho do header</param>
        /// <param name="column">Coluna onde deve iniciar o desenho do header</param>
        /// <param name="title">Texto que deve ser desenhado no header</param>
        /// <param name="horizontalLength">Tamanho horizontal do header, em células</param>
        /// <param name="verticalLength">Tamanho vertical do header, em células</param>
        private void AddTableHeader(IXLWorksheet worksheet, int row, int column, string title, int horizontalLength = 1, int verticalLength = 1)
        {
            var headerStyle = worksheet.Range(row, column, row + verticalLength - 1, column + horizontalLength - 1).Merge().Style;
            headerStyle.Font.FontSize = 26;
            headerStyle.Alignment.Vertical = XLAlignmentVerticalValues.Center;
            headerStyle.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
            headerStyle.Fill.BackgroundColor = XLColor.FromHtml(ColorHeaders);
            headerStyle.Font.FontColor = XLColor.White;
            worksheet.Cell(row, column).Value = title;
            worksheet.Row(row).Height = 40;
        }

        /// <summary>
        /// Adiciona uma linha personalizada de subheaders na tabela
        /// </summary>
        /// <param name="worksheet">Worksheet excel onde as linhas devem ser desenhadas</param>
        /// <param name="row">Posição inicial onde deve ser iniciado o desenho dos sub-headers</param>
        /// <param name="column">Posição inicial onde deve ser iniciado o desenho dos sub-headers</param>
        /// <param name="titles">Lista de subtitulos a serem desenhados na tabela, os estilos só serão aplicados para a quantidade contida nesta lista</param>
        private void AddTableSubHeader(IXLWorksheet worksheet, int row, int column, string[] titles)
        {
            for (int i = 0; i < titles.Length; i++)
            {
                worksheet.Cell(row, i + 2).Value = titles[i];
            }
            var subHeaderStyle = worksheet.Range(row, column, row, column + titles.Length - 1).Style;
            subHeaderStyle.Font.FontSize = 11;
            subHeaderStyle.Font.FontColor = XLColor.White;
            subHeaderStyle.Fill.BackgroundColor = XLColor.FromHtml(ColorSubHeaders);
            subHeaderStyle.Alignment.Horizontal = XLAlignmentHorizontalValues.Left;
        }

        /// <summary>
        /// Método utilizado para preencher e estilizar as linhas de uma tabela dentro do worksheet excel informado, partindo de qualquer posição do worksheet,
        /// Porém deve se atentar para informar a posição dentro da área onde está desenhando a tabela
        /// </summary>
        /// <param name="worksheet">Worksheet excel onde as linhas devem ser desenhadas</param>
        /// <param name="row">Linha inicial onde deve ser iniciado o desenho das linhas da tabela</param>
        /// <param name="column">Coluna inicial onde deve ser iniciado o desenho das linhas da tabela</param>
        /// <param name="data">Dados a serem preenchidos</param>
        private void AddTableLines(IXLWorksheet worksheet, int row, int column, ImpactReportTable data)
        {
            var currentRow = 0;
            foreach (ImpactReportTableLine line in data.Lines.SkipLast(1).OrderBy(x => x.Value))
            {
                var headerCellStyle = worksheet.Cell(row + currentRow, column).Style;

                headerCellStyle.Fill.BackgroundColor = XLColor.FromHtml(ColorCategories);
                headerCellStyle.Alignment.Horizontal = XLAlignmentHorizontalValues.Left;

                worksheet.Cell(row + currentRow, column).Value = line.Value;

                for (int i = 0; i < data.NumberValueFormats.Length; i++)
                {
                    var valueCellNumberStyle = worksheet.Cell(row + currentRow, column + i + 1).Style;

                    valueCellNumberStyle.Alignment.Horizontal = XLAlignmentHorizontalValues.Right;
                    valueCellNumberStyle.NumberFormat.Format = data.NumberValueFormats[i];
                }

                worksheet.Cell(row + currentRow, column + 1).Value = line.BeforeIA;
                worksheet.Cell(row + currentRow, column + 2).Value = line.Projection;
                worksheet.Cell(row + currentRow, column + 3).Value = line.AfterIA;
                worksheet.Cell(row + currentRow, column + 4).Value = line.DifferentPredifyXCompany;
                worksheet.Cell(row + currentRow, column + 5).Value = line.Variation;

                currentRow++;
            }


            var firstTotalDataLineStyle = worksheet.Cell(row + currentRow, column).Style;
            firstTotalDataLineStyle.Font.FontSize = 11;
            firstTotalDataLineStyle.Font.FontColor = XLColor.White;
            firstTotalDataLineStyle.Fill.BackgroundColor = XLColor.FromHtml(ColorHeaders);
            firstTotalDataLineStyle.Alignment.Horizontal = XLAlignmentHorizontalValues.Left;

            var secondTotalDataLineStyle = worksheet.Range($"F{row + currentRow}:G{row + currentRow}").Style;
            secondTotalDataLineStyle.Font.FontSize = 11;
            secondTotalDataLineStyle.Alignment.Horizontal = XLAlignmentHorizontalValues.Right;

            var lastLine = data.Lines.Last();

            if (data.Type != EConditionGenerateDataTableType.Royalty
                && lastLine.DifferentPredifyXCompany >= 0)
            {
                secondTotalDataLineStyle.Fill.BackgroundColor = XLColor.FromHtml(ColorTotalValue);
            }

            for (int i = 0; i < data.NumberValueFormats.Length; i++)
            {
                var valueCellNumberStyle = worksheet.Cell(row + currentRow, column + i + 1).Style;

                valueCellNumberStyle.Alignment.Horizontal = XLAlignmentHorizontalValues.Right;
                valueCellNumberStyle.NumberFormat.Format = data.NumberValueFormats[i];
            }

            worksheet.Cell(row + currentRow, column).Value = lastLine.Value;
            worksheet.Cell(row + currentRow, column + 1).Value = lastLine.BeforeIA;
            worksheet.Cell(row + currentRow, column + 2).Value = lastLine.Projection;
            worksheet.Cell(row + currentRow, column + 3).Value = lastLine.AfterIA;
            worksheet.Cell(row + currentRow, column + 4).Value = lastLine.DifferentPredifyXCompany;
            worksheet.Cell(row + currentRow, column + 5).Value = lastLine.Variation;

            if (data.Type == EConditionGenerateDataTableType.Royalty)
            {
                worksheet.Cell(row + currentRow - 1, column + 3).Value = "Meta";
                worksheet.Cell(row + currentRow - 1, column + 4).Value = "ROI";

                var personalizedFieldsStyle = worksheet.Range(row + currentRow - 1, column + 3, row + currentRow - 1, column + 4).Style;
                personalizedFieldsStyle.Font.Bold = true;
                personalizedFieldsStyle.Font.FontSize = 11;
                personalizedFieldsStyle.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
            }

        }
    }
}
