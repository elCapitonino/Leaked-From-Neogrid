﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services.SearchAPI.Models
{
    public class SearchAPIOptions
    {
        public Uri UrlBase { get; set; }
    }
}
