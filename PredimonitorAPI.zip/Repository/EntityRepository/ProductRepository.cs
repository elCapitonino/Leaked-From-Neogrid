using Repository.DbContexts;
using Repository.Entity.Databricks;
using Repository.EntityRepository.Bases;
using System.Data;

namespace Repository.EntityRepository;

public class ProductRepository : GenericDatabricksRepository<ProductEntity>, IProductRepository
{
    public ProductRepository(DatabricsDbContext dbContext) : base(dbContext, "products")
    {
    }
}