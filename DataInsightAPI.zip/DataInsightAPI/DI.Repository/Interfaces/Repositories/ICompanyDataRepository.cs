﻿namespace DI.Repository.Interfaces.Repositories
{
    public interface ICompanyDataRepository
    {
        Task<string> GetCompanyName(long CompanyId);
    }
}
