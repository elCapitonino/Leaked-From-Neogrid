﻿using Newtonsoft.Json;

namespace Domain.Models
{
    public sealed class GetAvailablePromptsResponse
    {
        [JsonProperty("title")]
        public required string Title {  get; set; }

        [JsonProperty("subsections")]
        public required AvailablePromptResponse[] Sections { get; set; }
    }
    public sealed class AvailablePromptResponse
    {
        [JsonProperty("subtitle")]
        public required string Title { get; set; }

        [JsonProperty("prompts")]
        public required string[] Prompts { get; set; }
    }
}
