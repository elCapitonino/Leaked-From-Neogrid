﻿using DI.Repository.Attributes;
using DI.Repository.Contexts;
using DI.Repository.Entities;
using DI.Repository.Enum;
using DI.Repository.Interfaces.Repositories;
using DI.Repository.Repositories.Base;

namespace DI.Repository.Repositories
{
    [UsePostgreContext]
    public sealed class MonthlyProjectionDataRepository : PostgreGenericNoModifyRepository<MonthlyProjectionDataEntity>, IMonthlyProjectionDataRepository
    {
        public MonthlyProjectionDataRepository(PostgreContext dbContext) : base(dbContext)
        {
        }

        public IEnumerable<MonthlyProjectionDataEntity> GetAll(long CompanyId, int startYearMonth, int endYearMonth, EGranularityType eGranularityType)
        {
            return _dbContext
                .Set<MonthlyProjectionDataEntity>()
                .Where(x => x.CompanyId == CompanyId && x.YearMonth >= startYearMonth && x.YearMonth <= endYearMonth && x.GranularityGroup!.GranularityType == eGranularityType);
        }
    }
}
