﻿using CS.Domain.Domain;
using CS.Domain.DTO;

namespace CS.Domain.Interfaces.Repositories
{
    public interface IEnterpriseSalesHistoryRepository
    {
        Task<IEnumerable<EnterpriseSalesHistoryElasticSimpleCalculator>> GetESHWithSimpleFilters(SimpleSearchDTO searchFilter);
    }
}
