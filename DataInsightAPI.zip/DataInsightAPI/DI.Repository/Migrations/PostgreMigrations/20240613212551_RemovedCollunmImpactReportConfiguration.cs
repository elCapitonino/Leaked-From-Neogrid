﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DI.Repository.Migrations.PostgreMigrations
{
    /// <inheritdoc />
    public partial class RemovedCollunmImpactReportConfiguration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ConsolidateGroupField",
                table: "ImpactReportConfiguration");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "ConsolidateGroupField",
                table: "ImpactReportConfiguration",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);
        }
    }
}
