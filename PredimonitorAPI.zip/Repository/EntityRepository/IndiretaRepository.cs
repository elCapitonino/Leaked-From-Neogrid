﻿using Repository.DbContexts;
using Repository.Entity;
using Repository.EntityRepository.Bases;

namespace Repository.EntityRepository
{
    public class IndiretaRepository : GenericMongoRepository<IndiretaEntity>, IIndiretaRepository
    {
        public IndiretaRepository(NeogridDbContext dbContext) : base(dbContext)
        {
        }

        public static string DbContextName => nameof(NeogridDbContext);
    }

}
