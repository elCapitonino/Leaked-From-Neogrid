from datetime import datetime
from typing import Dict, List, Optional, Union

from pydantic import BaseModel, confloat, validator

from predimonitor_type import search_source_type
from logger import logger


# general


class CrawlersOffline(BaseModel):
    idcrawlers: Optional[int] = None
    city: Optional[str] = None
    state: Optional[str] = None
    store: Optional[str] = None
    store_type: Optional[str] = None
    networks: Optional[str] = None
    cnpj: Optional[str] = None


class PriceParsingError(Exception):
    pass


class PriceRange(BaseModel):
    lower: Optional[confloat(ge=0)] = None
    upper: Optional[confloat(gt=0)] = None

    @validator("upper")
    @classmethod
    def validate_one_field_using_the_others(cls, field_value, values, field, config):
        lower = values.get("lower")
        if lower is None or field_value is None:
            return field_value
        if lower >= field_value:
            raise ValueError("price_range: lower deve ser menor do que upper")
        return field_value

    def is_product_valid(self, seller: Dict) -> bool:
        prices = []
        try:
            for price_obj in seller.get("prices", {}):
                if unit_price := price_obj.get("price_unit"):
                    prices.append(float(unit_price))
                elif price := price_obj.get("price"):
                    prices.append(float(price))
        except ValueError as exc:
            raise PriceParsingError(
                "parsing do preço nos documentos do Mongo falhou. Tente remover o filtro price_range."
            ) from exc
        if self.upper is not None and all(price > self.upper for price in prices):
            logger.debug(
                "preços (%s) fora do range permitido: [%s - %s]",
                prices,
                round(self.lower, 2) if self.lower else None,
                round(self.upper, 2) if self.upper else None,
            )
            return False
        if self.lower is not None and all(price < self.lower for price in prices):
            logger.debug(
                "preços (%s) fora do range permitido: [%s - %s]",
                prices,
                round(self.lower, 2) if self.lower else None,
                round(self.upper, 2) if self.upper else None,
            )
            return False
        return True


# V1


class ListProducts(BaseModel):
    id: str
    name: str
    code: Optional[str] = None
    ean: Optional[str] = None
    ncm: Optional[str] = None
    model: Optional[str] = None
    mandatoryTagModel: Optional[str] = None
    required_words: Optional[List[str]] = None
    restricted_words: Optional[List[str]] = None
    brand: Optional[str] = None
    language: str = "pt-br"
    price_range: Optional[PriceRange] = None


class SearchProductsBM25(BaseModel):
    start_date: datetime
    end_date: datetime
    idcrawlers: List[int]
    id_company: Optional[int] = None
    monitoring_item_date_filter: Optional[datetime] = None
    idcrawlers_offline: Optional[List[CrawlersOffline]] = None
    data_source: Optional[search_source_type] = search_source_type.predify
    products: Optional[List[ListProducts]] = None
    language: str = "pt-br"
    relative_threshold: confloat(gt=0.0, le=1.0) = 0.9
    fuzzy_threshold: confloat(ge=0.0, le=1.0) = 0.75
    restrictive_fuzzy_threshold: confloat(ge=0.0, le=1.0) = 0.9
    use_top_word: bool = True
    use_cosine: bool = True
    cache: bool = False
    bm25_mode: str = "bm25"


# V2


class UsedHours(BaseModel):
    min: Optional[int] = None
    max: Optional[int] = None


class EanList(BaseModel):
    ean: str = None
    description: str = None


class ListProductsPredmonitor(BaseModel):
    id_monitoring_item: int
    products: Optional[List] = None
    eans: Optional[List[EanList]] = None
    categories: Optional[List] = None
    sellers: Optional[List] = None
    #required_words: Optional[List[Union[None, List[str]]]] = None
    required_words: Optional[List[str]] = None
    restricted_words: Optional[List[str]] = None
    networks: Optional[List] = None
    brands: Optional[List[str]] = None
    sources: Optional[List] = None
    local_states: Optional[List] = None
    manufacture_years: Optional[List] = None
    used_hours: Optional[UsedHours] = None
    language: str = "pt-br"
    exactVector: Optional[bool] = True
    price_range: Optional[PriceRange] = None


class SearchProductsPredmonitorBM25(BaseModel):
    start_date: datetime = None
    end_date: datetime = None
    period_type: Optional[int] = None
    id_company: Optional[int] = None
    monitoring_item_date_filter: Optional[datetime] = None
    idcrawlers: Optional[List] = None
    idcrawlers_offline: Optional[List[CrawlersOffline]] = None
    data_source: Optional[search_source_type] = search_source_type.predify
    filters: ListProductsPredmonitor = None
    relative_threshold: confloat(gt=0.0, le=1.0) = 0.9
    fuzzy_threshold: confloat(gt=0.0, le=1.0) = 0.75
    restrictive_fuzzy_threshold: confloat(gt=0.0, le=1.0) = 0.9
    use_top_word: bool = True
    use_cosine: bool = True
    cache: bool = False
    bm25_mode: str = "bm25"
    ids_task: Optional[List] = None

class SearchHistoryV1(BaseModel):
    start_date: datetime = None
    end_date: datetime = None
    data_source: Optional[search_source_type] = search_source_type.predify
    product_links: List[str] = None




























#LIMA PASSOU POR AQUI
#AAAAAAAAAAAAAAAAAAAAAAAAHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH