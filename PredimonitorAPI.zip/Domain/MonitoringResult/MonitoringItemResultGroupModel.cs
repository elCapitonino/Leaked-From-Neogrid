﻿using Domain.MonitoringResult.Models;

namespace Domain.MonitoringResult
{
    internal class MonitoringItemResultGroupModel
    {
        public long MonitoringItemId { get; set; }
        public List<MonitoringItemResultModel> MonitoringItemResultModel { get; set; }
    }
}