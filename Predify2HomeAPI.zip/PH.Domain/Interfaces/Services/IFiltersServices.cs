﻿using PH.Domain.DTO;

namespace PH.Domain.Interfaces.Services
{
    public interface IFiltersServices
    {
        Task<FiltersMainDTO> Get();
    }
}
