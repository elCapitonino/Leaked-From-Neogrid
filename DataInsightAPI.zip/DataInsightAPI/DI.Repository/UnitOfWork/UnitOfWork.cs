﻿using DI.Repository.Contexts;
using DI.Repository.Enum;
using DI.Repository.Interfaces;
using DI.Repository.Interfaces.Repositories;
using System.Transactions;

namespace DI.Repository.UnitOfWork
{
    public class UnitOfWork : IUnitOfWork
    {
        private bool disposed = false;
        private readonly SqlContext sqlContext;
        private readonly PostgreContext postgreContext;

        public UnitOfWork(SqlContext sqlContext, PostgreContext postgreContext)
        {
            this.sqlContext = sqlContext;
            this.postgreContext = postgreContext;
            this.InitializeRepository(sqlContext, postgreContext);
        }

        public IMonthlySaleHistoryDataRepository MonthlySaleHistoryDataRepository { get; }
        public IProjectionImpactDataRepository ProjectionImpactDataRepository { get; }
        public IMonthlyProjectionDataRepository MonthlyProjectionDataRepository { get; }
        public IEnterprisePriceProjectionRepository EnterprisePriceProjectionRepository { get; }
        public IEnterprisePriceGroupRepository EnterprisePriceGroupRepository { get; }
        public IImpactReportConfigurationRepository ImpactReportConfigurationRepository { get; }
        public ICompanyDataRepository CompanyDataRepository { get; }
        public IMonthlyImpactDataRepository MonthlyImpactDataRepository { get; }
        public IGrupoRecursoRepository GrupoRecursosRepository { get; }
        public IGranularityGroupRepository GranularityGroupRepository { get; }

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    sqlContext.Dispose();
                    postgreContext.Dispose();
                }
            }
            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            System.GC.SuppressFinalize(this);
        }

        public int SaveChanges(EContextType contextType = EContextType.All)
        {
            var result = contextType switch
            {
                EContextType.SqlServer => sqlContext.SaveChanges(),
                EContextType.Postgre => postgreContext.SaveChanges(),
                EContextType.All => SaveAll(),
                _ => SaveAll(),
            };
            return result;
        }
        public Task<int> SaveChangesAsync(EContextType contextType = EContextType.All)
        {
            var result = contextType switch
            {
                EContextType.SqlServer => sqlContext.SaveChangesAsync(),
                EContextType.Postgre => postgreContext.SaveChangesAsync(),
                EContextType.All => SaveAllAsync(),
                _ => SaveAllAsync(),
            };
            return result;
        }
        public TransactionScope CreateTransactionScope() => new TransactionScope();
        public TransactionScope CreateTransactionScope(TransactionScopeAsyncFlowOption asyncFlowOption) => new TransactionScope(TransactionScopeOption.Required, TimeSpan.FromMinutes(60), asyncFlowOption);
        private int SaveAll()
        {
            sqlContext.SaveChanges();
            postgreContext.SaveChanges();
            return 0;
        }
        private async Task<int> SaveAllAsync()
        {
            await sqlContext.SaveChangesAsync();
            await postgreContext.SaveChangesAsync();
            return 0;
        }
    }
}