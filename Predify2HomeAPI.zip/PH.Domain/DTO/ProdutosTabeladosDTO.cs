﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PH.Domain.DTO
{
    public class ProdutosTabeladosDTO
    {
        public string EAN { get; set; }
        public string Description { get; set; }
        public double LastPrice { get; set; }
        public double FixedPrice { get; set; }
        public DateTime LastSale { get; set; }
    }
}
