﻿namespace DI.Domain.Models.ImpactReport
{
    public sealed class ImpactReportModel
    {
        public long? EnterprisePriceGroupsId { get; set; }
        public string? EnterprisePriceGroupsName { get; set; }
        public string? AffiliateName { get; set; }
        public string? Category { get; set; }
        public string? SubCategory { get; set; }
        public string? Product { get; set; }
        public string? PackageDescription { get; set; }
        public string? ProductName { get; set; }
        public string? ActionResult { get; set; }
        public string? ElasticityResult { get; set; }
        public string? SalePriceInferiorLimit_Demand_CurveABC { get; set; }
        public string? PriceGroupName { get; set; }
        public DateTime? PublishedDate { get; set; }
        public decimal? PriorCost { get; set; }
        public decimal? ProjectionCost { get; set; }
        public decimal? RealCost { get; set; }
        public decimal? PriorPrice { get; set; }
        public decimal? ProjectionPrice { get; set; }
        public decimal? RealPrice { get; set; }
        public bool? Adopted { get; set; }
        public decimal? PriorDemand { get; set; }
        public decimal? ProjectionDemand { get; set; }
        public decimal? RealDemand { get; set; }
        public decimal? PriorRevenue { get; set; }
        public decimal? ProjectionRevenue { get; set; }
        public decimal? RealRevenue { get; set; }
        public decimal? PriorProfit { get; set; }
        public decimal? ProjectionProfit { get; set; }
        public decimal? RealProfit { get; set; }
        public decimal? PriorMargin { get; set; }
        public decimal? ProjectionMargin { get; set; }
        public decimal? RealMargin { get; set; }
        public decimal? Royalty { get; set; }

    }
}
