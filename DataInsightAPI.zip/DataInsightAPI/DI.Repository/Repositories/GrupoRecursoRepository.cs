﻿using DI.Repository.Attributes;
using DI.Repository.Contexts;
using DI.Repository.Entities;
using DI.Repository.Interfaces.Repositories;
using DI.Repository.Repositories.Base;
using Microsoft.EntityFrameworkCore;

namespace DI.Repository.Repositories
{
    [UseSQLContext]
    public class GrupoRecursoRepository : SqlGenericNoModifyRepository<GrupoRecursoEntity>, IGrupoRecursoRepository
    {
        public GrupoRecursoRepository(SqlContext dbContext) : base(dbContext)
        {
        }

        public IEnumerable<GrupoRecursoEntity> GetAllByCompanyId(long companyId)
        {
            return _dbContext
                .Set<GrupoRecursoEntity>()
                .Where(x => x.IdEmpresa == companyId && !x.IsDeleted);
        }

        public GrupoRecursoEntity? GetByNameAndCompanyId(string nome, long companyId)
        {
            return _dbContext
            .Set<GrupoRecursoEntity>()
                .FirstOrDefault(x => x.Nome == nome && x.IdEmpresa == companyId && !x.IsDeleted);
        }

        public IQueryable<GrupoRecursoEntity> GetAll()
        {
            return _dbContext.Set<GrupoRecursoEntity>().AsQueryable();
        }

        public string GetHierarchyUserById(long companyId, string userId)
        {
            try
            {
                var userRole = _dbContext.Set<GrupoRecursoEntity>()
                    .Where(gr => gr.IdEmpresa == companyId && !gr.IsDeleted)
                    .Include(gr => gr.UsuarioGrupoRecursos)
                    .SelectMany(gr => gr.UsuarioGrupoRecursos, (grupo, usuarioGrupo) => new { grupo, usuarioGrupo })
                    .Where(result => result.usuarioGrupo.IdUsuario == userId && !result.usuarioGrupo.IsDeleted)
                    .Select(result => result.grupo.Nome)
                    .FirstOrDefault();

                return userRole;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao obter a hierarquia do usuário: {ex.Message}");
                throw;
            }
        }
    }
}
