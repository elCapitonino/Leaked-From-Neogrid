﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UpdateHash.Models
{
    public class IndiretaProducts
    {
        public ObjectId _id { get; set; }
        public int? ANOMESMOVIMENTO { get; set; }
        public string CNPJDISTRIBUIDOR { get; set; }

        [BsonElement("NOME DISTRIBUIDOR")]
        public string NOMEDISTRIBUIDOR { get; set; }

        [BsonElement("ULTIMA VENDA")]
        public DateTime? ULTIMAVENDA { get; set; }
        public string SETOR { get; set; }

        [BsonElement("DESCRICAOO PRODUTO")]
        public string DESCRICAOOPRODUTO { get; set; }

        [BsonElement("EAN PRODUTO")]
        public string EANPRODUTO { get; set; }

        public double? VALORVENDA { get; set; }
        public string PRECOMEDIO { get; set; }
        public double? QTDVENDA { get; set; }
        public string CEP { get; set; }
        public string ENDERECO { get; set; }
        public string BAIRRO { get; set; }
        public string CIDADE { get; set; }
        public string UF { get; set; }
        public string CUSTOITEM { get; set; }
        public string UF2 { get; set; }
        public string id_import { get; set; }
        public Coordinates? coordinates { get; set; }
    }

    public class Coordinates
    {
        public string type { get; set; }
        public float[] coordinates { get; set; }
    }
}
