﻿namespace Repository.Entity
{
    public sealed class EnterprisePriceGroups_DefaultFilterValueEntity : BaseEntity
    {
        public long IdEnterprisePriceGroups_DefaultFilterValue { get; set; }
        public long IdEnterprisePriceGroups_DefaultFilter { get; set; }
        public EnterprisePriceGroups_DefaultFilterEntity? EnterprisePriceGroups_DefaultFilter { get; set; }
        public long? IdParent { get; set; }
        public EnterprisePriceGroups_DefaultFilterValueEntity? Parent { get; set; }
        public string? Value { get; set; }
        public string? Description { get; set; }
        public bool IsDeleted { get; set; }
    }
}
