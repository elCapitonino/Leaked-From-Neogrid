﻿namespace DI.Repository.Interfaces
{
    public interface IEntity
    {
        Guid Id { get; }
    }
}
