﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Services.SearchAPI.SearchAPIService;

namespace Services.SearchAPI.Models
{
    public class SearchAPIRequest
    {
        [JsonProperty("id_company")]
        public long CompanyId { get; set; }

        [JsonProperty("products")]
        public List<Products> Products { get; set; }

        [JsonProperty("language")]
        public string Language { get; set; }

        [JsonProperty("relative_threshold")]
        public decimal? RelativeThreshold { get; set; }

        [JsonProperty("fuzzy_threshold")]
        public decimal? FuzzyThreshold { get; set; }

        [JsonProperty("restrictive_fuzzy_threshold")]
        public decimal? RestrictiveFuzzyThreshold { get; set; }

        [JsonProperty("use_top_word")]
        public bool? UseTopWord { get; set; }

        [JsonProperty("use_cosine")]
        public bool? UseCosine { get; set; }

        [JsonProperty("vectorizer_mode")]
        public string VectorizerMode { get; set; }

        [JsonProperty("start_date")]
        [JsonConverter(typeof(CustomDateFormatConverter), "yyyy-MM-dd")]
        public DateTime StartDate { get; set; }

        [JsonProperty("end_date")]
        [JsonConverter(typeof(CustomDateFormatConverter), "yyyy-MM-dd")]
        public DateTime EndDate { get; set; }

        [JsonProperty("id_crawlers")]
        public IEnumerable<int> CrawlersIds { get; set; }
        [JsonProperty("task_ids")]
        public IEnumerable<Guid> TaskIds { get; set; }

        public SearchAPIRequest Clone()
        {
            return new SearchAPIRequest
            {
                CompanyId = this.CompanyId,
                Products = this.Products?.Select(p => p.Clone()).ToList(),
                Language = this.Language,
                RelativeThreshold = this.RelativeThreshold,
                FuzzyThreshold = this.FuzzyThreshold,
                RestrictiveFuzzyThreshold = this.RestrictiveFuzzyThreshold,
                UseTopWord = this.UseTopWord,
                UseCosine = this.UseCosine,
                VectorizerMode = this.VectorizerMode,
                StartDate = this.StartDate,
                EndDate = this.EndDate,
                CrawlersIds = this.CrawlersIds?.ToList(),
                TaskIds = this.TaskIds?.ToList()
            };
        }
    }

    public class Products
    {
        [JsonProperty("tags")]
        public IEnumerable<Tags> Tags { get; set; }

        [JsonProperty("id_monitoring_item")]
        public long MonitoringItemId { get; set; }

        [JsonProperty("required_words")]
        public List<string> RequiredWords { get; set; }

        [JsonProperty("restricted_words")]
        public IEnumerable<string> RestrictedWords { get; set; }

        public Products Clone()
        {
            return new Products
            {
                Tags = this.Tags?.Select(t => t.Clone()).ToList(),
                MonitoringItemId = this.MonitoringItemId,
                RequiredWords = this.RequiredWords?.ToList(),
                RestrictedWords = this.RestrictedWords?.ToList()
            };
        }
    }

    public class Tags
    {
        [JsonProperty("description")]
        public string Description { get; set; }

        public Tags Clone()
        {
            return new Tags
            {
                Description = this.Description
            };
        }
    }
}
