﻿using System.Security.Claims;

namespace PredifyClientAPI.Models
{
    public interface ICurrentUser
    {
        string AccessToken { get; }
        bool IsAuthenticated { get; }
        string? Name { get; }
        Guid UserId { get; }
        ClaimsIdentity? Identity { get; }

    }
}
