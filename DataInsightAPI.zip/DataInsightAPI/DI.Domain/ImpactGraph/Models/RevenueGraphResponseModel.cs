﻿namespace DI.Domain.ImpactGraph.Models
{
    public class RevenueGraphResponseModel
    {
        public RevenueGraphResponseModel()
        {
            Categories = [];
            PreviousRevenue = new GraphDataModel();
            ProjectedRevenue = new GraphDataModel();
            RealizedRevenue = new GraphDataModel();
            Royalties = new GraphDataModel();
            Goal = new GraphDataModel();
        }

        public List<GraphCategoryModel> Categories { get; set; }
        public GraphDataModel PreviousRevenue { get; set; }
        public GraphDataModel ProjectedRevenue { get; set; }
        public GraphDataModel RealizedRevenue { get; set; }
        public GraphDataModel Royalties { get; set; }
        public GraphDataModel Goal { get; set; }
    }
}
