﻿using DI.Domain.Models.ImpactReport;
using DI.Domain.Services.Interfaces.Reports;
using DI.Domain.Utils;
using DI.Domain.ValueObjects;
using DI.Repository.Entities;
using DI.Repository.Enum;
using DI.Repository.Interfaces;
using DocumentFormat.OpenXml.Spreadsheet;
using Microsoft.Extensions.Configuration;
using System.Collections.Concurrent;
using System.Xml.Schema;

namespace DI.Domain.Services.Reports
{
    public class GetImpactReportDataService : IGetImpactReportDataService
    {
        private static readonly string[] TitlesSubHeaderDemanda = ["SUBCATEGORIAS", "DEMANDA PRÉ IA", "DEMANDA PROJETADA", "DEMANDA POS IA", "DIFERENÇA ANTES VS DEPOIS", "VARIAÇÃO"];
        private static readonly string[] TitlesSubHeaderReceita = ["SUBCATEGORIAS", "RECEITA PRÉ IA", "RECEITA PROJETADA", "RECEITA POS IA", "DIFERENÇA ANTES VS DEPOIS", "VARIAÇÃO"];
        private static readonly string[] TitlesSubHeaderLucroBruto = ["SUBCATEGORIAS", "LUCRO BRUTO PRÉ IA", "LUCRO BRUTO PROJETADA", "LUCRO BRUTO POS IA", "DIFERENÇA ANTES VS DEPOIS", "VARIAÇÃO"];
        private static readonly string[] TitlesSubHeaderMargemBruta = ["SUBCATEGORIAS", "MARGEM PRÉ IA", "MARGEM PROJETADA", "MARGEM POS IA", "DIFERENÇA ANTES VS DEPOIS", "VARIAÇÃO"];
        private static readonly string[] TitlesSubHeaderRoyalty = ["SUBCATEGORIAS", "VARIAÇÃO DE RECEITA ANTES E DEPOIS", "ROYALTY ADICIONAL"];

        private const string DefaultNumberFormat = "#,##0.00";
        private const string CurrencyNumberFormat = "R$ #,##0.00";
        private const string PercentageNumberFormat = "#,##0.00%";

        private readonly IUnitOfWork _uow;

        public GetImpactReportDataService(IUnitOfWork uow)
        {
            _uow = uow;
        }

        /// <summary>
        /// Método para obter os dados do relatório de impacto excel
        /// </summary>
        /// <param name="model">Dados da requisição</param>
        /// <param name="cancellationToken">Token de cancelamento da requisição</param>
        /// <returns>Dados do relatório de impacto para serem usados no relatório em excel</returns>
        public async Task<ValueObjects.ImpactReport> GenerateImpactReportData(ImpactConsolidatedRequestModel model, CancellationToken cancellationToken, string userId)
        {
            var result = new ValueObjects.ImpactReport();

            result.ImagePath = System.IO.Path.Combine(AppContext.BaseDirectory, "Assets", "img", "predify.png");

            var listImpactReportData = new List<ImpactReportWorksheet>();

            foreach (var infoGroup in model.PriceGroups.OrderBy(x => x.Month))
            {
                var impactReportData = await GetDataConsolidated(new YearMonth(infoGroup.Year, infoGroup.Month), model.Affiliates, model.CompanyId, infoGroup.PriceGroupIds, userId, cancellationToken);

                listImpactReportData.AddRange(impactReportData);
            }

            result.ImpactPreDataConsolidateds = listImpactReportData;

            return result;
        }

        public decimal GetAddicionalRoyalty(YearMonth yearMonth, long companyId, EGranularityType eGranularityType)
        {
            var sumRoyalties = _uow.MonthlySaleHistoryDataRepository
                .GetAll(companyId, yearMonth.AddMonths(-1).Value, yearMonth.Value, EGranularityType.ImpactConsolidateReport)
                .GroupBy(x => x.YearMonth).ToDictionary(x => x.Key, x => x.Sum(y => y.RoyaltyReal));

            var additionalRoyalty = 0m;

            if (sumRoyalties.TryGetValue(yearMonth.Value, out var sumRoyaltiesActualMonth) 
                && sumRoyalties.TryGetValue(yearMonth.AddMonths(-1).Value, out var sumRoyaltiesLastMonth))
                additionalRoyalty = sumRoyaltiesActualMonth - sumRoyaltiesLastMonth;

            return additionalRoyalty;
        }

        public async Task<IEnumerable<ImpactReportWorksheet>> GetDataConsolidated(YearMonth yearMonth, List<Affiliates> majorGranularityList, long companyId, IEnumerable<long> priceGroupIds, string userId, CancellationToken cancellationToken)
        {
            var userRole = _uow.GrupoRecursosRepository.GetHierarchyUserById(companyId, userId);

            var result = new List<ImpactReportWorksheet>();

            var configuration = _uow.ImpactReportConfigurationRepository.GetByCompanyId(companyId);

            var dataTypesToGenarateReports = GetMonthlyImpactDataTypesToGenerateReports(userRole, configuration);

            foreach (var dataTypesToGenarateReport in dataTypesToGenarateReports)
                result.Add(await GetDataConsolidated(yearMonth, majorGranularityList, companyId, priceGroupIds, userRole, dataTypesToGenarateReport, configuration, cancellationToken));

            return result;
        }

        private List<MonthlyImpactDataType> GetMonthlyImpactDataTypesToGenerateReports(string? userRole, ImpactReportConfigurationEntity? configuration)
        {
            var reportDataTypes = string.Equals(userRole, "Gerente", StringComparison.InvariantCultureIgnoreCase)
                ? new List<MonthlyImpactDataType>() { MonthlyImpactDataType.Geral }
                : new List<MonthlyImpactDataType>();

            reportDataTypes.AddRange([MonthlyImpactDataType.Normal,
                                      MonthlyImpactDataType.Priced,
                                      MonthlyImpactDataType.Approved,
                MonthlyImpactDataType.Adopted]);

            if (configuration.IncludeConsolidateReportFromLastYear)
                reportDataTypes.AddRange([MonthlyImpactDataType.AllLastYear,
                                          MonthlyImpactDataType.AdoptedLastYear]);

            return reportDataTypes;
        }

        public async Task<ImpactReportWorksheet> GetDataConsolidated(YearMonth yearMonth, List<Affiliates> majorGranularityList, long companyId, IEnumerable<long> priceGroupIds, string userRole, MonthlyImpactDataType dataType, ImpactReportConfigurationEntity? configuration, CancellationToken cancellationToken)
        {
            ImpactReportWorksheet response = new();

            IEnumerable<MonthlyImpactDataEntity> monthlyImpactDataTask = null;
            IEnumerable<EnterprisePriceGroupEntity> enterpriseGroupIdsTask = null;

            if (dataType == MonthlyImpactDataType.Geral)
            {
                monthlyImpactDataTask = await _uow.MonthlyImpactDataRepository.GetAll(companyId, yearMonth.Value, MonthlyImpactDataType.Normal, cancellationToken);
                enterpriseGroupIdsTask = await _uow.EnterprisePriceGroupRepository.GetByYearMonth(yearMonth.GetDateTime());
            }
            else
            {
                monthlyImpactDataTask = await _uow.MonthlyImpactDataRepository.GetAll(companyId, yearMonth.Value, dataType, cancellationToken);
                enterpriseGroupIdsTask = await _uow.EnterprisePriceGroupRepository.GetAllById(priceGroupIds);
            }

            var monthlyImpactDataDictionary = monthlyImpactDataTask.ToDictionary(x => x.ProductId, x => x);

            var listProductIds = new List<string>(monthlyImpactDataDictionary.Keys);

            var listImpactPreDataConsolidated = FillListImpactPreDataConsolidated(listProductIds, monthlyImpactDataDictionary);

            IEnumerable<ImpactPreDataConsolidatedData> datas;

            if (majorGranularityList != null && majorGranularityList.Count > 0 && dataType != MonthlyImpactDataType.Geral)
            {
                var majorGranularityValuesHashSet = majorGranularityList.Select(a => a.Value).ToHashSet();
                var containsMajorGranularity = monthlyImpactDataDictionary.Where(x => majorGranularityValuesHashSet.Contains(x.Value.MajorGranularity));

                response.TotalSkus = await _uow.MonthlySaleHistoryDataRepository
                    .GetCountSkus(companyId, EGranularityType.Projection, majorGranularityValuesHashSet, cancellationToken);

                response.TotalSkusPrecification = containsMajorGranularity.Sum(x => x.Value.PricingCount);
                response.ApprovedSkus = containsMajorGranularity.Sum(x => x.Value.AdoptionCount + x.Value.NotAdoptionCount);
                response.AdoptedSkus = containsMajorGranularity.Sum(x => x.Value.AdoptionCount);
                datas = listImpactPreDataConsolidated.Where(x => majorGranularityValuesHashSet.Contains(x.Affiliate));
            }
            else
            {
                response.TotalSkus = await _uow.MonthlySaleHistoryDataRepository
                .GetCountSkus(companyId, EGranularityType.Projection, cancellationToken);

                response.TotalSkusPrecification = monthlyImpactDataDictionary.Sum(x => x.Value.PricingCount);
                response.ApprovedSkus = monthlyImpactDataDictionary.Sum(x => x.Value.AdoptionCount + x.Value.NotAdoptionCount);
                response.AdoptedSkus = monthlyImpactDataDictionary.Sum(x => x.Value.AdoptionCount);
                datas = listImpactPreDataConsolidated;
            }

            if (response.ApprovedSkus != 0 && response.TotalSkusPrecification != 0)
                response.PercentageApprovedSkus = response.ApprovedSkus / response.TotalSkusPrecification;

            if (response.AdoptedSkus != 0 && response.TotalSkusPrecification != 0)
                response.PercentageAdoptedSkus = response.AdoptedSkus / response.TotalSkusPrecification;

            string monthName = yearMonth.Month.GetMonthName();
            var groupNames = enterpriseGroupIdsTask.Select(x => x.Name);

            response.GroupsCount = groupNames.Count();

            response.WorkSheetName = GetWorkSheetName(dataType, monthName);

            response.GroupName = string.Join(", ", groupNames);

            response.PeriodConsidered = $"{yearMonth.Month}/{yearMonth.Year}";

            IEnumerable<string> affiliates = null;

            if (dataType == MonthlyImpactDataType.Geral)
                affiliates = datas.Select(x => x.Affiliate).Distinct();
            else
                affiliates = majorGranularityList?.Select(x => x.Description ?? x.Value) ?? Enumerable.Empty<string>();

            response.AffiliatesCount = affiliates.Count();
            response.MajorGranularity = string.Join(", ", affiliates);

            var tables = new List<ImpactReportTable>() {
                    GenerateRevenueDataTable(datas),
                    GenerateDemandDataTable(datas),
                    GenerateProfitDataTable(datas),
                    GenerateMarginDataTable(datas)};

            bool excludeRoyalty = string.Equals(userRole, "Consultor", StringComparison.OrdinalIgnoreCase);

            if (configuration.ConsolidateReportRoyalty && !excludeRoyalty)
            {
                tables.Add(GenerateRoyaltyDataTable(datas, majorGranularityList, yearMonth, configuration, companyId));
            }

            response.Tables = tables;

            return response;
        }

        private IEnumerable<ImpactPreDataConsolidatedData> FillListImpactPreDataConsolidated(List<string> listProductIds, Dictionary<string, MonthlyImpactDataEntity> monthlyImpactDataDictionary )
        {
            ConcurrentBag<ImpactPreDataConsolidatedData> listImpactPreDataConsolidated = [];

            Parallel.ForEach(listProductIds.Distinct(), (productId) =>
            {
                monthlyImpactDataDictionary.TryGetValue(productId, out var monthImpactData);

                ImpactPreDataConsolidatedData impactPreDataConsolidatedData = new()
                {
                    Affiliate = monthImpactData?.MajorGranularity ?? string.Empty,
                    Value = productId,

                    RevenueBefore = monthImpactData?.PriorRevenue ?? 0,
                    RevenueProjection = monthImpactData?.ProjectionRevenue ?? 0,
                    RevenueAfter = monthImpactData?.RealRevenue ?? 0,

                    DemandBefore = monthImpactData?.PriorDemand ?? 0,
                    DemandProjection = monthImpactData?.ProjectionDemand ?? 0,
                    DemandAfter = monthImpactData?.RealDemand ?? 0,

                    MarginBefore = 0,
                    MarginProjection = 0,
                    MarginAfter = 0,

                    ProfitBefore = monthImpactData?.PriorProfit ?? 0,
                    ProfitProjection = monthImpactData?.ProjectionProfit ?? 0,
                    ProfitAfter = monthImpactData?.RealProfit ?? 0,

                    PriorRoyalty = monthImpactData?.PriorRoyalty ?? 0,
                    RealRoyalty = monthImpactData?.RealRoyalty ?? 0
                };

                if (impactPreDataConsolidatedData.ProfitBefore != 0 && impactPreDataConsolidatedData.RevenueBefore != 0)
                    impactPreDataConsolidatedData.MarginBefore = impactPreDataConsolidatedData.ProfitBefore / impactPreDataConsolidatedData.RevenueBefore;

                if (impactPreDataConsolidatedData.ProfitProjection != 0 && impactPreDataConsolidatedData.RevenueProjection != 0)
                    impactPreDataConsolidatedData.MarginProjection = impactPreDataConsolidatedData.ProfitProjection / impactPreDataConsolidatedData.RevenueProjection;

                if (impactPreDataConsolidatedData.ProfitAfter != 0 && impactPreDataConsolidatedData.RevenueAfter != 0)
                    impactPreDataConsolidatedData.MarginAfter = impactPreDataConsolidatedData.ProfitAfter / impactPreDataConsolidatedData.RevenueAfter;

                listImpactPreDataConsolidated.Add(impactPreDataConsolidatedData);
            });

            return listImpactPreDataConsolidated;
        }

        public string GetWorkSheetName(MonthlyImpactDataType dataType, string monthName) => dataType switch
        {
            MonthlyImpactDataType.Geral => $"Impacto Geral {monthName}",
            MonthlyImpactDataType.Adopted => $"Impacto Adotados {monthName}",
            MonthlyImpactDataType.Approved => $"Impacto Aprovados {monthName}",
            MonthlyImpactDataType.Priced => $"Impacto Precificados {monthName}",
            MonthlyImpactDataType.AllLastYear => $"{monthName} Ano Passado",
            MonthlyImpactDataType.AdoptedLastYear => $"Adotados {monthName} Ano Passado",
            _ => $"Impacto {monthName}"
        };

        public ImpactReportTable GenerateRevenueDataTable(IEnumerable<ImpactPreDataConsolidatedData> impactPreDataConsolidateds)
        {
            var groupsDatas = impactPreDataConsolidateds.GroupBy(x => x.Value.Split('|').LastOrDefault()).ToArray();

            var lines = new List<ImpactReportTableLine>();

            foreach (var data in groupsDatas)
            {
                if (string.IsNullOrWhiteSpace(data.Key))
                    continue;

                var item = new ImpactReportTableLine()
                {
                    Value = data.Key,
                    BeforeIA = data.Sum(x => x.RevenueBefore),
                    Projection = data.Sum(x => x.RevenueProjection),
                    AfterIA = data.Sum(x => x.RevenueAfter),
                    Variation = 0,
                    Type = EConditionGenerateDataTableType.Revenue,
                };

                item.DifferentPredifyXCompany = item.AfterIA - item.BeforeIA;

                if (item.BeforeIA != 0 && item.AfterIA != 0)
                    item.Variation = (item.AfterIA / item.BeforeIA) - 1;

                lines.Add(item);
            }

            var lineTotal = new ImpactReportTableLine()
            {
                Value = "Total",
                BeforeIA = lines.Sum(x => x.BeforeIA),
                Projection = lines.Sum(x => x.Projection),
                AfterIA = lines.Sum(x => x.AfterIA),
            };

            lineTotal.DifferentPredifyXCompany = lineTotal.AfterIA - lineTotal.BeforeIA;

            lineTotal.Variation = lineTotal.BeforeIA != 0 && lineTotal.AfterIA != 0
                ? (lineTotal.AfterIA / lineTotal.BeforeIA) - 1
                : 0;

            lines.Add(lineTotal);

            var numberFormats = new string[]
            {
                DefaultNumberFormat,
                DefaultNumberFormat,
                DefaultNumberFormat,
                DefaultNumberFormat,
                PercentageNumberFormat
            };

            return new ImpactReportTable()
            {
                Header = "RECEITA",
                Lines = lines,
                SubHeaders = TitlesSubHeaderReceita,
                NumberValueFormats = numberFormats
            };
        }

        /// <summary>
        /// Gera os dados do relatório de Demanda
        /// </summary>
        /// <param name="impactPreDataConsolidateds">Dados para geração do relatório</param>
        /// <returns>Dados do relatório</returns>
        public static ImpactReportTable GenerateDemandDataTable(IEnumerable<ImpactPreDataConsolidatedData> impactPreDataConsolidateds)
        {
            var groupsDatas = impactPreDataConsolidateds.GroupBy(x => x.Value.Split('|').LastOrDefault()).ToArray();

            var lines = new List<ImpactReportTableLine>();

            foreach (var data in groupsDatas)
            {
                if (string.IsNullOrWhiteSpace(data.Key))
                    continue;

                var item = new ImpactReportTableLine()
                {
                    Value = data.Key,
                    BeforeIA = data.Sum(x => x.DemandBefore),
                    Projection = data.Sum(x => x.DemandProjection),
                    AfterIA = data.Sum(x => x.DemandAfter),
                    Variation = 0,
                    Type = EConditionGenerateDataTableType.Demand
                };

                item.DifferentPredifyXCompany = item.AfterIA - item.BeforeIA;

                if (item.BeforeIA != 0 && item.AfterIA != 0)
                    item.Variation = (item.AfterIA / item.BeforeIA) - 1;

                lines.Add(item);
            }

            var lineTotal = new ImpactReportTableLine()
            {
                Value = "Total",
                BeforeIA = lines.Sum(x => x.BeforeIA),
                Projection = lines.Sum(x => x.Projection),
                AfterIA = lines.Sum(x => x.AfterIA),
                DifferentPredifyXCompany = lines.Sum(x => x.DifferentPredifyXCompany),
            };

            lineTotal.Variation = lineTotal.BeforeIA != 0 && lineTotal.AfterIA != 0
                ? (lineTotal.AfterIA / lineTotal.BeforeIA) - 1
                : 0;

            lines.Add(lineTotal);

            var numberFormats = new string[]
            {
                DefaultNumberFormat,
                DefaultNumberFormat,
                DefaultNumberFormat,
                DefaultNumberFormat,
                PercentageNumberFormat
            };

            return new ImpactReportTable()
            {
                Header = "DEMANDA",
                Lines = lines,
                SubHeaders = TitlesSubHeaderDemanda,
                NumberValueFormats = numberFormats
            };
        }

        /// <summary>
        /// Gera os dados do relatório de Lucro Bruto
        /// </summary>
        /// <param name="impactPreDataConsolidateds">Dados para geração do relatório</param>
        /// <returns>Dados do relatório</returns>
        public ImpactReportTable GenerateProfitDataTable(IEnumerable<ImpactPreDataConsolidatedData> impactPreDataConsolidateds)
        {
            var groupsDatas = impactPreDataConsolidateds.GroupBy(x => x.Value.Split('|').LastOrDefault()).ToArray();

            var lines = new List<ImpactReportTableLine>();

            foreach (var data in groupsDatas)
            {
                if (string.IsNullOrWhiteSpace(data.Key))
                    continue;

                var item = new ImpactReportTableLine()
                {
                    Value = data.Key,
                    BeforeIA = data.Sum(x => x.ProfitBefore),
                    Projection = data.Sum(x => x.ProfitProjection),
                    AfterIA = data.Sum(x => x.ProfitAfter),
                    Variation = 0,
                    Type = EConditionGenerateDataTableType.Profit
                };

                item.DifferentPredifyXCompany = item.AfterIA - item.BeforeIA;

                if (item.BeforeIA != 0 && item.AfterIA != 0)
                    item.Variation = (item.AfterIA / item.BeforeIA) - 1;

                lines.Add(item);
            }

            var lineTotal = new ImpactReportTableLine()
            {
                Value = "Total",
                BeforeIA = lines.Sum(x => x.BeforeIA),
                Projection = lines.Sum(x => x.Projection),
                AfterIA = lines.Sum(x => x.AfterIA),
                DifferentPredifyXCompany = lines.Sum(x => x.DifferentPredifyXCompany),
            };

            lineTotal.Variation = lineTotal.BeforeIA != 0 && lineTotal.AfterIA != 0
                ? (lineTotal.AfterIA / lineTotal.BeforeIA) - 1
                : 0;

            lines.Add(lineTotal);

            var numberFormats = new string[]
            {
                CurrencyNumberFormat,
                CurrencyNumberFormat,
                CurrencyNumberFormat,
                CurrencyNumberFormat,
                PercentageNumberFormat
            };

            return new ImpactReportTable()
            {
                Header = "LUCRO BRUTO",
                Lines = lines,
                SubHeaders = TitlesSubHeaderLucroBruto,
                NumberValueFormats = numberFormats,
            };
        }

        /// <summary>
        /// Gera os dados do relatório de Margem
        /// </summary>
        /// <param name="impactPreDataConsolidateds">Dados para geração do relatório</param>
        /// <returns>Dados do relatório</returns>
        public static ImpactReportTable GenerateMarginDataTable(IEnumerable<ImpactPreDataConsolidatedData> impactPreDataConsolidateds)
        {
            var groupsDatas = impactPreDataConsolidateds.GroupBy(x => x.Value.Split('|').LastOrDefault()).ToArray();

            var lines = new List<ImpactReportTableLine>();

            foreach (var data in groupsDatas)
            {
                if (string.IsNullOrWhiteSpace(data.Key))
                    continue;

                var profitBefore = data.Sum(x => x.ProfitBefore);
                var revenueAfter = data.Sum(x => x.RevenueAfter);
                var profitProjection = data.Sum(x => x.ProfitProjection);
                var revenueProjection = data.Sum(x => x.RevenueProjection);
                var profitAfter = data.Sum(x => x.ProfitAfter);
                var revenueBefore = data.Sum(x => x.RevenueBefore);

                var beforeIA = profitBefore != 0 && revenueBefore != 0 ? profitBefore / revenueBefore : 0;
                var projection = profitProjection != 0 && revenueProjection != 0 ? profitProjection / revenueProjection : 0;
                var afterIA = profitAfter != 0 && revenueAfter != 0 ? profitAfter / revenueAfter : 0;

                var item = new ImpactReportTableLine()
                {
                    Value = data.Key,
                    BeforeIA = beforeIA,
                    Projection = projection,
                    AfterIA = afterIA,
                    Variation = 0,
                    Type = EConditionGenerateDataTableType.Margin
                };

                item.DifferentPredifyXCompany = item.AfterIA - item.BeforeIA;
                item.Variation = item.AfterIA - item.BeforeIA;

                lines.Add(item);
            }

            decimal sumRevenueBefore = impactPreDataConsolidateds.Sum(x => x.RevenueBefore);
            decimal sumRevenueProjection = impactPreDataConsolidateds.Sum(x => x.RevenueProjection);
            decimal sumRevenueAfter = impactPreDataConsolidateds.Sum(x => x.RevenueAfter);

            var lineTotal = new ImpactReportTableLine()
            {
                Value = "Total",
                BeforeIA = sumRevenueBefore == 0 ? 0 : impactPreDataConsolidateds.Sum(x => x.ProfitBefore) / sumRevenueBefore,
                Projection = sumRevenueProjection == 0 ? 0 : impactPreDataConsolidateds.Sum(x => x.ProfitProjection) / sumRevenueProjection,
                AfterIA = sumRevenueAfter == 0 ? 0 : impactPreDataConsolidateds.Sum(x => x.ProfitAfter) / sumRevenueAfter,
            };

            lineTotal.DifferentPredifyXCompany = lineTotal.AfterIA - lineTotal.BeforeIA;
            lineTotal.Variation = lineTotal.AfterIA - lineTotal.BeforeIA;

            lines.Add(lineTotal);

            var numberFormats = new string[]
            {
                PercentageNumberFormat,
                PercentageNumberFormat,
                PercentageNumberFormat,
                PercentageNumberFormat,
                PercentageNumberFormat
            };

            return new ImpactReportTable()
            {
                Header = "MARGEM BRUTA",
                Lines = lines,
                SubHeaders = TitlesSubHeaderMargemBruta,
                NumberValueFormats = numberFormats
            };
        }


        /// <summary>
        /// Método para gerar a tabela Royalty utilizada apenas para a empresa 3026
        /// </summary>
        /// <param name="impactPreDataConsolidateds">Dados para geração da tabela</param>
        /// <param name="cmopanyId">Id da compania. Padrão 3026, única empresa que o utiliza atualmente</param>
        /// <returns></returns>
        public ImpactReportTable GenerateRoyaltyDataTable(IEnumerable<ImpactPreDataConsolidatedData> impactPreDataConsolidateds, IEnumerable<Affiliates> majorGranularityList, YearMonth yearMonth, ImpactReportConfigurationEntity impactReportConfiguration, long companyId)
        {
            var groupsDatas = impactPreDataConsolidateds.GroupBy(x => x.Value.Split('|').LastOrDefault()).ToArray();


            var additionalRoyalty = impactPreDataConsolidateds.Sum(x => x.RealRoyalty) - impactPreDataConsolidateds.Sum(x => x.PriorRoyalty);

            var majorGranularityCount = majorGranularityList.Count();

            var goal = (impactReportConfiguration.Goal * (majorGranularityCount != 0 ? majorGranularityCount : 1)) + additionalRoyalty;

            var lines = new List<ImpactReportTableLine>();

            foreach (var data in groupsDatas)
            {
                if (string.IsNullOrWhiteSpace(data.Key))
                    continue;

                var item = new ImpactReportTableLine()
                {
                    Value = data.Key,
                    BeforeIA = data.Sum(x => x.RevenueAfter) - data.Sum(x => x.RevenueBefore),
                    Type = EConditionGenerateDataTableType.Royalty
                };

                item.Projection = data.Sum(x => x.RealRoyalty) - data.Sum(x => x.PriorRoyalty);

                lines.Add(item);
            }

            var lineTotal = new ImpactReportTableLine()
            {
                Value = "Total",
                BeforeIA = lines.Sum(x => x.BeforeIA),
                Projection = lines.Sum(x => x.Projection),
                AfterIA = goal,
                DifferentPredifyXCompany = 0
            };

            if (lineTotal.Projection != 0)
                lineTotal.DifferentPredifyXCompany = lineTotal.Projection != 0 && lineTotal.AfterIA != 0
                    ? lineTotal.Projection / lineTotal.AfterIA
                    : 0;

            lines.Add(lineTotal);

            var numberFormats = new string[]
            {
                CurrencyNumberFormat,
                CurrencyNumberFormat,
                CurrencyNumberFormat,
                PercentageNumberFormat
            };

            return new ImpactReportTable()
            {
                Header = "ROYALTY",
                Lines = lines,
                SubHeaders = TitlesSubHeaderRoyalty,
                NumberValueFormats = numberFormats,
                Type = EConditionGenerateDataTableType.Royalty
            };
        }
    }
}
