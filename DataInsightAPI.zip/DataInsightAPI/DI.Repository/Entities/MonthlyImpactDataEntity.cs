﻿using DI.Repository.Enum;

namespace DI.Repository.Entities
{
    public class MonthlyImpactDataEntity : BaseEntity
    {
        public long CompanyId { get; set; }
        public string ProductId { get; set; }
        public int YearMonth { get; set; }

        public int AdoptionCount { get; set; }
        public int NotAdoptionCount { get; set; }
        public int PricingCount { get; set; }

        public decimal PriorDemand { get; set; }
        public decimal ProjectionDemand { get; set; }
        public decimal RealDemand { get; set; }

        public decimal PriorCost { get; set; }
        public decimal ProjectionCost { get; set; }
        public decimal RealCost { get; set; }

        public decimal PriorRevenue { get; set; }
        public decimal ProjectionRevenue { get; set; }
        public decimal RealRevenue { get; set; }

        public decimal PriorProfit { get; set; }
        public decimal ProjectionProfit { get; set; }
        public decimal RealProfit { get; set; }

        public decimal PriorRoyalty { get; set; }
        public decimal ProjectionRoyalty { get; set; }
        public decimal RealRoyalty { get; set; }

        public string ConsolidadeGroupBy { get; set; }
        public string MajorGranularity { get; set; }

        public MonthlyImpactDataType DataType { get; set; }
    }
}
