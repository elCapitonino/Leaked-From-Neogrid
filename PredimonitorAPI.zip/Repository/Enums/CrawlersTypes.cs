﻿namespace Repository.Enums
{
    public enum CrawlersTypes
    {
        Search = 1,
        Paginate = 2,
        Driver = 3,
    }
}
