﻿using MongoDB.Bson.Serialization.Attributes;

namespace Repository.Entity.Abv
{
    public class CategoryEntity
    {
        [BsonElement("SEQCATEGORIA")]
        public long? SeqCategoria { get; set; }

        [BsonElement("SEQCATEGORIA_PAI")]
        public long? SeqCategoriaPai { get; set; }

        [BsonElement("CATEGORIA")]
        public string? Categoria { get; set; }
    }

}
