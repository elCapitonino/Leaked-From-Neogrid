﻿using DI.Service.PredifyAPI.Access;
using DI.Service.PredifyAPI.Empresa;
using DI.Service.PredifyAPI.Models;
using Microsoft.Extensions.Options;

namespace DI.Service.PredifyAPI
{
    public class PredifyAPISystemManager
    {

        public PredifyAPISystemManager(HttpClient client, IOptions<PredifyAPIOptions> options)
        {
            EmpresaService = new EmpresaService(client);
            AccessService = new AccessService(client);
        }

        public IEmpresaService EmpresaService { get; }
        public IAccessService AccessService { get; }
    }
}
