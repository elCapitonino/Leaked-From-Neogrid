﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using Repository.Attributes;
using Repository.DbContexts;
using Repository.Entity;
using MongoDB.EntityFrameworkCore.Extensions;

namespace Repository.TypeConfiguration
{
    [DbContextTypeConfiguration(typeof(NeogridDbContext))]
    public class IndiretaTypeConfiguration : TypeConfigurationBase<IndiretaEntity>, IEntityTypeConfiguration<IndiretaEntity>
    {
        public override void Configure(EntityTypeBuilder<IndiretaEntity> builder)
        {
            builder.ToTable("indireta").ToCollection("indireta");
        }
    }

}
