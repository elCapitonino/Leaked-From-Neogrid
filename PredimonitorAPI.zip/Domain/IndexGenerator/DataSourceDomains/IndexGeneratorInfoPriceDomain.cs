﻿using AutoMapper;
using Domain.IndexGenerator.DataSourceDomains.Interfaces;
using Domain.IndexGenerator.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using MongoDB.Driver;
using Repository.Entity;
using Repository.UnitOfWork;
using System.Diagnostics;
using Microsoft.Extensions.Caching.Memory;
using Domain.Status;
using Repository.Enums;
using MongoDB.Bson;

namespace Domain.IndexGenerator.DataSourceDomains
{
    public class IndexGeneratorInfoPriceDomain : IndexGeneratorBase, IIndexGeneratorInfoPriceDomain
    {
        private readonly ILogger<IndexGeneratorInfoPriceDomain> _logger;
        private readonly IUnitOfWork _uow;
        private readonly IMapper _mapper;
        private readonly IStatusDomain _statusDomain;

        public IndexGeneratorInfoPriceDomain(ILogger<IndexGeneratorInfoPriceDomain> logger, IUnitOfWork uow, IMapper mapper, IStatusDomain statusDomain)
            : base(statusDomain)
        {
            _logger = logger;
            _uow = uow;
            _mapper = mapper;
            _statusDomain = statusDomain;
        }

        public async Task GenerateIndexSaoJoaoAsync(long companyId, int crawlerId, IEnumerable<MonitoringItemTags> monitoringItems, DateTime startDate, DateTime endDate, Guid? taskId, List<long> monitoringResultIdsDelete)
        {
            try
            {
                _logger.LogInformation($"Iniciando Geração de index da InfoPrice São João");
                var total = monitoringItems.Count();
                var count = 1;
                UpdateStatus(taskId, CrawlerSourceType.InfoPriceSaoJoao, MonitoringItemResultsStatusType.Running, total, 0);
                Stopwatch totalStopwatch = new Stopwatch();
                totalStopwatch.Start();
                _logger.LogInformation("InfoPrice São João - Total de monitoring items para serem processados: {total}", total);
                List<ObjectId> listUpdateHash = new List<ObjectId>();
                EnsureAllMonitoringItemId(monitoringItems);
                foreach (var monitoringItem in monitoringItems)
                {
                    try
                    {
                        if (!monitoringItem.Eans.Any())
                            continue;

                        var products = await _uow.InfoPriceSaoJoao.GetAll()
                            .Where(x => x.DataPreco >= startDate && x.DataPreco <= endDate && monitoringItem.Eans.Contains(x.GTINFormated) && x.OrigemPreco == "Nota Fiscal")
                            .Select(x => new
                            {
                                x.Id,
                                x.GTINFormated,
                                x.Hash,
                                x.Categoria,
                                Seller = x.Loja,
                                Brand = x.Rede,
                                x.UF,
                            })
                            .ToListAsync();

                        if(!products.Any())
                        {
                            products = await _uow.InfoPriceSaoJoao.GetAll()
                            .Where(x => x.DataPreco >= startDate && x.DataPreco <= endDate && monitoringItem.Eans.Contains(x.GTINFormated))
                            .Select(x => new
                            {
                                x.Id,
                                x.GTINFormated,
                                x.Hash,
                                x.Categoria,
                                Seller = x.Loja,
                                Brand = x.Rede,
                                x.UF,
                            })
                            .ToListAsync();
                        }
                       
                        listUpdateHash.AddRange(products.Where(x => string.IsNullOrEmpty(x.Hash)).Select(x => x.Id));

                        var entities = products.GroupBy(x => $"{GetOrGenerateHash(x.Hash, $"{x.GTINFormated}|{x.Seller}")}{x.Seller}{x.UF}{x.Categoria}{x.Brand}")
                            .Select(x => x.First()).Select(x => new MonitoringItemResultsEntity()
                            {
                                Brand = x.Brand,
                                Category = x.Categoria,
                                Hash = GetOrGenerateHash(x.Hash, $"{x.GTINFormated}|{x.Seller}"),
                                CompanyId = companyId,
                                CrawlerId = crawlerId,
                                MonitoringItemId = monitoringItem.MonitoringItemId,
                                Seller = x.Seller,
                                State = x.UF,
                            });

                        _uow.MonitoringItemResults.AddRange(entities, true);
                        UpdateStatus(taskId, CrawlerSourceType.InfoPriceSaoJoao, MonitoringItemResultsStatusType.Running, total, count);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, $"Error Search Monitoring Item {monitoringItem.MonitoringItemId} InfoPrice São João");
                        UpdateStatus(taskId, CrawlerSourceType.InfoPriceSaoJoao, MonitoringItemResultsStatusType.Error, total, count);
                    }
                    count++;
                }

                if (monitoringResultIdsDelete != null && monitoringResultIdsDelete.Any())
                {
                    _uow.MonitoringItemResults.DeleteAll(monitoringResultIdsDelete);
                }

                if (listUpdateHash.Any())
                {
                    var productsToUpdate = _uow.InfoPriceSaoJoao
                              .GetAll()
                              .Where(x => listUpdateHash.Contains(x.Id))
                              .ToList();

                    foreach (var product in productsToUpdate)
                    {
                        product.Hash = CalculateSHA256($"{product.GTINFormated}|{product.Loja}");
                    }

                    _uow.InfoPriceSaoJoao.Update(productsToUpdate, true);
                }

                totalStopwatch.Stop();
                _logger.LogInformation($"Finalizado Geração de index da InfoPrice São João - {totalStopwatch.Elapsed.TotalSeconds}s");
                UpdateStatus(taskId, CrawlerSourceType.InfoPriceSaoJoao, MonitoringItemResultsStatusType.Finished, total, --count);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error {MethodName}", nameof(GenerateIndexSaoJoaoAsync));
                throw;
            }
        }
    }
}
