using Domain.Product.Models;
using Domain.ProductSeller.Models;

namespace Domain.ProductSeller;

public interface IProductSellerDomain
{
    Task<ProductSellerResponse> GetProductSellersWithPrices(FiltersRequest request);
}