﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DI.Repository.Entities
{
    public class ProductLaterPeriodEntity
    {
        [Key]
        public Guid Id { get; set; }

        [Required]
        public long CompanyId { get; set; }

        [Required]
        [MaxLength(255)]
        public string ProductId { get; set; }

        [Required]
        public long PriceGroupId { get; set; }

        public DateTime? LaterPeriod { get; set; }

        [Required]
        public DateTime ApprovedDate { get; set; }

        [Required]
        public bool Found { get; set; }

        public Guid? ReferenceId { get; set; }

        [ForeignKey("ReferenceId")]
        public virtual ProductLaterPeriodEntity Reference { get; set; }
    }
}
