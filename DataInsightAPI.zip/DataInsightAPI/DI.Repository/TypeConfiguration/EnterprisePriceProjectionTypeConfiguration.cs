﻿using DI.Repository.Attributes;
using DI.Repository.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DI.Repository.TypeConfiguration
{
    [UseSQLContext]
    public class EnterprisePriceProjectionTypeConfiguration : TypeConfigurationBase<EnterprisePriceProjectionEntity>, IEntityTypeConfiguration<EnterprisePriceProjectionEntity>
    {
        public override void Configure(EntityTypeBuilder<EnterprisePriceProjectionEntity> builder)
        {
            ConfigureTableName(builder, "Enterprise_Prices_Projection");
            builder.ToTable("Enterprise_Prices_Projection", table => table.ExcludeFromMigrations());
            builder.HasKey(x => x.EnterprisePricesProjectionId);
            builder.Ignore(x => x.Id);
            builder.Ignore(x => x.UpdatedDate);
            builder.Ignore(x => x.CreatedDate);


            builder.HasOne(x => x.Elasticity).WithMany().HasForeignKey(x => x.ElasticityId);
            builder.HasOne(x => x.PriceGroup).WithMany().HasForeignKey(x => x.EnterprisePriceGroupsId);

            builder.Property(x => x.EnterprisePricesProjectionId).HasColumnName("IdEnterprisePricesProjection");
            builder.Property(x => x.EnterprisePriceGroupsId).HasColumnName("IdEnterprisePriceGroups");
            builder.Property(x => x.ProductPredifyId).HasColumnName("IdProductPredify");
            builder.Property(x => x.EnterprisePolicyMarginPositioningId).HasColumnName("IdEnterprisePolicyMarginPositioning");
            builder.Property(x => x.PriceReplicateId).HasColumnName("IdPriceReplicate");
            builder.Property(x => x.EnterpriseActivityLevelId).HasColumnName("IdEnterpriseActivityLevel");
            builder.Property(x => x.DistributionCenterId).HasColumnName("IdDistributionCenter");
            builder.Property(x => x.ElasticityId).HasColumnName("IdElasticity");
            builder.Property(x => x.ProductMarketResultId).HasColumnName("IdProductMarketResult");
            builder.Property(x => x.SaleTaxId).HasColumnName("IdSaleTax");




        }
    }
}
