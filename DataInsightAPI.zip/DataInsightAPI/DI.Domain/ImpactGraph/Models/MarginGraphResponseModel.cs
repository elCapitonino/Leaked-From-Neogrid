﻿namespace DI.Domain.ImpactGraph.Models
{
    public class MarginGraphResponseModel
    {
        public MarginGraphResponseModel()
        {
            Categories = [];
            PreviousMargin = new GraphDataModel();
            ProjectedMargin = new GraphDataModel();
            RealizedMargin = new GraphDataModel();
            Royalties = new GraphDataModel();
            Goal = new GraphDataModel();
        }

        public List<GraphCategoryModel> Categories { get; set; }
        public GraphDataModel PreviousMargin { get; set; }
        public GraphDataModel ProjectedMargin { get; set; }
        public GraphDataModel RealizedMargin { get; set; }
        public GraphDataModel Royalties { get; set; }
        public GraphDataModel Goal { get; set; }
    }
}
