﻿using Domain.MonitoringResult;
using Domain.MonitoringResult.Models;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;

namespace PredimonitorAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DynamicFilterController : ControllerBase
    {
        private readonly ILogger<DynamicFilterController> _logger;
        private readonly IMonitoringResultDomain _domain;

        public DynamicFilterController(ILogger<DynamicFilterController> logger, IMonitoringResultDomain domain)
        {
            _logger = logger;
            _domain = domain;
        }

        [HttpPost]
        [Route("GetFilter")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(DynamicFilterResponse))]
        [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status401Unauthorized, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
        [SwaggerOperation(Summary = "Dynamically retrieves filters for the predimonitor screen", Description = "Filters the table results and returns filters based on the parameters provided in the request body")]
        public async Task<IActionResult> GetFilter(long companyId, [FromBody] DynamicFilterRequest request)
        {
            if (request == null)
            {
                _logger.LogDebug("Null request received in GetFilter.Post");
                return BadRequest("Request cannot be null.");
            }

            if (!ModelState.IsValid)
            {
                _logger.LogDebug("Invalid request received in GetFilter.Post");
                return BadRequest("Invalid request data.");
            }

            try
            {
                var response = await _domain.GetMonitoringResultFilteredData(companyId, request);

                if (response == null)
                {
                    _logger.LogDebug($"No data found for companyId: {companyId}");
                    return NotFound("No data found for the given company ID.");
                }

                return Ok(response);
            }
            catch (UnauthorizedAccessException ex)
            {
                _logger.LogError($"Unauthorized access in GetFilter: {ex}");
                return Unauthorized("Unauthorized access.");
            }
            catch (ArgumentException ex)
            {
                _logger.LogError($"Bad request in GetFilter: {ex}");
                return BadRequest("Invalid argument: " + ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error executing GetFilter: {ex}");
                return StatusCode(StatusCodes.Status500InternalServerError, "An unexpected error occurred.");
            }
        }

        [HttpPost]
        [Route("GetResult")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(SeeResultResponse))]
        [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status401Unauthorized, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
        [SwaggerOperation(Summary = "Retrieves data accordingly to filters for the predimonitor screen", Description = "Get results from database accordingly to filters for the predimonitor screen")]
        public async Task<IActionResult> GetResult([FromBody] ResultFilterRequest request)
        {
            if (request == null)
            {
                _logger.LogDebug("Null request received in GetResult.Post");
                return BadRequest("Request cannot be null.");
            }

            if (!ModelState.IsValid)
            {
                _logger.LogDebug("Invalid request received in GetResult.Post");
                return BadRequest("Invalid request data.");
            }

            try
            {
                var response = await _domain.GetMonitoringItemResult(request);

                if (response == null || !response.Any())
                {
                    _logger.LogDebug($"No data found");
                    return NoContent();
                }

                return Ok(response);
            }
            catch (UnauthorizedAccessException ex)
            {
                _logger.LogError($"Unauthorized access in GetResult: {ex}");
                return Unauthorized("Unauthorized access.");
            }
            catch (ArgumentException ex)
            {
                _logger.LogError($"Bad request in GetResult: {ex}");
                return BadRequest("Invalid argument: " + ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error executing GetResult: {ex}");
                return StatusCode(StatusCodes.Status500InternalServerError, "An unexpected error occurred.");
            }
        }

        [HttpGet]
        [Route("GenerateCache")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(bool))]
        [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status401Unauthorized, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
        public async Task<IActionResult> GenerateCache(long companyId, DateTime? startDate = null, DateTime? endDate = null, DateTime? refDate = null, int skip = 0, bool? removeOlds = null, bool? removeOutliers = null)
        {
            if (companyId == null)
            {
                _logger.LogDebug("Null companyId received in GenerateCache.Get");
                return BadRequest("Request cannot be null.");
            }

            if (!ModelState.IsValid)
            {
                _logger.LogDebug("Invalid request received in GenerateCache.Get");
                return BadRequest("Invalid request data.");
            }

            try
            {
                await _domain.GenerateProductMarketResult(companyId, startDate, endDate, refDate, skip, removeOlds, removeOutliers);

                return Ok(true);
            }
            catch (UnauthorizedAccessException ex)
            {
                _logger.LogError($"Unauthorized access in GenerateCache: {ex}");
                return Unauthorized("Unauthorized access.");
            }
            catch (ArgumentException ex)
            {
                _logger.LogError($"Bad request in GenerateCache: {ex}");
                return BadRequest("Invalid argument: " + ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error executing GenerateCache: {ex}");
                return StatusCode(StatusCodes.Status500InternalServerError, "An unexpected error occurred.");
            }
        }
    }
}

