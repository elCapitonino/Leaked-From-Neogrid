﻿using DI.Domain.ValueObjects;

namespace DI.Domain.Models.ImpactReport
{
    public class ImpactPreDataConsolidated
    {
        public decimal TotalSkus { get; set; }
        public decimal TotalSkusPrecification { get; set; }
        public decimal ApprovedSkus { get; set; }
        public decimal AdoptedSkus { get; set; }
        public decimal PercentageApprovedSkus { get; set; }
        public decimal PercentageAdoptedSkus { get; set; }
        public string? WorkSheetName { get; set; }
        public string? GroupName { get; set; }
        public string? PeriodConsidered { get; set; }
        public IEnumerable<ImpactReportTable> Tables { get; set; }
        public IEnumerable<ImpactPreDataConsolidatedData>? Datas { get; set; }
    }

    public class ImpactPreDataConsolidatedData
    {
        public string Affiliate { get; set; }
        public string Value { get; set; }
        public decimal RevenueBefore { get; set; }
        public decimal RevenueProjection { get; set; }
        public decimal RevenueAfter { get; set; }

        public decimal DemandBefore { get; set; }
        public decimal DemandProjection { get; set; }
        public decimal DemandAfter { get; set; }

        public decimal MarginBefore { get; set; }
        public decimal MarginProjection { get; set; }
        public decimal MarginAfter { get; set; }

        public decimal ProfitBefore { get; set; }
        public decimal ProfitProjection { get; set; }
        public decimal ProfitAfter { get; set; }

        public decimal PriorRoyalty { get; set; }
        public decimal RealRoyalty { get; set; }
    }
}
