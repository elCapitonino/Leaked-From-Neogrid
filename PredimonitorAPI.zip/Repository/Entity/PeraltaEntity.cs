﻿using MongoDB.Bson.Serialization.Attributes;

namespace Repository.Entity
{
    public class PeraltaEntity : BaseMongoEntity
    {
        [BsonElement("WEEK_ID")]
        public int? WeekId { get; set; }

        [BsonElement("STORE_ID")]
        public int? StoreId { get; set; }

        [BsonElement("STORE")]
        public string? StoreName { get; set; }

        [BsonElement("STORE_ADDRESS")]
        public string? StoreAddress { get; set; }

        [BsonElement("STATE")]
        public string? State { get; set; }

        [BsonElement("RETAILER")]
        public string? Retailer { get; set; }

        [BsonElement("BANNER")]
        public string? Banner { get; set; }

        [BsonElement("FORMAT_MARKET")]
        public string? MarketFormat { get; set; }

        [BsonElement("CATEGORY")]
        public string? Category { get; set; }

        [BsonElement("MANUFACTURER")]
        public string? Manufacturer { get; set; }

        [BsonElement("BRAND")]
        public string? Brand { get; set; }

        [BsonElement("PRODUCT_DESCRIPTION")]
        public string? ProductDescription { get; set; }

        [BsonElement("EAN")]
        public string? Ean { get; set; }

        [BsonElement("WEEKLY_PRICE")]
        public decimal? WeeklyPrice { get; set; }

        [BsonElement("STORE_NAME")]
        public string? StoreChain { get; set; }

        [BsonElement("STATE_UF")]
        public string? StateUf { get; set; }

        [BsonElement("DATE")]
        public DateTime Date { get; set; }

        [BsonElement("CITY")]
        public string? City { get; set; }

        [BsonElement("CITY_2")]
        public string? City2 { get; set; }

        [BsonElement("HASH")]
        public string? Hash { get; set; }
    }

}
