﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using PH.Domain.Domain;
using PH.Domain.DTO;
using PH.Domain.Interfaces.Repositories;
using PH.Domain.Interfaces.Services;
using Spire.Xls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PH.Service.Services
{
    public class ProdutosTabeladosServices : IProdutosTabeladosServices
    {
        private readonly ILogger<ProdutosTabeladosServices> _logger;
        private readonly IProdutosTabeladosRepository _produtosTabeladosRepository;

        public ProdutosTabeladosServices(ILogger<ProdutosTabeladosServices> logger,
                     IProdutosTabeladosRepository produtosTabeladosRepository)
        {
            _logger = logger;
            _produtosTabeladosRepository = produtosTabeladosRepository;
        }

        public async Task ImportTabelados(IFormFile file)
        {
            _logger.LogInformation("InternalFileService AddInternal");

            try
            {
                List<ProdutosTabelados> produtosTabelados  = new List<ProdutosTabelados>();

                _logger.LogInformation($"Transformando excel para dados no arquivo {file.Name}");

                Workbook workbook = new Workbook();
                workbook.LoadFromStream(file.OpenReadStream());

                var sheet = workbook.ActiveSheet;
                produtosTabelados = ExtractFromExcel(sheet);

                await _produtosTabeladosRepository.InsertMany(produtosTabelados);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Erro InternalFileService AddInternal {ex.Message}");
                throw;
            }
        }

        private List<ProdutosTabelados> ExtractFromExcel(Worksheet sheet)
        {
            List<ProdutosTabelados> produtosTabelados = new List<ProdutosTabelados>();

            foreach (var cell in sheet.Rows)
            {
                //Pula cabeçalho
                if (cell.Row > 1)
                {
                    try
                    {
                        ProdutosTabelados produtos = new ProdutosTabelados();
                        produtos.EAN = cell.CellList[0].DisplayedText.Trim();
                        produtos.Description = cell.CellList[1].DisplayedText.Trim();
                        produtos.Brand = cell.CellList[2].DisplayedText.Trim();
                        produtos.State = cell.CellList[3].DisplayedText.Trim();
                        produtos.Price = Convert.ToDouble(cell.CellList[4].DisplayedText);
                        produtos.IdCompany = 3026;

                        produtosTabelados.Add(produtos);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, $"Erro ao adicionar linha {cell.Column}. {ex.Message}");
                        continue;
                    }
                }
            }

            return produtosTabelados;
        }

        public async Task<List<ProdutosTabeladosDTO>> GetProdutosTabelados (long idCompany, string state, string affiliate)
        {
            _logger.LogInformation("Iniciando busca de produtos tabelados");

            try
            {
                List<ProdutosTabeladosDTO> listProducts = new List<ProdutosTabeladosDTO> ();

                 var products = await _produtosTabeladosRepository.GetListProdutosTabelados(idCompany);
                var lastSales = await _produtosTabeladosRepository.GetLastSales(idCompany, affiliate);

                if (products != null && lastSales != null && products.Count() > 0 && lastSales.Count() > 0)
                {
                    foreach(var product in products)
                    {
                        if (product.State != null && product.State.Trim().ToUpper() != state.Trim().ToUpper())
                            continue;

                        var items = lastSales.Where(x => x.EAN == product.EAN).ToList().OrderByDescending(x => x.Date);

                        var item = items.FirstOrDefault();

                        if(item != null)
                        {
                            listProducts.Add(new ProdutosTabeladosDTO()
                            {
                                EAN = product.EAN,
                                Description = product.Description,
                                LastPrice = item.Price,
                                LastSale = item.Date,
                                FixedPrice = product.Price
                            });
                        }
                    }

                    return listProducts;
                }
                else
                    return listProducts;

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Erro ao buscar produtos tabelados {ex.Message}");
                throw;
            }
        }
    }
}
