"""
Módulo para busca com base em similaridade entre strings.
"""

import os
import re
from collections import defaultdict
from datetime import datetime
from enum import Enum
from functools import partial
from time import perf_counter
from typing import Any, Callable, Dict, List, Optional, Tuple
import itertools
import numpy as np
from fuzzy_vectorizer import FuzzyCountVectorizer
from vectorizer import BM25, SimpleVectorizer, Vectorizer
from rapidfuzz import distance, process
from sklearn.metrics.pairwise import cosine_similarity
from fastapi.exceptions import HTTPException

from cache import AsyncTTL
from brand_matcher import BrandMatcher
from async_mongo import AsyncMongoConnect
from logger import logger
from models.search_v3_models import PriceRange, SearchProductsPredmonitorBM25, SearchProductsBM25, UsedHours
from processing import Processing


class SearchVersion(Enum):
    V1 = 1
    V2 = 2


# TODO decidir entre normal e fuzzy
def check_required_words(name: str, required_words: Optional[List[str]] = None) -> bool:
    """Checa se as palavras exigidas estão presentes no nome."""
    if required_words is None or required_words == []:
        return True
    matrix = []
    lowercase_required_words = [word.lower() for word in required_words]
    # Criação de um produto cartesiano
    combinations = itertools.product(*[words.split(";") for words in lowercase_required_words])
    for combination in combinations: 
        vector = []
        for word in combination: 
            if word != "":
                vector.append(word)
        matrix.append(vector)
    for vector in matrix:
        if all(word in name for word in vector):
            return True
    return False

def check_restricted_words(name: str, restricted_words: Optional[List[str]] = None) -> bool:
    """Checa se as palavras restritas estão presentes no nome."""
    if restricted_words is None or restricted_words == []:
        return False
    lowercase_restricted_words = [word.lower() for word in restricted_words]
    return any(word in name.lower() for word in lowercase_restricted_words)


def check_required_words_fuzzy(
    name: str,
    required_words: Optional[List[str]] = None,
    min_fuzzy_similarity: float = 0.8,
) -> bool:
    """ "Checa se as palavras exigidas estão presentes no nome (versão fuzzy)."""
    if required_words is None:
        return True
    tokens = re.findall(r"(?u)\b\w\w+\b", name)
    return all(
        process.extract(
            word,
            tokens,
            score_cutoff=min_fuzzy_similarity,
            scorer=distance.Levenshtein.normalized_similarity,
        )
        for word in required_words
    )


def fuzzy_similarity(text_1: str, text_2: str, use_cosine: bool = True) -> float:
    """Calcula a similaridade utilizando um vetorizador fuzzy."""
    if len(text_1) == 0 or len(text_2) == 0:
        return 0.0

    vectorizer = FuzzyCountVectorizer()
    matrix, lengths = vectorizer.fit_transform([text_1, text_2])

    if use_cosine and lengths[0] >= 4:
        return cosine_similarity(matrix, matrix)[0, 1]
    return _set_similarity(matrix)


def _set_similarity(matrix: np.ndarray) -> float:
    """
    Similaridade: tokens em comum / número de tokens em text_1.
    """
    overlap = (matrix[0] * matrix[1] > 0).sum()
    reference = (matrix[0] > 0).sum()
    return overlap / reference


def find_top_word(name: str) -> Optional[str]:
    """
    Encontra a primeira palavra relevante de um nome.
    Provavelmente trata-se de uma palavra crucial para o produto.

    Palavra relevante: pelo menos três caracteres e com apenas letras.
    """
    words = re.findall(r"\b[^\W\d_]{3,}\b", name)
    if not words:
        return None
    return words[0].strip()


def _prepare_mongo_docs(mongo_docs: List[Dict[str, Any]], prep: Callable) -> List[Dict[str, Any]]:
    out = []
    for doc in mongo_docs:
        if "_id" not in doc:
            continue
        product_name_mongo = doc["_id"].get("product_name") or ""
        if not product_name_mongo:
            continue
        product_name_mongo = prep(product_name_mongo)
        product_model_mongo = doc["_id"].get("product_model") or ""
        if product_model_mongo:
            product_model_mongo = prep(product_model_mongo)
            if product_model_mongo not in product_name_mongo:
                product_name_mongo += f" {product_model_mongo}"
        doc.pop("_id", None)  # NOTE não é necessário, economiza espaço no cache
        doc["processed_name"] = product_name_mongo
        out.append(doc)
    return out

def _build_vectorizer(mongo_docs: List[Dict], bm25_mode: str) -> Optional[Vectorizer]:
    if len(mongo_docs) == 0:
        return None

    queries = [doc["processed_name"] for doc in mongo_docs]
    if bm25_mode == "simple":
        return SimpleVectorizer(queries)
    return BM25(queries)


# NOTE apenas kwargs são usados para determinar key do cache
# NOTE maxsize em bytes
@AsyncTTL(time_to_live=3600, maxsize=int(os.environ.get("CACHESIZE") or 1e9))
async def _fetch_ids_live(
    db_mongo: AsyncMongoConnect,
    prep: Callable,
    *,
    start_date,
    end_date,
    id_crawlers: Tuple[str, ...],
    id_company: Optional[int] = None,
    netshoes: bool = False,
    europe_products: bool = False,
    bm25_mode: str = "bm25",
    ids_task: Optional[Tuple] = None,
    **kwargs,
) -> Tuple[List[Dict[str, Any]], Optional[Vectorizer]]:
    if netshoes:
        mongo_docs = await db_mongo.get_products_netshoes(
            start_date,
            end_date,
            id_crawlers,
            id_company=id_company,
        )
    elif europe_products:
        mongo_docs = await db_mongo.get_products_europe_products_bm25(
            start_date,
            end_date,
            id_crawlers,
            id_company=id_company,
        )
    else:
        mongo_docs = await db_mongo.get_products_pred_monitor_bm25(
            start_date,
            end_date,
            id_crawlers,
            id_company=id_company,
            ids_task=ids_task
        )

    mongo_docs = list(mongo_docs)
    logger.debug("número de produtos dos crawlers: %s", len(mongo_docs))

    if len(mongo_docs) == 0:
        logger.warning(
            "nenhum ID retornado do Mongo: id_crawlers = %s | id_company = %s",
            id_crawlers,
            id_company,
        )

    mongo_docs = _prepare_mongo_docs(mongo_docs, prep)
    # NOTE modelo BM25 é construído aqui para entrar no cache
    vectorizer = _build_vectorizer(mongo_docs, bm25_mode)
    return mongo_docs, vectorizer


# NOTE apenas kwargs são usados para determinar key do cache
# NOTE maxsize em bytes
@AsyncTTL(time_to_live=3600, maxsize=int(os.environ.get("CACHESIZE") or 1e9))
async def _fetch_ids_by_monitoring_id(
    db_mongo: AsyncMongoConnect,
    prep: Callable,
    *,
    start_date,
    end_date,
    id_crawlers: Tuple[str, ...],
    monitoring_ids: Tuple[str, ...],
    id_company: Optional[int] = None,
    bm25_mode: str = "bm25",
    ids_task: Optional[Tuple] = None,
    **kwargs,
) -> Tuple[List[Dict[str, Any]], Optional[Vectorizer]]:
    mongo_docs = await db_mongo.get_products_by_monitoring_id(
        start_date,
        end_date,
        id_crawlers,
        monitoring_ids=monitoring_ids,
        id_company=id_company,
        ids_task=ids_task
    )

    mongo_docs = list(mongo_docs)
    logger.debug("número de produtos dos crawlers: %s", len(mongo_docs))

    if len(mongo_docs) == 0:
        logger.warning(
            "nenhum ID retornado do Mongo: id_crawlers = %s | id_company = %s",
            id_crawlers,
            id_company,
        )

    mongo_docs = _prepare_mongo_docs(mongo_docs, prep)
    # NOTE modelo BM25 é construído aqui para entrar no cache
    vectorizer = _build_vectorizer(mongo_docs, bm25_mode)
    return mongo_docs, vectorizer


class SearchV3:
    def __init__(self, netshoes: bool = False, europe_products: bool = False):
        self.db_mongo = AsyncMongoConnect()
        self.prep = None
        self.netshoes = netshoes
        self.europe_products = europe_products
        if netshoes:
            self.mongo_callback = self.db_mongo.get_selected_products_netshoes
        elif europe_products:
            self.mongo_callback = self.db_mongo.get_selected_products_europe_products
        else:
            self.mongo_callback = self.db_mongo.get_selected_products_pred_monitor
        logger.debug("SearchV3 criado: netshoes = %s europe_products = %s", netshoes, europe_products)

    async def _fetch_products(
        self,
        start_date,
        end_date,
        *,
        id_crawlers: List[int],
        bm25_mode: str,
        id_company: Optional[int] = None,
        cache: bool = False,
        ids_task: Optional[List] = None,
    ):
        id_crawlers = tuple(sorted(id_crawlers))
        ids, vectorizer = await _fetch_ids_live(
            self.db_mongo,
            self.prep,
            start_date=start_date,
            end_date=end_date,
            id_crawlers=id_crawlers,
            id_company=id_company,
            netshoes=self.netshoes,
            europe_products=self.europe_products,
            use_cache=cache,
            bm25_mode=bm25_mode,
            ids_task=ids_task,
        )
        return ids, vectorizer

    async def search_v2(self, request: SearchProductsPredmonitorBM25, cache: bool = False):
        logger.debug("-> search V3/V2: buscando em dados completos dos crawlers")
        init = perf_counter()

        prep = Processing()
        self.prep = partial(prep.run, language=request.filters.language)

        mongo_docs, vectorizer = await self._fetch_products(
            request.start_date,
            request.end_date,
            id_crawlers=request.idcrawlers,
            id_company=request.id_company,
            cache=cache,
            bm25_mode=request.bm25_mode,
            ids_task=request.ids_task,
        )
        result = await self._search_v2(request, mongo_docs, vectorizer)
        logger.debug("time: %.2f ms", (perf_counter() - init) * 1000)
        return result

    async def search_v2_by_monitoring_id(self, request: SearchProductsPredmonitorBM25, cache: bool = False):
        logger.debug("-> search V3/V2: buscando por id de monitoramento")
        init = perf_counter()

        prep = Processing()
        self.prep = partial(prep.run, language=request.filters.language)

        monitoring_id = request.filters.id_monitoring_item

        mongo_docs, vectorizer = await _fetch_ids_by_monitoring_id(
            self.db_mongo,
            self.prep,
            start_date=request.start_date,
            end_date=request.end_date,
            id_crawlers=tuple(sorted(request.idcrawlers)),
            monitoring_ids=(monitoring_id,),
            id_company=request.id_company,
            bm25_mode=request.bm25_mode,
            use_cache=cache,
        )

        result = await self._search_v2(request, mongo_docs, vectorizer)
        logger.debug("time: %.2f ms", (perf_counter() - init) * 1000)
        return result

    async def _search_v2(
        self, request: SearchProductsPredmonitorBM25, mongo_docs: List[Dict], vectorizer: Optional[Vectorizer]
    ):
        if not request.filters.products:
            return []

        result = []
        product_names = request.filters.products
        product_brand = request.filters.brands
        sellers = request.filters.sellers
        local_filter = request.filters.local_states
        hours_filter = request.filters.used_hours
        manufacture_year_filter = request.filters.manufacture_years
        required_words = request.filters.required_words
        restricted_words = request.filters.restricted_words

        for product_name in product_names:
            processor = DocumentProcessor(
                mongo_callback=self.mongo_callback,
                product_name=product_name,
                product_brand=product_brand,
                sellers=sellers,
                required_words=required_words,
                local_states=local_filter,
                used_hours=hours_filter,
                manufacture_years=manufacture_year_filter,
                restricted_words=restricted_words,
                vectorizer=vectorizer,
                string_processor=self.prep,
                language=request.filters.language,
                version=SearchVersion.V2,
                use_top_word=request.use_top_word,
                use_cosine=request.use_cosine,
                price_range=request.filters.price_range,
                relative_threshold=request.relative_threshold,
                fuzzy_threshold=request.fuzzy_threshold,
                restrictive_fuzzy_threshold=request.restrictive_fuzzy_threshold,
            )
            result.append(await processor.process(mongo_docs))

        return result

    async def search_v1_by_monitoring_id(self, request: SearchProductsBM25, cache: bool = False):
        logger.debug("-> search V3/V1: buscando por id de monitoramento")
        init = perf_counter()

        prep = Processing()
        self.prep = partial(prep.run, language=request.language)

        # TODO mudar tipo da requisição para int posteriormente
        try:
            monitoring_ids = tuple(sorted({int(product.id) for product in request.products}))
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=f"error when converting id to integer: {exc}") from exc

        mongo_docs, vectorizer = await _fetch_ids_by_monitoring_id(
            self.db_mongo,
            self.prep,
            start_date=request.start_date,
            end_date=request.end_date,
            id_crawlers=tuple(sorted(request.idcrawlers)),
            monitoring_ids=monitoring_ids,
            id_company=request.id_company,
            bm25_mode=request.bm25_mode,
            use_cache=cache,
        )

        result = await self._search_v1(request=request, mongo_docs=mongo_docs, vectorizer=vectorizer)
        logger.debug("time: %.2f ms", (perf_counter() - init) * 1000)
        return result

    async def search_v1(self, request: SearchProductsBM25, cache: bool = False):
        logger.debug("-> search V3/V1: buscando em dados completos dos crawlers")
        init = perf_counter()

        prep = Processing()
        self.prep = partial(prep.run, language=request.language)

        mongo_docs, vectorizer = await self._fetch_products(
            request.start_date,
            request.end_date,
            id_crawlers=request.idcrawlers,
            id_company=request.id_company,
            cache=cache,
            bm25_mode=request.bm25_mode,
        )

        result = await self._search_v1(request=request, mongo_docs=mongo_docs, vectorizer=vectorizer)
        logger.debug("time: %.2f ms", (perf_counter() - init) * 1000)
        return result

    async def _search_v1(
        self, *, request: SearchProductsBM25, mongo_docs: List[Dict], vectorizer: Optional[Vectorizer]
    ):
        if not request.products:
            return []

        result = []

        for product in request.products:
            product_name = product.name.lower()
            product_model = (product.model or "").lower()
            
            
            if product_model and product_model not in product_name:
                product_name += f" {product_model}"

            processor = DocumentProcessor(
                mongo_callback=self.mongo_callback,
                product_name=product_name,
                product_brand=product.brand,
                required_words=product.required_words,
                restricted_words=product.restricted_words,
                string_processor=self.prep,
                vectorizer=vectorizer,
                language=product.language,
                version=SearchVersion.V1,
                product_id=product.id,
                use_top_word=request.use_top_word,
                use_cosine=request.use_cosine,
                price_range=product.price_range,
                relative_threshold=request.relative_threshold,
                fuzzy_threshold=request.fuzzy_threshold,
                restrictive_fuzzy_threshold=request.restrictive_fuzzy_threshold,
            )
            result.append(await processor.process(mongo_docs))

        return result


class DocumentProcessor:
    def __init__(
        self,
        *,
        mongo_callback: Callable,
        product_name: str,
        language: str,
        string_processor: Callable,
        vectorizer: Optional[Vectorizer],
        version: SearchVersion,
        product_id: Optional[str] = None,
        price_range: Optional[PriceRange] = None,
        product_brand: Optional[List[str]] = None,
        sellers: Optional[List[str]] = None,
        product_category_name: Optional[List[str]] = None,
        required_words: Optional[List[str]] = None,
        local_states: Optional[List] = None,
        manufacture_years: Optional[List] = None,
        used_hours: Optional[UsedHours] = None,
        restricted_words: Optional[List[str]] = None,
        absolute_threhsold: float = 2,
        relative_threshold: float = 0.9,
        fuzzy_threshold: float = 0.7,
        restrictive_fuzzy_threshold: float = 0.9,
        use_top_word: bool = True,
        use_cosine: bool = True,
    ):
        self.brand_matcher = BrandMatcher()
        self.mongo_callback = mongo_callback
        self.language = language
        self.version = version
        self.product_id = product_id
        self.prep = string_processor
        self.product_name = product_name
        self.vectorizer = vectorizer
        self.ref_name = None
        self.top_word = None
        self.use_top_word = use_top_word
        self.use_cosine = use_cosine
        self.price_range = price_range
        self.product_brand = product_brand
        self.sellers = sellers
        self.product_category_name = product_category_name
        self.required_words = required_words
        self.local_states = local_states
        self.manufacture_years = manufacture_years
        self.used_hours = used_hours
        self.restricted_words = restricted_words
        self.absolute_threshold = absolute_threhsold
        self.relative_threshold = relative_threshold
        self.fuzzy_threshold = fuzzy_threshold
        self.restrictive_fuzzy_threshold = restrictive_fuzzy_threshold

    def _preprocess_strings(self) -> None:
        self.ref_name = self.prep(self.product_name)
        self.top_word = find_top_word(self.ref_name) if self.use_top_word else None

        if self.required_words:
            self.required_words = [self.prep(word) for word in self.required_words]

    async def process(self, mongo_docs: List[Dict]) -> List[Dict]:
        self._preprocess_strings()
        result = await self._process_product(mongo_docs)

        if self.version == SearchVersion.V1:
            result["name"] = result.pop("product")
            result["results"] = result.pop("result")
            result["id"] = self.product_id or ""

        return result

    async def _process_product(self, mongo_docs: List[Dict]) -> List[Dict]:
        product_result = {"product": self.product_name, "result": []}  # formato V2
        if len(mongo_docs) == 0:
            return product_result

        logger.debug("iniciando busca V2 (pred_monitor) com os termos: %s", self.ref_name)
        logger.debug("required words: %s", self.required_words)
        logger.debug("top word: %s", self.top_word)

        score_description = self.vectorizer.get_scores(self.ref_name)

        selected_ids_scores = []
        # 5 como valor mínimo para evitar produtos com máximo 0 -> traria todos acima do threshold
        prefilter_threshold = max(self.absolute_threshold, self.relative_threshold * max(score_description))
        for doc, score in zip(mongo_docs, score_description):
            if score < prefilter_threshold:
                logger.debug(
                    "excluindo o nome %s com os seguintes IDs no pre-filtro (relative_threshold): %s",
                    doc.get("processed_name", "[empty name]"),
                    doc.get("ids")
                )
                continue
            ids_scores = self._filter_fuzzy_similarity(doc)
            if ids_scores is not None:
                selected_ids_scores.append(ids_scores)

        logger.debug("%s nomes-URLs distintos acima do threshold", len(selected_ids_scores))
        if len(selected_ids_scores) == 0:
            logger.debug("nenhum produto acima do threshold -- produto: %s", self.product_name)
            return product_result

        selected_ids = [id_ for sublist in selected_ids_scores for id_, _ in sublist]
        selected_products = await self.mongo_callback(selected_ids)
        selected_products = {doc["_id"]: doc for doc in selected_products}

        for ids_scores in selected_ids_scores:
            result_ = self._build_result(ids_scores, selected_products)
            if result_:
                product_result["result"].extend(result_)

        product_result["result"] = list(sorted(product_result["result"], key=lambda x: x["score"], reverse=True))

        product_result["result"] = self._filter_results_by(product_result, self.used_hours, self.manufacture_years , self.local_states, self.product_brand, self.product_category_name, self.sellers)

        return product_result

    def _filter_fuzzy_similarity(
        self,
        doc: Dict,
    ) -> Optional[List[Tuple[str, float]]]:
        name = doc["processed_name"]
        if "ids" not in doc:
            logger.warning("documento sem campo ids")
            return None
        fuzzy_sim = fuzzy_similarity(self.ref_name, name, self.use_cosine)
        adjuted_threshold = self.fuzzy_threshold
        if self.top_word is not None and self.top_word not in name:
            adjuted_threshold = self.restrictive_fuzzy_threshold
        if fuzzy_sim < adjuted_threshold:
            logger.debug(
                "fuzzy_sim de %.2f entre strings abaixo do threshold de %.2f: %s -- %s",
                fuzzy_sim,
                adjuted_threshold,
                name,
                self.ref_name,
            )
            return None
        return [(id_, round(fuzzy_sim, 3)) for id_ in doc["ids"]]

    def _filter_results_by(self, results, hours_filter, manufacture_filter, local_filter, product_brand, product_category_name, sellers):
        try:
            filtered_results = results["result"]

            if local_filter:
                filtered_results = self.filter_by_local_state(filtered_results, local_filter)

            if hours_filter:
                filtered_results = self.filter_by_used_hours(filtered_results, hours_filter)

            if manufacture_filter:
                filtered_results = self.filter_by_manufacture_year(filtered_results, manufacture_filter)

            if product_brand:
                filtered_results = self.filter_by_product_brand(filtered_results, product_brand)

            if product_category_name:
                filtered_results = self.filter_by_product_category_name(filtered_results, product_category_name)

            if sellers:
                filtered_results = self.filter_by_sellers(filtered_results, sellers)

        except Exception as ex:
            logger.exception(f"Erro ao aplicar todos os filtros: {ex}")
 
        return filtered_results


    def filter_by_local_state(self, result, local_states):
        try:
            if (local_states != None) and (len(local_states) > 0):
                filtered_docs = list(filter(lambda x: str(x["product_local"]["state"]).lower() in local_states , result))

        except Exception as ex:
            logger.exception(f"Erro ao aplicar o filtro de estado: {ex}")

        return filtered_docs
        

    def filter_by_used_hours(self, result, used_hours):
        filtered_docs = []
        try:
            if used_hours.min != 0 and used_hours.max != 0:
                for i in result:
                        if (i["product_used_hours"] != None and int(used_hours.max) != 0):
                            if ((int(used_hours.min) <= int(i["product_used_hours"])) and (int(i["product_used_hours"]) <= int(used_hours.max))):
                                  filtered_docs.append(i)
                        elif (i["product_used_hours"] != None and int(used_hours.max) == 0):
                            if ((int(used_hours.min) <= int(i["product_used_hours"]))):
                                  filtered_docs.append(i)
            else:
                filtered_docs = result
        except Exception as ex:
            logger.exception(f"Erro ao aplicar o filtro de horas: {ex}")
    
        return filtered_docs

    def filter_by_manufacture_year(self, result, manufacture_year):
        filtered_docs = []
        try:
            if (manufacture_year != None) and (len(manufacture_year) > 0):
                filtered_docs = list(filter(lambda x: x["product_manufacture_year"] in manufacture_year , result))

        except Exception as ex:
            logger.exception(f"Erro ao aplicar o filtro de ano de fabricação: {ex}")

        return filtered_docs
    
    def filter_by_product_brand(self, result, product_brand):
        filtered_docs = []
        try:
            if (product_brand != None) and (len(product_brand) > 0):
                filtered_docs = list(filter(lambda x: x["product_brand"] in product_brand , result))

        except Exception as ex:
            logger.exception(f"Erro ao aplicar o filtro de marca: {str(ex)}")

        return filtered_docs
    
    def filter_by_product_category_name(self, result, product_category_name):
        filtered_docs = []
        try:
            if (product_category_name != None) and (len(product_category_name) > 0):
                filtered_docs = list(filter(lambda x: x["product_category_name"] in product_category_name , result))

        except Exception as ex:
            logger.exception(f"Erro ao aplicar o filtro de categoria: {str(ex)}")

        return filtered_docs
    
    def filter_by_sellers(self, result, sellers):
        filtered_docs = []
        try:
            if (sellers != None) and (len(sellers) > 0):
                filtered_docs = list(filter(lambda x: x["seller_name"] in sellers , result))

        except Exception as ex:
            logger.exception(f"Erro ao aplicar o filtro de seller: {str(ex)}")

        return filtered_docs

    def _build_result(self, ids_scores: List[Tuple[str, float]], selected_products: Dict[str, Any]) -> List[Dict]:
        docs = []
        for id_, score in ids_scores:
            if id_ not in selected_products:
                logger.warning("produto não encontrado no Mongo - ID %s", id_)
                continue

            doc = selected_products[id_]
            scorer = [0]
            if "crawler_date" not in doc:
                logger.warning("crawler_date missing from document (_id: %s)", id_)
            if self.required_words or self.restricted_words:
                def process_field(doc, field_name, required_words, restricted_words, scorer):
                    if field_name in doc:
                        field_value = doc[field_name]
                        if field_value is None:
                            return False
                        field_value = self.prep(field_value)
                        if check_required_words(field_value, required_words):
                            scorer[0] += 1
                        if check_restricted_words(field_value, restricted_words):
                            return True 

                # List of fields to process
                fields_to_process = ["product_name","trash","product_ean","product_model", "product_description", "site_sku"]

                doc["check_words"] = " ".join(str(doc.get(field)) or "" for field in fields_to_process)
                if process_field(doc, "check_words", self.required_words, self.restricted_words, scorer):
                    scorer[0] = 0

                if scorer[0] == 0:
                    logger.debug("excluindo produto %s por restricted_words ou required_words", id_)
                    continue

            doc["score"] = score
            docs.append(doc)
        if not docs:
            return None

        if self.version == SearchVersion.V1:
            link_map = defaultdict(list)
            for doc in docs:
                if "product_link" not in doc:
                    continue
                link = doc["product_link"]
                link_map[link].append(doc)

            link_docs = (
                sorted(docs_, key=lambda doc: doc.get("crawler_date") or datetime(year=1980, month=1, day=1))
                for docs_ in link_map.values()
            )
            docs = [docs_[-1] for docs_ in link_docs]

        result = []
        for doc in docs:
            result.extend(self._expand_one_document(doc))
        return result

    def _expand_one_document(self, doc: Dict[str, Any]) -> List[Dict]:
        doc_brand = doc.get("product_brand") or ""
        doc_brand = self.prep(doc_brand)
        score: float = doc["score"]
        brand_query = self.ref_name + " " + doc_brand
        if (
            self.product_brand
            and not any(self.brand_matcher(brand, brand_query) for brand in self.product_brand)
            and score < self.restrictive_fuzzy_threshold
        ):
            logger.debug(
                "brand '%s' not found in query: '%s' -> score %.2f below high threshold of %.2f",
                self.product_brand,
                brand_query,
                score,
                self.restrictive_fuzzy_threshold,
            )
            return []

        if "product_link" not in doc:
            return []
        if "sellers" not in doc:
            return []

        if self.version == SearchVersion.V1:
            return self._construct_v1_doc(doc)
        if self.version == SearchVersion.V2:
            return self._construct_v2_doc(doc)
        logger.warning("unsupported version provided: %s", self.version)
        return []

    def _construct_v2_doc(self, doc: Dict[str, Any]) -> List[Dict]:
        if "_id" not in doc:
            logger.warning("_id field not present in mongo document")
            return []

        product_local = doc.get("product_local")
        if not product_local:
            doc["product_local"] = {}
        if "state" not in doc["product_local"]:
            doc["product_local"]["state"] = None

        result_docs = []
        doc["sellers"] = doc.get("sellers") or []
        for seller_obj in doc["sellers"]:
            if self.price_range is not None and not self.price_range.is_product_valid(seller_obj):
                continue
            result_doc = {
                "id": str(doc["_id"]),
                "id_crawler": doc.get("id_crawler"),
                "product_name": doc.get("product_name"),
                "product_link": doc.get("product_link"),
                "site_sku": doc.get("site_sku"),
                "source": doc.get("source"),
                "language": self.language,
                "product_brand": doc.get("product_brand"),
                "product_model": doc.get("product_model"),
                "id_product_normalized": doc.get("id_product_normalized"),
                "product_local": doc.get("product_local"),
                "product_category_name": doc.get("product_category_name"),
                "score": doc.get("score"),
                "trash_score": 0,
                "crawler_date": doc.get("crawler_date"),
                "seller_name": seller_obj.get("seller_name"),
                "prices": seller_obj.get("prices"),
                "product_manufacture_year": doc.get("product_manufacture_year"),
                "product_used_hours": doc.get("product_used_hours"),
                "product_axles": doc.get("product_axles"),
                "product_mileage": doc.get("product_mileage"),
                "product_mileage_symbol": doc.get("product_mileage_symbol"),
                "product_fuel_tank_capacity": doc.get("product_fuel_tank_capacity"),
                "product_fuel_tank_capacity_symbol": doc.get("product_fuel_tank_capacity_symbol"),
                "product_truck_body_type": doc.get("product_truck_body_type"),
                "product_vehicle_year_model": doc.get("product_vehicle_year_model"),
                "product_manufacturer": doc.get("product_manufacturer"),
            }

            result_doc["coordinates"] = None

            if doc.get('product_local') is not None:
                product_local = doc.get('product_local')
                if(product_local.get('coordinates') is not None):
                    coordinates = product_local.get('coordinates')
                    if 'coordinates' in coordinates and len(coordinates['coordinates']) == 2:
                        result_doc["coordinates"] = {
                            "longitude": coordinates['coordinates'][0],
                            "latitude": coordinates['coordinates'][1]
                        }
                        result_doc["product_local"] = {
                            'state': product_local.get('state'),
                            'city': product_local.get('city')
                        }

            if seller_obj.get("coordinates") is not None:
                coordinates = seller_obj['coordinates']
                if 'coordinates' in coordinates and len(coordinates['coordinates']) == 2:
                    result_doc["coordinates"] = {
                        "longitude": coordinates['coordinates'][0],
                        "latitude": coordinates['coordinates'][1]
                    }
                    result_doc["product_local"] = {
                            'state': seller_obj.get('state_uf'),
                            'city': seller_obj.get('city')
                    }
            
            result_docs.append(result_doc)

        return result_docs

    def _construct_v1_doc(self, doc: Dict[str, Any]) -> List[Dict]:
        if "_id" not in doc:
            logger.warning("_id field not present in mongo document")
            return []
        doc["id"] = str(doc.pop("_id"))
        valid_price = False
        doc["sellers"] = doc.get("sellers") or []
        for seller_obj in doc["sellers"]:
            if self.price_range is not None and not self.price_range.is_product_valid(seller_obj):
                continue
            valid_price = True
        if not valid_price:
            return []
        return [doc]
