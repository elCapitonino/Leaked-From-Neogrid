﻿using AutoMapper;
using Repository.Entity;

namespace Domain.Status.Models
{
    public class StatusProfile : Profile
    {
        public StatusProfile()
        {
            CreateMap<MonitoringItemResultsStatusEntity, MonitoringItemResultsStatusResponse>().ReverseMap();
            CreateMap<MonitoringItemResultsStatusEntity, MonitoringItemResultsStatusRequest>()
                .ForMember(dest => dest.Step, opt => opt.MapFrom(src => src.CurrentStep))
                .ReverseMap();
                
        }
    }
}
