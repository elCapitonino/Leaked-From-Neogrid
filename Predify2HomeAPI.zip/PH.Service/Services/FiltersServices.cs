﻿using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using PH.Domain.DTO;
using PH.Domain.Interfaces.Repositories;
using PH.Domain.Interfaces.Services;

namespace PH.Service.Services
{
    public class FiltersServices : IFiltersServices
    {
        private readonly ILogger<FiltersServices> _logger;
        private readonly IFiltersRepository _repository;
        private readonly IMemoryCache _memoryCache;
        private readonly ICacheControlService _cacheControlService;

        public FiltersServices(ILogger<FiltersServices> logger,
                             IFiltersRepository repository,
                             IMemoryCache memoryCache,
                             ICacheControlService cacheControlService)
        {
            _logger = logger;
            _repository = repository;
            _memoryCache = memoryCache;
            _cacheControlService = cacheControlService;
        }

        public async Task<FiltersMainDTO> Get()
        {
            _logger.LogInformation("Service: buscando todos os Filters");

            try
            {
                FiltersMainDTO response = (FiltersMainDTO)_memoryCache.Get("Filters");

                if (response == null)
                {
                    response = await _repository.Get();
                    _cacheControlService.SettingTimeAndCache(response, "Filters");
                }

                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Service: erro ao buscar todos os Filters. {ex.Message}");
                throw;
            }
        }
    }
}
