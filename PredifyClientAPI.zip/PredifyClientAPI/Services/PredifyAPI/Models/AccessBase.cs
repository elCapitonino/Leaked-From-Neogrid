﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace PredifyClientAPI.Services.PredifyAPI.Models
{
    /// <summary>
    /// Modelo básico para consulta com id company.
    /// </summary>
    public class AccessBase
    {

        /// <summary>
        /// Id de identificação da Empresa.
        /// </summary>
        [Required]
        public virtual long idCompany { get; set; }
    }

    /// <summary>
    /// Modelo básico para consulta com paginação.
    /// </summary>
    public class AccessBaseWithPage : AccessBase
    {
        /// <summary>
        /// Qual página ira ser consultada.
        /// </summary>
        [DefaultValue(1)]
        public int page { get; set; } = 1;

        /// <summary>
        /// Registros por página.
        /// </summary>
        [DefaultValue(10)]
        public int recordsPerPage { get; set; } = 10;
    }

    public class AccessBaseWithPage<TFilter> : AccessBaseWithPage
    {
        /// <summary>
        /// Objeto que irá representar os filtros
        /// </summary>
        public TFilter Filters { get; set; }

        /// <summary>
        /// Objeto de Ordenação
        /// </summary>
        public AccessBaseWithPageOrder OrderBy { get; set; }
    }

    public class AccessBaseWithPageOrder
    {
        /// <summary>
        /// Campo a ser ordenado
        /// </summary>
        public string Field { get; set; }

        /// <summary>
        /// Epecifica se a ordenação será decrecent
        /// </summary>
        public bool Desc { get; set; }
    }

    /// <summary>
    /// Modelo que possuí o idCompany e idCost.
    /// </summary>
    public class AccessBaseByCost : AccessBase
    {
        /// <summary>
        /// Id do custo.
        /// </summary>
        [Required]
        public long idCost { get; set; }
        //public DateTime? dateRef { get; set; }
    }
}
