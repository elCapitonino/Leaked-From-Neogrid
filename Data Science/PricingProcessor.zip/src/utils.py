from typing import Optional

import pandas as pd

from src.exceptions import ConsistencyError

ADOPTION_TOLERANCE_PCT = 0.05


def build_product_id(df: pd.DataFrame, granularity: list[str]) -> Optional[pd.Series]:
    if not granularity:
        return None

    if df.empty:
        return None

    product_id = df[granularity].fillna("").agg("||".join, axis=1)
    return product_id


def check_product_id_uniqueness(df: pd.DataFrame) -> None:
    """Checks if each ProductId is unique in df, raises an exception otherwise."""
    duplicate = df.duplicated(subset=["ProductId"])
    duplicated_ids = df.loc[duplicate, "ProductId"].values.tolist()
    if duplicate.any():
        raise ConsistencyError(f"duplicate ProductIds found: {duplicated_ids}")
