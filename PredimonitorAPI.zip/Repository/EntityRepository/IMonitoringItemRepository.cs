﻿using Repository.Entity;
using Repository.EntityRepository.Bases;

namespace Repository.EntityRepository
{
    public interface IMonitoringItemRepository : IGenericRepository<MonitoringItemEntity, long>
    {
    }
}
