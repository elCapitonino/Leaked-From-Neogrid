﻿using DI.Repository.Entities;

namespace DI.Repository.Interfaces.Repositories
{
    public interface IEnterprisePriceGroupRepository
    {
        bool HasAccess(long companyId, long priceGroupId);

        EnterprisePriceGroupEntity GetById(long PriceGroupId);

        Task<IEnumerable<EnterprisePriceGroupEntity>> GetAllById(IEnumerable<long> PriceGroupId);

        Task<IEnumerable<EnterprisePriceGroupEntity>> GetByYearMonth(DateTime date);

    }
}
