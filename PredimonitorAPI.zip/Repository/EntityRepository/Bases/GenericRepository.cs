﻿using Microsoft.EntityFrameworkCore;
using MongoDB.Driver;
using Repository.DbContexts;
using Repository.Entity;

namespace Repository.EntityRepository.Bases
{
    public abstract class GenericRepository<TEntity, TPKType> : IGenericRepository<TEntity, TPKType> where TEntity : class, IEntityBase<TPKType>
    {
        protected readonly DbContext _dbContext;

        public static string DbContextName => nameof(ApplicationDbContext);

        public GenericRepository(DbContext dbContext)
        {
            _dbContext = dbContext;
            if (_dbContext.Database.IsRelational())
            {
                _dbContext.Database.SetCommandTimeout(TimeSpan.FromHours(5));
            }
        }
        public string? TableName
        {
            get
            {
                var entityType = _dbContext.Model.FindEntityType(typeof(TEntity));
                return entityType?.GetTableName();
            }
        }
        public TEntity Create(TEntity entity, bool autosave = true)
        {
            var response = _dbContext.Set<TEntity>().Add(entity);
            if (autosave)
                _dbContext.SaveChanges();
            return response.Entity;
        }

        public void AddRange(IEnumerable<TEntity> entities, bool autosave = false)
        {
            _dbContext.Set<TEntity>().AddRange(entities);
            if (autosave)
                _dbContext.SaveChanges();
        }

        public virtual void Delete(TPKType id)
        {
            var entity = GetById(id);
            _dbContext.Set<TEntity>().Remove(entity);
            _dbContext.SaveChanges();
        }
        public virtual void DeleteAll(IEnumerable<TPKType> ids)
        {
            var list = ids.Distinct().ToHashSet();
            var entities = _dbContext.Set<TEntity>()
                .Where(entity => list.Any(id => id.ToString() == entity.Id.ToString()));
            entities.ExecuteDelete();
            _dbContext.SaveChanges();
        }
        public virtual void Delete(TEntity entity, bool autosave = true)
        {
            _dbContext.Set<TEntity>().Remove(entity);
            if (autosave)
                _dbContext.SaveChanges();
        }

        public virtual IQueryable<TEntity> GetAll()
        {
            return _dbContext.Set<TEntity>();
        }
        public virtual TEntity? GetById(TPKType id)
        {
            return _dbContext.Set<TEntity>()
                    .FirstOrDefault(e => e.Id.ToString() == id.ToString());
        }

        public void Update(TEntity entity, bool autosave = true)
        {
            _dbContext.Set<TEntity>().Update(entity);
            if (autosave)
                _dbContext.SaveChanges();
        }

        public void Update(IEnumerable<TEntity> entity, bool autosave = true)
        {
            _dbContext.Set<TEntity>().UpdateRange(entity);
            if (autosave)
                _dbContext.SaveChanges();
        }

        public IQueryable<TEntity> ExecuteRawSQL(string sql)
        {
            return _dbContext.Set<TEntity>().FromSqlRaw(sql);
        }

        public async Task ExecuteRawSQLAsync(string sql)
        {
            await _dbContext.Database.ExecuteSqlRawAsync(sql);
        }

        public void SaveChanges()
        {
            _dbContext.SaveChanges();
        }
    }
}
