import pyodbc
# from cassandra.auth import PlainTextAuthProvider
# from cassandra.cluster import Cluster
# from pymongo import MongoClient
# from pyspark.conf import SparkConf

# auth_provider = PlainTextAuthProvider(
#     username='cassandra', password='cassandra')

# Conectar ScyllaDB
scyllaIP = '172.31.6.217'
scyllaPORT = 9042
scyllaKeyspace = 'predify_prod'
scyllaUser = 'cassandra'
scyllaPass = 'cassandra'

# Conectar ScyllaDB Homologação
scyllaIP_Homologacao = '172.31.6.217'
scyllaPORT_Homologacao = 9042
scyllaKeyspace_Homologacao = 'predify_hom'
scyllaUser_Homologacao = 'homologacao'
scyllaPass_Homologacao = 'hEpregaROdroCho4ruDA'

# Conectar AWS Produção
SQLServerIP = 'sql-predify-prd-001.database.windows.net,1433;'
SQLDataTable = 'sqldb-multiverso-prd'
SQLUId = 'data_science_user'
SQLPassoword = 'oxhR9@3$MmjKokD%^o7to'

# Conectar AWS Homologacao
# SQLServerIP_Homologacao = 'predify-homologacao.ccjyavyoczqo.us-west-2.rds.amazonaws.com;'
# SQLDataTable_Homologacao = 'multiverso'
# SQLUId_Homologacao = 'hom_predify'
# SQLPassoword_Homologacao = 'TRiSiVoMlToB8aw095iD'

# Conectar AWS Homologacao - Update 12/01/203 - Tiago
# SQLServerIP_Homologacao = 'predifynew.ccjyavyoczqo.us-west-2.rds.amazonaws.com;'
# SQLDataTable_Homologacao = 'homologacao'
# SQLUId_Homologacao = 'multi_admin'
# SQLPassoword_Homologacao = 'dUPH6blvaD98kajIK9dosP3t8OyOdO'

# Conectar AWS Homologacao - Update 08/02/2023
SQLServerIP_Homologacao = 'sql-predify-preprd-001.database.windows.net,1433;'
SQLDataTable_Homologacao = 'sqldb-multiverso-preprd'
SQLUId_Homologacao = 'multiAdmin'
SQLPassoword_Homologacao = 'dUPH6blvaD98kajIK9dosP3t8OyOdO'


# Conectar AWS Pre-Producao
SQLServerIP_PreProd = 'sql-predify-prd-001.database.windows.net,1433;'
SQLDataTable_PreProd = 'sqldb-multiverso-pre-prd'
SQLUId_PreProd = 'data_science_user'
SQLPassoword_PreProd = 'oxhR9@3$MmjKokD%^o7to'


# def getScyllaSession(environment=None):
#     cluster = None
#     if environment == 'homologacao':
#         cluster = Cluster(contact_points=[scyllaIP_Homologacao], port=scyllaPORT_Homologacao, auth_provider=PlainTextAuthProvider(
#             username=scyllaUser_Homologacao, password=scyllaPass_Homologacao))
#         return cluster.connect(scyllaKeyspace_Homologacao)
#     else:
#         cluster = Cluster(contact_points=[scyllaIP], port=scyllaPORT, auth_provider=PlainTextAuthProvider(
#             username=scyllaUser, password=scyllaPass))
#         return cluster.connect(scyllaKeyspace)


def getDadosAWSSession(environment:str) -> pyodbc.Connection:
    if environment == 'homologacao':
        str_conx = "Driver={ODBC Driver 17 for SQL Server};Server=" + str(SQLServerIP_Homologacao)
        str_conx += ";Database=" + str(SQLDataTable_Homologacao)
        str_conx += ";UID=" + str(SQLUId_Homologacao) + ";PWD=" + str(SQLPassoword_Homologacao) + ";"
        return pyodbc.connect(str_conx, autocommit=True)
    
    elif environment == 'producao':
        str_conx = "Driver={ODBC Driver 17 for SQL Server};Server=" + str(SQLServerIP)
        str_conx += ";Database=" + str(SQLDataTable)
        str_conx += ";UID=" + str(SQLUId) + ";PWD=" + str(SQLPassoword) + ";"
        return pyodbc.connect(str_conx, autocommit=True)
    
    elif environment == 'preproducao':
        str_conx = "Driver={ODBC Driver 17 for SQL Server};Server=" + str(SQLServerIP_PreProd)
        str_conx += ";Database=" + str(SQLDataTable_PreProd)
        str_conx += ";UID=" + str(SQLUId_PreProd) + ";PWD=" + str(SQLPassoword_PreProd) + ";"
        return pyodbc.connect(str_conx, autocommit=True)
    
    else:
        raise AttributeError("O `environment` especificado não é uma opção válida.")

# Dados Mongo
MongoServer = {
    "host": '172.31.46.114:27017',
    "port": '27017',
    "user": 'data_science01',
    "password": 'jbdsfbhvskjn@L'
}

# user: "petrobahia"
# pwd: "hK@1k=&vGIh7BlK"


# def getMongoSession():
#     return MongoClient(
#         MongoServer['host'], username=MongoServer["user"], password=MongoServer["password"], authMechanism='DEFAULT')
