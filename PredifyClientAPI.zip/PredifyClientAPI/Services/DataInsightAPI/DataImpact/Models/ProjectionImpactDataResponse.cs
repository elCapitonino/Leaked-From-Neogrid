﻿namespace PredifyClientAPI.Services.DataInsightAPI.DataImpact.Models
{
    public sealed class ProjectionImpactDataResponse
    {
        public Guid Id { get; set; }
        public required long CompanyId { get; set; }
        public long PriceGroupId { get; set; }
        public long PriceProjectionId { get; set; }
        public Guid GranularityGroupId { get; set; }
        public string? ProductId { get; set; }
        public required int YearMonth { get; set; }
        public string? Affiliate { get; set; }

        public decimal? PriorCost { get; set; }
        public decimal? ProjectionCost { get; set; }
        public decimal? RealCost { get; set; }

        public decimal? PriorPrice { get; set; }
        public decimal? ProjectionPrice { get; set; }
        public decimal? RealPrice { get; set; }

        public decimal? PriorDemand { get; set; }
        public decimal? ProjectionDemand { get; set; }
        public decimal? RealDemand { get; set; }

        public decimal? PriorRevenue { get; set; }
        public decimal? ProjectionRevenue { get; set; }
        public decimal? RealRevenue { get; set; }

        public decimal? PriorProfit { get; set; }
        public decimal? ProjectionProfit { get; set; }
        public decimal? RealProfit { get; set; }

        public decimal? PriorMargin { get; set; }
        public decimal? ProjectionMargin { get; set; }
        public decimal? RealMargin { get; set; }

        public bool Adopted { get; set; }
        public bool HasSuggestion { get; set; }
    }
}
