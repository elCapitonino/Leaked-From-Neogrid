from google.cloud import bigquery
import hashlib
from async_mongo import AsyncMongoConnect
from predimonitor_type import *
from logger import logger


class Search_linx_Vem():

    def __init__(self):
        print("desabilitado")
        # self.dbMongo = AsyncMongoConnect()
        # self.configFile = './app/sa-prd-pdc-bigquery-reader-01.json'

    async def search_linx_vem(self, products):
        return []
        ean_where = ""

        if (len(products.products) != 0 and products.products[0].ean != None):
            for i in products.products:
                ean_where += "codigo_produto = '" + i.ean + "' OR "

            ean_where = ean_where[:-4]

        client = bigquery.Client.from_service_account_json(self.configFile)

        if (ean_where != ""):
            ean_where = "({}) and ".format(ean_where)

        query = """
            SELECT
            FORMAT_DATE('%Y-%m-%d', data_da_transacao) AS issuance,
            codigo_da_loja,
            uf,
            cep,
            codigo_produto,
            descritivo_item,
            avg(preco_unitario) AS daily_price
            FROM `shared-data-platform-prd`.linx.fact_convenience_ticket_sellout_new
            WHERE {} data_da_transacao >= '{} 00:00:00' and data_da_transacao <= '{} 23:59:59'
            GROUP BY 1, 2, 3, 4, 5, 6;
            """.format(ean_where, products.start_date.strftime("%Y-%m-%d"), products.end_date.strftime("%Y-%m-%d"))

        query_job = client.query(query)  # Make an API request.

        full_result = []
        for ean in products.products:
            lista_ean = []
            for row in query_job.result():
                city = await self.dbMongo.get_city_search_by_postal_code(str(row[3]))
                lista_ean.append({'id': None,
                                'id_crawler': "266",
                                "product_name": ean.name,
                                "product_link": str(row[5]) + "_" + str(row[3]),
                                "product_ean": row[4],
                                "site_sku": 0,
                                "source": "Linx Vem",
                                "language": "pt-br",
                                "product_brand": None,
                                "id_product_normalized": None,
                                "trash_score": 0,
                                "crawler_date": row[0],
                                "sellers": [
                                {"seller_name": None,
                                    "prices":[{
                                        'price': str(row[6]),
                                        "price_currency": "BRL"
                                    }]
                                    }],
                                "product_local":
                                {'state': row[2],
                                    'city': self.validate_city(city)
                                    },
                                "product_manufacture_year": None,
                                "product_used_hours": None
                            })

            full_result.append({
                "name": ean.name,
                "results": lista_ean
            })

        return full_result


    def validate_city(self, city):
        return None
        if city == None or len(city) < 1:
            return None
        
        if 'logradouros' not in city[0] or city[0]['logradouros'] == None or len(city[0]['logradouros']) < 1:
            return None
        if 'cidade' in city[0]['logradouros'][0]:
            return city[0]['logradouros'][0]['cidade']
        return None

    def test_connection(self):
        return []
        client = bigquery.Client.from_service_account_json(self.configFile)

        query = """
                SELECT *
                FROM `shared-data-platform-prd.linx.fact_convenience_ticket_sellout_new` LIMIT 10
            """

        query_job = client.query(query)  # Make an API request.

        return list(query_job.result())
        




