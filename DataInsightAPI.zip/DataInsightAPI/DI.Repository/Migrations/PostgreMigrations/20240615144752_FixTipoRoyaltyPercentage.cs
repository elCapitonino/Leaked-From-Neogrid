﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DI.Repository.Migrations.PostgreMigrations
{
    /// <inheritdoc />
    public partial class FixTipoRoyaltyPercentage : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "RoyaltyPercentege",
                table: "MonthlySaleHistoryData",
                newName: "RoyaltyPercentage");

            migrationBuilder.RenameColumn(
                name: "RoyaltyPercentege",
                table: "MonthlyProjectionData",
                newName: "RoyaltyPercentage");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "RoyaltyPercentage",
                table: "MonthlySaleHistoryData",
                newName: "RoyaltyPercentege");

            migrationBuilder.RenameColumn(
                name: "RoyaltyPercentage",
                table: "MonthlyProjectionData",
                newName: "RoyaltyPercentege");
        }
    }
}
