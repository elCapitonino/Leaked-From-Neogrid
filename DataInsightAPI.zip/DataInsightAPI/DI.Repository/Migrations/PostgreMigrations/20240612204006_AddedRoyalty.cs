﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DI.Repository.Migrations.PostgreMigrations
{
    /// <inheritdoc />
    public partial class AddedRoyalty : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<decimal>(
                name: "RoyaltyPercentege",
                table: "MonthlyProjectionData",
                type: "numeric",
                nullable: false,
                defaultValue: 0m);

            migrationBuilder.AddColumn<decimal>(
                name: "RoyaltyReal",
                table: "MonthlyProjectionData",
                type: "numeric",
                nullable: false,
                defaultValue: 0m);

            migrationBuilder.AddColumn<decimal>(
                name: "Goal",
                table: "ImpactReportConfiguration",
                type: "numeric",
                nullable: false,
                defaultValue: 0m);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "RoyaltyPercentege",
                table: "MonthlyProjectionData");

            migrationBuilder.DropColumn(
                name: "RoyaltyReal",
                table: "MonthlyProjectionData");

            migrationBuilder.DropColumn(
                name: "Goal",
                table: "ImpactReportConfiguration");
        }
    }
}
