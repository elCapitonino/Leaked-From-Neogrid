﻿namespace Repository.Attributes
{
    [AttributeUsage(AttributeTargets.Class, Inherited = false, AllowMultiple = false)]
    sealed class DbContextTypeConfigurationAttribute : Attribute
    {
        public Type DbContextType { get; }

        public DbContextTypeConfigurationAttribute(Type dbContextType)
        {
            DbContextType = dbContextType;
        }
    }

}
