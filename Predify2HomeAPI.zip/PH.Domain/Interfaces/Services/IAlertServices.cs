﻿using PH.Domain.DTO;

namespace PH.Domain.Interfaces.Services
{
    public interface IAlertServices
    {
        Task<AlertMainDTO> Get(long idCompany, long idPriceGroup);
    }
}
