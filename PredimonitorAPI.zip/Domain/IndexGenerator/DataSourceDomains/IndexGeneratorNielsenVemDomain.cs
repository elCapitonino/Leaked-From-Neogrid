﻿using AutoMapper;
using Domain.IndexGenerator.DataSourceDomains.Interfaces;
using Domain.IndexGenerator.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Repository.Entity;
using Repository.UnitOfWork;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Caching.Memory;
using Domain.Status;
using Repository.Enums;
using MongoDB.Bson;

namespace Domain.IndexGenerator.DataSourceDomains
{
    public class IndexGeneratorNielsenVemDomain : IndexGeneratorBase, IIndexGeneratorNielsenVemDomain
    {
        private readonly ILogger<IndexGeneratorNielsenVemDomain> _logger;
        private readonly IUnitOfWork _uow;
        private readonly IMapper _mapper;
        private readonly IStatusDomain _statusDomain;

        public IndexGeneratorNielsenVemDomain(ILogger<IndexGeneratorNielsenVemDomain> logger, IUnitOfWork uow, IMapper mapper, IStatusDomain statusDomain)
            : base(statusDomain)
        {
            _logger = logger;
            _uow = uow;
            _mapper = mapper;
            _statusDomain = statusDomain;
        }

        public async Task GenerateIndexAsync(long companyId, int crawlerId, IEnumerable<MonitoringItemTags> monitoringItems, DateTime startDate, DateTime endDate, IEnumerable<string?> storeTypes, IEnumerable<string?> states, Guid? taskId, List<long> monitoringResultIdsDelete)
        {
            try
            {
                _logger.LogInformation($"Iniciando Geração de index da Nielsen Vem");
                var total = monitoringItems.Count();
                var count = 1;
                var lastMonitoringItem= 0l;
                UpdateStatus(taskId, CrawlerSourceType.NielsenVem, MonitoringItemResultsStatusType.Running, total, 0);
                _logger.LogInformation("Nielsen Vem - Total de monitoring items para serem processados: {Total}", total);
                List<ObjectId> listUpdateHash = new List<ObjectId>();
                EnsureAllMonitoringItemId(monitoringItems);
                try
                {
                    foreach (var monitoringItem in monitoringItems)
                    {
                        if (!monitoringItem.Eans.Any())
                            continue;

                        lastMonitoringItem = monitoringItem.MonitoringItemId;
                        var query = _uow.VemRepository.GetAll()
                        .Where(x => x.Date >= startDate && x.Date <= endDate && monitoringItem.Eans.Contains(x.Ean));

                        if (storeTypes.Any())
                            query = query.Where(x => storeTypes.Contains(x.MarketFormat));

                        if (states.Any())
                            query = query.Where(x => states.Contains(x.StateUf));

                        var products = await query
                            .Select(x => new
                            {
                                x.Id,
                                x.Ean,
                                x.StoreName,
                                x.Hash,
                                x.Category,
                                Seller = x.Retailer,
                                x.Brand,
                                UF = x.StateUf,
                            }).ToListAsync();

                        listUpdateHash.AddRange(products.Where(x => string.IsNullOrEmpty(x.Hash)).Select(x => x.Id));

                        var entities = products.GroupBy(x => $"{GetOrGenerateHash(x.Hash, $"{x.Ean}|{x.StoreName}|{x.UF}")}{x.Seller}{x.UF}{x.Brand}{x.Category}")
                            .Select(x => x.First())
                            .Select(x => new MonitoringItemResultsEntity()
                            {
                                Brand = x.Brand,
                                Category = x.Category,
                                Hash = GetOrGenerateHash(x.Hash, $"{x.Ean}|{x.StoreName}|{x.UF}"),
                                CompanyId = companyId,
                                CrawlerId = crawlerId,
                                MonitoringItemId = monitoringItem.MonitoringItemId,
                                Seller = x.Seller,
                                State = x.UF,
                            }).ToList();

                        _uow.MonitoringItemResults.AddRange(entities, true);
                        UpdateStatus(taskId, CrawlerSourceType.NielsenVem, MonitoringItemResultsStatusType.Running, total, count);
                        count++;
                    }

                    if (monitoringResultIdsDelete != null && monitoringResultIdsDelete.Any())
                    {
                        _uow.MonitoringItemResults.DeleteAll(monitoringResultIdsDelete);
                    }

                    if (listUpdateHash.Any())
                    {
                        var productsToUpdate = _uow.VemRepository
                                  .GetAll()
                                  .Where(x => listUpdateHash.Contains(x.Id))
                                  .ToList();

                        foreach (var product in productsToUpdate)
                        {
                            product.Hash = CalculateSHA256($"{product.Ean}|{product.StoreName}|{product.StateUf}");
                        }

                        _uow.VemRepository.Update(productsToUpdate, true);
                    }

                    _logger.LogInformation($"Finalizado Geração de index da Nielsen Vem");
                    UpdateStatus(taskId, CrawlerSourceType.NielsenVem, MonitoringItemResultsStatusType.Finished, total, --count);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error Search Monitoring Item {MonitoringItem} Nielsen Vem", lastMonitoringItem);
                    UpdateStatus(taskId, CrawlerSourceType.NielsenVem, MonitoringItemResultsStatusType.Error, total, count);
                }
               
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error Generate Index Nielsen Vem");
                throw;
            }
        }
    }
}
