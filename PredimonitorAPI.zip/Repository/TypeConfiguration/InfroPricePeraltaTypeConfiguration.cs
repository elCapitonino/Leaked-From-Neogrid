﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using MongoDB.EntityFrameworkCore.Extensions;
using Repository.Attributes;
using Repository.DbContexts;
using Repository.Entity;

namespace Repository.TypeConfiguration
{
    [DbContextTypeConfiguration(typeof(InfoPriceSaoJoaoDbContext))]
    public class InfroPricePeraltaTypeConfiguration : TypeConfigurationBase<InfoPricePeraltaEntity>, IEntityTypeConfiguration<InfoPricePeraltaEntity>
    {
        public override void Configure(EntityTypeBuilder<InfoPricePeraltaEntity> builder)
        {
            builder.ToTable("Peralta").ToCollection("Peralta");
        }
    }
}
