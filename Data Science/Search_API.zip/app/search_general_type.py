from pydantic import BaseModel
from typing import Optional
from typing import List
from datetime import datetime
from enum import Enum


class List_products(BaseModel):
    id: str
    name: str
    ean: Optional[str] = None
    ncm: Optional[str] = None
    model: Optional[str] = None
    brand: Optional[str] = None
    language: Optional[str] = None


class Search_Products(BaseModel):
    start_date: datetime = None
    end_date: datetime = None
    id_company: Optional[int] = None
    products: Optional[List[List_products]] = None
    idcrawlers: Optional[list] = None
    language: Optional[str] = None
