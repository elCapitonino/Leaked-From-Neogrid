﻿namespace DI.Repository.Entities
{
    public sealed class EnterpriseElasticityNewEntity : BaseNoKeyEntity
    {
        public long Enterprise_ElasticityNewId { get; set; }

        public long? CompanyId { get; set; }

        public decimal Elasticity { get; set; }

        public decimal? RawElasticity { get; set; }

        public decimal MeanQuantity { get; set; }

        public decimal MeanPrice { get; set; }

        public long EnterpriseAIConfigurationId { get; set; }

        public string? Granularity1 { get; set; }

        public string? Granularity2 { get; set; }

        public string? Granularity3 { get; set; }

        public string? Granularity4 { get; set; }

        public string? Granularity5 { get; set; }

        public string? Granularity6 { get; set; }

        public decimal RealMeanQuantity { get; set; }

        public decimal RealMeanPrice { get; set; }

        public string? Demand_CurveABC { get; set; }

        public string ElasticityResult
        {
            get
            {
                if (Elasticity < -1)
                    return "Elástica";
                else
                    return "Inelástica";
            }
        }
    }
}
