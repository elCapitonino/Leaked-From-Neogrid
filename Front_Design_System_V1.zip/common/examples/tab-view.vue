<template>
    <v-container class="px-10">
        {{ selectedTab }}
        <v-btn @click="selectedTab = 0"></v-btn>
        <prd-tabs :tabs="tabs" v-model="selectedTab" >
            <template v-slot:[`slider`]>
                <v-tabs-slider color="green"></v-tabs-slider>
            </template>
        </prd-tabs>



    </v-container>
</template>

<script>

import prdTabs from '../prd-tabs.vue'


export default {
    components:{
        prdTabs
    },
    name:'TabViewExample',
    data(){
        return {
            selectedTab: 0,
            tabs: [
                {
                    title: "Produtos", 
                    tooltipText: 'TXT_COMPARISON_TOOLTIP_PRODUCT'
                },
                {
                    title: "TXT_PRODUCT", 
                }
            ]
        }
    }
}
</script>