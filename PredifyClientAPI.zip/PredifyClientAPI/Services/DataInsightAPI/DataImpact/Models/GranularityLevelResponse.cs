﻿namespace PredifyClientAPI.Services.DataInsightAPI.DataImpact.Models
{
    public sealed class GranularityLevelResponse
    {
        public Guid Id { get; set; }

        public string? Description { get; set; }

        public required string FieldKey { get; set; }

        public string? FieldValue { get; set; }
    }
}
