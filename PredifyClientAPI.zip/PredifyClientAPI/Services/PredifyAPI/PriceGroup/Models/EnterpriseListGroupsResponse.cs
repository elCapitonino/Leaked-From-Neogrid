﻿using PredifyClientAPI.Services.PredifyAPI.PriceGroup.Enums;

namespace PredifyClientAPI.Services.PredifyAPI.PriceGroup.Models
{
    /// <summary>
    /// Modelo para resposta de consulta de grupos de precificação.
    /// </summary>
    public class EnterpriseListGroupsResponse
    {
        /// <summary>
        /// Identificador do grupo
        /// </summary>
        public long idEnterprisePriceGroups { get; set; }

        /// <summary>
        /// Identificador do treinamento de IA
        /// </summary>
        public long idAITraining { get; set; }

        /// <summary>
        /// Nome do Grupo de Precificação
        /// </summary>
        public string name { get; set; }

        /// <summary>
        /// data do ultimo calculo realizado
        /// </summary>
        public DateTime? calcDate { get; set; }

        /// <summary>
        /// Se as informações de precificação foram publicadas no TOTVS
        /// </summary>
        public bool published { get; set; }

        /// <summary>
        /// Data de publicação
        /// </summary>
        public DateTime? publishedDate { get; set; }

        /// <summary>
        /// Se o grupo podera ser recalculado ou não
        /// </summary>
        public bool? archive { get; set; }

        /// <summary>
        /// Propriedade para verficar é uma precificação gerada automaticamente
        /// </summary>
        public bool automatic { get; set; } = false;

        /// <summary>
        /// Lista de filtros
        /// </summary>
        public List<EnterpriseGroup_FilterResponse> Filters { get; set; }

        /// <summary>
        /// Indica se o grupo de precificação tem algum warnning
        /// </summary>
        public bool HasWarnings { get; set; }

        /// <summary>
        /// Propriedade que indica se esta calculando o grupo
        /// </summary>
        public bool IsCalculating { get; set; }

        /// <summary>
        /// Propriedade que indica se tem alguma projeção marcada para enviar para o ERP
        /// </summary>
        public bool IsProjectionPublished { get; set; }

        /// <summary>
        /// Nome do úsuario que aprovou essa precificação
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// Email do úsuario que aprovou essa precificação
        /// </summary>
        public string UserEmail { get; set; }
    }

    /// <summary>
    /// Modelo para inserção de filtros de um novo grupo de precificação.
    /// </summary>
    public class EnterpriseGroup_FilterResponse
    {
        /// <summary>
        /// Identificador dos filtros
        /// </summary>
        public long idEnterprisePriceGroup_Filter { get; set; }

        /// <summary>
        /// valor do filtro
        /// </summary>
        public string value { get; set; }

        /// <summary>
        /// Opção para deletar o filtro
        /// </summary>
        public bool isDeleted { get; set; }

        /// <summary>
        /// Identificador para qual filtro a empresa ira usar
        /// </summary>
        public long idEnterprisePriceGroups_DefaultFilter { get; set; }

        /// <summary>
        /// nome de qual filtro esta sendo usado (Ex: Categoria , Segmento , Subsegmento e etc.)
        /// </summary>
        public string fieldName { get; set; }

        /// <summary>
        /// se a propriedade for verdeira significa que o filtro é obrigatorio
        /// </summary>
        public bool preSelect { get; set; }

        /// <summary>
        /// enum para dizer qual coluna é para filtrar o valor
        /// </summary>
        public EnterprisePriceGroups_FilterType dbField { get; set; }
    }
}
