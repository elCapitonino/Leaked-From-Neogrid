"""
Script para gerar relatório comparando custos entre filiais da VEM (3026)
bem como compará-los com os dados do Predimonitor de custo.
"""

# %%
import asyncio
import json
import os
import sys
from datetime import timedelta

import aiohttp
import numpy as np
import pandas as pd
import requests
from dotenv import load_dotenv
from unidecode import unidecode

sys.path.append("../")
from geral import config

load_dotenv()

MAX_RETRIES = 2
# %%

conn = config.getDadosAWSSession("producao")

# %%

latest_date = conn.execute(
    "SELECT MAX(Issuance) FROM Enterprise_Sales_History WHERE IdCompany = 3026 AND IsDeletado = 0 AND IsLastPrice = 1"
).fetchone()[0]

# %%

stmt = """
SELECT
    Product, Affiliate, Description, AffiliateCity, AffiliateState,
    PackageDescription AS EAN, AffiliateName, PbCost, Category1Id AS cost_date, Category2Id AS true_cost
FROM Enterprise_Sales_History
WHERE IdCompany = 3026 AND IsDeletado = 0
AND IsLastPrice = 1 AND Issuance > ?
"""

start_date = latest_date - timedelta(days=30)
df = pd.read_sql(stmt, conn, params=(start_date,))
df.head()

# %%

df["AffiliateCity"] = df["AffiliateCity"].str.strip()
df["AffiliateCity"] = df["AffiliateCity"].str.title()

# %%

print(df.shape)
df = df.query("cost_date >= '2024-09-01'")
print(df.shape)

# %%

# XXX o que fazer quando não há custo próprio?
df_quartile = (
    df.loc[df["true_cost"] == "1", :]
    .groupby(["Product", "AffiliateCity", "AffiliateState"])[["PbCost"]]
    .agg(
        func=None,
        count=pd.NamedAgg(column="PbCost", aggfunc="count"),
        cost_q1=pd.NamedAgg(column="PbCost", aggfunc=lambda x: np.quantile(x, 0.25)),
        cost_q2=pd.NamedAgg(column="PbCost", aggfunc=lambda x: np.quantile(x, 0.50)),
    )
    .reset_index()
)

df_quartile_uf = (
    df.loc[df["true_cost"] == "0", :]
    .groupby(["Product", "AffiliateCity", "AffiliateState"])[["PbCost"]]
    .agg(
        func=None,
        count_uf=pd.NamedAgg(column="PbCost", aggfunc="count"),
        cost_q1_uf=pd.NamedAgg(column="PbCost", aggfunc=lambda x: np.quantile(x, 0.25)),
        cost_q2_uf=pd.NamedAgg(column="PbCost", aggfunc=lambda x: np.quantile(x, 0.50)),
    )
    .reset_index()
)

df_quartile.head()
# %%

df_m = pd.merge(
    df, df_quartile, how="left", on=["Product", "AffiliateCity", "AffiliateState"]
)
# df_m = pd.merge(
#     df_m, df_quartile_uf, how="left", on=["Product", "AffiliateCity", "AffiliateState"]
# )
# df_m["cost_q1"] = df_m["cost_q1"].fillna(df_m["cost_q1_uf"])
# df_m["cost_q2"] = df_m["cost_q2"].fillna(df_m["cost_q2_uf"])
df_m["ic_q1"] = df_m["PbCost"] / df_m["cost_q1"]
df_m["ic_q2"] = df_m["PbCost"] / df_m["cost_q2"]
df_m.head()

# %%

df_m["ic_q1"].describe()

# %%

df_m.to_excel("cost_ic.xlsx")
# %%

df_report = df_m[
    [
        "cost_q1",
        "AffiliateCity",
        "AffiliateState",
        "Affiliate",
        "AffiliateName",
        "Description",
        "PbCost",
        "ic_q1",
        "true_cost",
    ]
].rename(
    columns={
        "cost_q1": "Custo da cidade (quartil inferior)",
        "AffiliateCity": "Cidade",
        "AffiliateState": "UF",
        "Affiliate": "ZBRM",
        "AffiliateName": "Nome da loja",
        "Description": "Nome do produto",
        "PbCost": "Valor de compra da loja",
        "ic_q1": "Índice de competitividade sobre quartil inferior (%)",
        "true_cost": "Custo próprio",
    }
)

df_report.head()

# %%

df_report.to_excel("cost_ic_report.xlsx", index=False)

# %%


BASE_URL = "https://web-service.predify.me"
# BASE_URL = "https://predimonitor-api.predify.me/api/DynamicFilter/GetResult"
# BASE_URL = "https://pre-prod-service.predify.me"

# %%
headers = {"Content-Type": "application/x-www-form-urlencoded"}
res_access = requests.get(
    f"{BASE_URL}/token",
    data={
        "grant_type": "password",
        "username": os.getenv("EMAIL"),
        "password": os.getenv("PASSWORD"),
        "client_id": "multiverso-emp-angularjs-app",
    },
    headers=headers,
    timeout=10,
)

token = res_access.json()["access_token"]

# %%

headers = {"Authorization": f"Bearer {token}"}

# %%

stmt = """
SELECT [IdMonitoringItem]
      ,[Ean_Gtin]
  FROM [dbo].[MonitoringItem]
  WHERE IdCompany = 3026
  AND IsDeleted = 0
"""

monitoring_items = conn.execute(stmt).fetchall()

# %%


def _extract_predimonitor_info(x, ean):
    out = {}
    out["AffiliateState"] = x["state"].upper()
    out["AffiliateCity"] = unidecode(x["city"]).title()
    out["monitoringItemId"] = x["monitoringItemId"]
    out["predimonitor_price"] = x["price"]
    out["product_link"] = x["productLink"]
    out["crawler_date"] = x["crawlerDate"]
    out["EAN"] = ean
    return out


async def request_predimonitor(json_request, ean):
    async with aiohttp.ClientSession() as session:
        async with session.post(
            "https://predimonitor-api.predify.me/api/DynamicFilter/GetResult",
            headers=headers,
            json=json_request,
            timeout=120,
        ) as res:

            if res.status != 200:
                raise ValueError(
                    f"request failed with status {res.status}:\n{await res.text()}"
                )

            res_json = await res.json()

    all_results = []

    for res_item in res_json:
        price_results = res_item["priceResults"]

        results = list(map(lambda x: _extract_predimonitor_info(x, ean), price_results))
        all_results.extend(results)

    return all_results


async def consume_request_queue(queue, output):
    while not queue.empty():
        retries, item = await queue.get()
        if retries >= MAX_RETRIES:
            print(f"ERROR: item {item} reached maximum retries, skipping")
            continue

        print(f"requesting {item} [retry {retries}]")
        request_json = {
            "productNames": [],
            "monitoringItemIds": [item[0]],
            "categories": [],
            "sellers": [],
            "brands": [],
            "origins": [],
            "states": [],
            "years": [],
            "startDate": start_date.strftime("%Y-%m-%d"),
            "endDate": latest_date.strftime("%Y-%m-%d"),
            "hourMeter": {"min": 0, "max": 0},
            "isCost": True,
            "companyId": 3026,
        }
        try:
            result = await request_predimonitor(request_json, item[1])
        except Exception as exc:
            print(f"Predimonitor failed in retry {retries}:\n{exc}")
            await queue.put((retries + 1, item))

        output.extend(result)


# %%


async def search_predimonitor(
    monitoring_items, concurrency: int = 5, max_queue_size: int = 64
):
    queue = asyncio.Queue()
    tasks = set()
    out = []

    for _ in range(concurrency):
        task = asyncio.create_task(consume_request_queue(queue, out))
        task.add_done_callback(tasks.discard)
        tasks.add(task)

    for item in monitoring_items:
        await queue.put((0, item))
        if not tasks:
            for _ in range(concurrency):
                task = asyncio.create_task(consume_request_queue(queue, out))
                task.add_done_callback(tasks.discard)
                tasks.add(task)

        while queue.qsize() >= max_queue_size:
            await asyncio.sleep(0.1)

    await asyncio.gather(*tasks)
    return out


# %%

predimonitor_results = await search_predimonitor(monitoring_items[:10])

# %%

with open("predimonitor_data.json", "w", encoding="utf-8") as f:
    json.dump(predimonitor_results, f)

# %%

df_predi = pd.DataFrame(predimonitor_results)
df_predi = (
    df_predi.groupby(["AffiliateCity", "AffiliateState", "EAN"])[["predimonitor_price"]]
    .agg(
        func=None,
        pred_count=pd.NamedAgg(column="predimonitor_price", aggfunc="count"),
        pred_min=pd.NamedAgg(column="predimonitor_price", aggfunc=min),
        pred_q1=pd.NamedAgg(
            column="predimonitor_price", aggfunc=lambda x: np.quantile(x, 0.25)
        ),
        pred_q2=pd.NamedAgg(
            column="predimonitor_price", aggfunc=lambda x: np.quantile(x, 0.50)
        ),
        pred_mean=pd.NamedAgg(column="predimonitor_price", aggfunc=np.mean),
        pred_max=pd.NamedAgg(column="predimonitor_price", aggfunc=max),
    )
    .reset_index()
)
df_predi.head()

# %%

df_predi_m = pd.merge(
    df_m, df_predi, on=["AffiliateState", "AffiliateCity", "EAN"], how="left"
)
df_predi_m = df_predi_m.assign(pred_ic_q1=lambda x: x.PbCost / x.pred_q1)
df_predi_m = df_predi_m.assign(pred_ic_min=lambda x: x.PbCost / x.pred_min)
df_predi_m = df_predi_m.assign(pred_ic_q2=lambda x: x.PbCost / x.pred_q2)
df_predi_m = df_predi_m.assign(pred_ic_mean=lambda x: x.PbCost / x.pred_mean)
df_predi_m.head()

# %%

df_predi_m.query("pred_q1 > 0").sample(20)
# %%

df_predi_m["pred_ic_q1"].describe()

# %%

df_predi_m.to_excel("cost_ic_predi.xlsx")
# %%

df_predi_report = df_predi_m[
    [
        "cost_q1",
        "pred_q1",
        "AffiliateCity",
        "AffiliateState",
        "Affiliate",
        "AffiliateName",
        "Description",
        "PbCost",
        "ic_q1",
        "pred_ic_q1",
        "true_cost",
        "count",
        "pred_count",
    ]
].rename(
    columns={
        "cost_q1": "Custo da cidade (quartil inferior)",
        "pred_q1": "Preço no Predimonitor de custo (quartil inferior)",
        "AffiliateCity": "Cidade",
        "AffiliateState": "UF",
        "Affiliate": "ZBRM",
        "AffiliateName": "Nome da loja",
        "Description": "Nome do produto",
        "PbCost": "Valor de compra da loja",
        "ic_q1": "Índice de competitividade (IC, %) - BR MANIA",
        "pred_ic_q1": "IC (%) - Predimonitor - Quartil inf.",
        "pred_ic_min": "IC (%) - Predimonitor - Preço mínimo",
        "pred_ic_mean": "IC (%) - Predimonitor - Preço médio",
        "pred_ic_q2": "IC (%) - Predimonitor - Preço mediano",
        "true_cost": "Custo próprio",
        "count": "Número de lojas",
        "pred_count": "Número de registros Predimonitor",
    }
)

df_predi_report.head()

# %%

df_predi_report.to_excel("cost_ic_pred_report.xlsx", index=False)
# %%
