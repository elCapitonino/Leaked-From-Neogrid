import scripts.adoption as adoption
import scripts.report as report
import src.insert_data as insert_data
import src.report_config as report_config
from src.projections import get_next_published_pricegroups


def run_report_pipeline(
    pg_conn, pg_metadata, sql_engine, sql_metadata, id_company: int, price_group: int
):
    """
    report function to run the entire script
    :param idCompany: the idCompany to run the script for
    :param PriceGroup: the PriceGroup to run the script for
    """

    Granularity = report_config.get_granularity(pg_conn, pg_metadata, id_company)
    price_var = report_config.get_price_var(pg_conn, id_company)

    sql_raw_conn = sql_engine.raw_connection()
    with sql_engine.connect() as sql_conn:
        period_df = get_next_published_pricegroups(
            sql_conn=sql_conn,
            sql_metadata=sql_metadata,
            pg_conn=pg_conn,
            pg_metadata=pg_metadata,
            price_group=price_group,
            id_company=id_company,
        )
    Published_Date = period_df["PublishedDate"].iloc[0]

    df_report, df_applied_prices = report.generate_report(
        sql_raw_conn,
        id_company,
        price_group,
        Published_Date,
        Granularity,
        price_var,
        period_df,
    )
    df_report = adoption.apply_adoption_rules(
        sql_raw_conn,
        pg_conn,
        pg_metadata,
        df_report,
        id_company,
        price_group,
        Granularity,
        df_applied_prices,
    )

    df_report = report.recalculate_metrics(df_report)

    df_report = report.prepare_report(
        pg_conn, pg_metadata, df_report, id_company, Granularity, Published_Date
    )

    insert_data.insert_data_into_postgresql(
        pg_conn, pg_metadata, df_report, id_company, price_group
    )
    sql_raw_conn.close()
