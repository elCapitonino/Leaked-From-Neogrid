﻿using Repository.DbContexts;
using Repository.Entity;
using Repository.EntityRepository.Bases;

namespace Repository.EntityRepository
{
    public class MonitoringProductMarketResultRepository : GenericRepository<MonitoringProductMarketResultEntity, long>, IMonitoringProductMarketResultRepository
    {
        public MonitoringProductMarketResultRepository(ApplicationDbContext dbContext) : base(dbContext)
        {

        }
        public static string DbContextName => nameof(ApplicationDbContext);
    }
}
