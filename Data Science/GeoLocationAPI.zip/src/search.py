from typing import Any, Dict, Optional, Protocol, Tuple

from async_lru import alru_cache
from motor.core import AgnosticClient

from models.internal import AddressInfo, AddressInfoCoordinates, Coordinate
from models.request import InputAddressInfo
from models.response import GeosearchResult
from src.env import config
from src.exceptions import ExternalAPIError, MaxRetriesExceeded, NoCoordinateFound
from src.external_search.enum import ExternalSearchStatus
from src.logger import logger
from src.mongo import fetch_address_info, upsert_address_info

MAX_RETRIES = 2


class RemoteSearcher(Protocol):
    async def __call__(
        self, address: str
    ) -> Tuple[
        Optional[Coordinate], Optional[Dict[str, Any]], ExternalSearchStatus
    ]: ...


class GeoSearcher:
    def __init__(
        self, mongo_conn: AgnosticClient, remote_searcher: RemoteSearcher, mock: bool
    ) -> None:
        self.conn = mongo_conn
        self.remote_searcher = remote_searcher
        self.__mock = mock

    async def _upsert_address_info(self, address_info: AddressInfo):
        if self.__mock:
            return
        await upsert_address_info(self.conn, address_info)

    async def __call__(
        self, input_address_info: InputAddressInfo, use_cache: bool = True
    ) -> tuple[GeosearchResult, Optional[AddressInfoCoordinates]]:
        logger.debug(
            "searching coordinate of address << %s >>", input_address_info.id_consulta
        )
        address_info = AddressInfo(
            **input_address_info.model_dump(),
            error=False,
            retry_count=0,
        )

        doc = {}

        if use_cache:
            doc = await fetch_address_info(self.conn, input_address_info.id_consulta)

        if doc:
            logger.debug(
                "found address << %s >> in mongo", input_address_info.id_consulta
            )
            address_info = AddressInfo.model_validate(doc)
            if address_info.error and address_info.retry_count >= MAX_RETRIES:
                logger.warning(
                    "skipping address << %s >> due to too many retries with error",
                    input_address_info.id_consulta,
                )
                raise MaxRetriesExceeded()

            if not address_info.error:
                address_info_coord = AddressInfoCoordinates.model_validate(doc)
                result = GeosearchResult(
                    coordinates=address_info_coord.coordinates.to_mongo_geopoint(),
                    address_dict=address_info_coord.address_dict,
                )
                return result, None

        coord, address_dict, status = await self.remote_searcher(
            address_info.id_consulta
        )
        if status is ExternalSearchStatus.HTTP_ERROR:
            address_info.error = True
            await self._upsert_address_info(address_info)
            raise ExternalAPIError()

        if (
            coord is None
            or address_dict is None
            or status is ExternalSearchStatus.NO_ADDRESS_ERROR
        ):
            address_info.retry_count += 1
            address_info.error = True
            await self._upsert_address_info(address_info)
            raise NoCoordinateFound()

        address_info_coord = None
        if not self.__mock:
            address_info_coord = AddressInfoCoordinates(
                **address_info.model_dump(),
                coordinates=coord,
                address_dict=address_dict,
            )
            address_info_coord.error = False

        result = GeosearchResult(
            coordinates=coord.to_mongo_geopoint(),
            address_dict=address_dict,
        )

        return result, address_info_coord


@alru_cache(
    maxsize=int(config.get("CACHE_MAXSIZE", "256")),
    ttl=int(config.get("CACHE_TTL", "240")),
)
async def _cache_search(
    searcher: GeoSearcher,
    input_address_info: InputAddressInfo,
    use_cache: bool = False,
) -> tuple[GeosearchResult, Optional[AddressInfoCoordinates]]:
    return await searcher(input_address_info=input_address_info, use_cache=use_cache)


async def search(
    searcher: GeoSearcher,
    input_address_info: InputAddressInfo,
    use_cache: bool = False,
) -> tuple[GeosearchResult, Optional[AddressInfoCoordinates]]:
    if use_cache:
        result, address_info_coord = await _cache_search(
            searcher=searcher,
            input_address_info=input_address_info,
            use_cache=use_cache,
        )
    else:
        result, address_info_coord = await searcher(
            input_address_info=input_address_info, use_cache=use_cache
        )

    return result, address_info_coord
