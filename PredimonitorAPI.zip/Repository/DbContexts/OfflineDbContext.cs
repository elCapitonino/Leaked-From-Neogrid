﻿using Microsoft.EntityFrameworkCore;
using MongoDB.Driver;
using Repository.DbContexts.Bases;

namespace Repository.DbContexts
{
    public class OfflineDbContext : MongoDbContextBase
    {

        public OfflineDbContext(DbContextOptions<OfflineDbContext> options, IMongoClient mongoClient) : base(options, mongoClient)
        {

        }
        public override string DbContextName => nameof(OfflineDbContext);
    }
}
