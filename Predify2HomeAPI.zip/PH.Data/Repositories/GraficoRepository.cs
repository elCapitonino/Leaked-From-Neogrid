﻿using Dapper;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using PH.Domain.DTO;
using PH.Domain.DTO.Graficos;
using PH.Domain.Interfaces.Repositories;
using System.Data;
using System.Data.SqlClient;

namespace PH.Data.Repositories
{
    public class GraficoRepository : IGraficoRepository
    {
        private string _sQLConnectionString;
        private readonly IConfiguration _configuration;

        public GraficoRepository(IConfiguration configuration)
        {
            _configuration = configuration;
            _sQLConnectionString = _configuration.GetConnectionString("SQLConnectionString");
        }

        public async Task<List<GraficoDTO>> Get(string? loja, string? curva, string? categoria)
        {
            List<GraficoDTO> list = new List<GraficoDTO>();
            list.Add(await GerarGraficoUnidades(loja, curva, categoria));
            list.Add(await GerarGraficoPorcentagemProdutos(loja, curva, categoria));
            list.Add(await GerarGraficoMilharesReais(loja, curva, categoria));
            list.Add(await GerarGraficoMargemPorcentagem(loja, curva, categoria));

            return list;
        }

        private async Task<GraficoDTO> GerarGraficoMargemPorcentagem(string? loja, string? curva, string? categoria)
        {
            GraficoDTO graficoDTO = new GraficoDTO();
            graficoDTO.YAxisTitle = "Margem %";

            try
            {
                IDbConnection connection = CreateSqlConnection();
                var parametros = new { FILIAL = loja };
                var result = connection.Query<GraficoNumeroProdutos>("VEM_Busca_Margem_Media_Produto", parametros, commandType: CommandType.StoredProcedure, commandTimeout: 600);
                GerarGraficoProcedure(graficoDTO, result.ToList());
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return graficoDTO;
        }

        private async Task<GraficoDTO> GerarGraficoMilharesReais(string? loja, string? curva, string? categoria)
        {
            GraficoDTO graficoDTO = new GraficoDTO();
            graficoDTO.YAxisTitle = "Receita $";

            try
            {
                IDbConnection connection = CreateSqlConnection();
                var parametros = new { FILIAL = loja };
                var result = connection.Query<GraficoNumeroProdutos>("VEM_Busca_Receita_Produto", parametros, commandType: CommandType.StoredProcedure, commandTimeout: 600);
                GerarGraficoProcedure(graficoDTO, result.ToList());
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return graficoDTO;
        }

        private async Task<GraficoDTO> GerarGraficoPorcentagemProdutos(string? loja, string? curva, string? categoria)
        {
            GraficoDTO graficoDTO = new GraficoDTO();
            graficoDTO.YAxisTitle = "% Produtos";

            try
            {
                IDbConnection connection = CreateSqlConnection();
                var parametros = new { FILIAL = loja };
                var result = connection.Query<GraficoNumeroProdutos>("VEM_Busca_Porcentagem_Produto", parametros, commandType: CommandType.StoredProcedure, commandTimeout: 600);
                GerarGraficoProcedure(graficoDTO, result.ToList());
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return graficoDTO;
        }

        private async Task<GraficoDTO> GerarGraficoUnidades(string? loja, string? curva, string? categoria)
        {
            GraficoDTO graficoDTO = new GraficoDTO();
            graficoDTO.YAxisTitle = "Unidade Produtos";

            try
            {
                IDbConnection connection = CreateSqlConnection();
                var parametros = new { FILIAL = loja };
                var result = connection.Query<GraficoNumeroProdutos>("VEM_Busca_Numero_Produto_Por_Loja", parametros, commandType: CommandType.StoredProcedure, commandTimeout: 600);
                GerarGraficoProcedure(graficoDTO, result.ToList());
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return graficoDTO;
        }

        public async Task<List<GraficoReceitaDTO>> GetGraficoReceita(long idCompany, string? loja)
        {
            List<GraficoReceitaDTO> graficoDTO = new List<GraficoReceitaDTO>();

            try
            {
                IDbConnection connection = CreateSqlConnection();
                var parametros = new { IDCOMPANY = idCompany , FILIAL = loja };
                var result = connection.Query<GraficoHomeReceita>("Home_Grafico_Receita", parametros, commandType: CommandType.StoredProcedure, commandTimeout: 60000);

                graficoDTO.AddRange(result.Select(x => new GraficoReceitaDTO()
                { 
                    Date = new DateTime(x.Ano ,x.Mes, x.Dia),
                    Value = x.Value
                }));

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return graficoDTO;
        }

        private IDbConnection CreateSqlConnection() => new SqlConnection(_sQLConnectionString);

        private void GerarGraficoProcedure(GraficoDTO graficoDTO, List<GraficoNumeroProdutos> result)
        {
            double[] naoAderiram = new double[12];
            double[] aderiram = new double[12];
            double[] aprovados = new double[12];

            foreach (var item in result)
            {
                // - 7 é porque começa em julho
                naoAderiram[item.Mes - 7] = Math.Round(item.RejectionSuggested, 2);

                // - 7 é porque começa em julho
                aderiram[item.Mes - 7] = Math.Round(item.AdoptionSuggested, 2);

                // - 7 é porque começa em julho
                aprovados[item.Mes - 7] = Math.Round(item.Approved, 2);
            }


            graficoDTO.Data.Add(new GraficoDataDTO()
            {
                Name = "Preços sugeridos",
                Color = "#3C5CA7",
                Data = aprovados.ToList()
            });

            graficoDTO.Data.Add(new GraficoDataDTO()
            {
                Name = "Preços utilizados pelo PDV",
                Color = "#1D8527",
                Data = aderiram.ToList()
            }); ;

            graficoDTO.Data.Add(new GraficoDataDTO()
            {
                Name = "Preços não utilizados pelo PDV",
                Color = "#B00020",
                Data = naoAderiram.ToList()
            });
        }
    }
}