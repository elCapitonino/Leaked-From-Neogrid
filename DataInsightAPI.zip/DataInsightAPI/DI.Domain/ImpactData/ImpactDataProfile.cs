﻿using AutoMapper;
using DI.Domain.ImpactData.Models;
using DI.Repository.Entities;

namespace DI.Domain.ImpactData
{
    public class ImpactDataProfile : Profile
    {
        public ImpactDataProfile()
        {
            CreateMap<GranularityGroupEntity, GranularityGroupResponse>();
            CreateMap<GranularityLevelEntity, GranularityLevelResponse>();
            CreateMap<MonthlyImpactDataEntity, MonthlyImpactDataResponse>();
            CreateMap<ProjectionImpactDataEntity, ProjectionImpactDataResponse>();
        }
    }
}
