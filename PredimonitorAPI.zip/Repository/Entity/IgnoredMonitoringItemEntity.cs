﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Entity
{
    public class IgnoredMonitoringItemEntity : BaseEntity
    {
        public string ProductLink { get; set; }

        public string ProductSeller { get; set; }

        public bool IsDeleted { get; set; }

        public long MonitoringItemId { get; set; }
        public virtual MonitoringItemEntity MonitoringItem { get; set; }

    }
}
