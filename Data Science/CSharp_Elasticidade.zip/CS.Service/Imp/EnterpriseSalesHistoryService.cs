﻿using CS.Domain.Domain;
using CS.Domain.DTO;
using CS.Domain.Interfaces.Repositories;
using CS.Domain.Interfaces.Services;
using Microsoft.Extensions.Logging;

namespace CS.Service.Imp
{
    public class EnterpriseSalesHistoryService : IEnterpriseSalesHistoryService
    {
        private readonly IEnterpriseSalesHistoryRepository _repository;
        private readonly ILogger<EnterpriseSalesHistoryService> _log;

        public EnterpriseSalesHistoryService(IEnterpriseSalesHistoryRepository repository, 
                                             ILogger<EnterpriseSalesHistoryService> log)
        {
            _repository = repository;
            _log = log;
        }

        public async Task<List<EnterpriseElasticit>> SimpleElasticSearch(SimpleSearchDTO searchFilter)
        {
            try
            {
                _log.LogInformation("Buscando ESH");
                var enterpriseSalesHistoriesList =  await _repository.GetESHWithSimpleFilters(searchFilter);
                List<EnterpriseElasticit> listOfResults = new List<EnterpriseElasticit>();

                foreach (var products in enterpriseSalesHistoriesList.GroupBy(c=> c.Product))
                {
                    foreach (IGrouping<string, EnterpriseSalesHistoryElasticSimpleCalculator> affiliate in products.GroupBy(c=> c.Affiliate))
                    {
                        ElasticitCalc elasticitCalc = new ElasticitCalc();
                        EnterpriseElasticit? result = elasticitCalc.Calculate(enterpriseSalesHistoriesList.ToList(), searchFilter.referenceEndDate, products.Key, affiliate.Key);
                        listOfResults.Add(result);
                    }
                }

                return listOfResults;
            }
            catch (Exception ex)
            {
                _log.LogError(ex, ex.Message);
                throw;
            }
        }
    }
}
