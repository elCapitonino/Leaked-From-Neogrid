﻿using Repository.Entity;

namespace Domain.Models
{
    public sealed class RuleGroupResponse
    {
        public long Id { get; set; }

        public string Name { get; set; } = string.Empty;

        public long CompanyId { get; set; }

        public int NumberOrder { get; set; }

        public bool IsAllProducts { get; set; }

        public bool IsActive { get; set; }

        public string? AllowAbcCurve { get; set; }

        public int Elasticity { get; set; }

        public IEnumerable<RuleResponse> Rules { get; set; }

        public IEnumerable<RuleGroupFilterResponse> Filters { get; set; }
    }

    public class RuleGroupFilterResponse
    {
        public long? Id { get; set; }
        public string? Value { get; set; }
    }
}
