﻿using Services.SearchAPI.Models;

namespace Domain.Models
{
    public class AppsettingsOptions
    {
        public string ConnectionString { get; set; }
        public AppsettingsAuthOptions Auth { get; set; } = new();
        public AppsettingsCorsOptions Cors { get; set; } = new();
        public MongoDBSettingsOptions MongoDBSettings { get; set; } = new();
        public IndexConfigurationOptions IndexConfiguration { get; set; } = new();
        public SearchAPIOptions SearchAPISettings { get; set; } = new();
        public DatabricksSettingsOptions DatabricksSettings { get; set; } = new();
    }
    public class AppsettingsAuthOptions
    {
        public string Host { get; set; }
    }
    public class AppsettingsCorsOptions
    {
        public string[] AllowedOrigins { get; set; }
    }

    public class MongoDBSettingsOptions
    {
        public string ConnectionString { get; set; }
        public MongoDbSettingsDatabaseOptions Databases { get; set; }
    }

    public class MongoDbSettingsDatabaseOptions
    {
        public string Horus { get; set; }
        public string InfroPriceSaoJoao { get; set; }
        public string Normalizer { get; set; }
        public string SmarketCompetitor { get; set; }
        public string Nielsen { get; set; }
        public string Neogrid { get; set; }
        public string Linx { get; set; }
        public string Offline { get; set; }
        public string Scantech { get; set; }

    }

    public class IndexConfigurationOptions
    {
        public int PeriodyInMonthToIndexing { get; set; }
    }

    public class DatabricksSettingsOptions
    {
        public string? ConnectionString { get; set; }
        public string? Schema { get; set; }
    }
}