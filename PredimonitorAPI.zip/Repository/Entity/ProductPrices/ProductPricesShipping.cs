﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;

namespace Repository.Entity.ProductPrices
{
    public class ProductPricesShipping
    {
        [BsonElement("origin")]
        public string? Origin { get; set; }

        [BsonElement("destination")]
        public string? Destination { get; set; }

        [BsonElement("name")]
        public string? Name { get; set; }

        [BsonElement("price")]
        public decimal? Price { get; set; }

        [BsonElement("price_currency")]
        public string? PriceCurrency { get; set; }

        [BsonElement("date_max")]
        public DateTime? DateMax { get; set; }

        [BsonElement("date_min")]
        public DateTime? DateMin { get; set; }
    }
}
