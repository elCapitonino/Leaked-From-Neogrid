using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson.Serialization.Options;
using MongoDB.Driver.GeoJsonObjectModel;
using Repository.TypeConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Repository.Entity
{
    public class HorusProductsEntity : BaseMongoEntity
    {

        [BsonElement("brand")]
        public string? Brand { get; set; }

        [BsonElement("brand_group")]
        public string? BrandGroup { get; set; }

        [BsonElement("category")]
        public string? Category { get; set; }

        [BsonElement("city")]
        public string? City { get; set; }

        [BsonElement("cnpj")]
        public string? Cnpj { get; set; }

        [BsonElement("date")]
        public DateTime? Date { get; set; }

        [BsonElement("description")]
        public string? Description { get; set; }

        [BsonElement("ean")]
        public string? Ean { get; set; }

        [BsonElement("uf")]
        public string? Uf { get; set; }

        [BsonElement("price")]
        public decimal? Price { get; set; }

        [BsonElement("product_brand")]
        public string? ProductBrand { get; set; }

        [BsonElement("format_market")]
        public string? FormatMarket { get; set; }

        [BsonElement("zipcode")]
        public string? Zipcode { get; set; }

        [BsonElement("address")]
        public string? Address { get; set; }

        [BsonElement("coordinates")]
        public GeoJson2DGeographicCoordinatesWrapper? Coordinates { get; set; }

        [BsonElement("import_date")]
        public DateTime? ImportDate { get; set; }

        [BsonElement("hash")]
        public string? Hash { get; set; }
    }
}
