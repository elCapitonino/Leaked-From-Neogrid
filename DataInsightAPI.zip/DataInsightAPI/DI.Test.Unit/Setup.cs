﻿using DI.Repository.Contexts;
using DI.Repository.Interfaces;
using DI.Repository.UnitOfWork;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace DI.Test.Unit
{
    public class Setup : Xunit.Di.Setup
    {

        protected override void Configure()
        {
            ConfigureAppConfiguration((hostingContext, config) =>
            {

                bool reloadOnChange = hostingContext.Configuration.GetValue("hostBuilder:reloadConfigOnChange", true);
                if (hostingContext.HostingEnvironment.IsDevelopment())
                    config.AddUserSecrets<Setup>(true, reloadOnChange);

            });

            ConfigureServices((context, services) =>
            {
                var configurationBuilder = new ConfigurationBuilder();
                var path = Path.Combine(Directory.GetCurrentDirectory(), "appsettings.json");
                configurationBuilder.AddJsonFile(path, false);

                var root = configurationBuilder.Build();
                var connectionStringSqlServe = root.GetSection("ConnectionStrings").GetSection("SqlConnection").Value;
                var connectionStringNpgServe = root.GetSection("ConnectionStrings").GetSection("PostgreConnection").Value;

                services.AddDbContext<SqlContext>(options => options.UseSqlServer(connectionStringSqlServe), ServiceLifetime.Transient);
                services.AddDbContext<PostgreContext>(options => options.UseNpgsql(connectionStringNpgServe), ServiceLifetime.Transient);

                services.AddTransient<IUnitOfWork, UnitOfWork>();
            });
        }
    }
}