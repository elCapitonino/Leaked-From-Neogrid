﻿using AutoMapper;
using Domain.MonitoringResult.Models;
using Repository.Entity;
using Repository.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.MonitoringResult.Converters
{
    public class ResultFilterResponseToMonitoringProductMarketResultItemConverter : ITypeConverter<ResultFilterResponse, MonitoringProductMarketResultItemEntity>
    {
        public MonitoringProductMarketResultItemEntity Convert(ResultFilterResponse source, MonitoringProductMarketResultItemEntity destination, ResolutionContext context)
        {
            var dest = new MonitoringProductMarketResultItemEntity()
            {
                ProductName = source.ProductName,
                ProductLink = source.ProductLink,
                Brand = source.ProductBrand,
                SellerName = source.SellerName,
                SellerLink = source.ProductLink,
                CrawlerName = source.Marketplace,
                CrawlerId = (int)source.IdCrawler,
                Price = source.Price,
                LocalCity = source.City,
                LocalState = source.State,
                ZipCode = null,
                RefDate = source.CrawlerDate.Value,
                OnRequest = source.On_request ?? false,
                QuantityInstallments = source.QuantityInstallment,
                IsManual = false,
                DeflatedValue = source.DeflatedValue,
                IsDeleted = false,
                CreateDate = DateTime.Now,
                UpdateDate = DateTime.Now,
            };

            return dest;
        }
    }
}
