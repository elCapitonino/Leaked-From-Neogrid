"""
Módulo para logging. Utilize o objeto logger.
"""

import logging
import os

import uvicorn


if os.environ.get("DEBUG"):
    LOG_FORMAT = "{asctime} - {name} - {levelname} [{module}.{funcName}] - {message}"
else:
    LOG_FORMAT = "{asctime} - {name} - {levelname} - {message}"


logger = logging.getLogger("uvicorn.access")
logger.setLevel(logging.DEBUG if os.environ.get("DEBUG") else logging.INFO)
console_formatter = uvicorn.logging.ColourizedFormatter(LOG_FORMAT, style="{", use_colors=False)
logger.handlers[0].setFormatter(console_formatter)
