# TODO

[ ] pegar relatório diretamente do _endpoint_, sem necessidade de gerar arquivos manualmente
