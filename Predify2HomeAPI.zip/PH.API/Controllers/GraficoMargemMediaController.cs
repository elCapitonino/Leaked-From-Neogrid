﻿using Microsoft.AspNetCore.Mvc;
using PH.Domain.Interfaces.Services;
using PH.Service.Services;

namespace PH.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GraficoMargemMediaController : ControllerBase
    {
        private readonly ILogger<GraficoMargemMediaController> _logger;
        private readonly IGraficoMargemMediaServices _graficoMargemMeiaServices;

        public GraficoMargemMediaController(ILogger<GraficoMargemMediaController> logger,
                                             IGraficoMargemMediaServices GraficoMargemMediaServices)
        {
            _logger = logger;
            _graficoMargemMeiaServices = GraficoMargemMediaServices;
        }

        [HttpGet]
        [Route("GetGraficoMargem")]
        public async Task<IActionResult> GetGraficoMargem(string loja)
        {
            _logger.LogInformation($"Controller: Buscando dados do grafico de margem media da loja {loja}");

            try
            {
                var result = await _graficoMargemMeiaServices.GetGraficoMargem(loja);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Controller: Erro ao buscar dados do grafico de margem media da loja {loja}. {ex.Message}");
                return StatusCode(500, $"Erro ao buscar dados do grafico de margem media da loja {loja}.");
            }
        }
    }
}
