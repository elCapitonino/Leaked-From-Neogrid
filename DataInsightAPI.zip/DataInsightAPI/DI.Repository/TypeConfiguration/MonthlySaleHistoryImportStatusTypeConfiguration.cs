﻿using DI.Repository.Attributes;
using DI.Repository.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DI.Repository.TypeConfiguration
{
    [UsePostgreContext]
    public sealed class MonthlySaleHistoryImportStatusTypeConfiguration : TypeConfigurationBase<MonthlySaleHistoryImportStatusEntity>, IEntityTypeConfiguration<MonthlySaleHistoryImportStatusEntity>
    {
        public override void Configure(EntityTypeBuilder<MonthlySaleHistoryImportStatusEntity> builder)
        {
            ConfigureTableName(builder, "MonthlySaleHistoryImportStatus");
            builder.HasKey(x => x.Id);
            builder.Property(x => x.Id).ValueGeneratedOnAdd().HasDefaultValueSql("uuid_generate_v4()").IsRequired();
            builder.Property(x => x.CompanyId).IsRequired();
            builder.Property(x => x.Status).HasMaxLength(64).IsRequired();
        }
    }
}
