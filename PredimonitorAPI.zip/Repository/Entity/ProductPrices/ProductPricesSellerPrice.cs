﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;
using Repository.Enums;

namespace Repository.Entity.ProductPrices
{
    public class ProductPricesSellerPrice
    {
        [BsonElement("price")]
        public decimal? Price { get; set; }

        [BsonElement("price_from")]
        public decimal? PriceFrom { get; set; }

        [BsonElement("price_payment_type")]
        public string? PricePaymentType { get; set; }

        [BsonElement("price_unit_type")]
        public PriceUnitType? PriceUnitType { get; set; }

        [BsonElement("price_currency")]
        public string? PriceCurrency { get; set; }

        [BsonElement("cashback_value")]
        public decimal? CashbackValue { get; set; }

        [BsonElement("cashback_is_percent")]
        public bool? CashbackIsPercent { get; set; }

        [BsonElement("discount_value")]
        public decimal? DiscountValue { get; set; }

        [BsonElement("discount_is_percent")]
        public bool? DiscountIsPercent { get; set; }

        [BsonIgnoreIfNull]
        [BsonElement("installments")]
        public List<ProductPricesSellerPriceInstallment>? Installments { get; set; }

        [BsonElement("price_unit")]
        public decimal? PriceUnit { get; set; }

        [BsonElement("price_unit_from")]
        public decimal? PriceUnitFrom { get; set; }

        [BsonElement("price_unit_quantity")]
        public int? PriceUnitQuantity { get; set; }

        [BsonElement("price_pack")]
        public decimal? PricePack { get; set; }

        [BsonElement("price_pack_from")]
        public decimal? PricePackFrom { get; set; }

        [BsonElement("price_description")]
        public string? PriceDescription { get; set; }

        [BsonElement("is_pack")]
        public bool? IsPack { get; set; }

        [BsonElement("price_tax_st")]
        public decimal? PriceTaxST { get; set; }

        [BsonElement("is_inclused_st")]
        public bool? IsInclusedST { get; set; }

        [BsonElement("price_tax_ipi")]
        public decimal? PriceTaxIPI { get; set; }

        [BsonElement("is_inclused_ipi")]
        public bool? IsInclusedIPI { get; set; }

        [BsonElement("on_request")]
        public bool? OnRequest { get; set; }
    }
}
