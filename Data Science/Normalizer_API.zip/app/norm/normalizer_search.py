from norm.memorycache import MemoryCache
from norm.processing import Processing
from norm.extraction import Extraction


class NormalizerSearch:
    def __init__(self):
        self.memory = MemoryCache()
        self.prep = Processing()
        self.extr = Extraction()

    def norm_run_Search(self, texto: str) -> str:
        texto = texto.split(' ')
        list = []
        for i in texto:
            texto_processado = self.prep.run(i)
            texto_processado = texto_processado.replace(' ', '')
            list.append(texto_processado)

        list = ','.join(list)
        list = list.replace(',', ' ')
        # print(list)
        return list
