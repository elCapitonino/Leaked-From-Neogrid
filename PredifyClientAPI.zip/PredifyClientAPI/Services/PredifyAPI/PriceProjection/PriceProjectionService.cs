﻿using Newtonsoft.Json;
using PredifyClientAPI.Services.PredifyAPI.Models;
using PredifyClientAPI.Services.PredifyAPI.PriceProjection.Models;

namespace PredifyClientAPI.Services.PredifyAPI.PriceProjection
{
    public class PriceProjectionService : IPriceProjectionService
    {
        private readonly HttpClient _client;

        public PriceProjectionService(HttpClient client)
        {
            _client = client;
        }

        public async Task<GeneralResponse<List<EnterprisePriceProjectionExportResponse>>> ProjectionToSendERP(long idEnterprisePriceGroup)
        {
            var response = await _client.GetAsync($"/api/v2/Enterprise/PriceProjection/ProjectionToSendERP?idEnterprisePriceGroup={idEnterprisePriceGroup}");
            var content = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
                return JsonConvert.DeserializeObject<GeneralResponse<List<EnterprisePriceProjectionExportResponse>>>(content);
            else if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                throw new UnauthorizedAccessException();

            throw new Exception(content);
        }
    }
}
