﻿using PredifyClientAPI.Services.PredifyAPI.Models;
using PredifyClientAPI.Services.PredifyAPI.SaleHistory.Models;

namespace PredifyClientAPI.Services.PredifyAPI.SaleHistory
{
    public interface ISaleHistoryService
    {
        Task<AnswerModel<string>> PostSaleHistory(EnterpriseSalesHistoryAddRequest request);
    }
}
