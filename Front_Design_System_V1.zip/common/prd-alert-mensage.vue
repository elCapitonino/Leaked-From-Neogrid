
<template>
    <div>
        <v-alert dense outlined :type="type">
            {{text}}
        </v-alert>
    </div>
</template>

<script>
export default {
    name:"alertMensageComponent",
    data(){
        return{}
    },
    props:{
        text: {
            require: true,
            type: Boolean
        },
        type: {
            requere: true,
            type: String
        }
    }
}
</script>