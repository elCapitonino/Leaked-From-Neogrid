﻿using AutoMapper;
using Domain.Exceptions;
using Domain.Models;
using Microsoft.EntityFrameworkCore;
using Repository.UnitOfWork;
using Services.PredifyAPI;

namespace Domain.Rule
{
    public class RuleDomain : IRuleDomain
    {
        private readonly IUnitOfWork _uow;
        private readonly IMapper _mapper;
        private readonly PredifyAPIUserManager _predifyAPIUserManager;

        public RuleDomain(PredifyAPIUserManager predifyAPIUserManager, IUnitOfWork uow, IMapper mapper)
        {
            _uow = uow;
            _mapper = mapper;
            _predifyAPIUserManager = predifyAPIUserManager;
        }

        public async Task<List<RuleResponse>> GetByGroupId(long ruleGroupId)
        {
            long? companyId = (await _uow.RuleGroupRepository.GetAll().FirstOrDefaultAsync(x => x.RuleId == ruleGroupId))?.IdEmpresa;
            
            if (companyId == null)
                throw new NotFoundException("Não há grupo de regra com este id");

            if (!await _predifyAPIUserManager.AccessService.UserHasAccess(companyId.Value))
                throw new UnauthorizedAccessException($"Acesso não autorizado a empresa {companyId}");

            var entities = _uow.RuleRepository.GetAll()
                .Where(x => x.IdRule == ruleGroupId && x.IsDeletado == false)
                .Include(x => x.Values.Where(y => y.IsDeletado == false));

            var responses = _mapper.Map<List<RuleResponse>>(entities);

            return responses;
        }
    }
}
