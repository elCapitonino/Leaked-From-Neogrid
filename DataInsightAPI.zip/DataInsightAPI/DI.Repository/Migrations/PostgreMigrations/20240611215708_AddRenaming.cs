﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DI.Repository.Migrations.PostgreMigrations
{
    /// <inheritdoc />
    public partial class AddRenaming : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "QuantityPricing",
                table: "MonthlyProjectionData",
                newName: "PricingCount");

            migrationBuilder.RenameColumn(
                name: "QuantityNotAdopted",
                table: "MonthlyProjectionData",
                newName: "NotAdoptionCount");

            migrationBuilder.RenameColumn(
                name: "QuantityAdopted",
                table: "MonthlyProjectionData",
                newName: "AdoptionCount");

            migrationBuilder.RenameColumn(
                name: "IdCompany",
                table: "GranularityGroup",
                newName: "CompanyId");

            migrationBuilder.AlterColumn<string>(
                name: "Description",
                table: "GranularityGroup",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "character varying(64)",
                oldMaxLength: 64);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "PricingCount",
                table: "MonthlyProjectionData",
                newName: "QuantityPricing");

            migrationBuilder.RenameColumn(
                name: "NotAdoptionCount",
                table: "MonthlyProjectionData",
                newName: "QuantityNotAdopted");

            migrationBuilder.RenameColumn(
                name: "AdoptionCount",
                table: "MonthlyProjectionData",
                newName: "QuantityAdopted");

            migrationBuilder.RenameColumn(
                name: "CompanyId",
                table: "GranularityGroup",
                newName: "IdCompany");

            migrationBuilder.AlterColumn<string>(
                name: "Description",
                table: "GranularityGroup",
                type: "character varying(64)",
                maxLength: 64,
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "character varying(64)",
                oldMaxLength: 64,
                oldNullable: true);
        }
    }
}
