﻿using CS.Domain.Domain;

namespace CS.Cross
{
    public static class EnterpriseSalesHistoryProperties
    {
        public static List<string> GetDataProperties()
        {
            Type type = typeof(EnterpriseSalesHistory);
            List<string> properties = new List<string>();

            foreach (var prop in type.GetProperties())
            {
                properties.Add(prop.Name);
            }

            return properties;
        }
    }
}
