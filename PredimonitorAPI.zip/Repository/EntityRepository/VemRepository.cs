﻿using Repository.DbContexts;
using Repository.Entity;
using Repository.EntityRepository.Bases;

namespace Repository.EntityRepository
{
    public class VemRepository : GenericMongoRepository<VemEntity>, IVemRepository
    {
        public VemRepository(NielsenDbContext dbContext) : base(dbContext)
        {
        }
        public static string DbContextName => nameof(NielsenDbContext);
    }
}
