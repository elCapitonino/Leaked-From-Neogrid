﻿using DI.API.Utils.Cache;
using DI.Domain.ImpactGraph;
using DI.Domain.ImpactGraph.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Swashbuckle.AspNetCore.Annotations;

namespace DI.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class ImpactGraphController : ControllerBase
    {
        private readonly ILogger<ImpactGraphController> _logger;
        private readonly IImpactGraphDomain _domain;
        private readonly ICacheService _cacheService;

        public ImpactGraphController(ILogger<ImpactGraphController> logger, IImpactGraphDomain domain, IMemoryCache memoryCache, ICacheService cacheService)
        {
            _logger = logger;
            _domain = domain;
            _cacheService = cacheService;
        }

        [HttpPost]
        [Route("GetAdoption")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(AdoptionGraphResponseModel))]
        [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(string))]
        [SwaggerOperation(Summary = "Returns adoption graph data", Description = "Returns adoption graph data")]
        public IActionResult GetAdoptionImpactGraph([FromBody] GraphRequestModel request)
        {
            var cacheKey = request.GenerateCacheKey("AdoptionGraph");

            try
            {
                var responseModel = _cacheService.Get<AdoptionGraphResponseModel>(cacheKey);
                if (responseModel == null)
                {
                    responseModel = _domain.GetAdoptionImpactGraph(request.CompanyId, request.AffiliateIds);

                    _cacheService.Set(cacheKey, responseModel);
                }
                _logger.LogInformation("Adoption graph data retrieved successfully.");
                return Ok(responseModel);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving adoption graph data");
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPost]
        [Route("GetDemand")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(DemandGraphResponseModel))]
        [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(string))]
        [SwaggerOperation(Summary = "Returns demand graph data", Description = "Returns demand graph data")]
        public IActionResult GetDemandImpactGraph([FromBody] GraphRequestModel request)
        {
            var cacheKey = request.GenerateCacheKey("DemandGraph");
            try
            {
                var responseModel = _cacheService.Get<DemandGraphResponseModel>(cacheKey);
                if (responseModel == null)
                {
                    responseModel = _domain.GetDemandImpactGraph(request.CompanyId, request.AffiliateIds);

                    _cacheService.Set(cacheKey, responseModel);
                }
                _logger.LogInformation("Demand graph data retrieved successfully.");
                return Ok(responseModel);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving demand graph data");
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPost]
        [Route("GetMargin")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(MarginGraphResponseModel))]
        [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(string))]
        [SwaggerOperation(Summary = "Returns margin graph data", Description = "Returns margin graph data")]
        public IActionResult GetMarginImpactGraph([FromBody] GraphRequestModel request)
        {
            var cacheKey = request.GenerateCacheKey("MarginGraph");
            try
            {
                var responseModel = _cacheService.Get<MarginGraphResponseModel>(cacheKey);
                if (responseModel == null)
                {
                    responseModel = _domain.GetMarginImpactGraph(request.CompanyId, request.AffiliateIds);

                    _cacheService.Set(cacheKey, responseModel);
                }
                _logger.LogInformation("Margin graph data retrieved successfully.");
                return Ok(responseModel);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving margin graph data");
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPost]
        [Route("GetRevenue")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(RevenueGraphResponseModel))]
        [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(string))]
        [SwaggerOperation(Summary = "Returns revenue graph data", Description = "Returns revenue graph data")]
        public IActionResult GetRevenueImpactGraph([FromBody] GraphRequestModel request)
        {
            var cacheKey = request.GenerateCacheKey("RevenueGraph");
            try
            {
                var responseModel = _cacheService.Get<RevenueGraphResponseModel>(cacheKey);
                if (responseModel == null)
                {
                    responseModel = _domain.GetRevenueImpactGraph(request.CompanyId, request.AffiliateIds);

                    _cacheService.Set(cacheKey, responseModel);
                }
                _logger.LogInformation("Revenue graph data retrieved successfully.");
                return Ok(responseModel);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving revenue graph data");
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPost]
        [Route("GetProfit")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(ProfitGraphResponseModel))]
        [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(string))]
        [SwaggerOperation(Summary = "Returns profit graph data", Description = "Returns profit graph data")]
        public IActionResult GetProfitImpactGraph([FromBody] GraphRequestModel request)
        {
            var cacheKey = request.GenerateCacheKey("ProfitGraph");
            try
            {
                var responseModel = _cacheService.Get<ProfitGraphResponseModel>(cacheKey);
                if (responseModel == null)
                {
                    responseModel = _domain.GetProfitImpactGraph(request.CompanyId, request.AffiliateIds);

                    _cacheService.Set(cacheKey, responseModel);
                }
                _logger.LogInformation("Profit graph data retrieved successfully.");
                return Ok(responseModel);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving profit graph data");
                return StatusCode(500, ex.Message);
            }
        }
    }
}
