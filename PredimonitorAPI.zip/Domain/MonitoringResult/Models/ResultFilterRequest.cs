﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.MonitoringResult.Models
{
    public sealed class ResultFilterRequest : DynamicFilterRequest
    {
        /// <summary>
        /// Inicio do periodo a se considerar os resultados
        /// </summary>
        public DateTime StartDate { get; set; }

        /// <summary>
        /// Fim do periodo a se considerar os resultados
        /// </summary>
        public DateTime EndDate { get; set; }

        /// <summary>
        /// Modelo para definir intervalo de horas de uso de veiculos inicialmente ou qualquer outro maquinário
        /// </summary>
        public ResultFilterHourmeterRangeRequest? HourMeter { get; set; }

        /// <summary>
        /// Modelo para definir o intervalo de quilometragem de veiculos
        /// </summary>
        public ResultFilterKilometerRangeRequest? Kilometers { get; set; }

        /// <summary>
        /// Indica se a consulta é marcada apenas preços considerados custos pela empresa
        /// </summary>
        public bool IsCost { get; set; }

        public long CompanyId { get; set; }
    }

    public sealed class ResultFilterHourmeterRangeRequest
    {
        public int? Min { get; set; }
        public int? Max { get; set; }
    }

    public sealed class ResultFilterKilometerRangeRequest
    {
        public int? Min { get; set; }
        public int? Max { get; set; }
    }
}
