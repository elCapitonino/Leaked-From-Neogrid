﻿namespace Services.PredifyAPI.Access
{
    public interface IAccessService
    {
        Task<bool> UserHasAccess(long companyId);
    }
}
