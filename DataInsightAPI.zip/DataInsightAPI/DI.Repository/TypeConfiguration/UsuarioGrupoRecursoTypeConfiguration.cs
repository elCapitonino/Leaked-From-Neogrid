﻿using DI.Repository.Attributes;
using DI.Repository.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DI.Repository.TypeConfiguration
{
    [UseSQLContext]
    public sealed class UsuarioGrupoRecursoTypeConfiguration : IEntityTypeConfiguration<UsuarioGrupoRecursoEntity>
    {
        public void Configure(EntityTypeBuilder<UsuarioGrupoRecursoEntity> builder)
        {
            builder.ToTable("Usuario_GrupoRecurso");

            builder.HasKey(x => x.IdUsuario_GrupoRecurso);

            builder.Ignore(x => x.Id);
            builder.Ignore(x => x.UpdatedDate);
            builder.Ignore(x => x.CreatedDate);
            builder.Property(x => x.IdUsuario).IsRequired();
            builder.Property(x => x.IdGrupoRecurso).IsRequired();
            builder.Property(x => x.IsDeleted).IsRequired().HasColumnName("IsDeletado");
            builder.Property(x => x.DataHoraCriacao).IsRequired();
            builder.Property(x => x.DataHoraUltimaAlteracao).IsRequired();

            builder.HasOne(x => x.GrupoRecurso)
                   .WithMany(gr => gr.UsuarioGrupoRecursos)
                   .HasForeignKey(x => x.IdGrupoRecurso);
        }
    }
}
