﻿using System.ComponentModel.DataAnnotations;

namespace PredifyClientAPI.Services.PredifyAPI.Models
{
    public class GeneralAccess
    {
        /// <summary>
        /// Id de identificação da Empresa.
        /// </summary>
        [Required]
        public long IdCompany { get; set; }
    }

    /// <summary>
    /// Modelo básico para consulta com paginação.
    /// </summary>
    public class GeneralAccessPagination : GeneralAccess
    {
        /// <summary>
        /// Qual página ira ser consultada.
        /// </summary>
        public int Page { get; set; }

        /// <summary>
        /// Registros por página.
        /// </summary>
        public int RecordsPerPage { get; set; }

        public void Validate()
        {
            if (Page < 1) throw new Exception("Page need to be greater than 0");
            if (RecordsPerPage < 0) throw new Exception("RecordsPerPage need to be greater than 0");
        }
    }
}
