﻿using Domain.IndexGenerator.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.IndexGenerator.DataSourceDomains.Interfaces
{
    public interface IIndexGeneratorNielsenVemDomain
    {
        Task GenerateIndexAsync(long companyId, int crawlerId, IEnumerable<MonitoringItemTags> monitoringItems, DateTime startDate, DateTime endDate, IEnumerable<string?> cnpjs, IEnumerable<string?> states, Guid? taskId, List<long> monitoringResultIdsDelete);
    }
}
