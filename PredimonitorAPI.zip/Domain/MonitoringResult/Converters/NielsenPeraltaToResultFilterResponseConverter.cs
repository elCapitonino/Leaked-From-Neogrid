﻿using AutoMapper;
using Domain.MonitoringResult.Models;
using Repository.Entity;
using Repository.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.MonitoringResult.Converters
{
    public class NielsenPeraltaToResultFilterResponseConverter : ITypeConverter<PeraltaEntity, ResultFilterResponse>
    {
        public ResultFilterResponse Convert(PeraltaEntity source, ResultFilterResponse destination, ResolutionContext context)
        {
            var dest = new ResultFilterResponse()
            {
                ProductName = source.ProductDescription,
                ProductLink = source.Hash,
                ProductBrand = source.Brand,
                SellerName = source.StoreName,
                Marketplace = (string)context.Items["CrawlerName"],
                Price = source.WeeklyPrice,
                PaymentType = "-",
                Price_unit_type = PriceUnitType.UNITARIO,
                CrawlerDate = source.Date,
                Disregarded = false,              
                IdCrawler = (int)context.Items["CrawlerId"],
                City = source.City,               
                On_request = false,               
                State = source.StateUf,
                Coordinates = new PrediMonitorProduct_CoordinatesModel()
            };

            return dest;
        }
    }
}
