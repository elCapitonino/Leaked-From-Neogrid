﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Net.Http.Headers;
using PH.Domain.Interfaces.Services;
using PH.Service.Services;

namespace PH.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProdutosTabeladosController : ControllerBase
    {
        private readonly ILogger<ProdutosTabeladosController> _logger;
        private readonly IProdutosTabeladosServices _produtosTabeladosServices;

        public ProdutosTabeladosController(ILogger<ProdutosTabeladosController> logger,
                         IProdutosTabeladosServices ProdutosTabeladosServices)
        {
            _logger = logger;
            _produtosTabeladosServices = ProdutosTabeladosServices;
        }

        [HttpPost("Import")]
        [DisableRequestSizeLimit]
        [RequestFormLimits(MultipartBodyLengthLimit = int.MaxValue, ValueLengthLimit = int.MaxValue)]
        public async Task<IActionResult> FileImport(IFormFile file)
        {
            _logger.LogInformation("Iniciando import de arquivo");

            try
            {
                if (file.Length > 0)
                {
                    if (file.FileName.Contains("xlsx") || file.FileName.Contains("csv"))
                    {
                        await _produtosTabeladosServices.ImportTabelados(file);
                    }
                    else
                    {
                        return BadRequest("Formato de arquivo inválido");
                    }
                }
                else
                {
                    return BadRequest("Arquivo inválido");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Erro ao importar arquivo. Erro {ex.Message}");
                return StatusCode(500, "Erro ao importar arquivo");
            }

            return StatusCode(201, "Sucesso ao salvar arquivo no banco");
        }

        [HttpGet]
        public async Task<IActionResult> GetProdutosTabelados(long idCompany, string state, string affiliate)
        {
            _logger.LogInformation("Controller: Buscando todos os produtos tabelados");

            try
            {
                var produtosTabelados = await _produtosTabeladosServices.GetProdutosTabelados(idCompany, state, affiliate);
                return Ok(produtosTabelados);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Controller: Erro ao buscar todos os produtos tabelados. {ex.Message}");
                return StatusCode(500, "Erro ao buscar todos os produtos tabelados");
            }
        }
    }
}
