﻿using Azure.Core;
using Domain.BackgroundTasks.Models;
using Domain.Exceptions;
using Domain.Status;
using Domain.Status.Models;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.BackgroundTasks
{
    public class IndexGeneratorStatusService : IHostedService, IDisposable
    {
        private readonly ILogger<IndexGeneratorStatusService> _logger;
        private readonly IServiceProvider _services;
        private readonly IndexGeneratorStatusServiceOptions _options;
        private Timer? _timer = null;

        public IndexGeneratorStatusService(ILogger<IndexGeneratorStatusService> logger, IServiceProvider services, IOptions<IndexGeneratorStatusServiceOptions> options)
        {
            _logger = logger;
            _services = services;
            _options = options.Value;
        }

        public Task StartAsync(CancellationToken stoppingToken)
        {
            if (!_options.Enabled)
            {
                _logger.LogInformation("IndexGeneratorStatusService is disabled.");
                return Task.CompletedTask;
            }

            _logger.LogInformation("Timed Hosted Service running.");

            _timer = new Timer(DoWork, null, TimeSpan.Zero, _options.Interval);

            return Task.CompletedTask;
        }

        private async void DoWork(object? state)
        {
            using var scope = _services.CreateScope();
            var statusDomain = scope.ServiceProvider.GetRequiredService<IStatusDomain>();
            var taskRunnings = statusDomain.GetTaskRunnings();
            if (taskRunnings != null)
            {
                foreach (var taskRunning in taskRunnings)
                {
                    try
                    {
                        var executions = statusDomain.GetTaskStatus(taskRunning.TaskId.Value);
                        if (executions != null)
                        {
                            StringBuilder sb = new StringBuilder();
                            foreach (var execution in executions.Values)
                            {
                                sb.AppendLine($"{execution.Status} - SourceType: {execution.SourceType} - Message: {execution.Message}");
                            }
                            if (sb.Length > 0)
                                _logger.LogInformation(sb.ToString());

                            var executionValues = executions.Values.ToList();
                            var overallStatus = DetermineOverallStatus(executionValues);

                            if (overallStatus != Repository.Enums.MonitoringItemResultsStatusType.None)
                            {
                                statusDomain.AddOrUpdate(new MonitoringItemResultsStatusRequest()
                                {
                                    TaskId = taskRunning.TaskId,
                                    Step = taskRunning.CurrentStep,
                                    Status = overallStatus,
                                    Message = sb.ToString(),
                                    CompanyId = taskRunning.CompanyId,
                                });

                                if (overallStatus == Repository.Enums.MonitoringItemResultsStatusType.Finished || overallStatus == Repository.Enums.MonitoringItemResultsStatusType.Error)
                                {
                                    RemoveDynamicFilterCache(scope, taskRunning.CompanyId);

                                    _logger.LogInformation($"TaskId: {taskRunning.TaskId} - Overall Status: {overallStatus}");

                                    statusDomain.RemoveCache(taskRunning.TaskId.Value);
                                }
                            }
                        }
                    }
                    catch (NotFoundException ex)
                    {
                        statusDomain.AddOrUpdate(new MonitoringItemResultsStatusRequest()
                        {
                            TaskId = taskRunning.TaskId,
                            Step = taskRunning.CurrentStep,
                            Status = Repository.Enums.MonitoringItemResultsStatusType.Error,
                            Message = "A tarefa não conseguiu finalizar com sucesso!",
                            CompanyId = taskRunning.CompanyId,
                        });
                        _logger.LogError(ex, "Erro ao processar TaskId: {TaskId}, execução não está no cache", taskRunning.TaskId);
                    }
                    catch
                    {
                        _logger.LogError("Erro ao processar TaskId: {TaskId}", taskRunning.TaskId);
                    }
                }
            }
        }



        public Task StopAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation("Timed Hosted Service is stopping.");

            _timer?.Change(Timeout.Infinite, 0);

            return Task.CompletedTask;
        }

        public void Dispose()
        {
            _timer?.Dispose();
        }
        private void RemoveDynamicFilterCache(IServiceScope scope, long companyId)
        {
            var memoryCache = scope.ServiceProvider.GetRequiredService<IMemoryCache>();
            var key = $"DynamicFilter_{companyId}_" +
                       $"null_" +
                       $"null_" +
                       $"null_" +
                       $"null_" +
                       $"null_" +
                       $"null_" +
                       $"null_" +
                       $"False";
            memoryCache.Remove(key);
            memoryCache.Remove(key.Replace("False", "True"));
        }
        private bool IsAllExecutionsFinishedOrError(IEnumerable<StatusCacheModel> executions)
        {
            return executions.All(x => x.Status == Repository.Enums.MonitoringItemResultsStatusType.Finished ||
                                       x.Status == Repository.Enums.MonitoringItemResultsStatusType.Error);
        }
        private bool IsAllExecutionsError(IEnumerable<StatusCacheModel> executions)
        {
            return executions.All(x => x.Status == Repository.Enums.MonitoringItemResultsStatusType.Error);
        }
        private Repository.Enums.MonitoringItemResultsStatusType DetermineOverallStatus(IEnumerable<StatusCacheModel> executions)
        {
            if (!executions.Any())
                return Repository.Enums.MonitoringItemResultsStatusType.None;

            if (IsAllExecutionsFinishedOrError(executions))
                return Repository.Enums.MonitoringItemResultsStatusType.Finished;

            if (IsAllExecutionsError(executions))
                return Repository.Enums.MonitoringItemResultsStatusType.Error;

            return Repository.Enums.MonitoringItemResultsStatusType.Running;


        }
    }
}
