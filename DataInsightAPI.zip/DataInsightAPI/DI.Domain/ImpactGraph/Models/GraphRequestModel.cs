﻿namespace DI.Domain.ImpactGraph.Models
{
    public class GraphRequestModel
    {
        public long CompanyId { get; set; }
        public List<string> AffiliateIds { get; set; }

        public string GenerateCacheKey(string graphType)
        {
            return $"{graphType}_{CompanyId}_{string.Join(",", AffiliateIds.OrderBy(x => x))}";
        }
    }
}
