using Domain.ProductPrice.Models;

namespace Domain.ProductPrice;

public interface IProductPriceDomain
{
    Task<List<IgnoredProductPriceResponse>> GetIgnoredPrices(int companyId, string productId);
    bool IgnoreProductPrice(int companyId, string priceId);
    Task<bool> UnignoreProductPrice(int companyId, string priceId);
}