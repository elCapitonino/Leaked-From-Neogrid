from http import server
from pymongo import MongoClient

# conectar mongo

controle = 0

Server = {
    "host": '172.31.46.114:27017',
    "port": '27017',
    "user": 'normalizer_api',
    "password": 'zG#46!y6kW!RNl^'
}