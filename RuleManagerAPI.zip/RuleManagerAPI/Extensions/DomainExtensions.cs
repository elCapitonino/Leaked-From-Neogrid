﻿
using Domain.Copilot;
using Domain.Filters;
using Domain.Rule;
using Domain.RuleGroup;

namespace RuleManagerAPI.Extensions
{
    public static class DomainExtensions
    {
        public static void AddDomain(this IServiceCollection services)
        {
            services.AddScoped<ICopilotDomain, CopilotDomain>();
            services.AddScoped<IRuleGroupDomain, RuleGroupDomain>();
            services.AddScoped<IRuleDomain, RuleDomain>();
            services.AddScoped<IFilterDomain, FilterDomain>();
        }
    }
}
