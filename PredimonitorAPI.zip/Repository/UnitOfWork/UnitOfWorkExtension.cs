﻿using MongoDB.Driver;
using Repository.DbContexts;
using Repository.DbContexts.Bases;
using Repository.EntityRepository;
using System.Reflection;
using System.Runtime.CompilerServices;

namespace Repository.UnitOfWork
{
    public static class UnitOfWorkExtension
    {
        public static void InitializeRepository(this IUnitOfWork unitOfWork,IMongoClient mongoClient, DatabricsDbContext databricksDbContext, params IMultiDbContext[] dbContexts)
        {
            foreach (var property in unitOfWork.GetType().GetProperties())
            {
                try
                {                
                    var implementation = Assembly.GetExecutingAssembly()
                        .DefinedTypes
                        .FirstOrDefault(p => property.PropertyType.IsAssignableFrom(p) && !p.IsInterface);
                    if (implementation != null)
                    {
                        var type = unitOfWork.GetType();

                        var backingField = type
                          .GetFields(BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static)
                          .FirstOrDefault(field =>
                            field.Attributes.HasFlag(FieldAttributes.Private) &&
                            field.Attributes.HasFlag(FieldAttributes.InitOnly) &&
                            field.CustomAttributes.Any(attr => attr.AttributeType == typeof(CompilerGeneratedAttribute)) &&
                            (field.DeclaringType == property.DeclaringType) &&
                            field.FieldType.IsAssignableFrom(property.PropertyType) &&
                            field.Name.StartsWith($"<{property.Name}>")
                          );

                        if (property.PropertyType.GetInterfaces().Any(x => x.Name.StartsWith("IGenericRepository")))
                        {
                            PropertyInfo propertyInfo = implementation.GetProperty("DbContextName", BindingFlags.Static | BindingFlags.Public);

                            if (propertyInfo == null)
                            {
                                throw new Exception($"Não foi possível encontrar o PropertyInfo");
                            }

                            var dbContextName = propertyInfo.GetValue(property).ToString();
                            var dbContext = dbContexts.FirstOrDefault(p => p.DbContextName == dbContextName);

                            if (dbContext == null)
                            {
                                throw new Exception($"Não foi possível encontrar o DbContext {dbContextName}");
                            }

                            backingField.SetValue(unitOfWork, Activator.CreateInstance(implementation, new object[] { dbContext }));
                        }
                        else if (property.PropertyType.GetInterfaces().Any(x => x.Name.StartsWith("IGenericMongoRepository")))
                        {
                            backingField.SetValue(unitOfWork, Activator.CreateInstance(implementation, new object[] { mongoClient }));
                        }                  
                        else if(property.PropertyType.GetInterfaces().Any(x => x.Name.StartsWith("IGenericDatabricksRepository"))){
                            backingField.SetValue(unitOfWork,  Activator.CreateInstance(implementation, databricksDbContext));
                        }
                        else
                        {
                            throw new Exception($"Não foi possível encontrar a interface do repositório: ${property.Name}");
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw new Exception($"Erro ao criar a instância da propriedade {property.Name}", ex);
                }
            }
        }
    }
}
