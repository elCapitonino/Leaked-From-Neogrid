import ast
from collections import defaultdict
from datetime import date, datetime, timedelta
from typing import Any, NamedTuple, Optional

import numpy as np
import pandas as pd
from sqlalchemy import MetaData, Table, case, func, select

import scripts.period as period
import scripts.report as report
import src.report_config as report_config
from src.db import PostgreSQLConnection
from src.logger import logger
from src.utils import ADOPTION_TOLERANCE_PCT

MAP_SALES_HISTORY_PRICES_PROJECTION = {
    "Description": "ProductName",
}
MAP_PRICES_PROJECTION_SALES_HISTORY = {
    v: k for k, v in MAP_SALES_HISTORY_PRICES_PROJECTION.items()
}


# É aprovado quando:
## Regra 1 - Preço sugerido é igual ou 1% diferente da média de preço no período futuro
## Regra 2 - Média de preço no período futuro é igual a um preço sugerido em uma precificação anterior (limite início do mês + última precificação do mês anterior)
## Regra 3 - O preço deve ter sido alterado, se o cliente mantiver um preço sugerido anterior, o novo preço sugerido não é uma adoção


def build_report_config(pg_conn: PostgreSQLConnection, metadata, idCompany: int):
    logger.info("Building report configuration")
    try:
        Granularity_sql = report_config.get_granularity_sql(
            pg_conn, metadata, idCompany
        )
        Granularity_join_operation = report_config.get_granularity_join_operation(
            pg_conn, metadata, idCompany
        )
        return Granularity_sql, Granularity_join_operation
    except Exception as e:
        logger.error(f"An error occurred: {e}")
        raise


def concat_projection(
    sql_raw_conn,
    pg_conn: PostgreSQLConnection,
    metadata: MetaData,
    idCompany: int,
    PriceGroup: int,
) -> Optional[pd.DataFrame]:
    logger.info("Concatenating last projections")
    Previous_PriceGroups_list = period.get_previous_published_PriceGroups(
        idCompany, PriceGroup, sql_raw_conn
    )
    Granularidade_sql, Granularidade_join_operation = build_report_config(
        pg_conn, metadata, idCompany
    )
    df_list = []
    for i, PriceGroup in enumerate(Previous_PriceGroups_list):
        df_report = report.get_price_projection(
            sql_raw_conn, PriceGroup, Granularidade_sql, Granularidade_join_operation
        )
        df_report["IdEnterprisePriceGroups"] = PriceGroup
        df_report["ProjectionOrder"] = i
        df_list.append(df_report)

    if not df_list:
        return None

    df_concat = pd.concat(df_list, ignore_index=True)
    df_concat = df_concat.sort_values("ProjectionOrder")
    return df_concat


def filter_precified_SKUs(df_report, Granularity, Previous_Published_Projections):
    logger.info("Filtering precified SKUs")
    logger.info(f"report shape before filtering:{df_report.shape}")
    df_report["HasSuggestion"] = 1
    if Previous_Published_Projections is not None:
        last_Published_PriceGroup = Previous_Published_Projections[
            Previous_Published_Projections["ProjectionOrder"] == 0
        ]
        last_Published_PriceGroup = last_Published_PriceGroup[
            ["p_projecao"] + Granularity
        ]
        df_report = df_report.merge(
            last_Published_PriceGroup,
            on=Granularity,
            how="left",
            suffixes=("", "_last"),
        )
        df_report["HasSuggestion"] = np.where(
            df_report["p_projecao"] != df_report["p_projecao_last"], 1, 0
        )
    logger.info(
        f'Number of non Suggestions:{df_report[df_report["HasSuggestion"] == 0].shape[0]}'
    )
    return df_report


def apply_adoption_rules(
    sql_raw_conn,
    pg_conn: PostgreSQLConnection,
    pg_metadata: MetaData,
    df_report: pd.DataFrame,
    idCompany: int,
    PriceGroup: int,
    Granularity: list[str],
    applied_prices: pd.DataFrame,
) -> pd.DataFrame:
    Previous_Published_Projections = concat_projection(
        sql_raw_conn, pg_conn, pg_metadata, idCompany, PriceGroup
    )
    df_report = filter_precified_SKUs(
        df_report, Granularity, Previous_Published_Projections
    )

    applied_price_sets = (
        applied_prices.sort_values("ordem", ascending=True)
        .groupby(Granularity)["SalePrice"]
        .apply(lambda x: list(set(x)))
        .reset_index()
    )
    applied_price_sets.rename(columns={"SalePrice": "Applied_Price"}, inplace=True)
    applied_price_sets = applied_price_sets[["Applied_Price"] + Granularity]
    df_report = df_report.merge(applied_price_sets, on=Granularity, how="left")
    df_report["Applied_Price"] = df_report["Applied_Price"].astype(str)
    df_report["Adopted"] = 0
    df_report["IdEnterprisePriceGroups"] = str(PriceGroup)
    for index, row in df_report.iterrows():
        logger.debug(f"\n====================================================")
        logger.debug(f'Searching for adoption for SKU: {row["Product"]}')
        if pd.isnull(row["Applied_Price"]):
            logger.info(f"No sales on forward period, skipping SKU: {row['Product']}")
            break
        else:
            logger.debug(row["Applied_Price"])
            try:
                applied_prices_list = ast.literal_eval(row["Applied_Price"])
            except Exception:
                # FIXME evitar ast
                logger.debug("ast eval failed for %s", row["Applied_Price"])
                applied_prices_list = []
            projection_price = row["p_projecao"]
            for applied_price in applied_prices_list:
                absolute_difference = (
                    abs(projection_price - applied_price) / applied_price
                )
                if projection_price == applied_price or absolute_difference <= ADOPTION_TOLERANCE_PCT:
                    df_report.loc[index, "Adopted"] = 1
                    logger.info(
                        f"Adoption found: {row['Product']}, price: {applied_price}, projection: {projection_price}, PriceGroup: {PriceGroup}\n"
                    )
                    break
                if Previous_Published_Projections is not None:
                    logger.info(
                        f"Adoption not found in this projection, searching in previous projections for Product: {row['Product']} with price: {applied_price}\n"
                    )
                    filtered_projections = Previous_Published_Projections
                    granularity_values = []
                    for granularity in Granularity:
                        filtered_projections = filtered_projections[
                            filtered_projections[granularity] == row[granularity]
                        ]
                        granularity_values.append(row[granularity])
                    logger.debug(f'Product: {row["Product"]}, Price: {applied_price}')
                    logger.debug(f"Price Granularity: {granularity_values}")
                    logger.debug(
                        f"Number of prices found in last Projections: {filtered_projections.shape[0]}"
                    )
                    for _, filter_row in filtered_projections.iterrows():
                        logger.debug(
                            f'Comparing Projection {filter_row["IdEnterprisePriceGroups"]}: price: {filter_row["p_projecao"]} x Applied Price: {applied_price}'
                        )
                        if filter_row["p_projecao"] == applied_price:
                            df_report.loc[index, "Adopted"] = 1
                            df_report.loc[index, "IdEnterprisePriceGroups"] = (
                                filter_row["IdEnterprisePriceGroups"]
                            )
                            df_report.loc[index, "p_projecao"] = filter_row[
                                "p_projecao"
                            ]
                            df_report.loc[index, "d_projecao"] = filter_row[
                                "d_projecao"
                            ]
                            df_report.loc[index, "custo_projecao"] = filter_row[
                                "custo_projecao"
                            ]
                            logger.info(
                                f"Adoption found in last PriceGroup: {filter_row['IdEnterprisePriceGroups']}"
                            )
                            break
                        logger.info(
                            f"Adoption not found in previous projections for: {row['Product']}"
                        )
    return df_report
