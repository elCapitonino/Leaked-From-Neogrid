using Domain.Filter;
using Domain.Filter.Models;
using Domain.Product;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;

namespace PredimonitorAPI.Controllers;

[ApiController]
[Route("api/[controller]")]
public class FilterController : ControllerBase
{
    private readonly ILogger<FilterController> _logger;
    private readonly IFilterDomain _domain;

    public FilterController(ILogger<FilterController> logger, IFilterDomain domain)
    {
        _logger = logger;
        _domain = domain;
    }

    [HttpPost]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(FilterResponse))]
    [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(string))]
    [ProducesResponseType(StatusCodes.Status401Unauthorized, Type = typeof(string))]
    [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
    [SwaggerOperation(Summary = "Retrieves filters to the the predimonitor screen", Description = "Retrieves filters to the the predimonitor screen")]

    public async Task<IActionResult> Search(FilterRequest request)
    {
        if (request == null)
        {
            _logger.LogDebug("Null request received");
            return BadRequest("Request cannot be null.");
        }

        if (!ModelState.IsValid)
        {
            _logger.LogDebug("Invalid request received.");
            return BadRequest("Invalid request data.");
        }

        try
        {
            var response = await _domain.GetFilters(request);

            if (response is null)
            {
                _logger.LogDebug("No data found");
                return NoContent();
            }

            return Ok(response);
        }
        catch (UnauthorizedAccessException ex)
        {
            _logger.LogError(ex, "Unauthorized access");
            return Unauthorized("Unauthorized access.");
        }
        catch (ArgumentException ex)
        {
            _logger.LogError(ex, "Bad request");
            return BadRequest("Invalid argument: " + ex.Message);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error executing");
            return StatusCode(StatusCodes.Status500InternalServerError, "An unexpected error occurred.");
        }
    }
}