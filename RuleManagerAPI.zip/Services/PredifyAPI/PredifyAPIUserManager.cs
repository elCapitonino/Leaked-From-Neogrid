﻿using Microsoft.Extensions.Options;
using Services.PredifyAPI.Access;
using Services.PredifyAPI.Empresa;
using Services.PredifyAPI.Models;
using System.Net.Http.Headers;

namespace Services.PredifyAPI
{
    public class PredifyAPIUserManager
    {
        private readonly HttpClient client;

        public PredifyAPIUserManager(HttpClient client, IOptions<PredifyAPIOptions> options)
        {
            EmpresaService = new EmpresaService(client);
            AccessService = new AccessService(client);
            this.client = client;
        }

        public void SetAuthorization(string token) => client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
        public IEmpresaService EmpresaService { get; }
        public IAccessService AccessService { get; }
    }
}
