﻿using Microsoft.AspNetCore.Http;
using System.Security.Claims;

namespace DI.Domain.Models
{

    public class CurrentUser : ICurrentUser
    {
        private ClaimsIdentity? identity;

        public CurrentUser(IHttpContextAccessor httpContextAccessor)
        {
            identity = httpContextAccessor?.HttpContext?.User?.Identity as ClaimsIdentity;
        }
        public string? Name => identity?.Name;
        public bool IsAuthenticated => identity?.IsAuthenticated ?? false;
        public Guid UserId => Guid.TryParse(identity?.FindFirst(ClaimTypes.NameIdentifier)?.Value, out Guid userId) ? userId : throw new Exception($"Usuário autenticado: {IsAuthenticated}");
        public string AccessToken => identity?.FindFirst("access_token")?.Value ?? throw new Exception($"Usuário autenticado: {IsAuthenticated}");

        public ClaimsIdentity? Identity => identity;
    }
}
