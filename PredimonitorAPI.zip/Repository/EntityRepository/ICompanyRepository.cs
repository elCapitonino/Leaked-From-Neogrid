﻿using Repository.Entity;
using Repository.EntityRepository.Bases;

namespace Repository.EntityRepository
{
    public interface ICompanyRepository : IGenericRepository<CompanyEntity, long>
    {
    }
}
