﻿using Repository.Enums;

namespace Repository.Entity
{
    public sealed class DinPreRuleEntity : BaseEntity
    {
        public long RuleId { get; set; }

        public long IdEmpresa { get; set; }

        public string? Description { get; set; }

        public int NumberOrder { get; set; }

        public bool IsBlocked { get; set; }

        public bool IsAllProducts { get; set; }

        public bool IsActive { get; set; } = true;

        public bool IsSimulation { get; set; }

        public string? AllowAbcCurve { get; set; }

        public EElasticityFilter Enterprise_ElasticityStatus { get; set; }

        public bool IsDeletado { get; set; }

        public ICollection<DinPreRule_ConditionEntity> Conditions { get; set; }

        public ICollection<DinPreRule_DefaultFilter_ValueEntity> Filters { get; set; }
    }
}
