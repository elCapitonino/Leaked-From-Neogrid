﻿using Repository.Enums;

namespace Repository.Entity
{
    public sealed class DinPreRule_ConditionEntity : BaseEntity
    {
        public long ConditionId { get; set; }
        public long IdRule { get; set; }
        public DinPreRuleEntity? Rule { get; set; }
        public ERuleType ConditionType { get; set; }

        public int NumberOrder { get; set; }

        public bool IsActive { get; set; }

        public ICollection<DinPreRule_Cond_ValueEntity>? Values { get; set; }

        public bool IsDeletado { get; set; }
    }
}
