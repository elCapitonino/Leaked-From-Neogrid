# Geo Location API

Uma API.
Link: https://foo.bar

## Rodar localmente (sem Docker)

1. Instale as dependências (de preferência em ambiente virtual, versão testada: Python 3.8 por conta das versões antigas das bibliotecas):

```bash
python -m pip install -r requirements.txt
```

2. Rode com uvicorn:

```bash
export PYTHONPATH=.
export DEBUG=1
python -m uvicorn app.main:app --host 0.0.0.0 --port 8081 --reload
```

## Roder com Docker

```bash
docker build --tag geo_location_api .
docker run -p 8081:80 -e DEBUG=1 geo_location_api
```
