﻿using Repository.DbContexts;
using Repository.Entity;
using Repository.EntityRepository.Bases;

namespace Repository.EntityRepository
{
    public class MonitoringItemResultsStatusRepository : GenericRepository<MonitoringItemResultsStatusEntity, long>, IMonitoringItemResultsStatusRepository
    {
        public MonitoringItemResultsStatusRepository(ApplicationDbContext dbContext) : base(dbContext)
        {
        }
        public static string DbContextName => nameof(ApplicationDbContext);
    }
}
