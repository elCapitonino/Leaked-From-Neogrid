<template>
  <div class="pa-0" v-if="displayBanner">
    <v-banner elevation="3" rounded color="var(--white)" class="px-2">
      <v-row class="ma-0 pa-0 align-center" @click="closeBanner()">
        <v-col
          cols="12"
          sm="8"
          md="auto"
          lg="auto"
          class="pa-0 mx-0 margin-y-5"
        >
          <span class="pa-0 ma-0 banner-message">{{ message }} </span>
        </v-col>
        <v-spacer></v-spacer>
        <v-btn
          small
          color="var(--dark-moderate-blue-2)"
          class="white--text pa-2 rounded-sm margin-y-5"
          @click="makePayment()"
          >REALIZAR PAGAMENTO</v-btn
        >
      </v-row>
    </v-banner>
  </div>
</template>

<script>
export default {
  name: "banner-top-component",
  props: {
    message: {
      required: true,
      type: String,
    },
  },
  data() {
    return {
      displayBanner: true,
    };
  },
  methods: {
    closeBanner() {},

    makePayment() {
      console.log("make payment");
    },
  },
};
</script>

<style>
.banner-message {
  font-weight: 600;
  color: var(--dark-moderate-blue-2);
  font-size: 18px;
}
</style>