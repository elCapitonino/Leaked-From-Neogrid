﻿using Microsoft.EntityFrameworkCore;
using Repository.DbContexts.Bases;

namespace Repository.DbContexts
{
    public class ApplicationDbContext : DbContextBase
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {

        }
        public override string DbContextName => nameof(ApplicationDbContext);

    }
}
