"""
Configurações de agregação e estilo para relatório.
"""

from typing import NamedTuple

import numpy as np

from agg_functions import count_adoption, pct_adoption, pct_remarcado
from aggregator import AggregationStep
from report import ReportStyle


class ReportConfig(NamedTuple):
    # uma lista de AggregationStep por relatório agregado
    # ordem: do dado bruto ao geral
    agg_steps: list[list[AggregationStep]]
    style: ReportStyle = ReportStyle()


vem_config = ReportConfig(
    agg_steps=[
        [
            AggregationStep(
                "AffiliateName",
                "AffiliateName",
                lambda x: ", ".join(sorted(x.unique())),
            ),
            AggregationStep(
                "Category1",
                "Category1",
                lambda x: ", ".join(sorted(x.unique())),
            ),
            AggregationStep(
                "Category2",
                "Category2",
                lambda x: ", ".join(sorted(x.unique())),
            ),
            AggregationStep(
                "AffiliateState",
                "AffiliateState",
                lambda x: ", ".join(sorted(x.unique())),
            ),
            AggregationStep(
                "Influência da IA",
                "Sugestão de Adequação (quantidade de produtos)",
                count_adoption,
            ),
            AggregationStep(
                "Influência da IA",
                "Aderência aos Preços Sugeridos (%)",
                pct_adoption,
            ),
            AggregationStep(
                "Influência da IA",
                "Aderência às Alterações de Preço (%)",
                pct_remarcado,
            ),
        ],
        [
            AggregationStep(
                "Affiliate",
                "Número de Lojas",
                lambda x: len(x.unique()),
            ),
            AggregationStep(
                "Aderência às Alterações de Preço (%)",
                "Número de Lojas com Adoção de Alterações",
                lambda x: (x > 0).sum(),
            ),
            AggregationStep(
                "AffiliateState",
                "AffiliateState",
                lambda x: ", ".join(sorted(x.unique())),
            ),
            AggregationStep(
                "Sugestão de Adequação (quantidade de produtos)",
                "Sugestão de Adequação (quantidade de produtos)",
                np.sum,
            ),
            AggregationStep(
                "Aderência aos Preços Sugeridos (%)",
                "Aderência aos Preços Sugeridos (%)",
                np.mean,
            ),
            AggregationStep(
                "Aderência às Alterações de Preço (%)",
                "Aderência às Alterações de Preço (%)",
                np.mean,
            ),
        ],
    ],
    style=ReportStyle(fill_na_value="SEM VENDAS")
)


peralta_config = ReportConfig(
    agg_steps=[],
    style=ReportStyle()
)

CONFIGS = {
    3026: vem_config,
    2941: peralta_config,
}
