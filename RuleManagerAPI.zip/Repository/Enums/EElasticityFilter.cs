﻿namespace Repository.Enums
{
    public enum EElasticityFilter
    {
        All = 0,
        Elastic = 1,
        Inelastic = 2,
    }
}
