namespace Repository.Entity.Databricks;

public class CompanyProductPriceEntity
{
    public string Id { get; set; }
    public int CompanyId { get; set; }
    public string ProductId { get; set; }
    public DateTime Date { get; set; }
    public decimal Price { get; set; }
}