﻿using Domain.Exceptions;
using Domain.Rule;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace RuleManagerAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class RuleController : Controller
    {
        private readonly ILogger<RuleController> _logger;
        private readonly IRuleDomain _ruleDomain;
        public RuleController(IRuleDomain ruleDomain, ILogger<RuleController> logger)
        {
            _logger = logger;
            _ruleDomain = ruleDomain;
        }

        [HttpGet]
        [Route("GetByGroup")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(long))]
        [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status401Unauthorized, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(string))]
        public async Task<IActionResult> GetByGroup(long id)
        {
            try
            {
                return Ok(await _ruleDomain.GetByGroupId(id));
            }
            catch (NotFoundException ex)
            {
                _logger.LogError(ex.Message, ex);
                return NotFound(ex.Message);
            }
            catch (UnauthorizedAccessException ex)
            {
                _logger.LogError(ex.Message, ex);
                return Unauthorized(ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex);
                return BadRequest(ex.Message);
            }
        }
    }
}
