"""
Script para combinar seleção de produtos para filiais em CSV
(colunas Affiliate e Product) com arquivo JSON no formato
{"affiliate": [product_code_1, ...]}.
"""

import argparse
from datetime import date
from collections import defaultdict

import json
import pandas as pd


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--json")
    parser.add_argument("--csv")
    args = parser.parse_args()

    current_json = json.load(open(args.json, "r", encoding="utf-8"))
    current_json = {
        affiliate: products for affiliate, products in current_json.items() if products
    }

    df = pd.read_csv(args.csv, sep=";")
    csv_to_json = defaultdict(list)
    for _, row in df.iterrows():
        zbrm = str(row["Affiliate"])
        csv_to_json[zbrm].append(row["Product"])

    json_zbrm = set(current_json.keys())
    csv_zbrm = set(csv_to_json.keys())

    intersection = json_zbrm.intersection(csv_zbrm)
    assert not intersection, f"there are affiliates in both files: {intersection}"

    today = date.today()
    out = {**current_json, **csv_to_json}
    fpath = f"merged_chosen_products_{today.isoformat()}.json"
    with open(fpath, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print(f"saved to {fpath}")


if __name__ == "__main__":
    main()
