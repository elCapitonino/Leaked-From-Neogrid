import datetime
from typing import Optional

import numpy as np
import pandas as pd
import pyodbc

from src.logger import logger


def get_price_group_date(
    cursor: pyodbc.Cursor, PriceGroup: int, idCompany: int
) -> datetime.datetime:
    """
    Get the PublishedDate field from a PriceGroup based on the PriceGroup and the idCompany it belongs to
    :param cursor: connection.cursor object holding an sql connection to the database
    :param PriceGroup: the PriceGroup to get the date from
    :param idCompany: the idCompany that the PriceGroup belongs to

    return: the PublishedDate field from the PriceGroup
    """
    try:
        get_publish_date_query = f"""
            SELECT PublishedDate
            FROM enterprise_Price_Groups
            WHERE idCompany = {idCompany} AND IdEnterprisePriceGroups = {PriceGroup}
            """
        logger.debug(get_publish_date_query)
        cursor.execute(get_publish_date_query)
        PublishedDate = cursor.fetchone()[0]
        PublishedDate = pd.to_datetime(PublishedDate).strftime("%Y-%m-%d")
        return PublishedDate
    except Exception as exc:
        logger.error("this PriceGroup was not published yet", exc_info=True)
        raise exc


def get_oldest_issuance(cursor: pyodbc.Cursor, idCompany: int):
    """
    Get the oldest issuance date from the Enterprise_Sales_History table
    :param cursor: connection.cursor object holding an sql connection to the database
    :param idCompany: the idCompany to get the oldest issuance date from

    return: the oldest issuance date in the Enterprise_Sales_History table
    """
    cursor.execute(
        f"""
        SELECT Issuance
        FROM Enterprise_Sales_History
        WHERE idCompany = {idCompany}
        ORDER BY Issuance ASC
        """
    )
    logger.info("Collecting oldest issuance date from Enterprise_Sales_History.")
    SQL_oldest_issuance = cursor.fetchone()[0]
    SQL_oldest_issuance = pd.to_datetime(SQL_oldest_issuance).strftime("%Y-%m-%d")
    return SQL_oldest_issuance


def get_most_recent_issuance(cursor: pyodbc.Cursor, idCompany: int):
    """
    Get the most recent issuance date from the Enterprise_Sales_History table
    :param cursor: connection.cursor object holding an sql connection to the database
    :param idCompany: the idCompany to get the most recent issuance date from

    return: the most recent issuance date in the Enterprise_Sales_History table
    """
    cursor.execute(
        f"""
        SELECT Issuance
        FROM Enterprise_Sales_History
        WHERE idCompany = {idCompany}
        ORDER BY Issuance DESC
        """
    )
    logger.info("Collecting most recent issuance date from Enterprise_Sales_History.")
    SQL_latest_issuance = cursor.fetchone()[0]
    SQL_latest_issuance = pd.to_datetime(SQL_latest_issuance).strftime("%Y-%m-%d")
    return SQL_latest_issuance


def get_next_published_PriceGroup(
    cursor: pyodbc.Cursor, idCompany: int, reference_Date: str, PriceGroup: int
) -> Optional[int]:
    """
    Get the next published PriceGroup after the reference date
    :param cursor: connection.cursor object holding an sql connection to the database
    :param idCompany: the idCompany to get the next published PriceGroup from
    :param reference_Date: the reference date to get the next published PriceGroup from
    :param PriceGroup: the PriceGroup to exclude from the search

    returns: the next published PriceGroup after the reference date
    """
    try:
        get_dbField_query = f"""
        SELECT F.Value
        FROM Enterprise_Price_Groups_Filter F
        JOIN EnterprisePriceGroups_DefaultFilter DF
        ON F.IdEnterprisePriceGroups_DefaultFilter = DF.IdEnterprisePriceGroups_DefaultFilter
        WHERE DF.IdCompany = {idCompany}
        AND F.IsDeleted = 0
        and f.IdEnterprisePriceGroups = {PriceGroup}
        AND DF.PreSelect = 1;
        """
        cursor.execute(get_dbField_query)
        PriceGroup_DbField = cursor.fetchone()[0]

        next_published_pricegroup_query = f"""
            WITH FilteredEnterprisePriceGroups AS (
                SELECT F.IdEnterprisePriceGroups, F.Value
                FROM Enterprise_Price_Groups_Filter F
                JOIN EnterprisePriceGroups_DefaultFilter DF ON F.IdEnterprisePriceGroups_DefaultFilter = DF.IdEnterprisePriceGroups_DefaultFilter
                WHERE DF.IdCompany = {idCompany}
                AND F.IsDeleted = 0
                AND DF.PreSelect = 1
            )
            SELECT EPG.IdEnterprisePriceGroups
            FROM enterprise_Price_Groups EPG
            JOIN FilteredEnterprisePriceGroups FEPG ON EPG.IdEnterprisePriceGroups = FEPG.IdEnterprisePriceGroups
            WHERE EPG.idCompany = {idCompany}
            AND EPG.IsDeletado = 0
            AND EPG.PublishedDate >= '{reference_Date}' 
            AND EPG.IdEnterprisePriceGroups != {PriceGroup}
            AND FEPG.Value = '{PriceGroup_DbField}'
            ORDER BY EPG.PublishedDate ASC;
            """
        logger.info(
            "Collecting next published PriceGroup from Enterprise_Price_Groups."
        )
        cursor.execute(next_published_pricegroup_query)
        next_published_PriceGroup = cursor.fetchone()
        if next_published_PriceGroup is None:
            logger.info("There is no next published PriceGroup.")
            return None
        else:
            return next_published_PriceGroup[0]
    except Exception as e:
        logger.error(f"An error occurred: {e}")
        raise


def get_previous_published_PriceGroups(
    idCompany: int, PriceGroup: int, conn: pyodbc.Connection
):
    """
    Get the previous published PriceGroups before the reference date
    :param cursor: connection.cursor object holding an sql connection to the database
    :param idCompany: the idCompany to get the previous published PriceGroups from
    :param reference_Date: the reference date to get the previous published PriceGroups from
    :param PriceGroup: the PriceGroup to exclude from the search

    returns: the previous published PriceGroups before the reference date
    """
    try:
        cursor = conn.cursor()
        reference_Date = pd.to_datetime(
            get_price_group_date(cursor, PriceGroup, idCompany)
        )
        start_of_current_month = reference_Date.replace(day=1)
        start_of_previous_month = start_of_current_month - pd.DateOffset(months=1)

        month_search = f"""
        SELECT IdEnterprisePriceGroups
        from enterprise_Price_Groups
        WHERE idCompany = {idCompany} AND IsDeletado = 0
        and PublishedDate <= '{reference_Date}' and PublishedDate >= '{start_of_current_month}'
        and IdEnterprisePriceGroups != {PriceGroup}
        ORDER BY PublishedDate DESC
        """

        last_month_search = f"""
        SELECT top 1 IdEnterprisePriceGroups
        from enterprise_Price_Groups
        WHERE idCompany = {idCompany} AND IsDeletado = 0
        and PublishedDate >= '{start_of_previous_month}' and PublishedDate < '{start_of_current_month}'
        and IdEnterprisePriceGroups != {PriceGroup}
        ORDER BY PublishedDate DESC
        """
        logger.info(
            "Collecting previous published PriceGroups from Enterprise_Price_Groups."
        )
        cursor.execute(month_search)
        month_results = cursor.fetchall()
        month_results_list = [item[0] for item in month_results]
        df_month_results = pd.DataFrame(
            month_results_list, columns=["IdEnterprisePriceGroups"]
        )

        cursor.execute(last_month_search)
        last_month_results = cursor.fetchall()
        last_month_results_list = [item[0] for item in last_month_results]
        df_last_month_results = pd.DataFrame(
            last_month_results_list, columns=["IdEnterprisePriceGroups"]
        )

        last_PriceGroups_list = (
            df_month_results["IdEnterprisePriceGroups"].to_list()
            + df_last_month_results["IdEnterprisePriceGroups"].to_list()
        )
        logger.info(f"The last PriceGroups list is: {last_PriceGroups_list}")
        return last_PriceGroups_list
    except Exception as e:
        logger.error(f"An error occurred: {e}")
        raise
