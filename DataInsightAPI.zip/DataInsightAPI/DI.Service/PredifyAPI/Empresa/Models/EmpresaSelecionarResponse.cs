﻿namespace DI.Service.PredifyAPI.Empresa.Models
{
    public class EmpresaSelecionarResponse
    {
        public int IdEmpresa { get; set; }
        public string NomeRazaoSocial { get; set; }
        public int Setor { get; set; }
        public DateTime DataHoraUltimaAlteracao { get; set; }
        public bool IsBloqueado { get; set; }
        public string MotivoBloqueio { get; set; }
        public int StatusPagamento { get; set; }
        public float Faturamento { get; set; }
        public float LucroPrejuizo { get; set; }
        public string Municipio { get; set; }
        public string ProprietarioEmail { get; set; }
        public string ProprietarioNome { get; set; }
        public string ProprietarioTelefone { get; set; }
        public int IdCountry { get; set; }
    }

}
