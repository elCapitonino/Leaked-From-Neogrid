﻿using Microsoft.Extensions.Options;
using Services.PredifyAPI.Access;
using Services.PredifyAPI.Empresa;
using Services.PredifyAPI.Models;

namespace Services.PredifyAPI
{
    public class PredifyAPISystemManager
    {

        public PredifyAPISystemManager(HttpClient client, IOptions<PredifyAPIOptions> options)
        {
           EmpresaService = new EmpresaService(client);
           AccessService = new AccessService(client);
        }

        public IEmpresaService EmpresaService { get; }
        public IAccessService AccessService { get; }
    }    
}
