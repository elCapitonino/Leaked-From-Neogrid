using Domain.Product.Models;

namespace Domain.Filter.Models;

public class FilterRequest : FiltersRequest
{
    public string? ProductName { get; set; }
    public bool IsProductPagination { get; set; }
    public string? SellerName { get; set; }
    public bool IsSellerPagination { get; set; }
    public string? BrandName { get; set; }
    public bool IsBrandPagination { get; set; }
}