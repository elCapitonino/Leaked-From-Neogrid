﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.MonitoringResult.Models
{
    public class SeeResultResponse
    {
        public string? ProductName { get; set; }
        public string ProductLink { get; set; }
        public string? Section { get; set; }
        public string? Category { get; set; }
        public string? Ean { get; set; }
        public decimal? MinPrice { get; set; }
        public decimal? AvgPrice { get; set; }
        public decimal? MaxPrice { get; set; }
        public string? PriceCurrency { get; set; }
        public DateTime? AvgInfo_DateTime { get; set; }
        public List<ResultFilterResponse> PriceResults { get; set; }
        //public List<MaskedResult> MaskedSellersResults { get; set; }
        public long IdMonitoringItem { get; set; }
    }
}
