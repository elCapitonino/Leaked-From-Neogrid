"""
Script para preparar dados da VEM para clusterizar filiais (2024-03-13).
Requer um diretório data com os arquivos parquet gerados
pelo script raw_to_parquet do ETL da VEM (repositório Manual_ETL)
contendo dados do período de interesse.
"""
# %%

import pandas as pd
import numpy as np
import findspark
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from plotnine import *

# %%

findspark.init()
findspark.find()

spark = (
    SparkSession.builder.config("spark.driver.memory", "10g")
    .config("spark.driver.maxResultSize", "4g")
    .config("spark.executor.memory", "4g")
    .getOrCreate()
)

# %%

df_sales = spark.read.parquet("./data/sales.parquet")
df_sales.createOrReplaceTempView("raw_sales")
df_sales.show()
# %%

df_cost = spark.read.parquet("./data/cost.parquet")
df_cost.createOrReplaceTempView("raw_cost")

df_pbcost = spark.sql(
    "SELECT affiliate, mes_ano, glar_cod_artigo, avg(custo_loja) AS custo_loja FROM raw_cost GROUP BY 1, 2, 3"
)

df_pbcost.createOrReplaceTempView("cost")
# %%

query = """
    WITH sales AS (
        SELECT
            date_trunc('dd', issuance) AS issuance,
            zbrm,
            description,
            last(ean) AS ean,
            COUNT(DISTINCT cod_ticket) AS num_tickets,
            sum(quantity) AS quantity,
            mean(saleprice) AS saleprice,
            sum(quantity * saleprice) AS revenue,
            first(namesegment) AS namesegment
        FROM raw_sales
        WHERE issuance >= '2023-07-28'
        -- AND raw_sales.description IS NOT NULL
        -- AND raw_sales.description NOT IN ('NÃO VINCULADO', 'NAO VINCULADO', 'nan')
        GROUP BY 1, 2, 3
    ),
    tb_cost AS (
        SELECT
            *
        FROM (
            SELECT
                sales.ean,
                sales.zbrm,
                date_trunc('MM', issuance) AS cost_issuance,
                cost.mes_ano,
                cost.custo_loja AS pbcost,
                ROW_NUMBER() OVER (
                    PARTITION BY sales.ean, sales.zbrm, date_trunc('MM', issuance)
                    ORDER BY cost.mes_ano DESC
                ) AS rn
            FROM sales
            JOIN cost
            ON sales.ean = cost.glar_cod_artigo
            AND CAST(sales.zbrm AS STRING) = CAST(cost.affiliate AS STRING)
            AND date_trunc('MM', issuance) >= cost.mes_ano
        )
        WHERE rn = 1
    ),
    tb_sales_pbcost AS (
        SELECT
            sales.*,
            trim(split_part(sales.namesegment, ' / ', 1)) AS category,
            trim(split_part(sales.namesegment, ' / ', 2)) AS subcategory,
            tb_cost.pbcost,
            tb_cost.mes_ano AS cost_date
        FROM sales
        LEFT JOIN tb_cost
        ON sales.ean = tb_cost.ean
        AND sales.zbrm = tb_cost.zbrm
        AND date_trunc('MM', sales.issuance) = tb_cost.cost_issuance
    )
    SELECT * FROM tb_sales_pbcost
"""
# %%

sdf_sales = spark.sql(query)
sdf_sales.show()
# %%

affiliate_count = sdf_sales.groupBy("zbrm").count().alias("aff_count")
# %%
sdf_adj_margin = (
    sdf_sales.where(F.col("pbcost").isNotNull())
    .withColumn("total_cost", F.col("pbcost") * F.col("quantity"))
    .groupBy("zbrm")
    .agg(
        F.count("quantity").alias("pbcost_count"),
        F.sum(F.col("quantity")).alias("quantity"),
        F.sum(F.col("revenue")).alias("revenue"),
        F.sum(F.col("total_cost")).alias("total_cost"),
    )
    .withColumn("profit", F.col("revenue") - F.col("total_cost"))
    .withColumn("adj_margin", F.col("profit") / F.col("revenue"))
    .select("zbrm", "adj_margin", "pbcost_count")
)

sdf_affiliates = (
    sdf_sales.withColumn("FILTROS", F.col("category") == "FILTROS")
    .withColumn("OLEOS", F.col("category") == "OLEOS")
    .withColumn("MERCEARIA", F.col("category") == "MERCEARIA")
    .withColumn("BEBIDAS ALCOOLICAS", F.col("category") == "BEBIDAS ALCOOLICAS")
    .withColumn("TABACO", F.col("category") == "TABACO")
    .withColumn("BEBIDAS NAO ALCOOLICAS", F.col("category") == "BEBIDAS NAO ALCOOLICAS")
    .withColumn("BOMBONIERE", F.col("category") == "BOMBONIERE")
    .withColumn("FLUIDOS", F.col("category") == "FLUIDOS")
    .withColumn("BAZAR AUTOMOTIVO", F.col("category") == "BAZAR AUTOMOTIVO")
    .withColumn("BAZAR", F.col("category") == "BAZAR")
    .withColumn("OUTROS", F.col("category") == "OUTROS")
    .withColumn("BISCOITOS e SNACKS", F.col("category") == "BISCOITOS e SNACKS")
    .withColumn("PADARIA", F.col("category") == "PADARIA")
    .withColumn("CONGELADOS", F.col("category") == "CONGELADOS")
    .withColumn("NÃO VINCULADO", F.col("category") == "NÃO VINCULADO")
    .withColumn("FOOD SERVICE", F.col("category") == "FOOD SERVICE")
    .withColumn("PISTA", F.col("category") == "PISTA")
    .withColumn("ISENTOS", F.col("category") == "ISENTOS")
    .withColumn("total_cost", F.col("pbcost") * F.col("quantity"))
    .groupBy("zbrm")
    .agg(
        F.sum(F.col("quantity")).alias("quantity"),
        F.sum(F.col("revenue")).alias("revenue"),
        F.sum(F.col("total_cost")).alias("total_cost"),
        F.sum(F.col("revenue") * F.col("FILTROS").cast("float")).alias("FILTROS"),
        F.sum(F.col("revenue") * F.col("OLEOS").cast("float")).alias("OLEOS"),
        F.sum(F.col("revenue") * F.col("MERCEARIA").cast("float")).alias("MERCEARIA"),
        F.sum(F.col("revenue") * F.col("BEBIDAS ALCOOLICAS").cast("float")).alias("BEBIDAS ALCOOLICAS"),
        F.sum(F.col("revenue") * F.col("TABACO").cast("float")).alias("TABACO"),
        F.sum(F.col("revenue") * F.col("BEBIDAS NAO ALCOOLICAS").cast("float")).alias(
            "BEBIDAS NAO ALCOOLICAS"
        ),
        F.sum(F.col("revenue") * F.col("BOMBONIERE").cast("float")).alias("BOMBONIERE"),
        F.sum(F.col("revenue") * F.col("FLUIDOS").cast("float")).alias("FLUIDOS"),
        F.sum(F.col("revenue") * F.col("BAZAR AUTOMOTIVO").cast("float")).alias("BAZAR AUTOMOTIVO"),
        F.sum(F.col("revenue") * F.col("BAZAR").cast("float")).alias("BAZAR"),
        F.sum(F.col("revenue") * F.col("OUTROS").cast("float")).alias("OUTROS"),
        F.sum(F.col("revenue") * F.col("BISCOITOS e SNACKS").cast("float")).alias("BISCOITOS e SNACKS"),
        F.sum(F.col("revenue") * F.col("PADARIA").cast("float")).alias("PADARIA"),
        F.sum(F.col("revenue") * F.col("CONGELADOS").cast("float")).alias("CONGELADOS"),
        F.sum(F.col("revenue") * F.col("NÃO VINCULADO").cast("float")).alias("NÃO VINCULADO"),
        F.sum(F.col("revenue") * F.col("FOOD SERVICE").cast("float")).alias("FOOD SERVICE"),
        F.sum(F.col("revenue") * F.col("PISTA").cast("float")).alias("PISTA"),
        F.sum(F.col("revenue") * F.col("ISENTOS").cast("float")).alias("ISENTOS"),
    )
)

sdf_affiliates = sdf_affiliates.alias("affiliates")
affiliate_count = affiliate_count.alias("tb_count")

sdf_affiliates_count = (
    sdf_affiliates.join(affiliate_count, "zbrm", "left")
    .select("affiliates.*", "tb_count.count")
)

sdf_affiliates.count()
# %%

sdf_affiliates_count = sdf_affiliates_count.alias("tb_affiliates")
sdf_adj_margin = sdf_adj_margin.alias("tb_adj_margin")
sdf_affiliates_join = (
    sdf_affiliates_count.join(sdf_adj_margin, "zbrm", "left")
    .select("tb_affiliates.*", "tb_adj_margin.adj_margin", "tb_adj_margin.pbcost_count")
    .fillna({"total_cost": 0, "adj_margin": 1, "pbcost_count": 0})
)

sdf_affiliates_join.count()
# %%

sdf_final = (
    sdf_affiliates_join.withColumn(
        "pbcost_pct", F.col("pbcost_count").cast("float") / F.col("count")
    )
    .withColumn("profit", F.col("revenue") - F.col("total_cost"))
    .withColumn("margin", F.col("profit") / F.col("revenue"))
    .withColumn("FILTROS", F.col("FILTROS") / F.col("revenue"))
    .withColumn("OLEOS", F.col("OLEOS") / F.col("revenue"))
    .withColumn("MERCEARIA", F.col("MERCEARIA") / F.col("revenue"))
    .withColumn("BEBIDAS ALCOOLICAS", F.col("BEBIDAS ALCOOLICAS") / F.col("revenue"))
    .withColumn("TABACO", F.col("TABACO") / F.col("revenue"))
    .withColumn("BEBIDAS NAO ALCOOLICAS", F.col("BEBIDAS NAO ALCOOLICAS") / F.col("revenue"))
    .withColumn("BOMBONIERE", F.col("BOMBONIERE") / F.col("revenue"))
    .withColumn("FLUIDOS", F.col("FLUIDOS") / F.col("revenue"))
    .withColumn("BAZAR AUTOMOTIVO", F.col("BAZAR AUTOMOTIVO") / F.col("revenue"))
    .withColumn("BAZAR", F.col("BAZAR") / F.col("revenue"))
    .withColumn("OUTROS", F.col("OUTROS") / F.col("revenue"))
    .withColumn("BISCOITOS e SNACKS", F.col("BISCOITOS e SNACKS") / F.col("revenue"))
    .withColumn("PADARIA", F.col("PADARIA") / F.col("revenue"))
    .withColumn("CONGELADOS", F.col("CONGELADOS") / F.col("revenue"))
    .withColumn("NÃO VINCULADO", F.col("NÃO VINCULADO") / F.col("revenue"))
    .withColumn("FOOD SERVICE", F.col("FOOD SERVICE") / F.col("revenue"))
    .withColumn("PISTA", F.col("PISTA") / F.col("revenue"))
    .withColumn("ISENTOS", F.col("ISENTOS") / F.col("revenue"))
)

sdf_final.count()
# %%

df = sdf_final.toPandas()
df.head()
# %%

df.to_parquet("affiliate_data.parquet")
# %%
