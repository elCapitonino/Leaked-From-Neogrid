﻿using CommandLine;
using MongoDB.Driver;
using Serilog;
using UpdateHash.Handlers;
using UpdateHashHorus;
using UpdateHashHorus.Handlers;

class Program
{
    static async Task Main(string[] args)
    {
        var argument = Parser.Default.ParseArguments<CommandLineOptions>(args);

        var value = argument.Value;

        Log.Logger = new LoggerConfiguration()
                .WriteTo.Console()
                .WriteTo.File($"LogUpdateHash/{value.BaseType.ToString()}/log.txt", rollingInterval: RollingInterval.Minute)
                .CreateLogger();

        Log.Information("Iniciando o aplicativo");

        var connectionString = value.ConnectionString;
        var client = new MongoClient(connectionString);

        try
        {
            switch (value.BaseType)
            {
                case BaseType.Horus:
                    HorusHandler handlerHorus = new HorusHandler(client);
                    await handlerHorus.ExecuteAsync(value.Base, value.Collection, value.StartDate, value.EndDate, value.BatchSize, value.DryRun);
                    break;

                case BaseType.NilsenPeralta:
                    NielsenPeraltaHandler handlerNielsenPeralta = new NielsenPeraltaHandler(client);
                    await handlerNielsenPeralta.ExecuteAsync(value.Base, value.Collection, value.StartDate, value.EndDate, value.BatchSize, value.DryRun);
                    break;

                case BaseType.NielsenVem:
                    NielsenVemHandler handlerNielsenVem = new NielsenVemHandler(client);
                    await handlerNielsenVem.ExecuteAsync(value.Base, value.Collection, value.StartDate, value.EndDate, value.BatchSize, value.DryRun);
                    break;

                case BaseType.InfoPrice:
                    InfoPriceHandler handlerInfoPrice = new InfoPriceHandler(client);
                    await handlerInfoPrice.ExecuteAsync(value.Base, value.Collection, value.StartDate, value.EndDate, value.BatchSize, value.DryRun);
                    break;

                case BaseType.Indireta:
                    IndiretaHandler handlerIndireta = new IndiretaHandler(client);
                    await handlerIndireta.ExecuteAsync(value.Base, value.Collection, value.StartDate, value.EndDate, value.BatchSize, value.DryRun);
                    break;

                case BaseType.Smarket:
                    SmarketHandler handlerSmarket = new SmarketHandler(client);
                    await handlerSmarket.ExecuteAsync(value.Base, value.Collection, value.StartDate, value.EndDate, value.BatchSize, value.DryRun);
                    break;

                case BaseType.None:
                default:
                    break;
            }
        }
        catch (Exception ex)
        {
            Log.Information($"Error durante execução");
            Log.Error(ex, "Ocorreu um erro durante a execução do aplicativo");
        }
        finally
        {
            Log.Information($"Finalizado com sucesso");
            Log.CloseAndFlush();
        }
    }
}

