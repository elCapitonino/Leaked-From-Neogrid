﻿using Microsoft.Identity.Client;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver.GeoJsonObjectModel;

namespace Repository.Entity
{
    public class GeoJson2DGeographicCoordinatesWrapper : GeoJsonPoint<GeoJson2DGeographicCoordinates>
    {
        public GeoJson2DGeographicCoordinatesWrapper() : base(new GeoJson2DGeographicCoordinates(0, 0))
        {

        }
        public GeoJson2DGeographicCoordinatesWrapper(GeoJson2DGeographicCoordinates coordinates) : base(coordinates)
        {
            Coordinates = new double[] { coordinates.Latitude, coordinates.Longitude  };
        }

        [BsonElement("coordinates")]
        public double[] Coordinates { get; set; }
    }

}
