﻿namespace Repository
{
    public interface IMultiDbContext
    {
        public string DbContextName { get; }
    }

}
