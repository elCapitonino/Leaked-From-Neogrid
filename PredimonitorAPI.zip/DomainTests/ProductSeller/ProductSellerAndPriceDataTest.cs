using Domain.CompanyMonitoringCrawler;
using Domain.MonitoringResult;
using Domain.Product;
using Domain.Product.Models;
using Domain.ProductSeller;
using Domain.ProductSeller.Models;
using Domain.Status;
using DomainTests.DynamicFilter.Seed;
using DomainTests.Extensions;
using DomainTests.Product.Seed;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.DependencyInjection;
using MongoDB.Driver;
using Moq;
using Repository.DbContexts;
using Repository.Entity;
using Repository.UnitOfWork;

namespace DomainTests.ProductSeller;

//[TestClass()]
public class ProductSellerAndPriceDataTest
{
    private IServiceCollection _services;
    private ServiceProvider _serviceProvider;

    //[TestInitialize]
    public void Initialize()
    {
        _services = new ServiceCollection();
        var mongo = new Mock<MongoClient>().Object;

        _services.AddTransient<IMongoClient>(provider => mongo);
        _services.SetAutoMapper();

        _services.AddDbContext<ApplicationDbContext>(options => options.UseSqlite("Filename=:memory:").ConfigureWarnings(opt => opt.Ignore(RelationalEventId.AmbientTransactionWarning)));

        _services.AddDbContext<HorusDbContext>(options => options.UseMongoDB(mongo, "Horus").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
        _services.AddDbContext<InfoPriceSaoJoaoDbContext>(options => options.UseMongoDB(mongo, "InfroPriceSaoJoao").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
        _services.AddDbContext<NormalizerDbContext>(options => options.UseMongoDB(mongo, "Normalizer").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
        _services.AddDbContext<LinxDbContext>(options => options.UseMongoDB(mongo, "Linx").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
        _services.AddDbContext<NeogridDbContext>(options => options.UseMongoDB(mongo, "Neogrid").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
        _services.AddDbContext<NielsenDbContext>(options => options.UseMongoDB(mongo, "Nielsen").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
        _services.AddDbContext<SmarketCompetitorDbContext>(options => options.UseMongoDB(mongo, "SmarketCompetitor").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);
        _services.AddDbContext<OfflineDbContext>(options => options.UseMongoDB(mongo, "Offline").ConfigureWarnings(opt => opt.Ignore(CoreEventId.ManyServiceProvidersCreatedWarning)), ServiceLifetime.Transient);

        _services.AddTransient(provider => new DatabricsDbContext("Driver=Simba Spark ODBC Driver;Host=adb-1165720697464401.1.azuredatabricks.net;Port=443;HTTPPath=/sql/1.0/warehouses/bb3e5168ee7e6ca6;SSL=1;ThriftTransport=2;AuthMech=3;UID=token;PWD=dapib21631ae7a26d105f43b29d37237aa34;Timeout=30", "predimonitor_test"));

        _services.AddScoped<IMonitoringResultDomain, MonitoringResultDomain>();
        _services.AddScoped<ICompanyMonitoringCrawlerDomain, CompanyMonitoringCrawlerDomain>();
        _services.AddScoped<IStatusDomain, StatusDomain>();
        _services.AddScoped<IProductSellerDomain, ProductSellerDomain>();
        _services.AddMemoryCache();

        _services.AddScoped<IUnitOfWork, UnitOfWork>();
        _services.AddLogging();

        _serviceProvider = _services.BuildServiceProvider();

        var context = _serviceProvider.GetRequiredService<ApplicationDbContext>();
        context.Database.OpenConnection();
        context.Database.EnsureCreated();

        RemoveOldTestData(_serviceProvider.GetService<IUnitOfWork>()!);
    }

    private void RemoveOldTestData(IUnitOfWork uow)
    {
        uow.ProductRepository.ExecuteSQL("DELETE FROM predimonitor_test.products");
        uow.ProductSellerRepository.ExecuteSQL("DELETE FROM predimonitor_test.product_sellers");
        uow.ProductPriceRepository.ExecuteSQL("DELETE FROM predimonitor_test.product_prices");
        uow.IgnoredPriceRepository.ExecuteSQL("DELETE FROM predimonitor_test.ignored_prices");
    }

    private ProductTestData GenerateTestData(IUnitOfWork uow, int crawlerId, bool generateIgnored = false)
    {
        uow.Company.AddRange(CompanySeed.GetTestData(), autosave: true);

        uow.MonitoringCrawler.Create(new MonitoringCrawlerEntity { Id = crawlerId, Description = "Teste" }, autosave: true);

        var companyCrawlers = new List<CompanyMonitoringCrawlerEntity>()
        {
            new CompanyMonitoringCrawlerEntity{
                Id = 1,
                MonitoringCrawlerId = crawlerId,
                CompanyId = 1,
                IsDeleted = false,
                IsCost = true,
                IsSale = true
            }
        };

        uow.CompanyMonitoringCrawler.AddRange(companyCrawlers, autosave: true);

        var testData = ProductSeed.GetProductTestData(crawlerId);

        uow.ProductRepository.Insert(testData.Products);
        uow.ProductSellerRepository.Insert(testData.Sellers);
        uow.ProductPriceRepository.Insert(testData.Prices);

        if (generateIgnored)
        {
            uow.IgnoredPriceRepository.Insert(testData.IgnoredPrices);
        }

        return testData;
    }

    //[TestMethod()]
    public void GetProductSellersWithPricesShouldReturnPricesFromProductId()
    {
        var uow = _serviceProvider.GetService<IUnitOfWork>()!;
        var domain = _serviceProvider.GetService<IProductSellerDomain>()!;

        var testData = GenerateTestData(uow, 9201);

        var macaData = testData.Products.FirstOrDefault(x => x.Name == "Maçã" && x.Brand == "Fazenda XV");

        var request = new FiltersRequest()
        {
            CompanyId = 1,
            StartDate = DateTime.Now.Date.AddDays(-1),
            EndDate = DateTime.Now.Date,
            ProductIds = [macaData.Id],
            Take = 10
        };

        var result = domain.GetProductSellersWithPrices(request).Result;

        var macaSellers = testData.Sellers.Where(x => x.ProductId == macaData.Id).ToList();
        var macaPrices = testData.Prices.Where(x => macaSellers.Select(m => m.Id).Contains(x.ProductSellerId)).ToList();

        Assert.AreEqual(result.SellerPrices.Count(), macaPrices.Count, "Não retornou a quantidade de preços esperada");
    }

    //[TestMethod()]
    public void GetProductSellersWithPricesShouldReturnPricesFromProductIds()
    {
        var uow = _serviceProvider.GetService<IUnitOfWork>()!;
        var domain = _serviceProvider.GetService<IProductSellerDomain>()!;

        var testData = GenerateTestData(uow, 9202);

        var macasData = testData.Products.Where(x => x.Name == "Maçã").ToList();

        var request = new FiltersRequest()
        {
            CompanyId = 1,
            StartDate = DateTime.Now.Date.AddDays(-1),
            EndDate = DateTime.Now.Date,
            ProductIds = macasData.Select(x => x.Id).ToList(),
            Take = 10
        };

        var result = domain.GetProductSellersWithPrices(request).Result;

        var products = testData.Products.Where(x => request.ProductIds.Contains(x.Id)).ToList();
        var sellers = testData.Sellers.Where(x => products.Select(m => m.Id).Contains(x.ProductId)).ToList();
        var prices = testData.Prices.Where(x => sellers.Select(m => m.Id).Contains(x.ProductSellerId)).ToList();

        Assert.AreEqual(result.SellerPrices.Count(), prices.Count, "Não retornou a quantidade de preços esperada");

        var resultPrices = result.SellerPrices.Select(x => x.Price).OrderBy(x => x).ToList();
        var dataPrices = prices.Select(x => x.Price).OrderBy(x => x).ToList();

        Assert.IsTrue(resultPrices.SequenceEqual(dataPrices), "Os preços retornados não são os esperados");
    }

    //[TestMethod()]
    public void GetProductSellersWithPricesShouldReturnPaginatedPrices()
    {
        var uow = _serviceProvider.GetService<IUnitOfWork>()!;
        var domain = _serviceProvider.GetService<IProductSellerDomain>()!;

        var testData = GenerateTestData(uow, 9203);

        var macasData = testData.Products.Where(x => x.Name == "Maçã").ToList();

        var request = new FiltersRequest()
        {
            CompanyId = 1,
            StartDate = DateTime.Now.Date.AddDays(-1),
            EndDate = DateTime.Now.Date,
            ProductIds = macasData.Select(x => x.Id).ToList(),
            Take = 3,
            OrderBy = "Price ASC"
        };

        var result = domain.GetProductSellersWithPrices(request).Result;

        var products = testData.Products.Where(x => request.ProductIds.Contains(x.Id)).ToList();
        var sellers = testData.Sellers.Where(x => products.Select(m => m.Id).Contains(x.ProductId)).ToList();
        var prices = testData.Prices.Where(x => sellers.Select(m => m.Id).Contains(x.ProductSellerId)).OrderBy(x => x.Price).Take(3).ToList();

        Assert.AreEqual(result.SellerPrices.Count(), prices.Count, "Não retornou a quantidade de preços esperada");

        var resultPrices = result.SellerPrices.Select(x => x.Price).OrderBy(x => x).ToList();
        var dataPrices = prices.Select(x => x.Price).OrderBy(x => x).ToList();

        Assert.IsTrue(resultPrices.SequenceEqual(dataPrices), "Os preços retornados não são os esperados");
    }

    //[TestMethod()]
    public void GetProductSellersWithPricesShouldReturnPricesFromCategory()
    {
        var uow = _serviceProvider.GetService<IUnitOfWork>()!;
        var domain = _serviceProvider.GetService<IProductSellerDomain>()!;

        var testData = GenerateTestData(uow, 9204);

        var macasData = testData.Products.Where(x => x.Name == "Maçã").ToList();

        var request = new FiltersRequest()
        {
            CompanyId = 1,
            StartDate = DateTime.Now.Date.AddDays(-1),
            EndDate = DateTime.Now.Date,
            ProductIds = macasData.Select(x => x.Id).ToList(),
            Brands = ["Fazenda Dez"],
            Take = 10
        };

        var result = domain.GetProductSellersWithPrices(request).Result;

        var products = testData.Products.Where(x => request.ProductIds.Contains(x.Id) && x.Brand == "Fazenda Dez").ToList();
        var sellers = testData.Sellers.Where(x => products.Select(m => m.Id).Contains(x.ProductId)).ToList();
        var prices = testData.Prices.Where(x => sellers.Select(m => m.Id).Contains(x.ProductSellerId)).ToList();

        Assert.IsTrue(result.SellerPrices.All(x => x.Brand == "Fazenda Dez"), "Todos os produtos devem ter a marca filtrada");
        Assert.AreEqual(result.SellerPrices.Count(), prices.Count, "Não retornou a quantidade de preços esperada");

        var resultPrices = result.SellerPrices.Select(x => x.Price).OrderBy(x => x).ToList();
        var dataPrices = prices.Select(x => x.Price).OrderBy(x => x).ToList();

        Assert.IsTrue(resultPrices.SequenceEqual(dataPrices), "Os preços retornados não são os esperados");
    }

    //[TestMethod()]
    public void GetProductSellersWithPricesShouldReturnOnlyPricesNotIgnored()
    {
        var uow = _serviceProvider.GetService<IUnitOfWork>()!;
        var domain = _serviceProvider.GetService<IProductSellerDomain>()!;

        var testData = GenerateTestData(uow, 9205, true);

        var macaData = testData.Products.FirstOrDefault(x => x.Name == "Maçã" && x.Brand == "Fazenda XV");

        var request = new FiltersRequest()
        {
            CompanyId = 1,
            ProductIds = [macaData.Id],
            StartDate = DateTime.Now.Date.AddDays(-1),
            EndDate = DateTime.Now.Date,
            Take = 3,
            OrderBy = "Price ASC"
        };

        var result = domain.GetProductSellersWithPrices(request).Result;

        var products = testData.Products.Where(x => request.ProductIds.Contains(x.Id)).ToList();
        var sellers = testData.Sellers.Where(x => products.Select(m => m.Id).Contains(x.ProductId)).ToList();
        var prices = testData.Prices.Where(x => sellers.Select(m => m.Id).Contains(x.ProductSellerId)).OrderBy(x => x.Price).Skip(1).Take(3).ToList();

        Assert.AreEqual(result.SellerPrices.Count(), prices.Count, "Não retornou a quantidade de preços esperada");

        var resultPrices = result.SellerPrices.Select(x => x.Price).OrderBy(x => x).ToList();
        var dataPrices = prices.Select(x => x.Price).OrderBy(x => x).ToList();

        Assert.IsTrue(resultPrices.SequenceEqual(dataPrices), "Os preços retornados não são os esperados");
    }

    //[TestMethod()]
    public void GetProductSellersWithPricesShouldReturnPricesFilteredByDate()
    {
        var uow = _serviceProvider.GetService<IUnitOfWork>()!;
        var domain = _serviceProvider.GetService<IProductSellerDomain>()!;

        var testData = GenerateTestData(uow, 9206);

        var macaData = testData.Products.FirstOrDefault(x => x.Name == "Maçã" && x.Brand == "Fazenda XV");

        var request = new FiltersRequest()
        {
            CompanyId = 1,
            StartDate = DateTime.Now.AddDays(-1).Date,
            EndDate = DateTime.Now.AddDays(-1).Date,
            ProductIds = [macaData.Id],
            Take = 10
        };

        var result = domain.GetProductSellersWithPrices(request).Result;

        var products = testData.Products.Where(x => request.ProductIds.Contains(x.Id)).ToList();
        var sellers = testData.Sellers.Where(x => products.Select(m => m.Id).Contains(x.ProductId)).ToList();
        var prices = testData.Prices.Where(x => sellers.Select(m => m.Id).Contains(x.ProductSellerId) && x.CollectedDate.Date < DateTime.Now.Date).ToList();

        Assert.AreEqual(result.SellerPrices.Count(), prices.Count, "Não retornou a quantidade de preços esperada");
        Assert.IsFalse(result.SellerPrices.Any(x => x.Date.Date == DateTime.Now.Date), "Retornou preços indevidos");
    }
}