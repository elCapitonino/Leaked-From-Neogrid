﻿using DI.Repository.Attributes;
using DI.Repository.Contexts;
using DI.Repository.Entities;
using DI.Repository.Interfaces.Repositories;
using DI.Repository.Repositories.Base;
using Microsoft.EntityFrameworkCore;

namespace DI.Repository.Repositories
{
    [UseSQLContext]
    public sealed class CompanyDataRepository : SqlGenericNoModifyRepository<EnterprisePriceProjectionEntity>, ICompanyDataRepository
    {
        public CompanyDataRepository(SqlContext dbContext) : base(dbContext)
        {

        }

        public async Task<string> GetCompanyName(long CompanyId)
        {
            var query = $"SELECT NomeRazaoSocial FROM Empresa WHERE idEmpresa = {CompanyId}";

            string nomeRazaoSocial = null;

            await using (var command = _dbContext.Database.GetDbConnection().CreateCommand())
            {
                command.CommandText = query;

                await _dbContext.Database.OpenConnectionAsync();

                await using (var resultReader = await command.ExecuteReaderAsync())
                {
                    if (await resultReader.ReadAsync())
                    {
                        nomeRazaoSocial = resultReader.GetString(0);
                    }
                }
            }

            return nomeRazaoSocial;
        }
    }
}
