﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DI.Repository.Migrations.PostgreMigrations
{
    /// <inheritdoc />
    public partial class AddedNotProjectedCollumnsAndRemovedMargin : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Margin",
                table: "MonthlyProjectionData",
                newName: "RevenueNotProjected");

            migrationBuilder.AddColumn<decimal>(
                name: "DemandNotProjected",
                table: "MonthlyProjectionData",
                type: "numeric",
                nullable: false,
                defaultValue: 0m);

            migrationBuilder.AddColumn<decimal>(
                name: "ProfitNotProjected",
                table: "MonthlyProjectionData",
                type: "numeric",
                nullable: false,
                defaultValue: 0m);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "DemandNotProjected",
                table: "MonthlyProjectionData");

            migrationBuilder.DropColumn(
                name: "ProfitNotProjected",
                table: "MonthlyProjectionData");

            migrationBuilder.RenameColumn(
                name: "RevenueNotProjected",
                table: "MonthlyProjectionData",
                newName: "Margin");
        }
    }
}
