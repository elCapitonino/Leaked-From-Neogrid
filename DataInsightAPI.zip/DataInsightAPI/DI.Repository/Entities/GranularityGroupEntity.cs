﻿using DI.Repository.Enum;

namespace DI.Repository.Entities
{
    public sealed class GranularityGroupEntity : BaseEntity
    {
        public long CompanyId { get; set; }

        public EGranularityType GranularityType { get; set; }

        public string? Description { get; set; }

        public ICollection<GranularityLevelEntity>? GranularityLevels { get; set; }
    }
}
