using AutoMapper;
using Domain.IndexGenerator.DataSourceDomains.Interfaces;
using Domain.IndexGenerator.Models;
using Domain.Status;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using MongoDB.Bson;
using MongoDB.Driver;
using Repository.Entity;
using Repository.Enums;
using Repository.UnitOfWork;
using System.Diagnostics;

namespace Domain.IndexGenerator.DataSourceDomains
{
    public class IndexGeneratorHorusDomain : IndexGeneratorBase, IIndexGeneratorHorusDomain
    {
        private readonly ILogger<IndexGeneratorHorusDomain> _logger;
        private readonly IUnitOfWork _uow;
        private readonly IMapper _mapper;
        private readonly IStatusDomain _statusDomain;

        public IndexGeneratorHorusDomain(ILogger<IndexGeneratorHorusDomain> logger, IUnitOfWork uow, IMapper mapper, IStatusDomain statusDomain)
            : base(statusDomain)
        {
            _logger = logger;
            _uow = uow;
            _mapper = mapper;
            _statusDomain = statusDomain;
            
        }
        public async Task GenerateIndexAsync(HorusMonitoringRequest monitoringRequest)
        {
            try
            {
                _logger.LogInformation("Iniciando Geração de index da Horus, companyId: {CompanyId}", monitoringRequest.CompanyId);
                var total = monitoringRequest.MonitoringItems.Count();
                var count = 0;
                UpdateStatus(monitoringRequest.TaskId, CrawlerSourceType.Horus, MonitoringItemResultsStatusType.Running, total, count);
                Stopwatch totalStopwatch = new Stopwatch();
                totalStopwatch.Start();
                _logger.LogInformation("Horus - Total de monitoring items para serem processados: {total}", total);
                _logger.LogDebug("Horus - Request: {@monitoringRequest}", Newtonsoft.Json.JsonConvert.SerializeObject(monitoringRequest));
                List<ObjectId> listUpdateHash = new List<ObjectId>();

                EnsureAllMonitoringItemId(monitoringRequest.MonitoringItems);

                foreach (var monitoringItem in monitoringRequest.MonitoringItems)
                {
                    try
                    {
                        if (!monitoringItem.Eans.Any())
                        {
                            _logger.LogWarning("Monitoring Item {MonitoringItemId} Horus sem EAN", monitoringItem.MonitoringItemId);
                            continue;
                        }

                        var query = _uow.HorusProducts.GetAll()
                        .Where(x => x.Date >= monitoringRequest.StartDate && x.Date <= monitoringRequest.EndDate && monitoringItem.Eans.Contains(x.Ean));

                        if (monitoringRequest.Cnpjs.Any())
                            query = query.Where(x => monitoringRequest.Cnpjs.Contains(x.Cnpj));

                        if (monitoringRequest.Cities.Any())
                            query = query.Where(x => monitoringRequest.Cities.Contains(x.City));

                        if (monitoringRequest.States.Any())
                            query = query.Where(x => monitoringRequest.States.Contains(x.Uf));

                        if (monitoringRequest.StoreType.Any())
                            query = query.Where(x => monitoringRequest.StoreType.Contains(x.FormatMarket));

                        var products = await query
                            .Select(x => new
                            {
                                x.Id,
                                x.Ean,
                                x.Hash,
                                x.Category,
                                x.Cnpj,
                                Seller = x.Brand,
                                Brand = x.ProductBrand,
                                x.City,
                                UF = x.Uf,
                            }).ToListAsync();

                        listUpdateHash.AddRange(products.Where(x => string.IsNullOrEmpty(x.Hash)).Select(x => x.Id));

                        var entities = products.GroupBy(x => $"{GetOrGenerateHash(x.Hash, $"{x.Ean}|{x.Cnpj}")}{x.Seller}{x.City}{x.UF}{x.Category}{x.Brand}")
                            .Select(x => x.First())
                            .Select(x => new MonitoringItemResultsEntity()
                            {
                                Brand = x.Brand,
                                Category = x.Category,
                                Hash = GetOrGenerateHash(x.Hash, $"{x.Ean}|{x.Cnpj}"),
                                CompanyId = monitoringRequest.CompanyId,
                                CrawlerId = monitoringRequest.CrawlerId,
                                MonitoringItemId = monitoringItem.MonitoringItemId,
                                Seller = x.Seller,
                                State = x.UF,
                            }).ToList();

                        _uow.MonitoringItemResults.AddRange(entities, true);
                        count++;
                        UpdateStatus(monitoringRequest.TaskId, CrawlerSourceType.Horus, MonitoringItemResultsStatusType.Running, monitoringRequest.MonitoringItems.Count(), count);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, $"Error Search Monitoring Item {monitoringItem.MonitoringItemId} Horus");
                        UpdateStatus(monitoringRequest.TaskId, CrawlerSourceType.Horus, MonitoringItemResultsStatusType.Error, monitoringRequest.MonitoringItems.Count(), count);
                    }
                }
                if (monitoringRequest.MonitoringResultIdsDelete != null && monitoringRequest.MonitoringResultIdsDelete.Any())
                {
                    _uow.MonitoringItemResults.DeleteAll(monitoringRequest.MonitoringResultIdsDelete);
                }

                if (listUpdateHash.Any())
                {
                    var productsToUpdate = _uow.HorusProducts
                              .GetAll()
                              .Where(x => listUpdateHash.Contains(x.Id))
                              .ToList();

                    foreach (var product in productsToUpdate)
                    {
                        product.Hash = CalculateSHA256($"{product.Ean}|{product.Cnpj}");
                    }

                    _uow.HorusProducts.Update(productsToUpdate, true);
                }

                totalStopwatch.Stop();
                _logger.LogInformation($"Finalizado Geração de index da Horus - {totalStopwatch.Elapsed.TotalSeconds}s");
                UpdateStatus(monitoringRequest.TaskId, CrawlerSourceType.Horus, MonitoringItemResultsStatusType.Finished, total, count);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error {MethodName}", nameof(GenerateIndexAsync));
                throw;
            }
        }

      

        public async Task GenerateIndexAtacadoAsync(HorusMonitoringRequest monitoringRequest)
        {
            try
            {
                _logger.LogInformation($"Iniciando Geração de index da Horus Atacado");
                var total = monitoringRequest.MonitoringItems.Count();
                var count = 1;
                UpdateStatus(monitoringRequest.TaskId, CrawlerSourceType.Horus, MonitoringItemResultsStatusType.Running, total, 0);
                Stopwatch totalStopwatch = new Stopwatch();
                totalStopwatch.Start();
                List<ObjectId> listUpdateHash = new List<ObjectId>();

                _logger.LogInformation("Horus Atacado - Total de monitoring items para serem processados: {total}", total);

                _logger.LogDebug("Horus - Request: {@monitoringRequest}", Newtonsoft.Json.JsonConvert.SerializeObject(monitoringRequest));

                EnsureAllMonitoringItemId(monitoringRequest.MonitoringItems);

                foreach (var monitoringItem in monitoringRequest.MonitoringItems)
                {
                    try
                    {
                        if (!monitoringItem.Eans.Any())
                            continue;

                        var query = _uow.HorusProducts.GetAll()
                            .Where(x => monitoringRequest.StartDate <= x.Date && x.Date <= monitoringRequest.EndDate && monitoringItem.Eans.Contains(x.Ean) && x.FormatMarket == "Atacadista");

                        if (monitoringRequest.Cnpjs.Any())
                            query = query.Where(x => monitoringRequest.Cnpjs.Contains(x.Cnpj));

                        if (monitoringRequest.Cities.Any())
                            query = query.Where(x => monitoringRequest.Cities.Contains(x.City));

                        if (monitoringRequest.States.Any())
                            query = query.Where(x => monitoringRequest.States.Contains(x.Uf));

                        if (monitoringRequest.StoreType.Any())
                            query = query.Where(x => monitoringRequest.StoreType.Contains(x.FormatMarket));

                        var products = await query
                            .Select(x => new
                            {
                                x.Id,
                                x.Ean,
                                x.Hash,
                                x.Category,
                                x.Cnpj,
                                Seller = x.Brand,
                                Brand = x.ProductBrand,
                                x.City,
                                UF = x.Uf,
                            }).ToListAsync();

                        listUpdateHash.AddRange(products.Where(x => string.IsNullOrEmpty(x.Hash)).Select(x => x.Id));
                        
                        var entities = products.GroupBy(x => $"{GetOrGenerateHash(x.Hash, $"{x.Ean}|{x.Cnpj}")}{x.Seller}{x.City}{x.UF}{x.Category}{x.Brand}")
                            .Select(x => x.First())
                            .Select(x => new MonitoringItemResultsEntity()
                            {
                                Brand = x.Brand,
                                Category = x.Category,
                                Hash = GetOrGenerateHash(x.Hash, $"{x.Ean}|{x.Cnpj}"),
                                CompanyId = monitoringRequest.CompanyId,
                                CrawlerId = monitoringRequest.CrawlerId,
                                MonitoringItemId = monitoringItem.MonitoringItemId,
                                Seller = x.Seller,
                                State = x.UF,
                            }).ToList();

                        _uow.MonitoringItemResults.AddRange(entities, true);
                        UpdateStatus(monitoringRequest.TaskId, CrawlerSourceType.Horus, MonitoringItemResultsStatusType.Running, monitoringRequest.MonitoringItems.Count(), count);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, $"Error Search Monitoring Item {monitoringItem.MonitoringItemId} Horus Atacado");
                        UpdateStatus(monitoringRequest.TaskId, CrawlerSourceType.Horus, MonitoringItemResultsStatusType.Error, monitoringRequest.MonitoringItems.Count(), count);
                    }
                    count++;
                }
                if (monitoringRequest.MonitoringResultIdsDelete != null && monitoringRequest.MonitoringResultIdsDelete.Any())
                {
                    _uow.MonitoringItemResults.DeleteAll(monitoringRequest.MonitoringResultIdsDelete);
                }

                if (listUpdateHash.Any())
                {
                    var productsToUpdate = _uow.HorusProducts
                              .GetAll()
                              .Where(x => listUpdateHash.Contains(x.Id))
                              .ToList();

                    foreach (var product in productsToUpdate)
                    {
                        product.Hash = CalculateSHA256($"{product.Ean}|{product.Cnpj}");
                    }

                    _uow.HorusProducts.Update(productsToUpdate, true);
                }

                totalStopwatch.Stop();
                _logger.LogInformation($"Finalizado Geração de index da Horus Atacado - {totalStopwatch.Elapsed.TotalSeconds}s");
                UpdateStatus(monitoringRequest.TaskId, CrawlerSourceType.Horus, MonitoringItemResultsStatusType.Finished, total, --count);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error {MethodName}", nameof(GenerateIndexAtacadoAsync));
                throw;
            }
        }
    }
}
