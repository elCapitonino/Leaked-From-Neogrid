﻿using AutoMapper;
using Domain.Models;
using Repository.Entity;

namespace Domain.Filters
{
    public class FilterProfile : Profile
    {
        public FilterProfile()
        {
            CreateMap<EnterprisePriceGroups_DefaultFilterEntity, DefaultFilterResponse>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.EnterprisePriceGroups_DefaultFilterId))
                .ForMember(dest => dest.ParentId, opt => opt.MapFrom(src => src.IdParent))
                .ForMember(dest => dest.Description, opt => opt.MapFrom(src => src.FieldName))
                .ForMember(dest => dest.Values, opt => opt.MapFrom(src => src.Values));
            CreateMap<EnterprisePriceGroups_DefaultFilterValueEntity, DefaultFilterValueResponse>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.IdEnterprisePriceGroups_DefaultFilterValue))
                .ForMember(dest => dest.ParentId, opt => opt.MapFrom(src => src.IdParent))
                .ForMember(dest => dest.Description, opt => opt.MapFrom(src => string.IsNullOrWhiteSpace(src.Description) ? src.Value : src.Description))
                .ForMember(dest => dest.Value, opt => opt.MapFrom(src => src.Value));
        }
    }
}
