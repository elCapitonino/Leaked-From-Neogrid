﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using MongoDB.EntityFrameworkCore.Extensions;
using Repository.Attributes;
using Repository.DbContexts;
using Repository.Entity;

namespace Repository.TypeConfiguration
{
    [DbContextTypeConfiguration(typeof(ScantechSupermaxiDbContext))]
    public class ScantechSupermaxiTypeConfiguration : TypeConfigurationBase<ScantechSupermaxiEntity>, IEntityTypeConfiguration<ScantechSupermaxiEntity>
    {
        public override void Configure(EntityTypeBuilder<ScantechSupermaxiEntity> builder)
        {
            builder.ToTable("Supermaxi").ToCollection("Supermaxi");
        }
    }
}