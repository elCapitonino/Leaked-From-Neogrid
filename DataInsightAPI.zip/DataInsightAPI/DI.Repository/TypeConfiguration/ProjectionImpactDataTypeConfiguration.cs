﻿using DI.Repository.Attributes;
using DI.Repository.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DI.Repository.TypeConfiguration
{
    [UsePostgreContext]
    public sealed class ProjectionImpactDataTypeConfiguration : TypeConfigurationBase<ProjectionImpactDataEntity>, IEntityTypeConfiguration<ProjectionImpactDataEntity>
    {
        public override void Configure(EntityTypeBuilder<ProjectionImpactDataEntity> builder)
        {
            ConfigureTableName(builder, "ProjectionImpactData");
            builder.HasKey(x => x.Id);
            builder.Property(x => x.Id).ValueGeneratedOnAdd().HasDefaultValueSql("uuid_generate_v4()").IsRequired();
            builder.Property(x => x.ProductId).HasMaxLength(512);
            builder.Property(x => x.PriceGroupId).IsRequired();
            builder.Property(x => x.PriceProjectionId).IsRequired();
            builder.Property(x => x.Affiliate).HasMaxLength(128);

            builder.HasOne(x => x.GranularityGroup).WithMany().HasForeignKey(x => x.GranularityGroupId);

        }
    }
}
