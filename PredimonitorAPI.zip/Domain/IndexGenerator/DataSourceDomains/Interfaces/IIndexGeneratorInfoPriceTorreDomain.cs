﻿using Domain.IndexGenerator.Models;

namespace Domain.IndexGenerator.DataSourceDomains.Interfaces
{
    public interface IIndexGeneratorInfoPriceTorreDomain
    {
        Task GenerateIndexInfoPriceTorreAsync(long companyId, int crawlerId, IEnumerable<MonitoringItemTags> monitoringItems, DateTime startDate, DateTime endDate, Guid? taskId, List<long> monitoringResultIdsDelete);
    }
}
