﻿namespace DI.Domain.ImpactGraph.Models
{
    public class AdoptionGraphResponseModel
    {
        public AdoptionGraphResponseModel()
        {
            Categories = [];
            Adoptions = new GraphDataModel();
            NotAdoptions = new GraphDataModel();
            PricingCount = new GraphDataModel();
            Royalties = new GraphDataModel();
            Goal = new GraphDataModel();
        }

        public List<GraphCategoryModel> Categories { get; set; }
        public GraphDataModel Adoptions { get; set; }
        public GraphDataModel NotAdoptions { get; set; }
        public GraphDataModel PricingCount { get; set; }
        public GraphDataModel Royalties { get; set; }
        public GraphDataModel Goal { get; set; }
    }
}
