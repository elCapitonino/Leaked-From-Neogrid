<template>
  <div>
    <label class="label-comboBox">
      <slot name="title">{{ title }}</slot>
    </label>
    <v-text-field dense outlined hide-details v-bind="$attrs" class="mt-1">
    </v-text-field>
  </div>
</template>

<script>
export default {
  props: {
    title: {
      type: String,
    },
  },
  data() {
    return {};
  },
};
</script>