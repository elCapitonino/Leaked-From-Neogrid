﻿using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Primitives;

namespace DI.API.Utils.Cache
{
    public class CacheService : ICacheService
    {
        private readonly IMemoryCache _memoryCache;
        private static CancellationTokenSource _resetCacheToken = new CancellationTokenSource();

        public CacheService(IMemoryCache memoryCache)
        {
            _memoryCache = memoryCache;
        }

        public void ClearAll()
        {
            HandleClearAll();
        }

        private static void HandleClearAll()
        {
            _resetCacheToken.Cancel();
            _resetCacheToken.Dispose();
            _resetCacheToken = new CancellationTokenSource();
        }

        public void Set<TItem>(object key, TItem value, MemoryCacheEntryOptions? options = null)
        {
            if (options == null)
            {
                options = new MemoryCacheEntryOptions()
                        .SetSlidingExpiration(TimeSpan.FromMinutes(5))
                        .SetAbsoluteExpiration(TimeSpan.FromHours(1))
                        .SetPriority(CacheItemPriority.Low);
            }

            options.AddExpirationToken(new CancellationChangeToken(_resetCacheToken.Token));
            _memoryCache.Set(key, value, options);
        }

        public TItem Get<TItem>(object key)
        {
            return _memoryCache.TryGetValue(key, out TItem value) ? value : default;
        }

        public void Remove(object key)
        {
            _memoryCache.Remove(key);
        }
    }
}
