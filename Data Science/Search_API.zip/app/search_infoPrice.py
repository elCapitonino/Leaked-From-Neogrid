from models.search_v3_models import SearchProductsPredmonitorBM25
from predimonitor_type import *
from async_mongo import AsyncMongoConnect
from logger import logger

class Search_infoPrice():
    
    def __init__(self):
        self.dbMongo = AsyncMongoConnect()


    async def search_get_V1(self, products):
        full_result = []
        result_list = []

        cnpjs = None
        if (products.idcrawlers_offline is not None):
            cnpjs = [obj.cnpj for obj in products.idcrawlers_offline]
            cnpjs = list(filter(lambda x: x is not None and x !=
                          '' and x.strip() != '', cnpjs))

        eans = []
        start_date = products.start_date
        end_date = products.end_date
        if products is None or products.products[0].ean is None or not products.products[0].ean:
            return []

        for product in products.products:
            eans.append(product.ean)

        for ean in eans:
            try:
                result = await self.dbMongo.get_products_InfoPrice(start_date, end_date, ean, cnpjs)

                for documento in result:

                    item = documento["documento"]
                    result_list.append({'id': str(item['_id']),
                                        'id_crawler': 319,
                                        "product_name": item['descricao'],
                                        "product_link": str(item['_id']),
                                        "product_ean": item['gtin_formated'],
                                        "site_sku": 0,
                                        "source": "Info Price São João",
                                        "language": "pt-br",
                                        "product_brand": item['rede'],
                                        "id_product_normalized": None,
                                        "trash_score": 0,
                                        "crawler_date": item["data_preco"],
                                        "sellers": [
                                            {
                                                "seller_name": item["loja"],
                                                "prices":[{
                                                    'price': str(item['preco_pago']),
                                                    "price_currency": "BRL"
                                                }]
                                            }
                                        ],
                                        "product_local": {
                                            'state': item['uf'],
                                            'city': item['cidade']
                                            },
                                        "product_manufacture_year": None,
                                        "product_used_hours": None
                                    })

                full_result.append({
                    "name": products.products[0].name,
                    "results": result_list
                })

            except Exception as ex:
                print(" ------ Erro dados Info price  ------")
                print(str(ex))

        return full_result
    
    async def search_get_V2(self, products: SearchProductsPredmonitorBM25):
        full_result = []
        result_list = []

        cnpjs = None
        if (products.idcrawlers_offline is not None):
            cnpjs = [obj.cnpj for obj in products.idcrawlers_offline]
            cnpjs = list(filter(lambda x: x is not None and x !=
                          '' and x.strip() != '', cnpjs))
            
        start_date = products.start_date
        end_date = products.end_date

        t_produtos = products.filters.products
        t_eans = products.filters.eans
        t_brand = products.filters.brands
        t_categories = products.filters.categories
        t_sellers = products.filters.sellers

        # Crie um dicionário para armazenar os registros pelos nomes
        mapeamento = {objeto.description: objeto.ean for objeto in t_eans}


        eans = []
        # Agora, você pode acessar os registros usando os nomes da lista
        for p in t_produtos:
            ean = mapeamento.get(p, None)  # Use get() para lidar com nomes ausentes
            if ean is not None:
                eans.append(ean)

        try:
            for ean in eans:
                result_list = []
                result = await self.dbMongo.get_products_InfoPrice_v2(start_date, end_date, ean, cnpjs, t_brand, t_categories, t_sellers)

                for documento in result:
                    item = documento
                    try:
                        name = item['descricao']
                        result_list.append({
                            'id': str(item['_id']),
                            'id_crawler': 319,
                            "product_name": name,
                            "product_link": str(item['_id']),
                            "product_ean": item['gtin_formated'],
                            "site_sku": 0,
                            "source": "Info Price São João",
                            "language": "pt-br",
                            "product_brand": item['rede'],
                            "id_product_normalized": None,
                            "trash_score": 0,
                            "crawler_date": item["data_preco"],
                            "seller_name": item["loja"],
                            "format_market": None,
                            "coordinates": {
                                "longitude": item['longitude'],
                                "latitude": item['latitude'],
                            },
                            "prices": [
                                {
                                    'price': str(item['preco_pago'])
                                }
                            ],
                            "product_local":
                            {
                                'state': item['uf'],
                                'city': item['cidade']
                            },
                            "product_manufacture_year": None,
                            "product_used_hours": None
                        })
                        
                    except Exception as ex:
                        print(" ------ Erro dados Info price  ------")
                        print(str(ex))

                full_result.append({
                    "product": ean,
                    "result": result_list
                })

        except Exception as ex:
            print(" ------ Erro dados Info price  ------")
            print(str(ex))

        return full_result